/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)67       1.79  src/avs/fs/mmfs/ts/kernext/gpl-linux/tracelin.c, mmfs, avs_rfks0, rfks01416c 3/10/14 10:58:07 */

/**************************************************************************
 *
 * Loadable kernel module that implements the trace device. 
 *
 **************************************************************************/


#ifndef GPFS_PRINTF

#ifndef __KERNEL__
#  define __KERNEL__
#endif

#ifndef KBUILD_MODNAME
#define KBUILD_MODNAME tracedev
#endif

/* If trace is built into kernel, pick up GPFS flag definitions from a file
   rather than requiring them to be defined on the command line. */
#ifndef MODULE
/* #include <linux/ktrace.h> */
#endif

#include <Shark-gpl.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/string.h>

#if LINUX_KERNEL_VERSION > 2060900
#include <linux/hardirq.h>
#else
#include <asm/hardirq.h>
#endif
#include <asm/uaccess.h> /* copy_to/from_user */


#include <stdarg.h>
#include <Trace.h>
#include <lxtrace.h>
#include <verdep.h>
#include <cxiAtomic.h>

#define ROUNDUP(X,Y) ( (Y) * ( ((X)+(Y)-1) / (Y) ) )

extern int rl_trc_write(const char *bufP, size_t nBytes, int nb);
extern int rl_init(void);
extern void rl_cleanup(void);
extern void rl_trc_stop(void);
extern TraceRecord_t* kAssignSharedBufferSpace(int bytesNeeded);
spinlock_t seqLock;
volatile unsigned long long TraceSeq;

/* Lock that guards the list of retired segments for overwrite mode */
spinlock_t SegmentAllocLock;

#if LINUX_KERNEL_VERSION > 2060900 || \
  defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_X86_64)
#define EXPORTKDUMPDEV
#endif

#ifdef EXPORTKDUMPDEV
static int major_kdump = -1;
#endif

#if defined(MODULE)
MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION ("GPFS portability layer (tracing module)");
MODULE_AUTHOR ("IBM <gpfs@us.ibm.com>");
#if (LINUX_KERNEL_VERSION >= 2060500)
MODULE_INFO (supported, "external");
#endif
#endif /* MODULE */

/* If trace is built into kernel, then this is a dummy module */
#ifndef KTRACE

/* Global variables exported from the trace module.  Put this on a cache
   line by itself to avoid false sharing of these words that are read
   almost-always. */
TraceGBLS_t KTrace __attribute__ ((aligned(CACHE_LINE_SIZE))) =
  { TRACE_NONE, 0, NULL, 0 };

/* the daemon's task structure (for signal) */
static struct task_struct *TrcDaemonTaskP;

/* TrcReadLock serializes trace operations, as well as most other access
 * to the trace header element.
 */
static struct semaphore TrcReadLock;

/* Anchor for the trace state */
trcdev_anchor_t TrcAnchor;

/* Export pointers to internal data structures for debugging */
struct
{
  trcdev_anchor_t   *TrcAnchorP;
  struct semaphore  *TrcReadLockP;
} TraceVarAddrs = { &TrcAnchor, &TrcReadLock };

/* A trace record passed from a user thread consists of a data header
   followed by the marshalled arguments */
struct trcRec
{
  OverwriteHdr_t oHdr;
  trc_datahdr_t dHdr;
  char data[LXTRACE_MAX_DATA-sizeof(trc_datahdr_t) - sizeof(OverwriteHdr_t)];
};


/* Get the current clock cycle count. Duplicated in ktrcalls.c */
static inline UInt64 __readCycleCounter()
{
#if defined(GPFS_ARCH_X86_64)
  UInt32 low, high;
  __asm__ __volatile__("rdtsc" : "=a" (low), "=d" (high));
  return (low | ((UInt64)(high) << 32));
#elif defined(GPFS_ARCH_PPC64) 
  UInt64 val;
  __asm__ __volatile__("mftb %0" : "=r" (val));
  return val;
#elif defined(GPFS_ARCH_S390X)
  UInt64 val;
  __asm__ __volatile__("stck 0(%1)" : "=m" (val) : "a" (&val) : "cc");
  return val;
#else
  #error "Can't get CPU count for this linux architecture"
#endif
}
/* rdtscll is defined in various other places in the kernel,
   so use a different name here only to quiet compiler warning. */
#define rdtscall(val) \
  ((val) = __readCycleCounter())


/* Prepare the memory just allocated for the shared overwrite
   trace buffer.  Called with isCompleteInit true the first time
   after the buffer is created.  Called with isCompleteInit false
   when the buffer is going from state TRACE_OVERWRITE_QUIESCED or
   TRACE_OVERWRITE_FROZEN to state TRACE_OVERWRITE.  In this latter
   case, there may be daemon threads attempting to append to streams, so
   we should not clear the stream offsets. */
static void initializeSharedTraceBuffer(Boolean isCompleteInit)
{
  SharedTraceBufferHeader_t* trbP;
  TraceSegmentHdr_t* segP;
  UInt64 nextOffset;
  UInt32 nextIdx, prevIdx;
  int i;
#if defined(GPFS_ARCH_PPC64)
  extern unsigned long tb_ticks_per_sec;
#endif

  /* Clear buffer to all 0 before first use */
  if (isCompleteInit)
    memset(KTrace.tBufferBaseP, 0, KTrace.tBufferSize);

  /* Fill in constant fields only before first use */
  trbP = (SharedTraceBufferHeader_t*)KTrace.tBufferBaseP;
  if (isCompleteInit)
  {
    trbP->trbMagic = OVERWRITE_MAGIC;
    trbP->trbSize = KTrace.tBufferSize;
    /* init trbTotalSegmentsDumped later */
    trbP->trbNStreams = N_KERNEL_TRACE_STREAMS + N_DAEMON_TRACE_STREAMS;
    /* init trbNSegments later */

    /* Record offsets of stream descriptors and of buffer segments */
    trbP->trbStreamOffset = OFFSET_OF(trbStream, SharedTraceBufferHeader_t);
    trbP->trbSegmentOffset = OFFSET_OF(trbSegSpace, SharedTraceBufferHeader_t);

#if defined(GPFS_ARCH_X86_64) && LINUX_KERNEL_VERSION >= 2062200
    if (tsc_khz > 10000 && tsc_khz < 100000000)
      trbP->trbOSTimerRatePerSecond = tsc_khz * 1000uLL;
    else
      trbP->trbOSTimerRatePerSecond = 0;
#elif defined(GPFS_ARCH_PPC64)
    trbP->trbOSTimerRatePerSecond = tb_ticks_per_sec;
#else
    trbP->trbOSTimerRatePerSecond = 0;
#endif

#if 0
    printk("sizes: TraceBufferSegment_t %lu SharedTraceBufferHeader_t %lu\n",
           sizeof(TraceBufferSegment_t), sizeof(SharedTraceBufferHeader_t));
    printk("  TraceSegmentHdr_t %lu TrStreamDesc_t %lu\n",
           sizeof(TraceSegmentHdr_t), sizeof(TrStreamDesc_t));
#endif

    /* Initialize all stream headers */
    for (i=0; i<TOTAL_STREAMS; i++)
    {
      trbP->trbStream[i].stMagic = TRC_STREAM_MAGIC;
      trbP->trbStream[i].stStreamIndex = i;
    }
  }  /* end of initialization done only once */

  /* Place timestamp and corresponding cycle count into the header of
     the shared trace buffer */
  do_gettimeofday(&trbP->trbStartTOD);
  rdtscall(trbP->trbStartTimeStamp);

  /* Clear daemon start trace time */
  trbP->trbDaemonStartTimeStamp = 0;
  trbP->trbDaemonStartTOD.tv_sec = 0;
  trbP->trbDaemonStartTOD.tv_usec = 0;

  /* Clear quiesce time */
  trbP->trbQuiesceTimeStamp = 0;
  trbP->trbQuiesceTOD.tv_sec = 0;
  trbP->trbQuiesceTOD.tv_usec = 0;

  /* Clear earliest time at which all streams contain data */
  trbP->trbAllStreamsHaveDataTimeStamp = 0;

  /* Make all streams looks as if their buffer segments are full, with
     no segments assigned.  The first append attempt for each stream
     will therefore go through the code that acquires a new segment.
     Since the spin lock is held, this attempt to get a new segment will
     not interfere with the initialization that follows. */
  spin_lock(&SegmentAllocLock);
  for (i=0; i<TOTAL_STREAMS; i++)
  {
    trbP->trbStream[i].stSegmentAndOffset =
      IDX_AND_OFFSET_2_TRCWORD(NO_TRC_SEGMENT, TRACE_BUFFER_SEGMENT_BYTES);

    /* Clear all other stream header fields to zero */
    trbP->trbStream[i].stSegmentAllocs = 0;
    trbP->trbStream[i].stNSegmentAlreadyAlloc = 0;
    trbP->trbStream[i].stNSegmentsDumped = 0;
  }

  /* Initialize other fields in the header of the shared trace buffer */
  trbP->trbTotalSegmentsDumped = 0;
  trbP->trbNGetSegmentIoctls = 0;

  /* Build the list of free buffer segments.  Make these look like
     retired segments to avoid a special case for initial allocations. */
  nextOffset = sizeof(SharedTraceBufferHeader_t);
  nextIdx = 0;
  prevIdx = NO_TRC_SEGMENT;
  trbP->trbYoungestRetiredIdx = nextIdx;
  trbP->trbNSegments = 0;
  while (nextOffset+TRACE_BUFFER_SEGMENT_BYTES <= KTrace.tBufferSize)
  {
    segP = &trbP->trbSegSpace[nextIdx].segHdr;
    segP->segMagic = TRC_SEGMENT_MAGIC;
    segP->segThisIndex = nextIdx;
    segP->segStream = NO_TRACE_STREAM;
    segP->segYoungerRetiredIdx = prevIdx;
    segP->segStreamOlderIdx = NO_TRC_SEGMENT;
    segP->segStreamOlderTimestamp = 0;
    rdtscall(segP->segTimestamp);
    segP->segFillerTimestamp = segP->segTimestamp;
    trbP->trbOldestRetiredIdx = nextIdx;
    prevIdx = nextIdx;
    nextIdx += 1;
    nextOffset += TRACE_BUFFER_SEGMENT_BYTES;
    trbP->trbNSegments += 1;
  }
  spin_unlock(&SegmentAllocLock);
  EXPORT_FENCE;
}


static void setTraceState(trcdev_state_t newState)
{
  TrcAnchor.state = newState;
}


//free allocated buffer pages
static void free_buf(void* buf)
{
  vfree(buf);
}

static void *alloc_buf(unsigned long size)
{
  void *mem;

  mem = vmalloc(size);
  return mem;
}


/* Construct the static trace header element ("TrcAnchor").
 * trc_open will allocate buffers and set the appropriate values. */
static void trc_init()
{
  sema_init(&TrcReadLock, 1);

  /* Note:  Locks are not needed here.  There better not be any other
     threads trying to access TrcAnchor at this point.  If there were, then
     what would happen if a thread tried to acquire the locks a few
     instructions earlier, before we initialized the locks? */

  TrcAnchor.major = 0; /* dynamic assignment (by register_chrdev in trc_register) */
  TrcAnchor.minor = 0;
  TrcAnchor.nOpens = 0;
  spin_lock_init(&seqLock);
  TraceSeq = 0;
  TrcDaemonTaskP = NULL;
  TrcAnchor.state = TrcStateInitialized;
  spin_lock_init(&SegmentAllocLock);
}

/* Destroy the static trace header element (TrcAnchor) */
static void trc_term()
{
  /* Note: Locks are not needed here.  We're about to re-initialize, so
     if anyone is still using TrcAnchor at this point, we would clobber them. */

  if (KTrace.tBufferBaseP != NULL)
  {
    free_buf(KTrace.tBufferBaseP);
    KTrace.tBufferBaseP = NULL;
    printk("Unloading trace module; freeing shared GPFS trace buffer\n");
    KTrace.tBufferSize = 0;
  }

  /* (re)initialize all fields.  Rather than copy all the stuff that happens
   * in trc_init, we can use it here to reset all the fields. */
  trc_init();
}

#ifdef EXPORTKDUMPDEV

/* On ia64, kdump_read can read backtrace for every thread and copy back to user */
static ssize_t kdump_read(struct file *fileP, char *bufP, size_t nBytes,
                          loff_t *ppos)
{
  int rc= -EINVAL;
  unsigned long kaddr = (unsigned long)*ppos;

#if (defined(GPFS_ARCH_X86_64) && LINUX_KERNEL_VERSION >= 2061600 \
    && (defined(SUSE_LINUX)|| defined(REDHAT_AS_LINUX) \
        || defined(FEDORA_LINUX) || defined(DEBIAN_LINUX))) || \
    (defined(GPFS_ARCH_PPC64) && LINUX_KERNEL_VERSION >= 2061100)
  /* rw_verify_area does not allow kernel addr range,
     so a read() will fail with EINVAL.
     We subtracted the base kernel addr in kdump.c and add back in here. */
  unsigned long highBits = GPFS_KERNEL_OFFSET;
#else
  unsigned long highBits = 0;
#endif


  kaddr += highBits;

#if (defined(GPFS_ARCH_X86_64) && LINUX_KERNEL_VERSION >= 2061800 \
     && defined(REDHAT_AS_LINUX))
 
  /* Since RHEL 5, definition of macro __pa(x) has been changed. 
   * #define __pa(x)                 ((unsigned long)(x) - PAGE_OFFSET)
   * This definition is ok for i386 where kernel text/data is part of lineraly
   * mapped region. But that is not case with x86_64 where 40 MB
   * (ffffffff80000000 - ffffffff82800000) virtual address space has been fixed
   * for kernel text mapping assuming kernel load address is phy 0.
   * Therefore address need to be readjust accordingly
   */

  kaddr = (kaddr >= __START_KERNEL_map) ? 
          (kaddr -__START_KERNEL_map + PAGE_OFFSET) : kaddr ;
#endif

#if (! defined(GPFS_ARCH_PPC64))
  /* on ppc64, virt_addr_valid only can check kernel address belongs to directly
   * mapping part (PAGE_OFFSET - HIGH_MEMORY), it consider adress in vm area as
   * in-valid
   */
  if (virt_addr_valid(kaddr))
#endif
    if (copy_to_user(bufP, (void *)((unsigned long)*ppos + highBits), nBytes)==0)
      rc=nBytes;
  return((ssize_t)rc);
}

static int kdump_open(struct inode *inodeP, struct file *fileP)
{
   try_module_get(THIS_MODULE);
   fileP->f_pos=0;
   return 0;
}

static int kdump_close(struct inode *inodeP, struct file *fileP)
{
   module_put(THIS_MODULE);
   return 0;
}

static loff_t kdump_lseek(struct file *fileP, loff_t offset, int orgin)
{
   loff_t rc;

   if (orgin != 0)
      return(-EAGAIN);

   fileP->f_pos = offset;

   return(offset);
}
#endif

/* The device open operation.  The first open is initiated by the trace daemon,
 * and comes after registration.  It results in the allocation of the trace
 * buffers, and identifying the trace daemon (so it can be signalled when
 * buffers are ready to be read).  */
static int trc_open(struct inode *inodeP, struct file *fileP)
{
  int rc = 0;

  /* Serialize multiple opens and prevent state changes */
  down(&TrcReadLock);
  /* Only the daemon opens the device O_RDWR, and only does so when turning
   * trace on.
   */
  if ((fileP->f_flags & O_ACCMODE) == O_RDWR)
  {
     if (TrcAnchor.state != TrcStateInitialized)
     {
       /* For the shared trace buffer, multiple processes must open the
          trace device RDWR so they can mmap it into userspace */
       rc = 0;
       try_module_get(THIS_MODULE);
       TrcAnchor.nOpens += 1;
       goto exit;
     }

    /* The first open (lxtrace on) requires initialization of the header. */
    TrcAnchor.minor = MINOR(inodeP->i_rdev);

    /* Only supporting one such device */
    if (TrcAnchor.minor > 0)
    {
      rc = -ENODEV;
      goto exit;
    }

    setTraceState(TrcStateOpened);

    /* Since threads that handle VM page-outs also do traces, set flag so
       that we will not get blocked waiting to allocate pages.  Otherwise a
       deadlock could occur if the page-out thread was waiting for us to
       empty the trace buffer, and we are waiting for the page-out thread
       to free some pages. */
    current->flags |= PF_MEMALLOC;
  }

  /* Applications must open the trace device O_WRONLY.  These opens do not
   * require any processing.  If the daemon has turned tracing on, the open
   * is allowed and subsequent write() calls will be handled.  If the daemon
   * has NOT turned tracing on, the application open will be granted, but
   * subsequent write() calls will NOOP
   * until the daemon turns trace on. */

  else if ((fileP->f_flags & O_ACCMODE) != O_WRONLY)
  {
    /* After "trace on", subsequent trace control commands open O_RDONLY.  */
    /* This test is backwards; returns EALREADY if trace is OFF */
    if (TrcAnchor.state != TrcStateActiveKernelBuffer &&
        TrcAnchor.state != TrcStateActiveSharedBuffer)
    {
      rc = -EALREADY;
      goto exit;
    }
  }

  TrcAnchor.nOpens += 1;

  try_module_get(THIS_MODULE);

exit:
  up(&TrcReadLock);
  return rc;
}

static void my_send_sig_info(int mySig, struct siginfo * sigData,
                             struct task_struct *taskP)
{
   struct task_struct *g, *tsP;
#if defined(HAS_TASKLIST_LOCK)
   TASK_READ_LOCK;
   do_each_thread(g,tsP)
   {
     if (tsP == taskP)
     {
       send_sig_info(mySig, sigData, tsP);
       break;
     }
   } while_each_thread(g,tsP);
   TASK_READ_UNLOCK;
#else
   rcu_read_lock();
   if (taskP == NULL)
   {
     printk("ERROR: attempt to send signal to uninitialized pid.\n");
     rcu_read_unlock();
     return;
   }
   tsP = FIND_TASK_BY_PID(taskP->pid);
   if (tsP == NULL)
   {
      rcu_read_unlock();
      return;
   }
   if (tsP->pid == taskP->pid)
     send_sig_info(mySig, sigData, tsP);
   rcu_read_unlock();
#endif
}

static ssize_t
trc_write(struct file *fileP, const char *bufP, size_t nBytes, loff_t *posP)
{
  struct trcRec tr;
  int rc;

  /* A special value of nBytes == 0 means the caller only wants to
     find out whether tracing is enabled. */
  if (nBytes == 0 && (TrcAnchor.state != TrcStateActiveKernelBuffer))
    return -EBADF;

  /* Copy trace record from user address space */
  if (nBytes < 4 || nBytes > LXTRACE_MAX_DATA)
    return -EINVAL;
  if (copy_from_user(&tr, bufP, nBytes))
    return -EFAULT;

  if (KTrace.tMode == TRACE_BLOCKING)
    rl_trc_write((const char *)&tr.dHdr, nBytes, 0);
  return nBytes;
}

/* Before close, a sync of the trace device will flush the records
 * still in the read buffer (even though it might not be full).  A
 * close without this call could result in the loss of these records.
 */
static int
/* struct file *fP, struct dentry *dP, loff_t start, loff_t end, int datasync */
trc_fsync_internal(FILE_OPS_FSYNC_PARAMETERS)
{
  return 0;
  /* This only ever flushed the old-style trace buffers.  It needs to be
     connected to relay trace buffers. */
}


/* The externally visible version of trc_fsync_internal */
int trc_fsync()
{
  TRC_FSYNC_IMPLEMENTATION();
}

/* The device close operation. */
static int trc_close(struct inode *inodeP, struct file *fileP)
{
  down(&TrcReadLock);

  /* The trace daemon only closes the device upon termination. */
  if (TrcDaemonTaskP && TrcDaemonTaskP->tgid == current->tgid)
  {
    //the trace daemon can not handle SIGKILL
    //trace must be stoppped here 
    rl_trc_stop();
    /* The final trace daemon close.  Reset for subsequent use. */
    setTraceState(TrcStateInitialized);

    TrcDaemonTaskP = NULL;
    current->flags &= ~PF_MEMALLOC;
    TraceSeq = 0;
  }

  TrcAnchor.nOpens -= 1;

  module_put(THIS_MODULE);

  up(&TrcReadLock);
  return 0;
}

static void terminateOldDaemon()
{
  struct siginfo sigData;
  sigData.si_signo = SIGTERM;
  sigData.si_errno = 0;
  sigData.si_code  = SI_KERNEL;
  my_send_sig_info(SIGTERM, &sigData, TrcDaemonTaskP);
}


/* Internal function to assign a new buffer segment to the given stream */
int getBufferSegmentInternal(int trStreamIdx)
{
  SharedTraceBufferHeader_t* trbP;
  TrStreamDesc_t* streamP;
  TraceSegmentHdr_t* retiringSegP;
  TraceSegmentHdr_t* youngestRetiredSegP;
  TraceSegmentHdr_t* oldestRetiredSegP;
  TraceSegmentHdr_t* newSegP;
  TrcSegmentIdxAndOffset_t segIdxAndOffset;
  UInt32 retiringSegmentIdx;
  UInt32 oldestRetiredSegmentIdx;
  UInt32 newSegmentIdx;
  UInt32 currentSegmentIdx;
  UInt32 relSegmentOffset;
  int rc = 0;

  /* Get pointers to relevant data structures */
  trbP = (SharedTraceBufferHeader_t*)KTrace.tBufferBaseP;
  streamP = &trbP->trbStream[trStreamIdx];

  /* Lock the list of retired segments */
  spin_lock(&SegmentAllocLock);

  /* If there is no shared trace buffer, return a code that will cause
     the caller to return the address of a dummy trace record.  This
     should only happen during transitions when trace is being disabled. */
  if (KTrace.tBufferBaseP == NULL)
  {
    rc = ENOMEM;
    goto exit;
  }

  /* If the kernel trace state is anything other than TRACE_OVERWRITE,
     return a code that will cause the caller to return the address of a
     dummy trace record.  This is most likely to happen after the trace
     mode set has been set to TRACE_OVERWRITE_QUIESCED by lxtrace off
     or to TRACE_OVERWRITE_FROZEN by an assert or signal. */
  if (KTrace.tMode != TRACE_OVERWRITE)
  {
    rc = EBUSY;
    goto exit;
  }

  /* If the current segment for the indicated stream actually does
     have space, say because this function was recently called by a
     concurrent thread, return without changing anything */
  trbP->trbNGetSegmentIoctls += 1;
  segIdxAndOffset = streamP->stSegmentAndOffset;
  currentSegmentIdx = TRCWORD_2_INDEX(segIdxAndOffset);
  relSegmentOffset = TRCWORD_2_OFFSET(segIdxAndOffset);

  if (currentSegmentIdx != NO_TRC_SEGMENT  &&
      relSegmentOffset <= TRACE_BUFFER_SEGMENT_BYTES-MIN_TRACE_RECORD)
  {
    streamP->stNSegmentAlreadyAlloc += 1;
    goto exit;
  }

  /* Locate the segment just filled by this stream.  It is possible for
     retiringSegmentIdx to be NO_TRC_SEGMENT.  It is an error to access
     *retiringSegP in this case. */
  retiringSegmentIdx = currentSegmentIdx;

  /* Remove the oldest retired segment from the list of retired
     segments.  Since the size of the shared trace buffer is constrained
     to be sufficiently large, the list of retired segments can never be
     empty. */
  oldestRetiredSegmentIdx = trbP->trbOldestRetiredIdx;
  oldestRetiredSegP = &trbP->trbSegSpace[oldestRetiredSegmentIdx].segHdr;
  trbP->trbOldestRetiredIdx = oldestRetiredSegP->segYoungerRetiredIdx;

  /* Initialize the segment just removed from the retired list.  In
     a few lines, it will become the active segment for the current
     stream. */
  newSegmentIdx = oldestRetiredSegmentIdx;
  newSegP = oldestRetiredSegP;
  newSegP->segStream = trStreamIdx;
  newSegP->segYoungerRetiredIdx = NO_TRC_SEGMENT;
  if (retiringSegmentIdx == NO_TRC_SEGMENT)
  {
    newSegP->segStreamOlderIdx = NO_TRC_SEGMENT;
    newSegP->segStreamOlderTimestamp = 0;
  }
  else
  {
    retiringSegP = &trbP->trbSegSpace[retiringSegmentIdx].segHdr;
    newSegP->segStreamOlderIdx = retiringSegmentIdx;
    newSegP->segStreamOlderTimestamp = retiringSegP->segTimestamp;
  }
  rdtscall(newSegP->segTimestamp);
  newSegP->segFillerTimestamp = 0;

  /* If there is one, add the segment just filled by this stream to the
     LRU end of the list of retired segments */
  if (retiringSegmentIdx != NO_TRC_SEGMENT)
  {
    youngestRetiredSegP = &trbP->trbSegSpace[trbP->trbYoungestRetiredIdx].segHdr;
    youngestRetiredSegP->segYoungerRetiredIdx = retiringSegmentIdx;
    /* The segYoungerRetiredIdx back pointer in *retiringSegP was set
       to NO_TRC_SEGMENT when that segment first became active */
    trbP->trbYoungestRetiredIdx = retiringSegmentIdx;
  }

  /* Assign the recycled segment to the caller's stream.  Pack the
     buffer segment index and the initial offset in that segment into
     a single word so both values can be changed atomically. */
  streamP->stSegmentAndOffset =
    IDX_AND_OFFSET_2_TRCWORD(newSegmentIdx, sizeof(TraceSegmentHdr_t));

  /* Increment count of segments assigned to this stream */
  streamP->stSegmentAllocs += 1;

  /* Unlock the list of retired segments and return */
exit:
  spin_unlock(&SegmentAllocLock);
  return rc;
}


/* ioctl op used to for low-level access to trace operation. */
static long trc_ioctl_internal(struct file *fileP,
                               unsigned int op, unsigned long kx_args)
{
  int h, rc = 0;
  Boolean readLockHeld = false;
  struct kArgs args_cp;
  struct kArgs *args = (struct kArgs *)kx_args;
  char *p;
  struct siginfo sigData;
  int waitCount = 0;
  struct trcRec tr;
  int buffSize;
  int newMode;
  int oldMode;
  SharedTraceBufferHeader_t* trbP;
  TraceSegmentHdr_t* segP;
  TraceRecord_t* recP;
  TrcSegmentIdxAndOffset_t segIdxAndOffset;
  UInt32 currentSegmentIndex;
  UInt32 relOffset;
  Int64 daemonTrcBufSize;
  Int64 minBufferSize;
  UInt64 oTime;
  int i;
  struct cxiMemoryMapping_t
  {
    char *vaddr;        /* daemon address mapping */
    char *kvaddr;       /* kernel address of memory area (shared segment only) */
    int kBytes;         /* size of the area in kilobytes */
    int vindex;         /* index in shared segment mapping array */
    cxiXmem_t xmemDesc; /* cross-memory descriptor */
  };

  char *localTrcBufferP;
  int *tmpPtr;
  int tscSpeed = -1;

  if ((op != TrAppendPrivateBuffer) && (op != TrAppendSharedBuffer))
  {
    down(&TrcReadLock);
    readLockHeld = true;
  }

  switch (op)
  {
    case TrQueryKernelTraceMode:
      if (copy_from_user(&args_cp, args, sizeof(args_cp)))
      {
        rc = -EFAULT;
        break;
      }
      if (copy_to_user((int *)args_cp.arg1, &KTrace.tMode,
                       sizeof(KTrace.tMode)))
      {
        rc = -EFAULT;
        break;
      }
      break;

    case TrStartBlockingTrace:
      if (TrcAnchor.state == TrcStateActiveKernelBuffer)
      {
        rc = -EALREADY;
        break;
      }
      if (TrcAnchor.state != TrcStateOpened)
      {
        rc = -EBADF;
        break;
      }
      setTraceState(TrcStateActiveKernelBuffer);
      KTrace.tMode = TRACE_BLOCKING;
      EXPORT_FENCE;
      break;

    case TrStartOverwriteTrace:
      if (TrcAnchor.state != TrcStateActiveSharedBuffer)
      {
        rc = -EBADF;
        break;
      }
      KTrace.tMode = TRACE_OVERWRITE;
      EXPORT_FENCE;
      break;

    case TrStopTrace:
      if (TrcAnchor.state == TrcStateActiveSharedBuffer)
      {
        /* For blocking mode, we set the state to 'stopped' then
           when the lxtrace daemon exits we set it to 'initialized'
           so tracing can be restarted correctly. Just set it to initialized
           immediately for overwrite mode. */
        setTraceState(TrcStateInitialized);
      }
      else if (TrcAnchor.state == TrcStateActiveKernelBuffer)
      {
        setTraceState(TrcStateStopped);
        up(&TrcReadLock);
        readLockHeld = false;
        trc_fsync();
      }
      else
        rc = -EBADF;

      /* Signal the daemon to terminate. */
      sigData.si_signo = SIGTERM;
      sigData.si_errno = 0;
      sigData.si_code  = SI_KERNEL;
      my_send_sig_info(SIGTERM, &sigData, TrcDaemonTaskP);

      /* Wait for lxtrace to terminate, but don't wait forever.  At this
         point the signal has been delivered to lxtrace, but it may
         take some time for the process to exit.  Since TrcAnchor.state
         is changed from TrcStateStopped to TrcStateInitialized in
         trc_close(), which is called when lxtrace exits, if we return
         control to the caller right away, there'd be a window when
         tracing has ostensibly been stopped, and it should be OK to
         start tracing again, but trying to do so would fail with
         EALREADY in trc_open because TrcAnchor.state is not what the
         code expects.  So we give lxtrace some time to terminate.
         Something could go seriously wrong, and lxtrace may get stuck,
         so we don't wait forever. */
      while (TrcAnchor.state == TrcStateStopped && waitCount++ < 10)
      {
        current->state = TASK_INTERRUPTIBLE;
        schedule_timeout(100);
      }
      break;

    case TrRecycleTrace:
      if (TrcAnchor.state != TrcStateActiveKernelBuffer  &&
          TrcAnchor.state != TrcStateActiveSharedBuffer)
        rc = -EBADF;
      else
      {
        /* Signal the daemon to recycle. */
        sigData.si_signo = SIGIO;
        sigData.si_errno = 0;
        sigData.si_code  = SI_KERNEL;
        my_send_sig_info(SIGIO, &sigData, TrcDaemonTaskP);
      }
      break;

    case TrQuerySharedBufferSize:
      if (copy_from_user(&args_cp, args, sizeof(args_cp)))
      {
        rc = -EFAULT;
        break;
      }
      if (copy_to_user((Int64 *)args_cp.arg1, &KTrace.tBufferSize,
                    sizeof(Int64)))
      {
        rc = -EFAULT;
        break;
      }
      break;

    case TrDeallocateSharedBuffer:
      /* Called via kxFreeSharedTraceMemory.  Make sure no kernel threads will
         access the buffer about to be freed. */
      KTrace.tMode = TRACE_NONE;
      EXPORT_FENCE;
      if (KTrace.tBufferBaseP == NULL)
      {
        /* Buffer already freed.  Ignore second attempt. */
        break;
      }

      /* Wait for one second for running threads to notice the new trace
         mode */
      current->state = TASK_UNINTERRUPTIBLE;
      schedule_timeout(HZ);

      /* Free the shared trace buffer */
      printk("Freeing shared GPFS trace buffer\n");
      localTrcBufferP = KTrace.tBufferBaseP;
      KTrace.tBufferBaseP = NULL;
      free_buf(localTrcBufferP);
      KTrace.tBufferSize = 0;
      break;

    case TrRegisterTraceDaemon:
    /* Save pointer to the daemon task information */
      TrcDaemonTaskP = current;
      break;

    case TrAllocateSharedBuffer:
      if (copy_from_user(&args_cp, args, sizeof(args_cp)))
      {
        printk("Invalid argument to TrAllocateSharedBuffer; bad parm address 0x%lX\n",
               (long unsigned int)args);
        rc = -EFAULT;
        break;
      }
      if (KTrace.tBufferBaseP != NULL)
      {
        printk("The GPFS trace buffer is already allocated\n");
        setTraceState(TrcStateActiveSharedBuffer);
        break;
      }
      if (copy_from_user(&daemonTrcBufSize, (Int64 *)args_cp.arg1, sizeof(Int64)))
      {
        printk("Invalid argument to TrAllocateSharedBuffer; bad size address 0x%lX\n",
               (long)args_cp.arg1);
        rc = -EFAULT;
        break;
      }

      /* Make the shared buffer large enough to ensure that there will
         always be at least two buffer segments on the list of retired
         segments */
      minBufferSize =
        sizeof(SharedTraceBufferHeader_t) +
        (TOTAL_STREAMS+2)*TRACE_BUFFER_SEGMENT_BYTES;
      if (daemonTrcBufSize < minBufferSize)
        daemonTrcBufSize = minBufferSize;

      KTrace.tBufferSize = ROUNDUP(daemonTrcBufSize, PAGE_SIZE);
      KTrace.tBufferBaseP = (char *) alloc_buf(KTrace.tBufferSize);
      if (KTrace.tBufferBaseP == NULL)
      {
        printk("Memory allocation for shared GPFS trace buffer failed\n");
        rc = -EFAULT;
        break;
      }
      printk("Allocated shared GPFS trace buffer at 0x%lX\n",
             (long)KTrace.tBufferBaseP);

      initializeSharedTraceBuffer(true);

      if (TrcAnchor.state == TrcStateActiveKernelBuffer &&
          TrcDaemonTaskP != NULL)
      {
        /* If we had previously been running in blocking mode
           kill the old lxtrace daemon if necessary */
        terminateOldDaemon();
        TrcDaemonTaskP = NULL;
      }
      setTraceState(TrcStateActiveSharedBuffer);
      break;

    case TrAppendPrivateBuffer:
      if (KTrace.tMode != TRACE_BLOCKING)
      {
        rc = -EBADF;
        break;
      }
      //used for performance reason, provide same functionality as trc_write
      if (copy_from_user(&args_cp, args, sizeof(args_cp)))
      {
        rc = -EFAULT;
        break;
      }

      /* Copy trace record from user address space */
      if (args_cp.arg1 < 4 || args_cp.arg1 > LXTRACE_MAX_DATA)
      {
        rc = -EINVAL;
        break;
      }
      if (copy_from_user(&tr, (char *)args_cp.arg2, args_cp.arg1))
      {
        rc = -EFAULT;
        break;
      }
      if (TrcAnchor.state == TrcStateActiveSharedBuffer)
      {
        rc = -EINVAL;
        break;
      }
      else
      {
        /* In blocking mode, make sure we don't try to pass the
           OverwriteHdr_t along. */
        buffSize = args_cp.arg1 - sizeof(OverwriteHdr_t);
      }
      rl_trc_write((const char *)&tr.dHdr, buffSize, 0);
      rc = buffSize;
      break;

    case TrAppendSharedBuffer:
      if (KTrace.tMode != TRACE_OVERWRITE)
      {
        rc = -EBADF;
        break;
      }
      if (TrcAnchor.state != TrcStateActiveSharedBuffer)
      {
        rc = -EINVAL;
        break;
      }
      if (copy_from_user(&args_cp, args, sizeof(args_cp)))
      {
        rc = -EFAULT;
        break;
      }
      if (args_cp.arg1 < HDRSIZE || args_cp.arg1 > LXTRACE_MAX_DATA)
      {
        rc = -EINVAL;
        break;
      }
      recP = kAssignSharedBufferSpace(args_cp.arg1);
      oTime = recP->oHdr.oTime;
      if (copy_from_user((char *)recP, (char *)args_cp.arg2, args_cp.arg1))
      {
        rc = -EFAULT;
        break;
      }
      recP->oHdr.oTime = oTime;
      recP->oHdr.oProcess = current->pid;
      break;

    case TrGetBufferSegment:
      /* The argument passed in is actually the stream number */
      rc = getBufferSegmentInternal((int)(long)args);
      break;

    case TrSetKernelTraceMode:
      if (copy_from_user(&args_cp, args, sizeof(args_cp)))
      {
        rc = -EFAULT;
        break;
      }
      newMode = args_cp.arg1;

      /* Validate new mode */
      switch (newMode)
      {
        case TRACE_NONE:
          if (KTrace.tBufferBaseP != NULL)
          {
            rc = -EINVAL;
            goto setModeError;
          }
          break;

        case TRACE_OVERWRITE_QUIESCED:
        case TRACE_OVERWRITE_FROZEN:
          if (KTrace.tBufferBaseP == NULL  ||
              (KTrace.tMode != TRACE_OVERWRITE  &&
               KTrace.tMode != TRACE_OVERWRITE_QUIESCED &&
               KTrace.tMode != TRACE_OVERWRITE_FROZEN))
          {
            rc = -EINVAL;
            goto setModeError;
          }
          break;

        case TRACE_OVERWRITE:
          /* Trace mode cannot be set to OVERWRITE unless the overwrite
             trace buffer has already been allocated and blocking trace is
             not avtive */
          if (KTrace.tBufferBaseP == NULL  ||
              KTrace.tMode == TRACE_BLOCKING  ||
              KTrace.tMode == TRACE_BLOCKING_QUIESCED)
          {
            rc = -EINVAL;
            goto setModeError;
          }

          /* Reinitialize the shared trace buffer */
          if (KTrace.tMode == TRACE_OVERWRITE_QUIESCED  ||
              KTrace.tMode == TRACE_OVERWRITE_FROZEN)
            initializeSharedTraceBuffer(false);
          break;

        case TRACE_BLOCKING:
        case TRACE_BLOCKING_QUIESCED:
          if (KTrace.tMode != TRACE_NONE  &&
              KTrace.tMode != TRACE_BLOCKING  &&
              KTrace.tMode != TRACE_BLOCKING_QUIESCED)
          {
            rc = -EINVAL;
            goto setModeError;
          }
          break;

        default:
          rc = -EINVAL;
          break;
      }

      /* Save the new mode, which will immediately affect trace calls */
      oldMode = KTrace.tMode;
      KTrace.tMode = newMode;
      EXPORT_FENCE;

      /* If overwrite tracing was just quiesced or frozen, make the
         active buffer segments of all streams be full.  If daemon code
         continues to try to append to those segments, it will attempt
         to allocate new segments via TrGetBufferSegment.  That code
         will return an error because mode is TRACE_OVERWRITE_QUIESCED
         or TRACE_OVERWRITE_FROZEN.  The net effect is that once
         overwrite tracing is quiesced, the contents of the shared trace
         buffer will remain effectively unchanged while it is being
         dumped to disk.

         The code here to fill active segments with a filler record
         strongly resembles similar code in kAssignSharedBufferSpace. */
      if ((newMode == TRACE_OVERWRITE_QUIESCED ||
           newMode == TRACE_OVERWRITE_FROZEN)  &&
          oldMode != TRACE_OVERWRITE_QUIESCED  &&
          oldMode != TRACE_OVERWRITE_FROZEN)
      {
        /* Timestamp end-of-trace.  By default, the formatted trace
           report will not contain any traces beyond this time. */
        trbP = (SharedTraceBufferHeader_t*)KTrace.tBufferBaseP;
        do_gettimeofday(&trbP->trbQuiesceTOD);
        rdtscall(trbP->trbQuiesceTimeStamp);

        /* Mark all trace streams as having filled their active segment.
           Use ATOMIC_ADDLP on platforms where it is available to tracedev. */
        for (i=0; i<TOTAL_STREAMS; i++)
        {
#ifdef GPFS_ARCH_X86_64
          segIdxAndOffset = ATOMIC_ADDLP(&trbP->trbStream[i].stSegmentAndOffset,
                                         TRACE_BUFFER_SEGMENT_BYTES);
          currentSegmentIndex = TRCWORD_2_INDEX(segIdxAndOffset);
          relOffset = TRCWORD_2_OFFSET(segIdxAndOffset);
#else
          segIdxAndOffset = trbP->trbStream[i].stSegmentAndOffset;
          for (;;)
          {
            UInt32 newOffset;
            TrcSegmentIdxAndOffset_t newSegIdxAndOffset;
            Boolean csSuccess;

            /* Calculate what the new offset would be after the increment */
            currentSegmentIndex = TRCWORD_2_INDEX(segIdxAndOffset);
            relOffset = TRCWORD_2_OFFSET(segIdxAndOffset);
            newOffset = relOffset + TRACE_BUFFER_SEGMENT_BYTES;
            newSegIdxAndOffset =
              IDX_AND_OFFSET_2_TRCWORD(currentSegmentIndex, newOffset);

            /* Attempt the offset increment */
            csSuccess = ATOMIC_SWAP64((atomic_p)&trbP->trbStream[i].stSegmentAndOffset,
                                      &segIdxAndOffset, newSegIdxAndOffset);
            if (csSuccess)
              break;
          }
#endif

          segP = &trbP->trbSegSpace[currentSegmentIndex].segHdr;
          recP = (TraceRecord_t*) ((char*)segP + relOffset);
          if (relOffset <= TRACE_BUFFER_SEGMENT_BYTES-MIN_TRACE_RECORD)
          {
            rdtscall(recP->oHdr.oTime);
            segP->segFillerTimestamp = recP->oHdr.oTime;
            recP->oHdr.oMagic = LXTRACE_OVERWRITE_MAGIC;
            recP->oHdr.oLength = TRACE_BUFFER_SEGMENT_BYTES - relOffset;
            recP->oHdr.oProcess = current->pid;
            recP->dHdr.trHook = LXTRACE_FILLER;
            recP->dHdr.trNArgs = 0;
            recP->dHdr.trSPos = _TR_FORMAT_I;
            recP->dHdr.trSLen = 0;
          }
        }
      }
      break;

setModeError:
      break;

    case TrAckDaemonOverwriteTracing:
      /* Error if there is no overwrite buffer */
      if (KTrace.tBufferBaseP == NULL)
      {
        rc = EINVAL;
        break;
      }

      /* Add a timestamp to the overwrite trace buffer of when tracing was
         actually enabled in daemon code */
      trbP = (SharedTraceBufferHeader_t*)KTrace.tBufferBaseP;
      do_gettimeofday(&trbP->trbDaemonStartTOD);
      rdtscall(trbP->trbDaemonStartTimeStamp);
      rc = 0;
      break;

    default:
      rc = -EINVAL;
      break;
  }

  if (readLockHeld)
    up(&TrcReadLock);

  return rc;
}

int trc_mmap(struct file *file, struct vm_area_struct *vma)
{
  /* Maps the trace buffer that was vmalloc'ed by ioctl
     TrAllocateSharedBuffer to userspace (either for the daemon or for
     lxtrace).  Userspace will call mmap and this function handles that
     mapping. */
  Int64 mmapLength = vma->vm_end - vma->vm_start;
  unsigned long pfn, start = vma->vm_start;
  int rc;
  char *ptrP  = (char *)KTrace.tBufferBaseP;
  if (KTrace.tBufferBaseP == NULL)
    return -ENOMEM;
  if (TrcAnchor.state != TrcStateActiveSharedBuffer)
  {
    printk("Attempt to mmap GPFS trace buffer when not in overwrite mode\n");
    return -ENOMEM;
  }
  /* This shouldn't ever happen, but just in case things get out of sync */
  if (KTrace.tBufferSize != mmapLength)
    {
      printk("mmapLength %d, KTrace.tBufferSize %lld. Mismatch, mmap fails\n",
             (int)mmapLength, KTrace.tBufferSize);
      return -EINVAL;
    }
  for (mmapLength; mmapLength > 0; mmapLength -= PAGE_SIZE)
  {
    pfn = vmalloc_to_pfn(ptrP);
#ifdef GPFS_ARCH_S390X
    rc = remap_pfn_range(vma, start, pfn, PAGE_SIZE, PAGE_KERNEL);
#else
    rc = remap_pfn_range(vma, start, pfn, PAGE_SIZE, PAGE_SHARED);
#endif
    if (rc < 0)
    {
      printk("Error in trc_mmap, remap_pfn_range rc %d\n", rc);
      return rc;
    }
    start += PAGE_SIZE;
    ptrP += PAGE_SIZE;
  }
  vma->vm_flags |= VM_RESERVED;
  return 0;
}


#ifdef HAVE_UNLOCKED_IOCTL
static long trc_unlocked_ioctl(struct file *fileP, unsigned int op,
                                 unsigned long kx_args)
{
  return trc_ioctl_internal(fileP, op, kx_args);
}
#endif
static int trc_ioctl(struct inode *inodeP, struct file *fileP,
                     unsigned int op, unsigned long kx_args)
{
  return trc_ioctl_internal(fileP, op, kx_args);
}

static struct file_operations trc_ops =
{
  llseek:     NULL,
  write:      trc_write, /* Trace points write to the device */
#ifdef HAS_READDIR
  readdir:    NULL,
#endif
  poll:       NULL,
#ifdef HAVE_UNLOCKED_IOCTL
  unlocked_ioctl: trc_unlocked_ioctl,
#else
  ioctl:      trc_ioctl, /* control op to change buffering or dump state */
#endif
  mmap:       trc_mmap,  /* Maps the kernel space trace buffer to user space */
  open:       trc_open,  /* Prepare the device for tracing */
  flush:      NULL,
  release:    trc_close, /* Terminate tracing and close the device */
  fsync:      trc_fsync_internal, /* Sync all buffered data to the daemon */
  fasync:     NULL,
  lock:       NULL,
};

#ifdef EXPORTKDUMPDEV
static struct file_operations kdump_ops =
{
  llseek:     kdump_lseek,
  read:       kdump_read,  /* read op allows the daemon to retrieve records */
  write:      NULL, /* Trace points write to the device */
#ifdef HAS_READDIR
  readdir:    NULL,
#endif
  poll:       NULL,
  mmap:       NULL,
  open:       kdump_open,  /* Prepare the device for tracing */
  flush:      NULL,
  release:    kdump_close, /* Terminate tracing and close the device */
  fsync:      NULL, /* Sync all buffered data to the daemon */
  fasync:     NULL,
  lock:       NULL,
};
#endif
/* Register the trace device "/dev/trace" and save the major number in 
 * the header 
 */
static int trc_register()
{
  int major = register_chrdev(0, "trace", &trc_ops);
  if (major < 0)
    return major;
  TrcAnchor.major = major;
#ifdef EXPORTKDUMPDEV
  major_kdump = register_chrdev(0, "kdump", &kdump_ops);
#endif
  return 0;
}

/* Unregister the trace device */
static void trc_unregister()
{
  unregister_chrdev(TrcAnchor.major, "trace");
  TrcAnchor.major = 0;
#ifdef EXPORTKDUMPDEV
  if (major_kdump >= 0)
     unregister_chrdev(major_kdump, "kdump");
  major_kdump = 0;
#endif

}

/* Module initialization */
static int __init myModuleInit(void)
{
  int rc;
  trc_init();

  rc = rl_init();
  if (rc < 0)
    return rc;

  return trc_register();
}

static void __exit myModuleExit(void)
{
  rl_cleanup();
  trc_unregister();
  trc_term();
}

module_init(myModuleInit);
module_exit(myModuleExit);

#endif /* KTRACE */
#endif /* GPFS_PRINTF */
