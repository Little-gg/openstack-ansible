/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
static char sccsid[] = "@(#)45	1.13  src/avs/fs/mmfs/ts/kernext/gpl-linux/mmfsmod.c, mmfs, avs_rfks0, rfks01416c 6/4/10 09:40:18";

/* A file shipped with the portability layer that is
 * compiled and linked with the mmfs module (non portability
 * layer).   Used so that struct module can be included and 
 * compiled according to the customer's kernel configuration.
 * The mmfs module is not dependent on anything else in the 
 * kernel except for this struct module silliness.
 */
#if !defined(GPL_KBUILD)
#define KBUILD_MODNAME mmfs
#include <modpost.c>
#else
#include <linux/module.h>
#endif
/* mmfs module initialization for 2.6 */

#ifdef MODULE
MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION ("GPFS Kernel Module");
MODULE_AUTHOR ("IBM <gpfs@us.ibm.com>");
#if (LINUX_KERNEL_VERSION >= 2060500)
MODULE_INFO(supported, "external");
#endif
#endif

