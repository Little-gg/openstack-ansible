/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)61	1.160  src/avs/fs/mmfs/ts/kernext/ibm-linux/cxiSharedSeg-plat.h, mmfs, avs_rfks0, rfks01416c 10/30/13 13:23:01 */

#ifndef _h_cxiSharedSeg_plat
#define _h_cxiSharedSeg_plat

#ifndef _h_cxiSharedSeg
#error Platform header (XXX-plat.h) should not be included directly
#endif

#include <cxiSystem.h>
#include <gpfs.h>

#define SHARED_SEGMENT_BASE (UIntPtr(SharedSegmentBase))
EXTERN char* SharedSegmentBase;

/* Globals for daemon using swizzled pointers with the shared segment */
EXTERNC int initPtrSwizzling(Boolean initKernel);

EXTERN char * SharedSegmentKernelBase;
EXTERN char * SharedSegmentKernelMax;
EXTERN Ptrdiff SharedSegmentOffset;
EXTERN IntPtr SharedSegmentSwizzledSize;
EXTERN char * SharedSegmentSwizzledBase;
EXTERN char * SharedSegmentSwizzledMax;
EXTERN unsigned long SSegUserMin;
EXTERN unsigned long SSegUserMax;

/* ioctl ops */
enum kxOps
{
  RegisterMMFSDaemon                  = 1,
  // reserved for FIGETBSZ            = 2,
  ThreadInitOrTerm                    = 3,
  SignalOrBroadcastCondvar            = 4,
  GetCondWaiters                      = 5,
  WaitCondvar                         = 6,
  InitKernelMailboxes                 = 7,
  EnableIO                            = 8,
  TerminateMailboxes                  = 9,
  StackAddrToThreadID                 = 10,
  kernelTrace                         = 11,
  GetDiskInfo                         = 12,
  RegisterMMFSSessionId               = 13,
  kernelRecLockReset                  = 14,
  SetCommState                        = 15,
  AcquireMutex                        = 16,
  ReleaseMutex                        = 17,
  RegisterNodeAddr                    = 18,
  InitializeRevokeTab                 = 19,
  RegisterObjType                     = 20,
  SetTraceLevel                       = 21,
  kxtraceit                           = 22,
  kPoll                               = 23,
  GetLocalSGIdCounter                 = 24,
#ifdef GPFS_CACHE
  PcacheCtl                           = 25,
#endif
  AwaitAsyncIOCompletion              = 26,
  LocalIO                             = 27,
  GetSimpleLock                       = 28,
  MapPrivate                          = 29,
  SetMountInfoByID                    = 30,
  FreeMailboxStorage                  = 31,
  RegisterMMFSSeg                     = 32,
#ifdef SMB_LOCKS
  BreakOplock                         = 33,
#endif
  GetStructSize                       = 34,
  GetMapCount                         = 35,
  DefineShSeg                         = 36,
  SetPrivLevel                        = 37,
  kernelSendFlock                     = 38,
  kernelWaitForFlock                  = 39,
  kernelCommonReclock                 = 40,
  kernelDoTraceDump                   = 41,
  SetNPagesAvailable                  = 42,
  CoreDump                            = 43,
  kernelDisableSyncRetry              = 44,
  kernelEnableSyncRetry               = 45,
  ClearMountInfo                      = 46,
  RetryRecover                        = 47,
  TerminateAsyncIO                    = 48,
  kernelRLRevokeLock                  = 49,
  kernelRLRevokeUnLock                = 50,
  SetPageoutThread                    = 51,
  ClearPageoutThread                  = 52,
  Fattr                               = 53,
  FsAttr                              = 54,
  Attr                                = 55,
  GetACL                              = 56,
  PutACL                              = 57,
  Fstat                               = 58,
  Stat                                = 59,
  AtomvarInit                         = 60,
  VFSStatCtl                          = 61,
  kernelMmapControl                   = 62,
  kernelMmapInfo                      = 63,
  CatalogGetMounts                    = 64,
  GetMountInfoByID                    = 65,
  uvmount                             = 66,
  saveThreadInfo                      = 67,
  kernelMmapFlush                     = 68,
  InvalidateOSNode                    = 69,
  HasMountHelper                      = 70,
#ifdef P_NFS4
  PnfsCtl                             = 71,
#endif
  AllocVinfo                          = 72,
  CleanupVinfo                        = 73,
  kernelMadvise                       = 74,
  updateOSNode                        = 75,
  Quotactl                            = 76,
  CheckThreadStateCtl                 = 77,
#ifdef DYNASSERTS_FULL
  SetAssertLevel                      = 78,
#endif
  MapAndRecord                        = 79,
  ReleaseAndForget                    = 80,
  InitPtrSwizzling                    = 81,
  CalcMaxSharedSegment                = 82,
  AllocSharedMemory                   = 83,
  FreeSharedMemory                    = 84,
  FreeAllSharedMemory                 = 85,
  SetTakeOwnership                    = 86,
  InitializeNodeHashTab               = 87,
  ClampLocks                          = 88,
  UnClampLocks                        = 89,
  CheckNTAccess                       = 90,
  noOp                                = 91,
  // unused  92,
  CleanupStaleNFS                     = 93,
  GetKernelBoundary                   = 94,
  // unused  95,
  BlockingMutexStatsCtl               = 96,
  FindCloseNFS                        = 97,
  SetMachineSID                       = 98,
  GetPrivLevel                        = 99,
  InvalidateVolatileOSNodes           = 100,
  ThreadPtrToThreadID                 = 101,
  DmApiCall                           = 102,
  DmRemoveSession                     = 103,
  DmGetSessions                       = 104,
  DmUpdateSessions                    = 105,
  AttachSharedMemory                  = 106,
  DetachSharedMemory                  = 107,
  XmemXfer                            = 108,
  ctlDMS                              = 109,
  QuiesceOperations                   = 110,
  ResumeOperations                    = 111,
#ifdef SMB_LOCKS
  GetShare                            = 112,
  GetDelegation                       = 113,
#endif
  WinOps                              = 114,
#ifdef SMB_LOCKS
  OplockInit                          = 115,
  OplockTerm                          = 116,
  OplockNotify                        = 117,
#endif
  SanApiCall                          = 118,
  GetThreadID                         = 119,
  GetTimeOfDay                        = 120,
  kernelLockCallback                  = 121,
  CheckBuildTime                      = 122,
  UMount                              = 123,
  GetKernelPageSize                   = 124,
  GetFilesetId                        = 125,
#ifdef LOCK_TRACING
  GetCPUId                            = 126,
  LockTracingStart                    = 127,
  LockTracingStop                     = 128, 
  IsLockTracingSafe                   = 129,  
#endif
  GetRealFileName                     = 130,
  isCallback                          = 131,
  CloneFile                           = 132,
  FTruncate                           = 133,
  Declone                             = 134,
  TestThSXLock                        = 135,
  InvalidateAllDentries               = 136,
  InitializeConfig                    = 137,
  GetFixedAddrs                       = 138,
  SetTimes                            = 139,
  Ganesha                             = 140,
  lweop_CrSession                     = 141,
  lweop_DeSession                     = 142,
  lweop_GaSession                     = 143,
  lweop_QySession                     = 144,
  lweop_GetEvents                     = 145,
  lweop_RespEvent                     = 146,
  InitCIFSTable                       = 147,
  DumpCIFSTable                       = 148,
  // unused 149,
  // unused 150,
  // unused 151,
  // unused 152,
  // unused 153,
  // unused 154,
  // unused 155,
  GetTraceLevel                       = 156,
  AioComplete                         = 157,
  CleanupIncompleteAio                = 158,
#ifdef TS_RPC_PERF
  GetTscKhz                           = 159,
#endif

/* Always keep the following item as the final element
 * in this enumeration to define the array boundary for 
 * ss_ioctl_ops */
  MAX_SS_IOCTL_OPS
};

#define kxOp_tostring(ent) \
  (((ent) == 0)? "UNUSED 0"                           : \
   ((ent) == 1)? "RegisterMMFSDaemon"                 : \
   ((ent) == 3)? "ThreadInitOrTerm"                   : \
   ((ent) == 4)? "SignalOrBroadcastCondvar"           : \
   ((ent) == 5)? "GetCondWaiters"                     : \
   ((ent) == 6)? "WaitCondvar"                        : \
   ((ent) == 7)? "InitKernelMailboxes"                : \
   ((ent) == 8)? "EnableIO"                           : \
   ((ent) == 9)? "TerminateMailboxes"                 : \
   ((ent) == 10)? "StackAddrToThreadID"               : \
   ((ent) == 11)? "kernelTrace"                       : \
  ((ent) == 12)? "GetDiskInfo"                        : \
  ((ent) == 13)? "RegisterMMFSSessionId "             : \
  ((ent) == 14)? "kernelRecLockReset"                 : \
  ((ent) == 15)? "SetCommState"                       : \
  ((ent) == 16)? "AcquireMutex"                       : \
  ((ent) == 17)? "ReleaseMutex"                       : \
  ((ent) == 18)? "RegisterNodeAddr"                   : \
  ((ent) == 19)? "InitializeRevokeTab"                : \
  ((ent) == 20)? "RegisterObjType"                    : \
  ((ent) == 21)? "SetTraceLevel"                      : \
  ((ent) == 22)? "kxtraceit"                          : \
  ((ent) == 23)? "kPoll"                              : \
  ((ent) == 24)? "GetLocalSGIdCounter"                : \
  ((ent) == 26)? "AwaitAsyncIOCompletion"             : \
  ((ent) == 27)? "LocalIO"                            : \
  ((ent) == 28)? "GetSimpleLock"                      : \
  ((ent) == 29)? "MapPrivate"                         : \
  ((ent) == 30)? "SetMountInfoByID"                   : \
  ((ent) == 31)? "FreeMailboxStorage"                 : \
  ((ent) == 32)? "RegisterMMFSSeg"                    : \
  ((ent) == 33)? "BreakOplock"                        : \
  ((ent) == 34)? "GetStructSize"                      : \
  ((ent) == 35)? "GetMapCount"                        : \
  ((ent) == 36)? "DefineShSeg"                        : \
  ((ent) == 37)? "SetPrivLevel"                       : \
  ((ent) == 38)? "kernelSendFlock"                    : \
  ((ent) == 39)? "kernelWaitForFlock"                 : \
  ((ent) == 40)? "kernelCommonReclock"                : \
  ((ent) == 41)? "kernelDoTraceDump"                  : \
  ((ent) == 42)? "SetNPagesAvailable"                 : \
  ((ent) == 43)? "CoreDump"                           : \
  ((ent) == 44)? "kernelDisableSyncRetry"             : \
  ((ent) == 45)? "kernelEnableSyncRetry"              : \
  ((ent) == 46)? "ClearMountInfo"                     : \
  ((ent) == 47)? "RetryRecover"                       : \
  ((ent) == 48)? "TerminateAsyncIO"                   : \
  ((ent) == 49)? "kernelRLRevokeLock"                 : \
  ((ent) == 50)? "kernelRLRevokeUnLock"               : \
  ((ent) == 51)? "SetPageoutThread"                   : \
  ((ent) == 52)? "ClearPageoutThread"                 : \
  ((ent) == 53)? "Fattr"                              : \
  ((ent) == 54)? "FsAttr"                             : \
  ((ent) == 55)? "Attr"                               : \
  ((ent) == 56)? "GetACL"                             : \
  ((ent) == 57)? "PutACL"                             : \
  ((ent) == 58)? "Fstat"                              : \
  ((ent) == 59)? "Stat"                               : \
  ((ent) == 60)? "AtomvarInit"                        : \
  ((ent) == 61)? "VFSStatCtl"                         : \
  ((ent) == 62)? "kernelMmapControl"                  : \
  ((ent) == 63)? "kernelMmapInfo"                     : \
  ((ent) == 64)? "CatalogGetMounts"                   : \
  ((ent) == 65)? "GetMountInfoByID"                   : \
  ((ent) == 66)? "uvmount"                            : \
  ((ent) == 67)? "saveThreadInfo"                     : \
  ((ent) == 68)? "kernelMmapFlush"                    : \
  ((ent) == 69)? "InvalidateOSNode"                   : \
  ((ent) == 70)? "IsInheritedFD"                      : \
  ((ent) == 71)? "pNFS"                               : \
  ((ent) == 72)? "AllocVinfo"                         : \
  ((ent) == 73)? "CleanupVinfo"                       : \
  ((ent) == 74)? "kernelMadvise"                      : \
  ((ent) == 75)? "updateOSNode"                       : \
  ((ent) == 76)? "Quotactl"                           : \
  ((ent) == 77)? "CheckThreadStateCtl"                : \
  ((ent) == 78)? "SetAssertLevel"                     : \
  ((ent) == 79)? "MapAndRecord"                       : \
  ((ent) == 80)? "ReleaseAndForget"                   : \
  ((ent) == 81)? "SetDosAttr"                         : \
  ((ent) == 82)? "CalcMaxSharedSegment"               : \
  ((ent) == 83)? "AllocSharedMemory"                  : \
  ((ent) == 84)? "FreeSharedMemory"                   : \
  ((ent) == 85)? "FreeAllSharedMemory"                : \
  ((ent) == 86)? "SetTakeOwnership"                   : \
  ((ent) == 87)? "InitializeNodeHashTab"              : \
  ((ent) == 88)? "unused"                             : \
  ((ent) == 89)? "unused"                             : \
  ((ent) == 90)? "CheckNTAccess"                      : \
  ((ent) == 91)? "noOp"                               : \
  ((ent) == 92)? "InvalidateSnapshot"                 : \
  ((ent) == 93)? "CleanupStaleNFS"                    : \
  ((ent) == 94)? "GetKernelBoundary"                  : \
  ((ent) == 96)? "BlockingMutexStatsCtl"              : \
  ((ent) == 97)? "FindCloseNFS"                       : \
  ((ent) == 98)? "SetMachineSID"                      : \
  ((ent) == 99)? "GetPrivLevel"                       : \
  ((ent) == 100)? "InvalidateVolatileOSNodes"         : \
  ((ent) == 101)? "ThreadPtrToThreadID"               : \
  ((ent) == 102)? "DmApiCall"                         : \
  ((ent) == 103)? "DmRemoveSession"                   : \
  ((ent) == 104)? "DmGetSessions"                     : \
  ((ent) == 105)? "DmUpdateSessions"                  : \
  ((ent) == 106)? "AttachSharedMemory"                : \
  ((ent) == 107)? "DetachSharedMemory"                : \
  ((ent) == 108)? "XmemXfer"                          : \
  ((ent) == 109)? "startDMS"			      : \
  ((ent) == 110)? "QuiesceOperations"                 : \
  ((ent) == 111)? "ResumeOperations"                  : \
  ((ent) == 112)? "GetShare"                          : \
  ((ent) == 113)? "GetDelegation"                     : \
  ((ent) == 114)? "WinOps"                            : \
  ((ent) == 115)? "OplockInit"                        : \
  ((ent) == 116)? "OplockTerm"                        : \
  ((ent) == 117)? "OplockNotify"                      : \
  ((ent) == 118)? "SanApiCall"                        : \
  ((ent) == 119)? "GetThreadID"                       : \
  ((ent) == 120)? "GetTimeOfDay"                      : \
  ((ent) == 121)? "kernelLockCallback"                : \
  ((ent) == 122)? "CheckBuildTime"                    : \
  ((ent) == 123)? "UMount"                            : \
  ((ent) == 124)? "GetKernelPageSize"                 : \
  ((ent) == 125)? "GetFilesetId"                      : \
  ((ent) == 126)? "GetCPUId"                          : \
  ((ent) == 127)? "LockTracingStart"                  : \
  ((ent) == 128)? "LockTracingStop"                   : \
  ((ent) == 129)? "IsLockTracingSafe"                 : \
  ((ent) == 130)? "GetRealFileName"                   : \
  ((ent) == 131)? "isCallback"                        : \
  ((ent) == 132)? "CloneFile"                         : \
  ((ent) == 133)? "FTruncate"                         : \
  ((ent) == 134)? "Declone"                           : \
  ((ent) == 135)? "TestThSXLock"                      : \
  ((ent) == 136)? "InvalidateAllDentries"             : \
  ((ent) == 137)? "InitializeConfig"                  : \
  ((ent) == 138)? "GetFixedAddrs"                     : \
  ((ent) == 139)? "SetTimes"                          : \
  ((ent) == 140)? "Ganesha"                           : \
  ((ent) == 141)? "lweCreateSession"                  : \
  ((ent) == 142)? "lweDestroySession"                 : \
  ((ent) == 143)? "lweGetAllSession"                  : \
  ((ent) == 144)? "lweQuerySession"                   : \
  ((ent) == 145)? "lweGetEvents"                      : \
  ((ent) == 146)? "lweRespondEvent"                   : \
  ((ent) == 147)? "InitCIFSTable"                     : \
  ((ent) == 148)? "DumpCIFSTable"                     : \
  ((ent) == 156)? "GetTraceLevel"                     : \
  ((ent) == 157)? "AioComplete"                       : \
  ((ent) == 158)? "CleanupIncompleteAio"             : \
  ((ent) == 159)? "GetTscKhz"                        : \
   "??")

/* Arguments are passed from the GPFS daemon to its kernel module by
   copying them into a kxArgs struct, then passing that struct to the
   kernel via ioctl.  Once inside the kernel, the target routine is
   called with the right number of arguments out of the kxArgs struct.
   The target routine is declared without parameter info; e.g., 'int
   foo(...);'  When the actual parameters are 32 bit values and the
   long argument definitions are 64 bits (that is, on any 64 bit
   architecture), more bytes of data are being passed than the target
   routine expects.  If arguments were passed on the stack, one might
   think this would not work.  However, for X86_64, it appears that the
   space allocated for a parameter is always 64 bits wide, although
   possibly only some of the bits are expected to be initialized.  Also,
   the first 6 parameters are passed in registers, so the target routine
   can easily ignore the extra high-order bits. */
struct kxArgs
{
  IntPtr arg1;
  IntPtr arg2;
  IntPtr arg3;
  IntPtr arg4;
  IntPtr arg5;
  IntPtr arg6;
};

/* Remapping structure for handling 32-bit API calls in 64-bit GPFS */
struct kxArgs32
{
  UInt32 arg1;
  UInt32 arg2;
  UInt32 arg3;
  UInt32 arg4;
  UInt32 arg5;
  UInt32 arg6;
};

#ifndef GPFS_SUPER_MAGIC
/* ASCII code for "GPFS" in the struct statfs f_type field */
/* This value must match same define in gpfs.h */
#define GPFS_SUPER_MAGIC     0x47504653
#endif

EXTERNC_BEGIN
  int  ss_init();
  void gpfs_proc_export_init(void);
  void gpfs_proc_export_term(void);
  void InitSharedMemory();
  void TermSharedMemory();
  void CleanUpSharedMemory();
#ifdef API_32BIT
  void gpfs_reg_ioctl32();
  void gpfs_unreg_ioctl32();
#endif /* API_32BIT */
EXTERNC_END

#define ASSERTBASESEG(ADDR, REA, TAG)

#define SET_PRIVILEGE_LEVEL() (NOOP)

#ifdef __cplusplus
EXTERNC int (*ss_ioctl_op[MAX_SS_IOCTL_OPS])(...);
#else
EXTERNC int (*ss_ioctl_op[MAX_SS_IOCTL_OPS])();
#endif /* __cplusplus */

struct cxiMemoryMapping_t;

EXTERNC_BEGIN
  /* Compute how large the total size shared segment
   * is allowed to grow, based on a desired size.  A value of 0 for
   * desiredBytes means to compute the default maximum size. 
   */
  IntRC cxiCalcMaxSharedSegment(Int64 desiredBytes, Int64* actualBytesP);

  IntRC cxiAllocSharedMemory(struct cxiMemoryMapping_t *mappingP, 
                                  Boolean isSharedSegment);
  IntRC cxiFreeSharedMemory(struct cxiMemoryMapping_t *mappingP, 
                                 Boolean isSharedSegment);
  IntRC cxiAttachSharedMemory(struct cxiMemoryMapping_t *mappingP, 
                                  Boolean isSharedSegment);
  IntRC cxiDetachSharedMemory(struct cxiMemoryMapping_t *mappingP, 
                                  Boolean isSharedSegment);
  IntRC cxiRecordSharedMemory(struct cxiMemoryMapping_t *mappingP);

  /* Map a section of memory MAP_PRIVATE */
  IntRC kxMapPrivate(char *inAddr, unsigned long len, unsigned long prot,
                         char **outAddr);

  /* Kernel calls implemented in portability layer */
  IntRC kxPoll(void* fdListP, int nFDs, int timeoutMS);
  IntRC kxGetACL(const char *pathname, int flags, void *aclP);
  IntRC kxPutACL(const char *pathname, int flags, void *aclP);
  IntRC kxMadvise(void* addr, size_t len, int advice);
#ifdef SMB_LOCKS
  IntRC setSMBOpenLockControl(void *kopP, void *vP, void *infoP, int command,
                                  int lockmode);
  IntRC setSMBOplock(void *vP, void *infoP, int accessWant, int oplockWant,
                         void *breakArgP, int *oplockGrantedP, Boolean isAsync);
  IntRC kxGetShare(int fd, unsigned int share, unsigned int deny);
  IntRC kxGetDelegation(int fd, unsigned int delegate_access,
                            void *cb_token, void *cookie);
#endif
  IntRC kxQuotactl(const char *pathname, int cmd, int qid, void *bufferP);
#ifdef FILESETMAPPING_API
  IntRC kxGetFilesetId(const char *pathname, const char *name, int *idP);
#endif
  IntRC kxGetTimeOfDay(cxiTimeStruc_t *tP);
EXTERNC cxiThreadId kxGetThreadID();
  IntRC kxUMount(int flag, char *pathname, int force, int *ret_err);
  IntRC kxGetRealFileName(int fd, const char * pathnameP,  char *realFilenameP, int *lenP);
#ifdef CLONE_FILE
  IntRC kxCloneFile(CloneOp clop, const char *sourcePathP, const char *destPathP);
  IntRC kxDeclone(DecloneOp dcop, int fd, int ancLimit, UInt32 nBlocksHi, UInt32 nBlocksLo, Int64 *offsetP);
#endif
  IntRC kxFtruncate(int fd, offset_t length);
#ifdef LIGHT_WEIGHT_EVENT
  IntRC kxlweCreateSession(lwe_sessid_t oldsid, char *sessinfop, lwe_sessid_t *newsidp);
  IntRC kxlweDestroySession(lwe_sessid_t sid);
  IntRC kxlweGetAllSession(u_int nelem, lwe_sessid_t *sidbufp, u_int *nelemp);
  IntRC kxlweQuerySession(lwe_sessid_t sid, size_t buflen, void* bufp, size_t *rlenp);
  IntRC kxlweGetEvents(lwe_sessid_t sid, unsigned int maxmsgs, 
                       unsigned int flags, size_t buflen, 
		       void* bufp, size_t *rlenp);
  IntRC kxlweRespondEvent(lwe_sessid_t sid, lwe_token_t token, lwe_resp_t response, int reterror);
#endif  
#if defined(GPFS_GPL)
#if defined(GPFS_ARCH_X86_64) || defined(GPFS_ARCH_S390X)
/* stat64 only relevant to 32-bit binaries with x86-64 (asm/ia32.h) */
#define stat64 stat
#endif /* GPFS_ARCH_X86_64  || GPFS_ARCH_S390X */
#endif /* GPFS_GPL*/

  struct stat64;
  IntRC tsstat(const char *pathname, struct stat64 *statP, 
               unsigned int *litemaskP, unsigned int flags);
  IntRC tsfstat(int fileDesc, struct stat64 *statP);

EXTERNC_END

#endif /* _h_cxiSharedSeg_plat */


