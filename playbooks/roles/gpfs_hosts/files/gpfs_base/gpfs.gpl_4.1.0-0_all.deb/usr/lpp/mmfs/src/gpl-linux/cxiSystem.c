/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/

/*
 * Linux implementation of basic common services
 *
 * Contents:
 *     cxiGetThreadId
 *     getpid
 *     cxiIsSuperUser
 *     DoPanic
 *     logAssertFailed
 *     getCred
 *     putCred
 *     cxiGetCred
 *     cxiPutCred
 *   Kernel memory allocation services:
 *     cxiMallocPinned
 *     cxiFreePinned
 *
 */

#include <Shark-gpl.h>

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/time.h>
#include <linux/file.h>
#include <linux/string.h>
#include <asm/uaccess.h>
#include <linux/vmalloc.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/syscalls.h>
#ifdef USE_KTHREAD_CREATE
#include <linux/kthread.h>
#endif

#include <Logger-gpl.h>
#include <verdep.h>
#include <linux2gpfs.h>
#include <cxiSystem.h>
#include <cxiAtomic.h>
#include <cxi2gpfs.h>
#include <cxiIOBuffer.h>
#include <cxiSharedSeg.h>
#include <cxiCred.h>
#include <gpfs_nfs.h>

#include <Trace.h>
#include <lxtrace.h>
#include <cxiMode.h>
#if LINUX_KERNEL_VERSION < 2063000
#include <linux/swap.h>
#endif
#include <linux/writeback.h>
#if LINUX_KERNEL_VERSION >= 2062600
#include <linux/fdtable.h>
#endif

#ifdef QOSIO
#include <qosio-k.h>
#endif

#ifdef GANESHA
extern int ganesha_tgid;
extern int ganesha_tgid_old;

void cxiSetGaneshaPid(int pid)
{
  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_SETGANID,
        "cxiSetGaneshaPid: to pid %d by %d curr tgid %d old tgid %d\n",
         pid, cxiGetProcessId(), ganesha_tgid, ganesha_tgid_old);

  if (ganesha_tgid != 0)
    ganesha_tgid_old = ganesha_tgid;
  ganesha_tgid = pid;
}

pid_t cxiGetGaneshaPid()
{
  return ganesha_tgid;
}
#endif

/* This is in the Redhat kernel series */
extern int posix_locks_deadlock(struct file_lock *, struct file_lock *);

#ifdef INSTRUMENT_LOCKS
struct BlockingMutexStats BlockingMutexStatsTable[MAX_GPFS_LOCK_NAMES];
#endif  /* INSTRUMENT_LOCKS */

/* We record the daemon's process group since it can uniquely identify
 * a thread as being part of the GPFS daemon.  pid is unique per thread
 * on linux due to their clone implementation.
 */
static pid_t DaemonPGrp = -1;

/* Get the kernel thread ID. */
cxiThreadId cxiGetThreadId()
{
  /* ENTER(1); */
  return current->pid;
}

/* Get the kernel process ID. */
pid_t getpid()
{
  /* ENTER(1); */
  return current->pid;
}

/* Get the kernel process group ID. */
cxiThreadId cxiGetProcessId()
{
  /* ENTER(1); */
  return current->tgid;
}

/* Get the real user ID. */
cxiUid_t getuid()
{
#if LINUX_KERNEL_VERSION >= 2062900
  return FROM_KUID(current->cred->uid);
#else
  return current->uid;
#endif
}

/* Get the effective user ID. */
cxiUid_t geteuid()
{
#if LINUX_KERNEL_VERSION >= 2062900
  return FROM_KUID(current->cred->euid);
#else
  return current->euid;
#endif
}

#ifdef QOSIO
/* Get the Qos Id */
unsigned int cxiGetQosId()
{
  unsigned int qosid;

  if (current->io_context)
    qosid = current->io_context->ioprio<<QOSID_SHIFT;  /* qos id for ordinary process is the ionice value */
  else
    qosid = QOSID_A_PROCESS;

  qosid |= QOSID_LOWMASK & current->pid; // fold in the pid for  mmtop
  return qosid;
}
#endif

/* eCredSmallP is caller's ext_cred_t buffer
 * uCredPP is the ucred struct (NULL on Linux)
 * eCredBigPP is the ext_cred_t struct * (if successful)
 *
 * cxiPutCred should be called to release when operation has been completed.
 */
int cxiGetCred(ext_cred_t *eCredSmallP, void *privVfsP, void **uCredPP, ext_cred_t **eCredBigPP)
{
  int rc;

  ENTER(0);
  *uCredPP = NULL;

  LOGASSERT(eCredSmallP != NULL && eCredBigPP != NULL);

  /* In case caller fails to set *eCredBigPP */
  if (*eCredBigPP == NULL)
    *eCredBigPP = eCredSmallP;

  rc = getCred(eCredSmallP, eCredBigPP);

xerror:
  EXIT_RC(0, rc);
  return rc;
}

/* *eCredSmallP is ext_cred_t on stack or may be kmalloced (as the case is for pcache).
 * **eCredBigPP is *eCredSmallP or kmalloced big by getCred().
 * uCredP is ignored on Linux.
 */
int cxiPutCred(void *uCredP, ext_cred_t *eCredSmallP, ext_cred_t **eCredBigPP)
{
  putCred(eCredSmallP, eCredBigPP);
  return 0;
}

/*
 * *eCredSmallP only supports 32 GIDs.  eCredSmallP may point to kernel
 * stack or a kmalloc buffer as it is for pcache.
 *
 * *eCredBigPP may be equal to eCredSmallP or *eCredBigPP may have been
 * kmalloced by a previous getCred call if the number of GIDs exceeeded 32
 * or UID remapping was enabled.  If we kmalloc a new ext_cred_t, we must
 * kfree *eCredBigPP if it was kmalloced by a previous getCred call.
 */

#if MAX_ECRED_SIZE > MAX_GPFS_KMALLOC
#error MAX_ECRED_SIZE can not be bigger than MAX_GPFS_KMALLOC
#endif

int
getCred(ext_cred_t *eCredSmallP, ext_cred_t **eCredBigPP)
{
  ext_cred_t *eCredP = eCredSmallP;
  size_t size;
  int rc = 0;
  int nGroups;
  int uidRemapOn = 0;
  static int fPrintk = 0;

  ENTER(0);

#ifdef UIDREMAP
  uidRemapOn = gpfs_ops.UIDremapOn();
#endif

  LOGASSERT(*eCredBigPP != NULL);

  if (eCredSmallP != *eCredBigPP)
  {
    cxiFreeUnpinned(*eCredBigPP);
    *eCredBigPP = eCredSmallP;
  }

  nGroups = CRED_GRP(current, ngroups);

  if (nGroups > ECRED_NGROUPS || uidRemapOn)
  {
    if (nGroups > MAX_ECRED_NGROUPS)
    {
      if (!fPrintk)
      {
        printk("GPFS: nGids %d exceeds supported nGids %lu for user %d\n",
               nGroups, MAX_ECRED_NGROUPS, FROM_KUID(CRED(current, fsuid)));
        fPrintk = 1;
      }
      rc = EACCES;
      goto xerror;
    }

    size = uidRemapOn ? MAX_ECRED_SIZE :
           (size_t)(& (((ext_cred_t *)0)->eGroups[nGroups]));
    eCredP = (ext_cred_t *)cxiMallocUnpinned(size);

    TRACE6(TRACE_VNODE, 3, TRCID_LINUXOPS_SETCRED,
           "getCred: fsuid %d fsgid %d nGroups %d uidRemapOn %d 0x%lX size %d\n",
            FROM_KUID(CRED(current, fsuid)), FROM_KGID(CRED(current, fsgid)), nGroups, uidRemapOn,
            eCredP, size);

    if (eCredP == NULL)
    {
      rc = ENOMEM;
      goto xerror;
    }
    eCredP->num_groups_max = MAX_ECRED_NGROUPS;
  }
  else
  {
    eCredP->num_groups_max = ECRED_NGROUPS;
  }

  if (nGroups > 0)
  {

#if LINUX_KERNEL_VERSION > 2060300
    /* We could add code that walks the blocks ptr array when we support
       MAX_CRED_SIZE > PAGE_SIZE */
    LOGASSERT(MAX_ECRED_NGROUPS <= NGROUPS_PER_BLOCK);
    memcpy(eCredP->eGroups,
           CRED_GRP(current, blocks)[0],
           nGroups*sizeof(gid_t));
#else
    memcpy(eCredP->eGroups,
           current->groups,
           nGroups*sizeof(gid_t));
#endif
  }

  eCredP->principal = FROM_KUID(CRED(current, fsuid)); /* user id */
  eCredP->group = FROM_KGID(CRED(current, fsgid));     /* primary group id */
  eCredP->num_groups = nGroups;
  eCredP->winAccessFlags = 0;

#if defined(REDHAT_RHEL55) || (LINUX_KERNEL_VERSION >= 2062700)
  /* In kernels 2.6.27 or later, capabilities are enabled by default
     and may be used (for example) in lieu of setting fsuid where nfsd
     is trying to reconnect a directory into the dentry cache.  Here we
     need to save the effective capabilities that we support so that they
     can be considered in subsequent accesss checking.  Since this is
     sometimes done outside the kernel (the provided "capable()" function
     cannot be used), we set equivalent GPFS-defined bits. */

  eCredP->capabilities = (capable(CAP_DAC_OVERRIDE)? CAP_TO_MASK(CAP_DAC_OVERRIDE): 0) |
                         (capable(CAP_DAC_READ_SEARCH)? CAP_TO_MASK(CAP_DAC_READ_SEARCH): 0);
#else
  eCredP->capabilities = 0;
#endif

  /* If authorized (by config parameter) to bypass normal traversal checking,
     set flag in the cred for subsequent checking. */

  if (gpfs_ops.gpfsIsCifsBypassTraversalChecking() && cxiIsSambaThread())
    eCredP->winAccessFlags |= GPFS_WINACCFLAG_HAS_TRAVERSE_PRIVILEGE;

  *eCredBigPP = eCredP;

xerror:

  EXIT(0);
  return rc;
}

void
putCred(ext_cred_t *eCredSmallP, ext_cred_t **eCredBigPP)
{
  LOGASSERT(*eCredBigPP != NULL);

  if (eCredSmallP != *eCredBigPP)
  {
    cxiFreeUnpinned(*eCredBigPP);
    *eCredBigPP = eCredSmallP;
  }
  return;
}


/* Convert a kernel stack address to the thread ID of the thread that
 * uses that stack
 */
int
cxiStackAddrToThreadId(char* stackP, cxiThreadId* tidP)
{
  struct task_struct * tP;
  /* the kernel stack is base off the thread_info struct in the 2.6 kernel
   * will get the task pointer out of thread_info struct.
   */
  struct thread_info * iP;
  void *srcP = NULL; // copy data from this address
  int offset = 0;    // offset of a data field
  int size   = 0;    // size of a data field
  int rc     = 0;    // return code
  ENTER(0);
  iP = (struct thread_info *) ((UIntPtr)stackP & ~((UIntPtr)(THREAD_SIZE-1)));
  *tidP = -1; // return this as task pid if any of the pointers is bad

  // Use __copy_from_user instead of pointer dereference to avoid
  // the risk of crashing the kernel due to a bad pointer.
  // use __copy_from_user to do tP = iP->task;
  offset = OFFSET_OF(task, struct thread_info);
  size = sizeof(struct task_struct *);
  srcP = (char *)iP + offset;
  rc = __copy_from_user(&tP, srcP, size);
  if (rc == 0) // success of __copy_from_user
  {
    // use __copy_from_user to do *tidP = tP->pid;
    offset = OFFSET_OF(pid, struct task_struct);
    size = sizeof(pid_t);
    srcP = (char *)tP + offset;
    rc = __copy_from_user(tidP, srcP, size);
    if (rc != 0)   // failure of __copy_from_user
      *tidP = -1;  // avoid random bad values
  }
  EXIT(0);
  return 0;
}

/* Convert a kernel thread pointer to the corresponding thread ID */
int
cxiThreadPtrToThreadId(char* threadP, cxiThreadId* tidP)
{
  struct task_struct * tP;

  ENTER(0);
  tP = (struct task_struct *) threadP;
  *tidP = tP->pid;

  EXIT(0);
  return 0;
}


/* Return true if caller has has maximum authorization (is root) */
Boolean cxiIsSuperUser()
{
  return (FROM_KUID(CRED(current, euid)) == 0);
}

#ifdef LOCK_TRACING
/* Get the CPU ID on which the process is run */
Int32 cxiGetCPUId()
{
  return smp_processor_id();
}
#endif

/* Get the process max filesize limit (ulimit -f) */
Int64 cxiGetMaxFileSize()
{
  if ((signed long)MY_RLIM_CUR(RLIMIT_FSIZE) == -1L)
    return MAX_INT64;
  else
    return (MY_RLIM_CUR(RLIMIT_FSIZE));
}

/* Routine to send a signal to the current thread/process */
void cxiSendSigThread(int sig)
{
  ENTER(0);
  send_sig(sig, current, 0);
  EXIT(0);
}


#ifdef MALLOC_DEBUG
/* This tracks mallocs and frees on a limited basis.
 * Implemented originally to determine if we were leaking
 * any memory after an unload.  This is not really thread
 * safe for multiple processors unless they're automatically
 * cache coherent without memory barriers (i386).   Its useful
 * for detecting memory leaks on a single processor system.
 */
#define MALLOC_RECORDS 5000 /* max mallocs to track */
struct mallocStat
{
  void *beginP;
  unsigned short size;
  unsigned short type;
};
static struct mallocStat *mstatP = NULL;
unsigned int nextMalloc = 0;

void
MallocDebugStart()
{
  int i;

  ENTER(0);
  if (mstatP == NULL)
    mstatP = vmalloc(MALLOC_RECORDS * sizeof(struct mallocStat));

  if (mstatP == NULL)
  {
    EXIT(0);
    return;
  }

  for (i = 0; i < MALLOC_RECORDS; i++)
  {
    mstatP[i].beginP = NULL;
    mstatP[i].size = 0;
    mstatP[i].type = 0;
  }
  printk("MallocDebugStart 0x%X\n", mstatP);
  EXIT(0);
}

void
MallocDebugEnd()
{
  int i;

  ENTER(0);
  if (mstatP != NULL)
  {
    for (i = 0; i < MALLOC_RECORDS; i++)
    {
      if (mstatP[i].beginP != NULL)
        printk("MallocDebug: beginP 0x%X size %d type %d STILL ALLOCATED!\n",
               mstatP[i].beginP, mstatP[i].size, mstatP[i].type);
    }
  }

  vfree(mstatP);
  mstatP = NULL;
  EXIT(0);
}

void
MallocDebugNew(void *ptr, unsigned short size, unsigned short type)
{
  void *bP;
  int i;
  int j;
  int swrc;
  int oldval;
  int where = nextMalloc;

  ENTER(0);

  if (mstatP == NULL)
  {
    EXIT(0);
    return;
  }

  for (i = where; i < MALLOC_RECORDS + where; i++)
  {
    if (i >= MALLOC_RECORDS)
      j = i - MALLOC_RECORDS;
    else
      j = i;

    bP = mstatP[j].beginP;
    if (bP == NULL)
    {
      swrc = ATOMIC_SWAP(&mstatP[j].beginP, &bP, ptr);
      if (swrc)
      {
        mstatP[j].size = size;
        mstatP[j].type = type;
        break;
      }
    }
  }

  EXIT(0);
}

void
MallocDebugDelete(void *ptr)
{
  void *bP;
  int i;
  int swrc;
  int next;
  int found = 0;

  ENTER(0);
  if (mstatP == NULL)
  {
    EXIT(0);
    return;
  }

  for (i = 0; i < MALLOC_RECORDS; i++)
  {
    bP = mstatP[i].beginP;
    if (bP == ptr)
    {
      next = nextMalloc;
      ATOMIC_SWAP(&nextMalloc, &next, i);

      swrc = ATOMIC_SWAP(&mstatP[i].beginP, &bP, NULL);
      DBGASSERT(swrc);
      found = 1;
      break;
    }
  }

  if (!found)
    printk("MallocDebug: 0x%X not found!\n", ptr);
  EXIT(0);
}
#endif /* MALLOC_DEBUG */

/* Allocate pinned kernel memory */
void* cxiMallocPinned(int nBytes)
{
  void *ptr;

  /* kmalloc only supports requests for up to 131027 bytes.  Anything
     larger than this results in a BUG() call. */
  ENTER(0);
  if (nBytes > MAX_GPFS_KMALLOC)
  {
    EXIT(0);
    return NULL;
  }

  ptr = kmalloc(nBytes, GFP_KERNEL);

  TRACE3(TRACE_MALLOC, 5, TRCID_CXIMALLOCPINNED,
         "cxiMallocPinned: %d bytes at 0x%lX caller 0x%lX",
         nBytes, ptr, __builtin_return_address(0));

#ifdef MALLOC_DEBUG
  MallocDebugNew(ptr, nBytes, 1);
#endif

  EXIT(0);
  return ptr;
}

/* Free pinned kernel memory that was allocated with cxiMallocPinned */
/* Must not block on lack of memory resourses */
void cxiFreePinned(void* p)
{
  ENTER(0);
#ifdef MALLOC_DEBUG
  MallocDebugDelete(p);
#endif

  TRACE2(TRACE_MALLOC, 5, TRCID_CXIFREEPINNED,
         "cxiFreePinned: at 0x%lX caller 0x%lX",
         p, __builtin_return_address(0));

  kfree(p);
  EXIT(0);
}

/* Get the kernel thread ID. */
void* cxiGetFcntlOwner(eflock_t *flP)
{
  return flP? flP->l_owner: current->files;
}

#if LINUX_KERNEL_VERSION >= 2060900
struct lock_manager_operations lm_operations = {
};
#endif

#if defined(REDHAT_RHEL54) || (LINUX_KERNEL_VERSION >= 2063000)
/* Record the revoke handler pid on F_SETLK so that it can be
   recognized on the corresponding UNLCK. */

static pid_t DaemonLockPID = -1;
#endif

/* Perform local advisory locking. */
IntRC cxiFcntlLock(void *advObjP,
                   int cmd,
                   void *lockStructP,
                   cxiFlock_t *flockP,
                   int (*retryCB)(),
                   cxiOff64_t size,
                   cxiOff64_t offset,
                   UIntPtr *retry_idP)
{
  int len, rc = 0;
  struct file_lock fl, conf, *flP, *gflP, *cflP = NULL;
  Boolean keepLockElement = false;

  /* cast platform independent arguments as appropriate for linux */
  void (*RetryFcn)(struct file_lock*) = (void (*)(struct file_lock*))retryCB;
  struct file localFile = {}, *filp = &localFile;
  struct dentry localDEntry = {}, *dp = &localDEntry;
  ENTER(0);
  flP = (struct file_lock *) lockStructP;

  localFile.f_dentry = &localDEntry;
  FILE_LOCK_INIT(filp);
  localDEntry.d_inode = (struct inode *)advObjP;

  /* Lock commands can have two different values.  Convert them at
   * entry to the portability layer so that we only have to check
   * for one of them.
   */
#if !defined(__64BIT__)
  if (cmd == F_GETLK64) cmd = F_GETLK;
  if (cmd == F_SETLK64) cmd = F_SETLK;
  if (cmd == F_SETLKW64) cmd = F_SETLKW;
#endif

  /* Callers have the option of passing a platform dependent lock structure
     (struct file_lock *lockSructP) or the generic (cxiFlock_t *flockP). */
  if (flockP)
  {
    flP = &fl; /* Use a local file_lock structure */

    /* If there is potential for the kernel to continue to make use of our
       file struct after return from the posix_lock_file call (either a
       SETLK request that may be granted, or SETLKW request that could
       be granted or queued waiting for an unlock), then we must malloc
       the structures here so it can persist until the lock is released.

       Also, recovery of kernel locks after a failure need to allocate
       file structures since the kernel may have already released the
       real ones. */

    if ((cmd == F_SETLKW) ||
        ((cmd == F_SETLK) && (flockP->l_type != F_UNLCK)) ||
        ((cmd == F_SETLK) && (flockP->l_type == F_UNLCK) && !retry_idP))
    {
      len = sizeof(struct file_lock) +
            sizeof(struct file) +
            sizeof(struct dentry);
      flP = (struct file_lock*)cxiMallocUnpinned(len);
      if (flP == NULL)
      {
        rc = ENOMEM;
        goto exit;
      }
      cxiMemset(flP, 0, len);
      filp = (struct file*)((char *)flP + sizeof(struct file_lock));
      dp = (struct dentry *)((char *)filp + sizeof(struct file));
      filp->f_dentry = dp;
      FILE_LOCK_INIT(filp);
      dp->d_inode = (struct inode *)advObjP;
    }
    else
      cxiMemset(flP, 0, sizeof(struct file_lock));

    locks_init_lock(flP); /* Initialize list_head structs */
    cxiFlockToVFS(flockP, flP);
  }

  /* daemon didn't know the owner and required kernel code to fill it in. */
  if (!flP->fl_owner)
    flP->fl_owner = (fl_owner_t)cxiGetFcntlOwner(NULL);

  /* 1) If the file pointer is provided (fl_file) set the filp arg from
        it.  This is the mainline case of an application fcntl call.
     2) When called by kxCommonReclock (revoke or recovery processing) we
        must use locally-allocated structures (filp set accordingly above).
        a)  For the cases where we have had to malloc file/dentry structures
            (potentially blocking SETLKW calls not originating from an application
            fcntl call) clear the file_lock structure pointer.  Otherwise
            posix_lock_file_conf may copy the pointer, and /proc/locks may
            try to access the storage after we free it below.  Note that
            lock_get_status handles a null fl_file.
        b) For other kxCommonReclock calls, it is ok to set fl_file to the
           locally declared file struct (localFile).  */

  if (flP->fl_file)
    filp = flP->fl_file;
  else
  {
#if defined(REDHAT_RHEL54) || (LINUX_KERNEL_VERSION >= 2063000)
    /* On these kernels, fl_file is used when an UNLCK causes a previous
       lock to be removed (locks_delete_lock calls fasync_helper with
       fl_file, where it is then used to get a lock in the file struct).
       As a result, we can no longer allow a NULL filp here.  We will
       pass our locally allocated pointer, but take care that if the
       SETLKW is immediately granted, we do not free this space
       until the corresponding UNLK has been processed. */

    flP->fl_file = filp;
#else
    if (flockP && (flP!=&fl))
      flP->fl_file = NULL;
    else
      flP->fl_file = filp;
#endif
  }

  /* Note that this all depends on us having serialized such locking for
     this file during from before the posix_test_lock() until after the
     posix_block_lock().  The revoke lock that we hold here provides us
     the necessary serilization. */

  TRACE10(TRACE_VNODE, 3, TRCID_FCNTLLOCK_ENTER,
         "cxiFcntlLock posix_lock_file: flP 0x%lX fl_file 0x%lX filp 0x%lX pid %d owner 0x%X "
         "inodeP 0x%lX range 0x%lX-%lX cmd %s type %s\n",
         flP, flP->fl_file, filp,
         flP->fl_pid, flP->fl_owner, advObjP, flP->fl_start, flP->fl_end,
         (cmd == F_GETLK) ? "GETLK" : (cmd == F_SETLK) ? "SETLK" : "SETLKW",
         (flP->fl_type == F_RDLCK) ? "RDLCK" :
         (flP->fl_type == F_WRLCK) ? "WRLCK" : "UNLCK");

#if defined(NFS_CLUSTER_LOCKS) || \
      (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION >= 2061800)
  conf.fl_ops = NULL;
  conf.fl_lmops = NULL;

  if (cmd == F_GETLK)
  {
    /* Check for conflicts.  If found, return the information.
       If there are NO conflicts, return F_UNLCK in fl_type. */
#if defined(NFS_CLUSTER_LOCKS) && !defined(REDHAT_RHEL5)
    posix_test_lock(filp, flP);
#else
    gflP = &conf;
    rc = posix_test_lock(filp, flP, gflP);
    if (rc) {
      rc = 0;
      flP->fl_start = gflP->fl_start;
      flP->fl_end = gflP->fl_end;
      flP->fl_type = gflP->fl_type;
      flP->fl_pid = gflP->fl_pid;
      flP->fl_owner = gflP->fl_owner;
    }
    else
      flP->fl_type = F_UNLCK;
#endif

    TRACE7(TRACE_VNODE, 3, TRCID_FCNTLLOCK_GETLK,
           "cxiFcntlLock getlk: rc %d pid %d owner 0x%X inodeP 0x%lX "
           "range 0x%lX-%lX type %s\n", rc,
           flP->fl_pid, flP->fl_owner, advObjP, flP->fl_start, flP->fl_end,
           (flP->fl_type == F_RDLCK) ? "RDLCK" :
           (flP->fl_type == F_WRLCK) ? "WRLCK" : "UNLCK");

  }
  else
  { /* Begin: do the locking, but handle the blocking via our retry routine. */
    /* Test the lock.   What this really does for us is return the blocker
       if one exists.  This is needed to queue up the request if a conflicting
       lock is already held. */

    /* A blocking unlock doesn't make any sense, but we should handle
       it gracefully. */
    if ((cmd == F_SETLKW) && (flP->fl_type == F_UNLCK))
       cmd = F_SETLK; /* otherwise we get !fl_notify in existing locks! */

    if (cmd == F_SETLKW) {
      flP->fl_flags |= FL_SLEEP;
      if (!flP->fl_lmops) {
        flP->fl_lmops = &lm_operations;
        lm_operations.fl_notify = (void *)RetryFcn;
      }
    }
    rc = posix_lock_file_conf(filp, flP, &conf);
#if defined(FILE_LOCK_DEFERRED)
    if (rc == FILE_LOCK_DEFERRED)
      rc = -EAGAIN;
#endif
    if (rc == -EAGAIN && (cmd == F_SETLKW) && flP->fl_lmops == &lm_operations)
    {
      /* Queue the blocker structures */
      keepLockElement = true;
      if (retry_idP)
        *retry_idP = (ulong)flP; // returned to caller and saved in sleepElement
    }

#if defined(REDHAT_RHEL54) || (LINUX_KERNEL_VERSION >= 2063000)
    /* If the lock was granted immediately, the lock structure (including
       fl_file) was copied into the Linux structures.  Keep the storage
       that was allocated for the file structure around until the UNLCK
       so that kernel references are ok. Note that this allocated storage
       is being returned in fl_file, so the UNLCK call will be able to free it. */

    TRACE4(TRACE_VNODE, 3, TRCID_FCNTLLOCK_FL_FILE,
         "cxiFcntlLock posix_lock_file: rc %d flockP 0x%lX fl @0x%lX DaemonLockPID %d",
         rc, flockP, &fl, DaemonLockPID);

    if ((rc == 0) && flockP)
    {
      /* This is a revoke handler call SETLKW, that was immediately granted.
         The fl_file pointer is to storage allocated above, and needs to be
         maintained until the UNLCK is processed. */

      if ((flP!=&fl) && (flP->fl_type != F_UNLCK))
      {
        keepLockElement = true;

        /* Keeping the pid here as a way to note that a revoke is in
           progress, and the next UNLCK will be from the revoke handler
           (at which time we should free the storage).  */

        DaemonLockPID = flP->fl_pid;
      }

      /* On the subsequent UNLCK from the revoke handler, free the space
         we allocated during the SETLKW */

      if ((DaemonLockPID == flP->fl_pid) && (flP->fl_type == F_UNLCK))
      {
        struct file_lock *oldFlP = (struct file_lock *)((caddr_t)flP->fl_file - sizeof(struct file_lock));

        /* Note that the UNLCK is SETLK (not SETLKW), so no new allocation
           happens here.  We recognize this is a revoke-handler call because
          flockP and fl_pid==DaemonLockPID.   Note that no other call can
          get in-between since the revoke handler holds the RL lock. */

        DaemonLockPID = -1;

        oldFlP->fl_file = NULL;
        cxiFreeUnpinned(oldFlP);

      }
    }
#endif

#else // not NFS_CLUSTER_LOCKS
  if (cmd == F_GETLK)
  {
    /* Check for conflicts.  If found, return the information.
       If there are NO conflicts, return F_UNLCK in fl_type. */
    if (NULL != (gflP = posix_test_lock(&localFile, flP))) {
      flP->fl_start = gflP->fl_start;
      flP->fl_end = gflP->fl_end;
      flP->fl_type = gflP->fl_type;
      flP->fl_pid = gflP->fl_pid;
      flP->fl_owner = gflP->fl_owner;
    }
    else
      flP->fl_type = F_UNLCK;

    TRACE6(TRACE_VNODE, 3, TRCID_FCNTLLOCK_GETLK2,
           "cxiFcntlLock getlk: pid %d owner 0x%X inodeP 0x%lX "
           "range 0x%lX-%lX type %s\n",
           flP->fl_pid, flP->fl_owner, advObjP, flP->fl_start, flP->fl_end,
           (flP->fl_type == F_RDLCK) ? "RDLCK" :
           (flP->fl_type == F_WRLCK) ? "WRLCK" : "UNLCK");
  }
  else
  { /* Begin: do the locking, but handle the blocking via our retry routine. */
    /* Test the lock.   What this really does for us is return the blocker
       if one exists.  This is needed to queue up the request if a conflicting
       lock is already held. */

    /* Serialize during the posix_lock_file/posix_locks_deadlock
       pair of calls. */
    LOCK_KERNEL();

    if ((flP->fl_type == F_UNLCK) || !(cflP = posix_test_lock(&localFile, flP)))
    {
      /* No conflicting lock:  get the lock for the caller. */
      rc = POSIX_LOCK_FILE(&localFile, flP);
    }
    else
    { /* Conflicting lock:  ..... */
      rc = EAGAIN;

      if (cmd == F_SETLKW)
      {
        if (cflP && posix_locks_deadlock(flP, cflP))
        {
          rc = EDEADLK;
        }
        else
        {
          /* Queue the blocker structures */
          keepLockElement = true;
          if (retry_idP)
            *retry_idP = (ulong)flP; // returned to caller and saved in sleepElement
#if LINUX_KERNEL_VERSION >= 2060900
          flP->fl_lmops = &lm_operations;
          flP->fl_lmops->fl_notify = RetryFcn;
#else
          flP->fl_notify = RetryFcn;
#endif
          posix_block_lock(cflP, flP);
        }
      }
    }

    UNLOCK_KERNEL();
#endif

    TRACE2(TRACE_VNODE, 3, TRCID_FCNTLLOCK_EXIT,
           "cxiFcntlLock posix_lock_file: rc %d retry_id 0x%lX\n", rc, cflP);
  } /* End: do the locking, but handle the blocking via our retry routine. */

exit:

  if (flockP)
  {
    /* Caller wanted results in flockP */
    cxiVFSToFlock((void *)flP, flockP);

    /* If we allocated the locking structure and then didn't need to use
       it (the lock request didn't block), free it. */

    if ((flP!=&fl) && (!keepLockElement)) {
      cxiFreeUnpinned(flP);
    }
  }

  if (rc < 0)
    rc = -rc;  /* make it positive */
  EXIT_RC(0, rc);
  return rc;
}

void cxiFcntlUnblock(void *retry_idP)
{
  struct file_lock *flP = (struct file_lock *)retry_idP;
  Boolean gotLocked = false;
  struct inode *inodeP = NULL;
#if defined(HAS_FILE_INODE)
  inodeP = file_inode(flP->fl_file);
#endif

  ENTER(0);
  /* Include some sanity checks on the retry id (file_lock)
     before passing it into the routine that does the work.
     It should be properly linked (via its list_head structures)
     in a file_lock_list that has blocked waiters.  Also,
     we would only be backing this out by the process that
     has originally blocked, so verify the pid. */

#if LINUX_KERNEL_VERSION >= 2063800
  LOCK_FLOCKS(inodeP);
  gotLocked = true;
#else
  if (!KERNEL_LOCKED())
  {
    LOCK_KERNEL();
    gotLocked = true;
  }
#endif
  if (!list_empty(&flP->fl_block) && !FL_LINK_EMPTY(&flP->fl_link)  &&
       flP->fl_next)
  {
    if (gotLocked)
    {
      gotLocked = false;
#if LINUX_KERNEL_VERSION >= 2063800
      UNLOCK_FLOCKS(inodeP);
#else
      UNLOCK_KERNEL();
#endif
    }
    POSIX_UNBLOCK_LOCK(flP->fl_file, flP);
  }

  if (gotLocked)
#if LINUX_KERNEL_VERSION >= 2063800
    UNLOCK_FLOCKS(inodeP);
#else
    UNLOCK_KERNEL();
#endif

  EXIT(0);
  return;
}

#define for_each_lock(inodeP, lockP) \
        for (lockP = &inodeP->i_flock; *lockP != NULL; lockP = &(*lockP)->fl_next)

static Boolean isSameLcok(struct file_lock *cfl, struct file_lock *bfl)
{
  Boolean same = false;

  TRACE10(TRACE_VNODE, 3, TRCID_IS_SAME_LOCK_1,
        "isSameLcokl: fl 0x%lX:0x%lX fl_lmops 0x%lX:0x%lX start %lld:%lld end start %lld:%lld type %d:%d",
         cfl, bfl, cfl->fl_lmops, bfl->fl_lmops, cfl->fl_start, bfl->fl_start,
         cfl->fl_end, bfl->fl_end, cfl->fl_type, bfl->fl_type);

  if (cfl->fl_lmops && cfl->fl_lmops->fl_compare_owner)
  {
    if (bfl->fl_lmops == cfl->fl_lmops &&
        cfl->fl_lmops->fl_compare_owner(cfl, bfl))
    {
      if ((cfl->fl_end == bfl->fl_end) &&
          (cfl->fl_start == bfl->fl_start) &&
          (cfl->fl_type == bfl->fl_type))
        same = true;
    }
  }
  return same;
}

int cxiFcntlCancel(void *fileLockP)
{
  struct file_lock *cfl = (struct file_lock *)fileLockP;
  struct file_lock **last;
  struct file_lock *bfl = NULL;
  struct inode *inodeP = NULL;
  int code = 0, rc = ENOENT;
  Boolean gotLocked = false;

  if (cfl && cfl->fl_file && cfl->fl_file->f_dentry)
  {
    inodeP = cfl->fl_file->f_dentry->d_inode;
  }
  else
  {
    code = 3;
    rc = ENOENT;
    goto out;
  }

#if LINUX_KERNEL_VERSION >= 2063800
  LOCK_FLOCKS(inodeP);
  gotLocked = true;
#else
  if (!KERNEL_LOCKED())
  {
    LOCK_KERNEL();
    gotLocked = true;
  }
#endif

  for_each_lock(inodeP, last)
  {
    struct file_lock *flP = *last;

    if (flP->fl_flags & FL_POSIX &&
        !list_empty(&flP->fl_block))
    {
      list_for_each_entry(bfl, &flP->fl_block, fl_block)
      {
        if (isSameLcok(cfl, bfl))
        {
          code = 7;
          if (gotLocked)
#if LINUX_KERNEL_VERSION >= 2063800
            UNLOCK_FLOCKS(inodeP);
#else
            UNLOCK_KERNEL();
#endif
          gotLocked = false;
#if LINUX_KERNEL_VERSION >= 2063200
          rc = POSIX_UNBLOCK_LOCK(bfl->fl_file, bfl);
#else
          posix_unblock_lock(bfl->fl_file, bfl);
          rc = 0;
#endif
          if (rc == 0)
          {
            code = 9;
            cxiFreeUnpinned(bfl);
          }
          goto out;
        }
      }
    }
  }
out:

  if (gotLocked)
#if LINUX_KERNEL_VERSION >= 2063800
    UNLOCK_FLOCKS(inodeP);
#else
    UNLOCK_KERNEL();
#endif

  TRACE3(TRACE_VNODE, 3, TRCID_CANCEL_1,
        "cxiFcntlCancel: rc %d code %d bfl 0x%lX",
         rc, code, bfl);

  return rc;
}

void cxiSetNlink(struct cxiNode_t* cnP, UInt32 nlink)
{
  if (cnP)
  {
    struct inode *inodeP = GNP_TO_VP(cnP);
    if (inodeP)
    {
      TRACE3(TRACE_VNODE, 3, TRCID_SET_NLINK,
             "cxiSetNlink change ino %lld i_nlink %u to %u",
             inodeP->i_ino, inodeP->i_nlink, nlink);
      set_nlink(inodeP, nlink);
    }
  }
}

IntRC cxiFcntlReset(void *vfsP, cxiPid_t mmfsd_pid)
{
  int rc = 0;
  struct super_block *sbP = (struct super_block *)vfsP;
  struct list_head *fllP;
  struct file_lock *fl;
  struct dentry *dentryP;

  ENTER(0);
  LOCK_KERNEL();

restart:

#if LINUX_KERNEL_VERSION >= 2061600
//??? find a different way to clear locks  file_lock_list is not exported anymore
#else
  fllP = file_lock_list.next;

  while(fllP != &file_lock_list)
  {
    fl = list_entry(fllP, struct file_lock, fl_link);
    fllP = fllP->next;

    /* If there are mmfs lock structures, release them. */

    if (fl &&
        fl->fl_file &&
        fl->fl_file->f_dentry &&
        fl->fl_file->f_dentry->d_inode)
    {
      dentryP = fl->fl_file->f_dentry;

      /* If this lock belongs to the specified vfs, release advisory locks. */
      if (dentryP->d_sb == sbP)
      {
        /* remove all our locks */
        rc = gpfs_ops.gpfsFcntlReset((void *)dentryP->d_inode, mmfsd_pid);
        if (rc == ENOSYS)
          goto xerror;

        /* After freeing unknown numbers of locks in gpfsFcntlReset (all
           locks for the inode), restart from the top of the lock list */
        goto restart;
      }
    }
  }
#endif

xerror:
  UNLOCK_KERNEL();
  EXIT_RC(0, rc);
  return rc;
}

void *
cxiGetPrivVfsP(void *vfsP)
{
  struct super_block *sbP = (struct super_block *)vfsP;

  /* Do some sanity checking */
  if ( (sbP->s_magic != GPFS_SUPER_MAGIC) ||
       ((UIntPtr) sbP->s_fs_info < GPFS_KERNEL_OFFSET) )
    printSuperList(sbP);
  LOGASSERT( sbP->s_magic == GPFS_SUPER_MAGIC );
  LOGASSERT( (UIntPtr) sbP->s_fs_info >= GPFS_KERNEL_OFFSET );

  return sbP->s_fs_info;
}


#ifdef NFS_DEBUG
/* These flags are defined in the kernel and control various cprintk
   calls.  This provides us a way to easily turn these on/off for
   debugging our NFS support. */
extern unsigned int nlm_debug;
extern unsigned int nfsd_debug;
extern unsigned int nfs_debug;
extern unsigned int rpc_debug;
#endif

IntRC cxiTrace(cxiTrace_t trace)
{
#ifdef NFS_DEBUG
  int rc = 0;

  ENTER(0);
  switch (trace)
  {
    case cxiTraceNFS:
      nlm_debug = nfsd_debug = nfs_debug = rpc_debug = ~0;
      break;
    case cxiTraceNFSoff:
      nlm_debug = nfsd_debug = nfs_debug = rpc_debug =  0;
      break;
    default:
      rc = EINVAL;
      break;
  }
  EXIT_RC(0, rc);
  return rc;
#else
  return ENOSYS;
#endif
}

void cxiFlockToVFS(eflock_t* lckdatP, void* vP)
{
  struct file_lock* flP = (struct file_lock *)vP;

  ENTER(0);
  if ((flP) && (lckdatP))
  {
    flP->fl_pid   = lckdatP->l_pid;
    flP->fl_owner = lckdatP->l_owner;
    flP->fl_type  = lckdatP->l_type;
    flP->fl_start = lckdatP->l_start;
    flP->fl_flags = FL_POSIX;
#if defined(NFS_CLUSTER_LOCKS) || \
      (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION >= 2061800)
    flP->fl_lmops = lckdatP->l_lmops;
    flP->fl_file  = lckdatP->l_file;
    flP->fl_ops   = NULL;
#else
    if (lckdatP->l_caller == L_CALLER_LOCKD)
      flP->fl_flags |= FL_LOCKD;
#endif
    if (lckdatP->l_len == 0)
      flP->fl_end = FL_OFFSET_MAX;
    else
      flP->fl_end = lckdatP->l_len + lckdatP->l_start - 1;
  }
  EXIT(0);
  return;
}

int cxiVFSCallback(eflock_t* lckreqP, eflock_t* lckdatP,
                        int(* callback)(void *, void *, int), int result)
{
  struct file_lock fl;
  struct file *fileP;
  struct file_lock conf, *confP = NULL;
  int rc = ENOENT;

  ENTER(0);

#ifdef NFS_CLUSTER_LOCKS
  cxiFlockToVFS(lckreqP, &fl);
  fileP = fl.fl_file;
  conf.fl_ops = NULL;
  conf.fl_lmops = NULL;
  if (!result) { /* try to get the posix lock */
    if (!fileP || !fileP->f_dentry || !fileP->f_dentry->d_inode)
      return -1;

    conf.fl_ops = NULL;
    conf.fl_lmops = NULL;
    rc = posix_lock_file_conf(fileP, &fl, &conf);
    TRACE3(TRACE_VNODE, 3, TRCID_VFSCALLBACK_1,
        "cxiVFSCallback: client 0x%lX rc %d result %d\n",
         callback, rc, result);
    if (rc)
      callback(&fl, &conf, EBUSY);
    else
    {      /* got the posix lock */
      rc = callback(&fl, NULL, result);
      if (rc) {  /* too late, free the lock */
        fl.fl_type = F_UNLCK;
        rc = POSIX_LOCK_FILE(fileP, &fl);
      }
    }
  }
  else
  {
    if (lckdatP) {
      cxiFlockToVFS(lckdatP, &conf);
      confP = &conf;
    }
    rc = callback(&fl, confP, result);
    TRACE3(TRACE_VNODE, 3, TRCID_VFSCALLBACK_2,
        "cxiVFSCallback: lckdatP 0x%lX rc %d result %d\n",
         lckdatP, rc, result);
  }
#endif

  if (rc < 0)
    rc = -rc;  /* make it positive */

  EXIT_RC(0, rc);
  return rc;
}

void cxiVFSToFlock(void *vP, eflock_t *lckdatP)
{
  struct file_lock* flP = (struct file_lock *)vP;

  ENTER(0);
  if ((flP) && (lckdatP))
  {
    lckdatP->l_pid    = flP->fl_pid;
    lckdatP->l_owner  = flP->fl_owner;
    lckdatP->l_type   = flP->fl_type;
    lckdatP->l_start  = flP->fl_start;
    lckdatP->l_flags  = flP->fl_flags;
#if defined(NFS_CLUSTER_LOCKS) || \
      (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION >= 2061800)
    lckdatP->l_lmops  = (void *)flP->fl_lmops;
    lckdatP->l_file   = flP->fl_file;
    lckdatP->l_flags  = flP->fl_flags;
    if (lckdatP->l_lmops) /* must be lockd or nfsd */
#else
    lckdatP->l_lmops  = NULL;
    lckdatP->l_file   = NULL;
    lckdatP->l_flags  = 0;
    if (flP->fl_flags & FL_LOCKD)
#endif
      lckdatP->l_caller = L_CALLER_LOCKD;
    else
      lckdatP->l_caller = L_CALLER_NULL;
    if (flP->fl_end == FL_OFFSET_MAX)
      lckdatP->l_len = 0;
    else
      lckdatP->l_len    = flP->fl_end - flP->fl_start + 1;
  }
  EXIT(0);
  return;
}


/* Sleep for the indicated number of milliseconds */
void cxiSleep(int ms)
{
  ENTER(0);
  TRACE1(TRACE_VNODE, 9, TRCID_SLEEP,
         "cxiSleep: begin delay %d\n", ms);
  current->state = TASK_INTERRUPTIBLE;
  /* For large HZ rearrange jiffies calculation and
     use presumably larger word size to minimize overflow risk */
  if (unlikely(HZ > 1000))
    schedule_timeout(((long)ms)*HZ/1000);
  else
    schedule_timeout(ms/(1000/HZ));
  TRACE2(TRACE_VNODE, 9, TRCID_SLEEP_END,
         "cxiSleep: end delay %d HZ %d\n", ms, HZ);
  EXIT(0);
}

/* delay for some microseconds */
void cxiUsleep(unsigned long usecs)
{
  if (usecs<7000)
    udelay(usecs);
  else
    cxiSleep(usecs/1000);
}

/* Sleep for the indicated number of milliseconds */
void cxiUnInerruptibleSleep(int ms)
{
  ENTER(0);
  TRACE1(TRACE_VNODE, 9, TRCID_UNINT_SLEEP,
         "cxiUnInerruptibleSleep: begin delay %d\n", ms);
  current->state = TASK_UNINTERRUPTIBLE;
  /* For large HZ rearrange jiffies calculation and
     use presumably larger word size to minimize overflow risk */
  if (unlikely(HZ > 1000))
    schedule_timeout(((long)ms)*HZ/1000);
  else
    schedule_timeout(ms/(1000/HZ));
  TRACE2(TRACE_VNODE, 9, TRCID_UNINT_SLEEP_END,
         "cxiUnInerruptibleSleep: end delay %d HZ %d\n", ms, HZ);
  EXIT(0);
}


void cxiOpenNFS(void *iP)
{
  struct inode *inodeP = (struct inode *)iP;
  int refcount;

  /* A reference is placed on the cxiNode here when the first NFS reference
     is added */
  ENTER(0);
  refcount = cxiRefOSNode(NULL, ((cxiNode_t *)(cxiGetCnP(inodeP))), iP, 1);

  TRACE7(TRACE_VNODE, 3, TRCID_OPENNFS,
        "openNFS iP 0x%lX inode %lld (0x%X) mode 0x%X nlink %u gen_ip 0x%lX "
        "refcount %d\n",
        inodeP, (inodeP) ? inodeP->i_ino : INVALID_INODE_NUMBER,
        (inodeP) ? inodeP->i_ino : INVALID_INODE_NUMBER,
        (inodeP) ? inodeP->i_mode : -1,
        (inodeP) ? inodeP->i_nlink : -1,
        (inodeP) ? inodeP->PRVINODE : NULL,
        refcount);

  DBGASSERT(refcount != 0);
  EXIT(0);
}


IntRC cxiCloseNFS(void *vP, void *viP, void *kernOpP)
{
  struct inode *iP = (struct inode *)vP;
  int rc;

  /* If viP is NULL, the file was never actually opened.
     If viP is not NULL, close it. */
  ENTER(0);
  if (viP == NULL || VP_TO_PVP(iP) == NULL || VP_TO_CNP(iP) == NULL)
    rc = 0;
  else
    rc = gpfs_ops.gpfsClose(VP_TO_PVP(iP), VP_TO_CNP(iP), FREAD|FWRITE,
                            (struct MMFSVInfo *)viP, true,
                            (struct KernelOperation *)kernOpP);

#if LINUX_KERNEL_VERSION > 2060000
  /* Prune disconnected dentries:
     When gpfs_nfsd_iget_dentry cannot find an existing dentry on the
     inode->i_dentry list, it allocates a new entry using d_alloc_anon,
     and the new dentry then remains in a disconnected state (subsequent
     gpfs_i_revalidate calls cannot splice it in on the right lists, since
     the code doesn't know what the object name or the parent dir).
     The problem is that when an NFS client tries to unlink the file, the
     anon dentry created by gpfs_nfsd_iget_dentry remains intact.  If we
     detect the unlink here during delayed NFS close, prune the denries
     in order to recover these. */

  if (iP->i_nlink == 0)
    d_prune_aliases(iP);
#endif

  /* Whether or not the open was ever done, we must remove the hold that
     GetNFS placed on the inode. */
  cxiPutOSNode((void *)iP);

  EXIT_RC(0, rc);
  return rc;
}

static int cxiNFSCluster = 0;

void cxiSetNFSCluster(int set)
{
  cxiNFSCluster = set;
}

int cxiGetNFSCluster()
{
  return cxiNFSCluster;
}

cxiIno_t cxiGetInodeNum(void *f)
{
  cxiIno_t ino = 0;
  struct file *fP = (struct file *)f;

  if (fP && fP->f_dentry && fP->f_dentry->d_inode)
    ino = fP->f_dentry->d_inode->i_ino;

  TRACE2(TRACE_VNODE, 3, TRCID_INO_NUM,
          "cxiGetInodeNum: fP 0x%lX ino %lld\n", fP, ino);

  return ino;
}

cxiIno_t cxiGetInodeNumber(void *vP)
{
  cxiIno_t ino = 0;
  struct inode *iP = (struct inode *)vP;

  if (iP)
    ino = iP->i_ino;

  return ino;
}

static int cxiPNFSmds = 0;

void cxiSetPNFSmds(int set)
{
  cxiPNFSmds = set;
}

int cxisPNFSmds()
{
  return cxiPNFSmds;
}

/* To avoid failing the NFS client the NFSD thread is put to sleep. Another
   node will takeover this client and the operation will continue without any
   errors to the application.
*/
void cxiNFSError(int rc, const char *str)
{
  static last_nfs_pid = 0;

  if (rc)
  {
    TRACE2(TRACE_VNODE, 3, TRCID_NFS_ERROR,
          "cxiNFSError: %s got rc %d\n", str, rc);

    if (cxiNFSCluster &&
        (cxiIsNFSThread()
#ifdef GANESHA
         || cxiIsGaneshaThread()
#endif
        )
        && (rc == ESTALE || rc == -ESTALE))
    {
      TRACE2(TRACE_VNODE, 1, TRCID_NFS_ERROR_1,
            "cxiNFSError: NFS got error %d from %s sleep\n", rc, str);

#ifdef GANESHA
      if ((cxiGetProcessId() == ganesha_tgid) &&
          (cxiGetProcessId() == last_nfs_pid))
        return;
#endif
      cxiUnInerruptibleSleep(120000); // wait 120 seconds

      last_nfs_pid = cxiGetProcessId();
    }
#ifdef GANESHA
    else if (cxiGetProcessId() == last_nfs_pid)
      last_nfs_pid = 0;
#endif
  }
}

void * cxiGetNfsP(void *vP)
{
  if (vP && VP_TO_CNP((struct inode *)vP))
    return VP_TO_NFSP((struct inode *)vP);
  else
    return NULL;
}

void cxiSetNfsP(void *vP, void *newP)
{
  if (VP_TO_CNP((struct inode *)vP))
    VP_TO_NFSP((struct inode *)vP) = newP;
}

void * cxiGetCnP(void *vP)
{ return (void *)VP_TO_CNP((struct inode *)vP); }

void * cxiGetPvP(void *vP)
{ return (void *)VP_TO_PVP((struct inode *)vP); }

void * cxiGNPtoVP(void *vP)
{ return (void *)GNP_TO_VP((struct cxiNode_t *)vP); }

Boolean cxiIsGpfsVP(void *vP)
{ return GPFS_TYPE(((struct inode *)vP)); }

/* Main routine of kproc */
static int kprocMain(void *argP)
{
  cxiKProcData_t *kpdP = (cxiKProcData_t *)argP;

  /* Change our process name */
  ENTER(0);
  current->comm[sizeof(current->comm) - 1] = '\0';
  strncpy(current->comm, kpdP->nameP, sizeof(current->comm) - 1);

#ifndef USE_KTHREAD_CREATE
  /* Change parent of a kernel process so that when it exits, it won't
   * send a SIGCHLD signal to the process that created it, and it won't
   * be left as a zombie.
   */
  daemonize(kpdP->nameP);
#endif

  /* Call the function specified by startKProc */
  kpdP->func(kpdP);
  EXIT(0);
  return 0;
}

/* Create a new kernel process */
cxiPid_t
cxiStartKProc(struct cxiKProcData_t *kpdP)
{
  cxiPid_t pid;
  struct task_struct *tP = NULL;

#ifndef USE_KTHREAD_CREATE
  pid  = kernel_thread(kprocMain, kpdP, kpdP->kprocFlags);
#else
  tP = kthread_run(kprocMain, kpdP, kpdP->nameP);
  if (IS_ERR(tP)) {
    pid = PTR_ERR(tP);
  }
  else {
    pid = tP -> pid;
  }
#endif
  ENTER(0);
  kpdP->pid = pid > 0 ? pid : KPROC_FAILED_PID;

  TRACE2(TRACE_VNODE, 1, TRCID_CXISTART_KPROC_LINUX,
         "cxiStartKProc %s pid %d \n", kpdP->nameP, kpdP->pid);
  EXIT(0);
  return kpdP->pid;
}

void
cxiStopKProc(struct cxiKProcData_t *kpdP)
{
  cxiPid_t pid;

  ENTER(0);
  cxiBlockingMutexAcquire(&kpdP->lock);

  TRACE2(TRACE_VNODE, 1, TRCID_CXISTOP_KPROC_LINUX,
         "cxiStopKProc: %s pid %d \n", kpdP->nameP, kpdP->pid);

  if (!KPROC_RUNNING(kpdP))
  {
    cxiBlockingMutexRelease(&kpdP->lock);
    EXIT(0);
    return;
  }

  pid = kpdP->pid;              // Cache pid before signal/wait
  kpdP->terminate = true;
  cxiWaitEventSignal(&kpdP->kprocEvent);

  while (kpdP->pid != KPROC_UNASSIGNED_PID)
    cxiWaitEventWait(&kpdP->startStopEvent, &kpdP->lock, 0);

  cxiBlockingMutexRelease(&kpdP->lock);
  EXIT(0);
}

/*-------------------------------------------------------------------
 * logAssertFailed  - Subroutine consolidating logGenIF() and
 *                    DoPanic() calls.
 *------------------------------------------------------------------*/

static char PanicMsgBuf[2048];

void cxiPanic(const char* panicStrP)
{
  printk( GPFS_NOTICE  "kp %d: cxiPanic: %s\n", cxiGetThreadId(), panicStrP);
  TRACE1(TRACE_ERRLOG, 0, TRCID_PANIC, "cxiPanic: %s\n", panicStrP);
#ifndef DISABLE_KERNEL_PANIC
  BUG();
#endif
}

static void
DoPanic(const char* condP, const char* filenameP, int lineNum, Int32 retCode,
        Int32 reasonCode, const char *dataStr)
{
  const char *p;
  int bytesLeft;

  p = cxiStrrchr(filenameP, '/');
  if (p == NULL)
    p = filenameP;
  else
    p += 1;

  sprintf(PanicMsgBuf, "%s:%d:%d:%d:", p, lineNum, retCode, reasonCode);
  bytesLeft = sizeof(PanicMsgBuf) - strlen(PanicMsgBuf);
  if (dataStr)
  {
    strncat(PanicMsgBuf, dataStr, bytesLeft-1);
    bytesLeft = sizeof(PanicMsgBuf) - strlen(PanicMsgBuf);
  }
  strncat(PanicMsgBuf, ":", bytesLeft-1);
  bytesLeft = sizeof(PanicMsgBuf) - strlen(PanicMsgBuf);
  if (condP)
    strncat(PanicMsgBuf, condP, bytesLeft-1);
  cxiPanic(PanicMsgBuf);
}

#ifdef MODULE
void
logAssertFailed(UInt32 flags,            /* LOG_FATAL_ERROR or LOG_NONFATAL_ERROR */
                const char *srcFileName, /* __FILE__ */
                UInt32 srcLineNumber,    /* __LINE__ */
                Int32  retCode,          /* return code value */
                Int32  reasonCode,       /* normally errno */
                UInt32 logRecTag,        /* tag if have associated error log rec */
                const char *dataStr,     /* assert data string */
                const char *failingExpr) /* expression that evaluated to false */
{
  int i;

  printk("GPFS logAssertFailed: %s file %s line %d\n",
         failingExpr, srcFileName, srcLineNumber);
  ENTER(0);
  TRACE3(TRACE_ERRLOG, 0, TRCID_MODULE_LOGASSERT_1,
         "logAssertFailed: %s retCode %d reasonCode %d\n",
         failingExpr, retCode, reasonCode);
  TRACE2(TRACE_ERRLOG, 0, TRCID_MODULE_LOGASSERT_2,
         "logAssertFailed: file %s line %d\n", srcFileName, srcLineNumber);
#ifndef GPFS_PRINTF
  /* fsync buffered lxtrace records */
  trc_fsync();

#ifdef STOP_TRACE_ON_FAILURE
  /* Turn off tracing right after the failure occurs.  This may only turn
     off tracing in the kernel. */
  for (i=0 ; i<MAX_TRACE_CLASSES ; i++)
    TraceFlagsP[i] = 0;
#endif

  /* Wait 10 seconds to allow the lxtrace daemon to complete the sync. */
  cxiSleep(10000);
#endif
  gpfs_ops.gpfsDaemonToDie(srcFileName, srcLineNumber, retCode, reasonCode,
                           dataStr, failingExpr);

  DoPanic(failingExpr, srcFileName, srcLineNumber, retCode, reasonCode,
          dataStr);
}
#else /* !MODULE */
void
logAssertFailed(UInt32 flags,
                const char *srcFileName,
                UInt32 srcLineNumber,
                Int32  retCode,
                Int32  reasonCode,
                UInt32 logRecTag,
                const char *dataStr,
                const char *failingExpr);
#endif /* MODULE */


typedef struct cxiWaitElement_t
{
  cxiWaitList_t waitList;  /* previous and next element in chain */

  /* Linux would normally organize a wait_queue_head_t with any number
   * of wait_queue_t elements.  However since we're implementing "wakeup
   * with return code" we have to ensure the OS wakes up the exact sleeper
   * we want.  Thus we have only a one to one relationship to ensure the
   * OS can only pick our favorite.
   */
  wait_queue_head_t qhead;
  wait_queue_t qwaiter;
  int wakeupRC;            /* wakeup return code */

} cxiWaitElement_t;


#define CXI_WAIT_LIST_ADD(headP, elementP) \
   (headP)->prevP->nextP = (elementP); \
   (elementP)->prevP = (headP)->prevP; \
   (headP)->prevP = (elementP);        \
   (elementP)->nextP = (headP);

#ifdef DBGASSERTS
/* The DBGASSERT version of this macro must set the removed element to
   point to itself, to satisfy the check after waking up in
   cxiWaitEventWait due to an explicit wakeup */
#define CXI_WAIT_LIST_REMOVE(elementP) \
   (elementP)->prevP->nextP = (elementP)->nextP; \
   (elementP)->nextP->prevP = (elementP)->prevP; \
   (elementP)->nextP = (elementP);               \
   (elementP)->prevP = (elementP);
#else
#define CXI_WAIT_LIST_REMOVE(elementP) \
   (elementP)->prevP->nextP = (elementP)->nextP; \
   (elementP)->nextP->prevP = (elementP)->prevP;
#endif


/* Initialize abstract wait event with OS specific
 * initialization function
 */
void
cxiWaitEventInit(cxiWaitEvent_t *weP)
{
  spinlock_t *lockP = (spinlock_t *)&weP->lword;

  spin_lock_init(lockP);
  weP->waitList.nextP = weP->waitList.prevP = &weP->waitList;
}

Boolean
cxiWaitEventHasWaiters(cxiWaitEvent_t *weP)
{
  unsigned long flags;
  spinlock_t *lockP = (spinlock_t *)(weP->lword);
  Boolean rc;

  spin_lock_irqsave(lockP, flags);
  rc = (weP->waitList.nextP != &weP->waitList);
  spin_unlock_irqrestore(lockP, flags);
  return rc;
}

/* Do not add trace records.  Some callers depend on not being
 * interrupted by the trace daemon.
 */
enum WakeType { wBroadcast, wSignal, wWakeOne };
static inline void
doWakeup(cxiWaitEvent_t *wEventP, enum WakeType wtype, int wakeupRC)
{
  unsigned long flags;
  spinlock_t *lockP = (spinlock_t *)(wEventP->lword);
  cxiWaitList_t *headP;
  cxiWaitList_t *tmpP;
  cxiWaitElement_t *wP;

  DBGASSERT(wakeupRC != 0);
  spin_lock_irqsave(lockP, flags);

  /* We wake up from the front back (FIFO semantics).  There's only one
     wait element per wake_queue_head_t, so record the return code and
     wake up the one element.  Remove cxiWaitElement_t from the waitList
     in the cxiWaitEvent_t when it is awakened. */
  headP = &wEventP->waitList;

  for (tmpP = headP->nextP; tmpP != headP; tmpP = headP->nextP)
  {
    CXI_WAIT_LIST_REMOVE(tmpP);

    wP = list_entry(tmpP, cxiWaitElement_t, waitList);
    wP->wakeupRC = wakeupRC;
    wake_up(&wP->qhead);
    if (wtype != wBroadcast)
    {
      /* There is no longer any difference between wSignal and wWakeOne;
         both behave like AIX, where the thread doing the wakeup removes
         the waitElement from the queue.

         Note:  This is an inline routine and the wType argument is a
         compile-time constant, so the "if" tests in this routine are done
         by the compiler and do not generate any code. */
      break;
    }
  }
  spin_unlock_irqrestore(lockP, flags);
}

int
cxiCopyIn(const char *from, char *to, size_t size)
{
  int ignore;

  /* The daemon needs to bypass access checks since copy to
   * shared segment would inadvertantly fail.
   */
  ENTER(0);
  if (PROCESS_GROUP(current) == DaemonPGrp)
    ignore = __copy_from_user(to, from, size);
  else
    if (copy_from_user(to, from, size))
    {
      EXIT_RC(0, EFAULT);
      return EFAULT;
    }
  EXIT(0);
  return 0;
}

int
cxiCopyOut(const char *from, char *to, size_t size)
{
  int ignore;
  /* The daemon needs to bypass access checks since copy to
   * shared segment would inadvertantly fail.
   */
  ENTER(0);
  if (PROCESS_GROUP(current) == DaemonPGrp)
    ignore = __copy_to_user(to, from, size);
  else
    if (copy_to_user(to, from, size))
    {
      EXIT_RC(0, EFAULT);
      return EFAULT;
    }
  EXIT(0);
  return 0;
}

int
cxiCopyInstr(const char *from, char *to, size_t size, size_t *len)
{
  size_t retval;

  ENTER(0);
  retval = strncpy_from_user(to, from, size);
  if ((retval > 0) && (retval <= size))
  {
    *len = retval;
    EXIT(0);
    return 0;
  }
  *len = 0;
  if (retval < 0)
    retval = EFAULT;
  else
    retval = E2BIG;
  EXIT_RC(0, retval);
  return (int)retval;
}

long cxiSafeGetLong(long* from)
{
  long tmp;
#ifdef GPFS_ARCH_S390X
  if (IS_KERNEL_ADDR(from))
    return *from;
#endif /* _GPFS_ARCH_S390X */
  __get_user(tmp, from);
  return tmp;
}

#if 0
/* If we are going access 64 bit values on 32 bit platforms we need a
   version of a function like this that would work to provide atomic
   access to a 64 bit value for sharing data between daemon and the kernel */
long long cxiSafeGetLongLong(volatile long long* from)
{
  long long tmp;
#ifdef GPFS_ARCH_S390X
  if (IS_KERNEL_ADDR(from))
    return *from;
#endif /* _GPFS_ARCH_S390X */
  __get_user(tmp, from);
  return tmp;
}
#endif /* Sample - Not Used */

int cxiSafeGetInt(int* from)
{
  int tmp;
#ifdef GPFS_ARCH_S390X
  if (IS_KERNEL_ADDR(from))
    return *from;
#endif /* _GPFS_ARCH_S390X */
  __get_user(tmp, from);
  return tmp;
}

void cxiSafePutLong(long val, long* to)
{
#ifdef GPFS_ARCH_S390X
  if (IS_KERNEL_ADDR(to))
  {
    *to = val;
    return;
  }
#endif /* _GPFS_ARCH_S390X */
  __put_user(val, to);
}

void cxiSafePutInt(int val, int* to)
{
#ifdef GPFS_ARCH_S390X
  if (IS_KERNEL_ADDR(to))
  {
    *to = val;
    return;
  }
#endif /* _GPFS_ARCH_S390X */
  __put_user(val, to);
}

#ifdef GPFS_ARCH_X86_64
/* Check if 64-bit user process */
int
cxiIS64U(char *addr)
{
#if LINUX_KERNEL_VERSION > 2060500
  return !(test_thread_flag(TIF_IA32));
#else
  return !(current->thread.flags & THREAD_IA32);
#endif
}
#endif

#ifdef GPFS_ARCH_PPC64
int
cxiIS64U(char* addr)
{
  return !(test_thread_flag(TIF_32BIT));
}
#endif

#ifdef GPFS_ARCH_S390X
int
cxiIS64U(char* addr)
{
  return !(test_thread_flag(TIF_31BIT));
}

static int primary_space_mode(void)
{
  unsigned int epsw;

  asm volatile(
    "epsw       %0,0\n"
    : "=d" (epsw));

  return !(epsw & 0x0000C000);
}

/*
 * Linux on System z architecture initialization
 */
int cxiCheckS390x(void)
{
  /* Ensure USERSPACE_MMAP_BOUNDARY is a valid boundary to distinguish
   * user space (daemon) and kernel spaces (vmalloc) addresses. */
  if ((unsigned long) VMALLOC_START <= USERSPACE_MMAP_BOUNDARY) {
    printk("GPFS mmfslinux for Linux on System z requires a "
           "region-second kernel address space\n");
    return -ENOMEM;
  }

  /* Ensure the kernel runs in primary space mode and, hence, user runs
   * in the home space mode (user_mode=home).
   * Note: The primary_space_mode() must run in kernel address space.
   */
  if (!primary_space_mode()) {
    printk("GPFS mmfslinux Linux on System z requires the "
           "user_mode=home kernel parameter to be specified\n");
    return -EINVAL;
  }

  return 0;
}

#endif


/* Transfer data from buffer(s) in user space to or from a buffer in the
   kernel. */
int
cxiUiomove(register char* kBufP,          /* address of kernel buffer */
           register size_t nBytes,        /* #bytes to transfer */
           Boolean toKernel,              /* direction of xfer(read/write)*/
           register struct cxiUio_t* uioP) /* user area description */
{
  register struct cxiIovec_t * iovP;
  size_t cnt;
  int rc;
#ifdef TRACE_IO_DATA
  char* origKBufP = kBufP;
  int trcdata[4];
#endif
  int ignore;

  ENTER(0);
  TRACE4(TRACE_FOPS, 6, TRCID_CXISYSTEM_037,
         "cxiUiomove enter: kBufP 0x%lX uioP 0x%lX nBytes %ld toKernel %d\n",
         kBufP, uioP, nBytes, toKernel);
  if (uioP->uio_resid <= 0)
  {
    EXIT_RC(0, ENOMEM);
    return ENOMEM;
  }
  rc = 0;
  if (uioP->uio_iovcnt == 1)
  {
    /*
     * Fastpath for most common case of iovcnt == 1.  Saves a
     * few instructions.
     */
    iovP = uioP->uio_iov;
    cnt = iovP->iov_len;
    if (cnt <= 0)
    {
      uioP->uio_iovcnt--;
      uioP->uio_iov++;
      uioP->uio_iovdcnt++;
      EXIT(0);
      return 0;
    }
    if (cnt > nBytes)
      cnt = nBytes;

    if (toKernel)
    {
      /* The daemon needs to bypass access checks since copy to
       * shared segment would inadvertantly fail.  Copies to
       * kernel address space also perform no validity check.
       */
      if (uioP->uio_segflg == UIO_SYSSPACE)
        memcpy(kBufP, (char *)iovP->iov_base, cnt);
      else if (PROCESS_GROUP(current) == DaemonPGrp)
        ignore = __copy_from_user(kBufP, (char *)iovP->iov_base, cnt);
      else
        if (copy_from_user(kBufP, (char *)iovP->iov_base, cnt))
        {
          EXIT_RC(0, EFAULT);
          return EFAULT;
        }
    }
    else
    {
      int spam;
      /* The daemon needs to bypass access checks since copy to
       * shared segment would inadvertantly fail.  Copies to
       * kernel address space also perform no validity check.
       */
      if (uioP->uio_segflg == UIO_SYSSPACE)
        memcpy((char *)iovP->iov_base, kBufP, cnt);
      else if (PROCESS_GROUP(current) == DaemonPGrp)
        ignore = __copy_to_user((char *)iovP->iov_base, kBufP, cnt);
      else
        if (copy_to_user((char *)iovP->iov_base, kBufP, cnt))
        {
          EXIT_RC(0, EFAULT);
          return EFAULT;
        }
    }

    iovP->iov_base = (char *)iovP->iov_base + cnt;
    iovP->iov_len -= cnt;
    uioP->uio_resid -= cnt;
    uioP->uio_offset += cnt;
#ifdef TRACE_IO_DATA
    if (cnt >= sizeof(trcdata))
      memcpy(trcdata, origKBufP, sizeof(trcdata));
    else
    {
      memset(trcdata, 0xAA, sizeof(trcdata));
      memcpy(trcdata, origKBufP, cnt);
    }
    TRACE5(TRACE_FOPS, 7, TRCID_CXISYSTEM_039a,
           "uiomove exit 1: rc %d data %08X %08X %08X %08X\n",
           rc, trcdata[0], trcdata[1], trcdata[2], trcdata[3]);
#else
    TRACE1(TRACE_FOPS, 7, TRCID_CXISYSTEM_039,
           "uiomove exit 1: rc %d\n",
           rc);
#endif
    EXIT_RC(0, rc);
    return rc;
  }
  while (nBytes > 0 && uioP->uio_resid && rc == 0)
  {
    if (uioP->uio_iovcnt <= 0)
    {
      EXIT_RC(0, ENOMEM);
      return ENOMEM;
    }
    iovP = uioP->uio_iov;
    cnt = iovP->iov_len;
    if (cnt <= 0)
    {
      uioP->uio_iovcnt--;
      uioP->uio_iov++;
      uioP->uio_iovdcnt++;
      continue;
    }
    if (cnt > nBytes)
      cnt = nBytes;

    if (toKernel)
    {
      /* The daemon needs to bypass access checks since copy to
       * shared segment would inadvertantly fail.  Copies to
       * kernel address space also perform no validity check.
       */
      if (uioP->uio_segflg == UIO_SYSSPACE)
        memcpy(kBufP, (char *)iovP->iov_base, cnt);
      else if (PROCESS_GROUP(current) == DaemonPGrp)
        ignore = __copy_from_user(kBufP, (char *)iovP->iov_base, cnt);
      else
        if (copy_from_user(kBufP, (char *)iovP->iov_base, cnt))
        {
          EXIT_RC(0, EFAULT);
          return EFAULT;
        }
    }
    else
    {
      /* The daemon needs to bypass access checks since copy to
       * shared segment would inadvertantly fail.  Copies to
       * kernel address space also perform no validity check.
       */
      if (uioP->uio_segflg == UIO_SYSSPACE)
        memcpy((char *)iovP->iov_base, kBufP, cnt);
      else if (PROCESS_GROUP(current) == DaemonPGrp)
        ignore = __copy_to_user((char *)iovP->iov_base, kBufP, cnt);
      else
        if (copy_to_user((char *)iovP->iov_base, kBufP, cnt))
        {
          EXIT_RC(0, EFAULT);
          return EFAULT;
        }
    }
    iovP->iov_base = (char *)iovP->iov_base + cnt;
    iovP->iov_len -= cnt;
    uioP->uio_resid -= cnt;
    uioP->uio_offset += cnt;
    kBufP += cnt;
    nBytes -= cnt;
  }
#ifdef TRACE_IO_DATA
  cnt = kBufP - origKBufP;
  if (cnt >= sizeof(trcdata))
    memcpy(trcdata, origKBufP, sizeof(trcdata));
  else
  {
    memset(trcdata, 0xAA, sizeof(trcdata));
    memcpy(trcdata, origKBufP, cnt);
  }
  TRACE5(TRACE_FOPS, 7, TRCID_CXISYSTEM_041a,
         "uiomove exit 2: rc %d data %08X %08X %08X %08X\n",
         rc, trcdata[0], trcdata[1], trcdata[2], trcdata[3]);
#else
  TRACE1(TRACE_FOPS, 7, TRCID_CXISYSTEM_041,
         "uiomove exit 2: rc %d\n",
         rc);
#endif
  EXIT_RC(0, rc);
  return rc;
}

/*
  Try to force some sanity checks at compile type
 */
/* TO DO: revise this to handle comparisons beyond equality/inequality */
/* STATIC_DBGASSERT(sizeof(spinlock_t), SPINLOCK_T_SIZE); */

/* A routine to check that the definitions in our cxiTypes.h
 * files are equivalent to the system definitions.  The module
 * should not load if it receives an error from this routine.
 */
int
cxiCheckTypes()
{
  int rc = 0;
  ENTER(0);

  /* Make sure cxiBlockingMutex_t fits in the space provided.  If not,
     the implementation of the cxiBlockingMutex... routines needs to
     use the embedded space to record a pointer to kmalloc'ed space holding
     the semaphore. */
  if (sizeof(struct semaphore) > GPFS_LINUX_SEM_SIZE)
  {
    printk("cxiCheckTypes: semaphore %u > GPFS_LINUX_SEM_SIZE %d\n",
           (unsigned int)sizeof(struct semaphore), GPFS_LINUX_SEM_SIZE);
    rc = 1;
  }

  /* Size of spinlock_t is smaller for UP case with gcc 3.x, so just
     insure SPINLOCK_T_SIZE is large enough for both the UP and SMP case. */
  if (sizeof(spinlock_t) > SPINLOCK_T_SIZE)
  {
    printk("cxiCheckTypes: spinlock_t %u > SPINLOCK_T_SIZE %d\n",
           (unsigned int)sizeof(spinlock_t), SPINLOCK_T_SIZE);
    rc = 2;
  }

  /* Ensure that size of pid_t matches cxiThreadId (32-bits) */
  if (sizeof(pid_t) != sizeof(cxiThreadId))
  {
    printk("cxiCheckTypes: pid_t %u != cxiThreadId %u\n",
           (unsigned int)sizeof(pid_t), (unsigned int)sizeof(cxiThreadId));
    rc = 3;
  }

  if (rc > 0)
    TRACE1(TRACE_TASKING, 2, TRCID_CXISYSTEM_CHKTYPES,
           "cxiCheckTypes: system type mismatch on type number %d!\n", rc);
  EXIT_RC(0, rc);
  return rc;
}

/* Routine to get current time of day in nanosecond format.  This is called
   from an I/O completion routine, so it must not do any tracing. */
int
cxiGetTOD(cxiTimeStruc_t *tsP)
{
  struct timespec ts;

#if (LINUX_KERNEL_VERSION >= 2061800)
  getnstimeofday(&ts);
#else
  ts = CURRENT_TIME;
#endif
  tsP->tv_sec = ts.tv_sec;
  tsP->tv_nsec = ts.tv_nsec;

  return 0;
}

Boolean
cxiIsNFSThread()
{
# if defined(GPFS_LITTLE_ENDIAN) && !defined(__64BIT__)
    /* Note comparison against a multibyte character constant (not a string
      constant).  Order of characters in word is reversed due to little-
      endian representation of integers. */
    if (* ((int*)&current->comm[0]) != 0x6473666e) // 'dsfn'
       return false;
    if (* ((char*)&current->comm[4]) == '\0')
       return true;
    return (* ((int*)&current->comm[2]) == 0x00346473);  // '4ds'
# else
    if ((strcmp(current->comm, "nfsd") == 0) ||
        (strcmp(current->comm, "nfsd4") == 0))
      return true;
    return false;
# endif
}

Boolean
cxiIsGaneshaThread()
{
#ifdef GANESHA
  TRACE4(TRACE_VNODE, 5, TRCID_IS_GANESHA_1,
        "cxiIsGaneshaThread: ganesha_tgid %d tgid %d pid %d %s ",
         ganesha_tgid, cxiGetProcessId(), current->pid, current->comm);

#if 0 // use name
  if (strncmp(current->comm, "gpfs.ganesha", 12) == 0)
#else // use tgid
  if (cxiGetProcessId() == ganesha_tgid)
#endif
    return true;
#endif
  return false;
}

Boolean
cxiIsLockdThread()
{
# if defined(GPFS_LITTLE_ENDIAN) && !defined(__64BIT__)
    /* Note comparison against a multibyte character constant (not a string
      constant).  Order of characters in word is reversed due to little-
      endian representation of integers. */
    if ((* ((int*)&current->comm[0]) != 0x6b636f6c) |  // 'kcol'
        (* ((int*)&current->comm[2]) != 0x00646b63));  // ' dkc'
       return false;
    return * ((char*)&current->comm[5]) == '\0';
# else
    return (strcmp(current->comm, "lockd") == 0);
# endif
}

Boolean
cxiIsNFS4Thread()
{
# if defined(GPFS_LITTLE_ENDIAN) && !defined(__64BIT__)
    /* Note comparison against a multibyte character constant (not a string
      constant).  Order of characters in word is reversed due to little-
      endian representation of integers. */
    if ((* ((int*)&current->comm[0]) != 0x6473666e) |  // 'dsfn'
        (* ((int*)&current->comm[2]) != 0x00346473));  // '4ds'
       return false;
    return * ((char*)&current->comm[5]) == '\0';
# else
    return (strcmp(current->comm, "nfsd4") == 0);
# endif
}

Boolean
cxiIsKupdateThread()
{
  /* In 2.6 pdflush replaced kupdated and bdflush from 2.4 */
  return CURRENT_IS_PDFLUSH();
}

#ifdef SMB_LOCKS
Boolean
cxiIsSambaOrLockdThread()
{
# if defined(GPFS_LITTLE_ENDIAN) && !defined(__64BIT__)
    /* Note comparison against a multibyte character constant (not a string
      constant).  Order of characters in word is reversed due to little-
      endian representation of integers. */
    Boolean rc = (((* ((int*)&current->comm[0]) == 0x64626d73) &   // 'dbms'
                   (* ((char*)&current->comm[4]) == '\0'))    |
                  ((* ((int*)&current->comm[0]) == 0x6b636f6c) &   // 'kcol'
                   (* ((int*)&current->comm[2]) == 0x00646b63)));  // 'dkc'
    if (!rc)
      return gpfs_ops.gpfsIsCifs();
    else
      return rc;
# else
    return (((strcmp(current->comm, "smbd") == 0)  |
             (strcmp(current->comm, "lockd") == 0)) ||
             gpfs_ops.gpfsIsCifs());
# endif
}

Boolean
cxiIsSambaThread()
{
# if defined(GPFS_LITTLE_ENDIAN) && !defined(__64BIT__)
    /* Note comparison against a multibyte character constant (not a string
      constant).  Order of characters in word is reversed due to little-
      endian representation of integers. */
    Boolean rc = ((* ((int*)&current->comm[0]) == 0x64626d73) &  // 'dbms'
                  (* ((char*)&current->comm[4]) == '\0'));
    if (!rc)
      return gpfs_ops.gpfsIsCifs();
    else
      return rc;
# else
    return ((strcmp(current->comm, "smbd") == 0) ||
            gpfs_ops.gpfsIsCifs());
# endif
}
#endif

Boolean
cxiIsGPFSThread()
{
# if defined(GPFS_LITTLE_ENDIAN) && !defined(__64BIT__)
  return (((* ((int*)&current->comm[0]) == 0x73666d6d) &  // 'sfmm'
           (* ((int*)&current->comm[2]) == 0x00647366))); // 'dsf'
# else
  return (strcmp(current->comm, "mmfsd") == 0);
# endif
}

Boolean
cxiIsCriticalThread()
{
  /* Some threads should not be blocked in vain, or a deadlock may soon
     follow.  kswapd is one, but other threads on the memory allocation
     path should be treated as critical as well. */
  return current->flags & (PF_KSWAPD | PF_MEMALLOC);
}

Boolean cxiIsGpfsSwapdThread()
{
  return (strcmp(current->comm, "gpfsSwapdKproc") == 0);
}

#ifdef GPFS_CACHE
/* Check if the command is issued from localls group */
Boolean cxiIsPcacheLsThread()
{
  return ( GID_EQ(CRED(current, gid), MAKE_KGID(PCACHE_LOCALLS_GID)) );
}

/* Check if the command is issued from localstat group */
Boolean cxiIsPcacheStatThread()
{
  return ( GID_EQ(CRED(current, gid), MAKE_KGID(PCACHE_LOCALSTAT_GID)) );
}

/* Check if the command is issued from localrm group */
Boolean cxiIsPcacheRmThread()
{
  return ( GID_EQ(CRED(current, gid), MAKE_KGID(PCACHE_LOCALRM_GID))) ||
           ( CRED_GROUPS(current) && CRED_GRP(current, ngroups) > 0 &&
             GID_EQ(GROUP_AT(CRED_GROUPS(current), CRED_GRP(current, ngroups-1)), MAKE_KGID(PCACHE_LOCALRM_GID)));
}
Boolean cxiIsTSPcacheThread()
{
  return ( GID_EQ(CRED(current, gid), MAKE_KGID(PCACHE_TSPCACHE_GID)) );
}

Boolean cxiIsPcacheListdirtyThread()
{
  return ( GID_EQ(CRED(current, gid), MAKE_KGID(PCACHE_LISTDIRTY_GID)) );
}

Boolean cxiIsPcacheNativeThread()
{
  return ( CRED_GROUPS(current) && CRED_GRP(current, ngroups) > 0 &&
           GID_EQ(GROUP_AT(CRED_GROUPS(current), CRED_GRP(current, ngroups-1)), MAKE_KGID(PCACHE_NATIVE_GID)));
}
#endif

#ifdef INSTRUMENT_LOCKS
void InitBlockingMutexStats()
{
  memset(BlockingMutexStatsTable, 0, sizeof(BlockingMutexStatsTable));
}
#endif

/* Initialize a cxiBlockingMutex_t.  Instead of the DBGASSERT, this routine
   should kmalloc a struct semaphore if bmSem is too small.  */
void cxiBlockingMutexInit(cxiBlockingMutex_t* mP, int bmNameIdx)
{
  ENTER(0);
  DBGASSERT(sizeof(struct semaphore) <= GPFS_LINUX_SEM_SIZE);
#ifdef INSTRUMENT_LOCKS
  DBGASSERT(bmNameIdx < MAX_GPFS_LOCK_NAMES);
#endif  /* INSTRUMENT_LOCKS */

  TRACE2(TRACE_KLOCKL, 3, TRCID_BM_INIT,
         "cxiBlockingMutexInit: mP 0x%lX idx %d\n",
         mP, bmNameIdx);
  init_MUTEX((struct semaphore *)mP->bmSem);
  mP->bmOwnerP = NULL;
  mP->lockNameIndex = bmNameIdx;
  EXIT(0);
}


/* Enter critical section, blocking this thread if necessary.  Mark this
   thread as the owner of the mutex before returning. */
void
REGPARMS cxiBlockingMutexAcquire(cxiBlockingMutex_t* mP)
{
  ENTER(1);
  TRACE4(TRACE_KLOCKL, 9, TRCID_BM_ACQ,
         "cxiBlockingMutexAcquire: about to acquire 0x%lX type %d "
         "current 0x%lX currentOwner 0x%lX\n",
         mP, mP->lockNameIndex, current, mP->bmOwnerP);

  DBGASSERTRC(mP->bmOwnerP != (char *)current,
              PTR_TO_INT32(mP->bmOwnerP), PTR_TO_INT32(mP), 0);

#ifdef INSTRUMENT_LOCKS
  BlockingMutexStatsTable[mP->lockNameIndex].bmsAcquires += 1;
  if (mP->bmOwnerP != NULL)
  {
    BlockingMutexStatsTable[mP->lockNameIndex].bmsConflicts += 1;

#ifdef LOCK_TRACING
    gpfs_ops.gpfsInsertTraceInfo(mP, 8, mP->lockNameIndex);
#endif
  }
#endif

  down((struct semaphore *)mP->bmSem);
  mP->bmOwnerP = (char *)current;

  TRACE1(TRACE_KLOCKL, 9, TRCID_BM_ACQ_EXIT,
         "cxiBlockingMutexAcquire: returning after acquiring 0x%lX\n", mP);

#ifdef LOCK_TRACING
 gpfs_ops.gpfsInsertTraceInfo(mP, 1, mP->lockNameIndex);
#endif
  EXIT(1);
}

/* Same as cxiBlockingMutexAcquire, but without traces and
   other non-essential code.  To be called only from
   performance-critical paths. */
void
REGPARMS cxiBlockingMutexAcquireFast(cxiBlockingMutex_t* mP)
{
  down((struct semaphore *)mP->bmSem);
  mP->bmOwnerP = (char *)current;
}

/* Leave critical section and awaken waiting threads */
void
REGPARMS cxiBlockingMutexRelease(cxiBlockingMutex_t* mP)
{
  ENTER(1);
  TRACE4(TRACE_KLOCKL, 9, TRCID_BM_REL,
         "cxiBlockingMutexRelease: about to release 0x%lX type %d "
         "current 0x%lX currentOwner 0x%lX\n",
         mP, mP->lockNameIndex,current, mP->bmOwnerP);

  if (mP->bmOwnerP == (char *)current)
  {
     mP->bmOwnerP = NULL;
     up((struct semaphore *)mP->bmSem);
  }

#ifdef LOCK_TRACING
   gpfs_ops.gpfsInsertTraceInfo(mP, 2, mP->lockNameIndex);
#endif

  EXIT(1);
}

/* Same as cxiBlockingMutexRelease, but without traces and
   other non-essential code.  To be called only from
   performance-critical paths. */
void
REGPARMS cxiBlockingMutexReleaseFast(cxiBlockingMutex_t* mP)
{
  if (mP->bmOwnerP == (char *)current)
  {
     mP->bmOwnerP = NULL;
     up((struct semaphore *)mP->bmSem);
  }
}


/* Free resources associated with this cxiBlockingMutex_t in preparation
   for freeing the storage it occupies */
void cxiBlockingMutexTerm(cxiBlockingMutex_t* mP)
{
  ENTER(0);
  TRACE2(TRACE_KLOCKL, 3, TRCID_BM_TERM,
         "cxiBlockingMutexTerm: mP 0x%lX type %d\n", mP, mP->lockNameIndex);

  /* Verify that mutex is not held */
  DBGASSERT(mP->bmOwnerP == NULL);
  DBGASSERT(SEM_COUNT((struct semaphore *)mP->bmSem) == 1);
  EXIT(0);
}


/* Return true if a cxiBlockingMutex_t is held by the calling process */
Boolean
cxiBlockingMutexHeldByCaller(cxiBlockingMutex_t* mP)
{
  Boolean result;
  char* ownerP;
  cxiPid_t ownerPid;

  /* Cache bmOwnerP is case it changes to NULL */
  ENTER(0);
  ownerP = mP->bmOwnerP;
  if (ownerP == NULL)
    result = false;
  else
  {
    cxiThreadPtrToThreadId(ownerP, &ownerPid);
    result = (current->pid == ownerPid);
  }
  TRACE2(TRACE_KLOCKL, 9, TRCID_CXISYSTEM_017,
         "cxiBlockingMutexHeldByCaller: owner 0x%lX returns %d\n",
         ownerP, result);
  EXIT_RC(0, result);
  return result;
}


/* Return true if a cxiBlockingMutex_t has one or more processes waiting
   on it */
Boolean cxiBlockingMutexHasWaiters(cxiBlockingMutex_t* mP)
{
  struct semaphore * semP = (struct semaphore *)mP->bmSem;
  Boolean result;

  ENTER(0);
#ifdef PREEMPT_RT_LINUX_PATCH
  if (SEM_COUNT(semP) > 0)
#else
  if ((void*)SEM_WAIT_TASKLIST(semP).next != (void*)&SEM_WAIT_TASKLIST(semP).next)
#endif
    result = true;
  else
    result = false;
  TRACE2(TRACE_KLOCKL, 9, TRCID_CXISYSTEM_018,
         "cxiBlockingMutexHasWaiters: mP 0x%lX hasWaiters %d\n",
         mP, result);
  EXIT_RC(0, result);
  return result;
}


/* Wait for a cxiWaitEventSignal, cxiWaitEventBroadcast, or
   cxiWaitEventBroadcastRC.  Drop the associated cxiBlockingMutex_t
   *mutexP while waiting, and reacquire it before returning.
   If INTERRUPTIBLE is set in waitFlags, waits interruptibly;
   otherwise, waits uninterruptibly.
     Returns THREAD_INTERRUPTED if interrupted before being woken up,
   THREAD_AWAKENED, if woken up by cxiWaitEventSignal or
   cxiWaitEventBroadcast, or the result value passed to
   cxiWaitEventBroadcastRC, if woken up by cxiWaitEventBroadcastRC. */
int cxiWaitEventWait(cxiWaitEvent_t* weP, cxiBlockingMutex_t* mutexP,
                     int waitFlags)
{
  spinlock_t *lockP = (spinlock_t *)(weP->lword);
  unsigned long flags;
  cxiWaitElement_t waitElement;
  int count = 0;
  int rc;

  ENTER(0);
  TRACE3(TRACE_KLOCKL, 3, TRCID_CXISYSTEM_EVENT_WAIT_ENTER,
         "cxiWaitEventWait enter: weP 0x%lX waitFlags 0x%X about to release "
         "mutex 0x%lX \n", weP, waitFlags, mutexP);

  /* Verify that caller is holding the mutex */
  DBGASSERTRC(mutexP->bmOwnerP == (char *)current,
              PTR_TO_INT32(mutexP->bmOwnerP), PTR_TO_INT32(mutexP), 0);

  /* initialize our wait element */
  init_waitqueue_head(&waitElement.qhead);
  init_waitqueue_entry(&waitElement.qwaiter, current);
  __add_wait_queue(&waitElement.qhead, &waitElement.qwaiter);
  waitElement.wakeupRC = 0;

  /* update our task state to not running any more */
  if (waitFlags & INTERRUPTIBLE)
    current->state = TASK_INTERRUPTIBLE;
  else
    current->state = TASK_UNINTERRUPTIBLE;

  /* add our wait element to the end of the wait list */
  spin_lock_irqsave(lockP, flags);
  CXI_WAIT_LIST_ADD(&weP->waitList, &waitElement.waitList);
  spin_unlock_irqrestore(lockP, flags);

  /* Release the mutex.  Note: calling cxiBlockingMutexRelease here is
     problematic, because it makes trace calls, which may block the current
     process, which would overwrite the task state (current->state) we just
     updated.  A way around this would be to move out task state update to
     after the call to cxiBlockingMutexRelease, but then, before calling
     schedule(), we would have to re-acquire the wait-list lock and check
     wakeupRC to see whether somebody has already woken us up since we
     released the mutex.  Since there is a trace at the top of this routine,
     we don't need the one in cxiBlockingMutexRelease; hence, just do the
     release right here. */
  mutexP->bmOwnerP = NULL;
  up((struct semaphore *)mutexP->bmSem);

#ifdef LOCK_TRACING
   gpfs_ops.gpfsInsertTraceInfo(mutexP, 2, mutexP->lockNameIndex);
#endif
again:
  /* call the scheduler */
  schedule();

  /* Remove ourself from the wait list ... except:
     Even though we may enter uninterrubtible sleep, this sleep can in
     fact be interrupted in at least two scenarios:
     1) page_alloc code may call wakeup_kswapd().  This should be
        a very rare event with the current code, since we make an effort
        to avoid blocking kswapd.
     2) While signals are supposed to be ignored during uninterruptible
        sleep, it turns out that some signals, e.g. SIGSEGV and SIGBUS,
        cause us to wake up.  It doesn't look like the signal has been
        delivered yet, but sleep is interrupted.  The signal will be
        delivered later (probably when exiting kernel).
     Our callers can't handle unexpected return from uninterruptible
     sleep.  In either of the two cases above, it should be safe to go
     back to sleep and wait to be woken up properly.
   */
  spin_lock_irqsave(lockP, flags);

  if (waitElement.wakeupRC == 0)
  {
    /* A zero wakeup code means we were interrupted rather than woken
       up.  If not waiting interruptibly, go back and wait again.  If
       waiting interruptibly, remove this waitElement from the list of
       waiters and return. */
    if ((waitFlags & INTERRUPTIBLE) == 0)
    {
      TRACE3N(TRACE_KLOCKL, 1, TRCID_CXISYSTEM_EVENT_WAIT_INTERRUPTED,
              "cxiWaitEventWait: interrupted weP 0x%lX mutexP 0x%lX rc %d\n",
              weP, mutexP, waitElement.wakeupRC);
      current->state = TASK_UNINTERRUPTIBLE;
      spin_unlock_irqrestore(lockP, flags);
      goto again;
    }
    else
    {
      DBGASSERT(waitElement.waitList.nextP != &waitElement.waitList);
      CXI_WAIT_LIST_REMOVE(&waitElement.waitList);
      rc = THREAD_INTERRUPTED;
    }
  }
  else
  {
    /* Wake up that was explicitly requested by doWakeup.  At this
       point, waitElement must have already been removed from the
       waitList of its cxiWaitEvent_t by doWakeup. */
    DBGASSERT(waitElement.waitList.nextP == &waitElement.waitList);
    rc = waitElement.wakeupRC;
  }

  spin_unlock_irqrestore(lockP, flags);

  /* re-acquire the mutex */
  cxiBlockingMutexAcquire(mutexP);

  TRACE3(TRACE_KLOCKL, 9, TRCID_CXISYSTEM_EVENT_WAIT_EXIT,
         "cxiWaitEventWait exit: weP 0x%lX mutexP 0x%lX rc %d\n",
         weP, mutexP, waitElement.wakeupRC);

  EXIT(0);
  return rc;
}

/* Wake up one thread waiting on this cxiWaitEvent_t.  Must not sleep */
void
cxiWaitEventSignal(cxiWaitEvent_t* weP)
{
  /* ENTER(0); */
  TRACE1N(TRACE_KLOCKL, 3, TRCID_CXISYSTEM_SIGNAL,
         "cxiWaitEventSignal: weP 0x%lX\n", weP);

  doWakeup(weP, wSignal, THREAD_AWAKENED); /* wake up one */
  /* EXIT(0); */
}


/* Wake up one thread waiting on this cxiWaitEvent_t.  This is the same as
   cxiWaitEventSignal(), except this routine guarantees that multiple wake
   up calls will each pick a different thread if more than one is waiting. */
void
cxiWaitEventWakeupOne(cxiWaitEvent_t* weP)
{
  /* ENTER(0); */
  TRACE1(TRACE_KLOCKL, 3, TRCID_CXISYSTEM_WAKEUP_ONE,
         "cxiWaitEventWakeupOne: weP 0x%lX\n", weP);

  doWakeup(weP, wWakeOne, THREAD_AWAKENED); /* wake up one */
  /* EXIT(0); */
}


/* Wake up all threads waiting on this cxiWaitEvent_t */
void
cxiWaitEventBroadcast(cxiWaitEvent_t* weP)
{
  ENTER(0);
  TRACE1(TRACE_KLOCKL, 3, TRCID_CXISYSTEM_BROADCAST,
         "cxiWaitEventBroadcastRC: weP 0x%lX\n", weP);

  doWakeup(weP, wBroadcast, THREAD_AWAKENED); /* wake up all */
  EXIT(0);
}


/* Wake up all threads waiting on this cxiWaitEvent_t and cause them to
   return rc from their cxiWaitEventWait calls. */
void
cxiWaitEventBroadcastRC(cxiWaitEvent_t* weP, int rc)
{
  ENTER(0);
  TRACE2(TRACE_KLOCKL, 3, TRCID_CXISYSTEM_BROADCAST_RC,
         "cxiWaitEventBroadcastRC: weP 0x%lX rc %d\n", weP, rc);

  doWakeup(weP, wBroadcast, rc);  /* wake up all */
  EXIT_RC(0, rc);
}

/* alloc big memory area */
void *
cxiBigMalloc(int size)
{
  void *ptr;

  ENTER(0);
  ptr = vmalloc(size);

#ifdef MALLOC_DEBUG
  MallocDebugNew(ptr, size, 2);
#endif

  EXIT(0);
  return ptr;
}

/* free big memory area */
void
cxiBigFree(char *ptr)
{
  ENTER(0);
#ifdef MALLOC_DEBUG
  MallocDebugDelete(ptr);
#endif

  EXIT(0);
  vfree(ptr);
}

#ifdef SMB_LOCKS
/* Determine if current process has this file open */
void *
cxiCheckOpen(struct cxiNode_t* cnP)
{
  int count;
  int i;
  struct file** fdList;
  struct file*  fileP;
  struct inode* inodeP;
  void* foundP = NULL;

  ENTER(0);

  /* Need to traverse fd list while holding file_lock, to synchronize
     with fd list expansion. */
  spin_lock(&current->files->file_lock);

#if LINUX_KERNEL_VERSION >= 2061300
  count = current->files->fdt->max_fds;
  fdList = current->files->fdt->fd;
#else
  count = current->files->max_fds;
  fdList = current->files->fd;
#endif
  inodeP = GNP_TO_VP(cnP);

  TRACE3(TRACE_VNODE,9,TRCID_CXICHECKOPEN_ENTRY,
         "cxiCheckOpen: entry.  %d files in fd list. Checking for inode %lld "
         "at 0x%x", count, inodeP->i_ino, inodeP);

  for (i = 0; i < count; i++)
  {
    fileP = fdList[i];

    if (fileP != NULL &&
        fileP->f_dentry != NULL &&
        fileP->f_dentry->d_inode == inodeP)
    {
      TRACE1(TRACE_VNODE, 9,TRCID_CXICHECKOPEN_FOUND,
             "cxiCheckOpen: found open file. vinfoP 0x%x",
             fileP->private_data);
      foundP = fileP->private_data;
      break;
    }
  }
  spin_unlock(&current->files->file_lock);

  EXIT(0);
  return foundP;
}

IntRC cxiBreakOplock(void *breakArgP, int oplockNew)
{
  /* On Linux, we use its kernel oplock support.  The get_lease()
   * call is the operation to revoke conflicting leases.
   */
  int rc;
  ENTER(0);

  /* O_NONBLOCK: prevents the thread from waiting for the lease return.
   * In the case of a Samba thread, we only want to get EWOULDBLOCK
   * back if the conflict is held within Samba iteself. If a wait is
   * needed, breakSMBOplock will invoke cxiWaitForBreak.
   */

  /* Linux op to revoke conflicting leases */
  rc = abs(break_lease((struct inode *)breakArgP,
                       (cxiIsSambaThread()? 0: O_NONBLOCK) |
                       ((oplockNew==smbOplockShared)? FMODE_READ: FMODE_WRITE)));

  TRACE3(TRACE_VNODE, 4,TRCID_CXIBREAKOPLOCK,
         "cxiBreakOplock: exit rc %d inode 0x%lX oplock %d\n",
          rc, breakArgP, oplockNew);

  EXIT(0);
  return rc;
}

DECLARE_WAIT_QUEUE_HEAD(oplock_break_queue);

/* No initialization required on Linux */
IntRC cxiInitBreakQ() { return 0; }

/* No initialization required on Linux */
IntRC cxiTermBreakQ() { return 0; }

/* Send the notification that the oplock break completed */
IntRC cxiSendBreakMsg(void *ofP)
{
  ENTER(0);
  /* There is only one oplock_break_queue, and no means to pass the ofP back to
   * the waiters.  This will wake all of them up and they will recheck their
   * oplock states and wait again if necessary (with a timeout).
   */
   wake_up_interruptible(&oplock_break_queue);

  TRACE1(TRACE_SMB, 3, TRCID_SEND_BREAK, "cxiSendBreakMsg: ofP 0x%lX\n", ofP);
  EXIT(0);
  return 0;
}

/* Suspend the caller until either the oplock break completes, or the timeout
 * is reached.
 */
IntRC cxiWaitForBreak(void *fileArgP, int oplockCurrent, int timeoutSeconds)
{
  DECLARE_WAITQUEUE(wait, current);
  signed long timeout;

  ENTER(0);
  TRACE3(TRACE_SMB, 5, TRCID_BREAKWAIT,
         "cxiWaitForBreak: file 0x%lX, oplockCurrent %d timeoutSeconds %d\n",
         fileArgP, oplockCurrent, timeoutSeconds);

  add_wait_queue(&oplock_break_queue, &wait);
  timeout = timeoutSeconds * HZ;
  while (timeout > 0) {
    set_current_state(TASK_INTERRUPTIBLE);
    /* Check whether the oplock has been released or downgraded */
    if (gpfs_ops.SMBGetOplockState(fileArgP) < oplockCurrent)
      break;
    timeout = schedule_timeout(timeout);
  }
  set_current_state(TASK_RUNNING);
  remove_wait_queue(&oplock_break_queue, &wait);

  TRACE0(TRACE_SMB, 5, TRCID_BREAKWAIT_EXIT,
         "cxiWaitForBreak exit\n");

  EXIT(0);
  return 0;
}
#endif


/* Get the address of the first byte not addressible by processes */
UIntPtr cxiGetKernelBoundary()
{
  return GPFS_KERNEL_OFFSET;
}


/* Get the kernel page size */
unsigned long cxiGetKernelPageSize()
{
  return PAGE_SIZE;
}

/* Get fixed address and size of pagepool and TM pool */
void cxiGetFixedAddrs(char **kPagePoolLowerPP, char **kPagePoolUpperPP,
                      char **kTMPoolPP, Int64 *kTMPoolSizeP)
{
  TRACE4(TRACE_SHARED, 1, TRCID_FIXED_ADDRS_ENTER,
         "cxiGetFixedAddrs: enter pp low 0x%lX pp upper 0x%lX TM pool 0x%lX TM pool size %ld",
         *kPagePoolLowerPP, *kPagePoolUpperPP, *kTMPoolPP, *kTMPoolSizeP);

  GPL_GET_FIXED_ADDRS(*kPagePoolLowerPP,*kPagePoolUpperPP,*kTMPoolPP,*kTMPoolSizeP);

  TRACE4(TRACE_SHARED, 1, TRCID_FIXED_ADDRS_EXIT,
         "cxiGetFixedAddrs: exit  pp low 0x%lX pp upper 0x%lX TM pool 0x%lX TM pool size %ld",
         *kPagePoolLowerPP, *kPagePoolUpperPP, *kTMPoolPP, *kTMPoolSizeP);

  return;
}

/* Return true if this process holds the big kernel lock (BKL) */
Boolean cxiHoldsBKL()
{
  return CURRENT_LOCK_DEPTH >= 0;
}


/* Tell the OS that this thread is involved in handling VM page-out
   requests and should not be blocked waiting for page allocation.
   Return true if successful. */
Boolean cxiSetPageoutThread()
{
  if (current->flags & PF_MEMALLOC)
    return false;
  current->flags |= PF_MEMALLOC;
  return true;
}


/* Tell the OS that this thread is no longer involved in handling VM
   page-out requests. */
void cxiClearPageoutThread()
{
  current->flags &= ~PF_MEMALLOC;
}


/* Yield the CPU to allow other processes to run */
void
cxiYield()
{
  ENTER(0);
  schedule();
  EXIT(0);
}

/* Linux filldir has changed signatures depending on kernel level.
 * We always pass a 64bit offset from the GPFS layer.
 */
int
cxiFillDir(void *vargP, const char *nameP, int namelen,
           offset_t offset, int snOffset, cxiIno_t ino, void *eP)
{
  int result, err = 0;
  cxiFillDirArg_t *fillDirArgP = (cxiFillDirArg_t *)vargP;
  filldir_t fnP = (filldir_t)fillDirArgP->fnP;
  cxiMode_t mode = 0;
  unsigned short d_type = 0;

  ENTER(0);
  if (eP != NULL)
    err = gpfs_ops.gpfsParseDirEntry(eP, &mode, NULL);

  if (!err)
    d_type = (((mode) & 0170000) >> PERM_BITS);

  result = fnP(fillDirArgP->argP, nameP, namelen, (loff_t)offset, ino, d_type);
  EXIT_RC(0, result);
  return result;
}

#ifdef DISK_LEASE_DMS

static struct timer_list DMSTimer[MAX_DMS_INDEX];
static int (*DMSgetNIOsInProgressP)(int);

#define PANIC_FOR_REAL 1

static void cxiDMSExpired(unsigned long data)
{
  int idx = data;
  int nIOs = DMSgetNIOsInProgressP(idx);
  /* ENTER(0); */
  /* This code is executed on the interrupt level -- can't use tracing */
  if (nIOs != 0)
  {
#ifdef PANIC_FOR_REAL
    panic("GPFS Deadman Switch timer has expired, and there are still"
          " %d outstanding I/O requests\n", nIOs);
#else
    printk("GPFS Deadman Switch timer [%d] has expired; IOs in progress: %d\n",
           idx, nIOs);
#endif
  }
}

/*
  Start dead man switch, with the timeout specified by the delay
  argument (in seconds).
*/
void cxiStartDMS(int idx, int delay, int (*funcP)(int))
{
  unsigned long njiffies = delay * HZ;

  /* Only allow the daemon or other root users to make this kernel call */
  if (!cxiIsSuperUser())
    return;
  ENTER(0);

  /* There can be only one timer active at any given moment */
  if (timer_pending(&DMSTimer[idx]))
    del_timer(&DMSTimer[idx]);

  init_timer(&DMSTimer[idx]);
  DMSTimer[idx].expires = jiffies + njiffies;
  DMSTimer[idx].function = cxiDMSExpired;
  DMSTimer[idx].data = idx;
  /* save the pointer to nIOsInProgress to a static var */
  DMSgetNIOsInProgressP = funcP;
  add_timer(&DMSTimer[idx]);
  TRACE3(TRACE_DLEASE, 2, TRCID_DMS_STARTED,
         "DMS timer [%d] started, delay %d, time %d\n",
         idx, delay, jiffies/HZ);
  EXIT(0);
}

void cxiStopDMS(int idx)
{
  /* Only allow the daemon or other root users to make this kernel call */
  if (!cxiIsSuperUser())
    return;
  ENTER(0);

  if (timer_pending(&DMSTimer[idx]))
    del_timer(&DMSTimer[idx]);
  TRACE2(TRACE_DLEASE, 2, TRCID_DMS_STOPPED,
         "DMS timer [%d] stopped, time %d\n", idx, jiffies/HZ);
  EXIT(0);
}

/* dummy init routine.  Since on Linux the timer is
   stored in a static memory, there's nothing to be done
*/
IntRC cxiInitDMS(void)
{
  return 0;
}

void cxiShutdownDMS(void)
{
  int i;

  ENTER(0);
  for (i = 0; i < MAX_DMS_INDEX; i++)
    cxiStopDMS(i);
  EXIT(0);
}

#endif /* DISK_LEASE_DMS */

void cxiSetBit(unsigned long *flagP, int flag_bit)
{
   set_bit(flag_bit,flagP);
}
void cxiClearBit(unsigned long *flagP, int flag_bit)
{
   clear_bit(flag_bit,flagP);
}
Boolean cxiTestBit(unsigned long *flagP, int flag_bit)
{
   return test_bit(flag_bit,flagP);
}

/* In order to setup our termination callback routine (gpfs_f_cleanup)
 * we create a dummy file and add it to our file table.  Then, upon
 * process termination, the release file operation will be called in
 * order to close the file.  The only operation we define for this
 * dummy file is release (gpfs_f_cleanup).
 */
int
cxiRegisterCleanup()
{
  int code = 0, rc = 0;
  struct inode *iP = NULL;
  struct file *fileP = NULL;
  struct dentry *dentryP = NULL;
  extern int cleanupFD;
  extern struct super_block *shutdownSuperP;
#if defined(USE_ALLOC_FILE)
  struct path path;
#endif

  /* We record the daemon's process group because certain
   * checks on cxiCopyIn/cxiCopyOut are bypassed for the daemon.
   */
  ENTER(0);
  DaemonPGrp = PROCESS_GROUP(current);

  /* Make sure we only create one file */
  if (cleanupFD)
  {
    EXIT_RC(0, EEXIST);
    return EEXIST;
  }

  DBGASSERT(shutdownSuperP != NULL);

  /* Allocate an inode struct */
  iP = new_inode(shutdownSuperP);
  if (!iP)
  {
    code = 1;
    rc = ENOMEM;
    goto xerror;
  }

  /* Set file type to something other than regular file (S_IFREG) to
     prevent the Integrity Measurement Architecture (IMA) runtime from
     counting this file and complaining about imbalance. */
  iP->i_mode = S_IFBLK;

  /* Allocate an available file descriptor */
  cleanupFD = get_unused_fd();
  if (cleanupFD < 0)
  {
    code = 2;
    rc = ENFILE;
    goto xerror;
  }
#if defined(USE_ALLOC_FILE)

  /* Allocate a dentry sruct */
#ifdef NEW_D_MAKE_ROOT
  dentryP = dget(d_make_root(iP));
#else
  dentryP = dget(d_alloc_root(iP));
#endif
  if (!dentryP)
  {
#ifdef NEW_D_MAKE_ROOT
    /* If fail, d_make_root will iput root inode itself */
    iP = NULL;
#endif
    code = 4;
    rc = ENOMEM;
    goto xerror;
  }
  /* Just chain it on the current root mount.  When
   * the file is closed its fput() will decrement
   * the mount count (hence the mntget here)
   */
  path.mnt = mntget(TASK_ROOTMNT(current));
  path.dentry = dentryP;

  /* Allocate a file struct */
  fileP = alloc_file(&path, 0, &gpfs_cleanup_fops);
  if (!fileP)
  {
    code = 3;
    rc = ENFILE;
    goto xerror;
  }
#else
  /* Allocate a file struct */
  fileP = get_empty_filp();
  if (!fileP)
  {
    code = 3;
    rc = ENFILE;
    goto xerror;
  }

  /* Allocate a dentry sruct */
#ifdef NEW_D_MAKE_ROOT
  dentryP = dget(d_make_root(iP));
#else
  dentryP = dget(d_alloc_root(iP));
#endif
  if (!dentryP)
  {
#ifdef NEW_D_MAKE_ROOT
    /* If fail, d_make_root will iput root inode itself */
    iP = NULL;
#endif
    code = 4;
    rc = ENOMEM;
    goto xerror;
  }

  /* Initialize and chain our file sructure */
  fileP->f_dentry = dentryP;
  fileP->f_op     = &gpfs_cleanup_fops;
  /* Just chain it on the current root mount.  When
   * the file is closed its fput() will decrement
   * the mount count (hence the mntget here)
   */
  fileP->f_vfsmnt = mntget(TASK_ROOTMNT(current));
#endif

  fileP->f_flags  = O_RDONLY;
#ifdef LONG_FILECOUNT
  atomic_long_set(&fileP->f_count, 1);
#else
  atomic_set(&fileP->f_count, 1);
#endif

  /* Install the descriptor so it gets "closed" upon our termination */
  fd_install(cleanupFD, fileP);

  /* Set FD_CLOEXEC so that forked processes (like mmfsup.scr) do not
   * inherrit this descriptor.  We want the cleanup routine to be run
   * when the last mmfsd process terminates.
   */
#if LINUX_KERNEL_VERSION >= 2061300
  FD_SET_BIT(cleanupFD, current->files->fdt->close_on_exec);
#else
  FD_SET_BIT(cleanupFD, current->files->close_on_exec);
#endif
  /* Once the descriptor for this dummy file is added to our file table,
   * it is inherrited by all the processes of the daemon.  As each
   * terminates, the files->count is decremented and on the last process
   * termination all the descriptors will be closed by filp_close.
   *
   * The one catch here is that our file table is inherrited by the
   * kernel threads we start as well as user processes.  This would
   * cause a problem in that daemon termination does not include these
   * kernel threads which aren't killed until restart (and therefore
   * the file is never closed).  In order for our operation to be
   * driven at daemon termiation, we must remove the file table from
   * these kernel threads.  This is done in via cxiReparent() by
   * the mmap pager kproc.
   */

xerror:
  TRACE4(TRACE_VNODE, 1, TRCID_CXIREGISTERCLEANUP_EXIT,
         "cxiRegisterCleanup: fd %d iP %X rc %d code %d\n",
         cleanupFD, iP, rc, code);

  if (rc)
  {
    if (dentryP);
      dput(dentryP);

    if (cleanupFD)
      put_unused_fd(cleanupFD);

    if (fileP)
#if LINUX_KERNEL_VERSION >= 2060900
      fput(fileP);
#else
      put_filp(fileP);
#endif

    if (iP)
      iput(iP);

    cleanupFD = 0;
  }

  EXIT_RC(0, rc);
  return rc;
}

#ifdef NFS4_ACL
/* Linux routines to be called when processing NFSv4 audit/alarm ACL entries */
int cxiAuditWrite(int numargs, ...) { return ENOSYS; }
#endif /* NFS4_ACL */

/* Currently no OS specific VFS initialization for Linux */
int
cxiInitVFS(int vfsType)
{
  return 0;
}

UIntPtr
cxiGetKernelStackSize()
{
  return (UIntPtr)THREAD_SIZE;
}

void cxiPathRel(void *ndP)
{
  DBGASSERT( ndP != NULL);
  PATH_PUT( (struct nameidata *) ndP);
  cxiFreeUnpinned(ndP);
}

int
cxiPathToVfsP(void **privVfsPP, char *kpathname, void **ndPP, void **cnPP,
              Boolean traverseLink)
{
   struct gpfsVfsData_t *privVfsP = NULL;
   struct nameidata *ndP = NULL;
   struct inode * iP;
   cxiNode_t *cnP;
   int rc = 0;
   Boolean rel = false;
   int code = 0;
   *ndPP = NULL;
   *privVfsPP = NULL;

   ENTER(0);
   if (kpathname == NULL)
   {
     code = 1;
     rc = EINVAL;
     goto xerror;
   }

   ndP = (struct nameidata *)cxiMallocUnpinned(sizeof(struct nameidata));
   if (ndP == NULL)
   {
     code = 2;
     rc = ENOMEM;
     goto xerror;
   }

   /* For DMAPI, this is called by dm_path_to_handle or dm_path_to_fshandle,
    * According to dmapi documentation, we should return the symbolic link
    * itself instead of the object that link references.
    * so here we need to use the function which does not traverse the link */
   if (!traverseLink)
     rc = USER_LPATH(kpathname, ndP);
   else
     rc = USER_PATH(kpathname, ndP);

   if (rc)
   {
     rc = -rc;
     code = 3;
     goto xerror;
   }

   rel = true;
   iP = NDP_TO_IP(ndP);
   DBGASSERT(iP != NULL);
   if (!GPFS_TYPE(iP))
   {
     code = 4;
     rc = ENXIO;
     goto xerror;
   }

   privVfsP = VP_TO_PVP(iP);

   if (privVfsP == NULL)
   {
     code = 5;
     rc = ENOENT;
  }
  cnP = VP_TO_CNP(iP);
  *privVfsPP = (void *)privVfsP;
  *ndPP = (void *)ndP;
  if (cnPP != NULL)
    *cnPP = (void *)cnP;

xerror:
  if (rc && ndP)
  {
    if (rel)
     cxiPathRel(ndP);
    else
     cxiFreeUnpinned(ndP);
  }
  EXIT_RC(0, rc);
  return rc;
}


#ifdef KSTACK_CHECK
/* Kernel stack checking: for each active thread that is making
   subroutine calls in the kernel, allocate a stack_history_t.  Within
   each stack_history_t, create a frame_desc_t for each level of
   subroutine call.  Two lists of frame_desc_t's are maintained: one for
   the current call stack, and one for the deepest call stack seen so
   far for this thread.  Upon exit from the lowest-level routine, check
   whether the maximum stack depth threshhold has been exceeded.  If it
   has, print the traceback of the maximum stack usage.  Keep hashes of
   the tracebacks printed to avoid printing the same traceback more than
   once.  Since cxiTraceExit is not called for every routine exit,
   maintenance of call chains is not exact; a routine entry with
   stackUsed less than the current entry implies return of the previous
   routine.

   Note that these routines cannot call any other routine that has
   ENTER/EXIT macros inside of it, to avoid recursion. */

/* Maximum size of of a stack frame before it is considered large enough
   to complain about, warn when over 3/4 of stack size. */
#define STACK_LIMIT_WARNING (THREAD_SIZE - ((THREAD_SIZE) >> 2))

/* Description of one level of a call stack */
typedef struct frame_desc
{
  /* Function name and file name containing the function */
  const char * fdFuncNameP;
  const char * fdFileNameP;

  /* Pointer to frame_desc of caller, or NULL if this is the first
     frame.  Also used to link free frame descriptors together on the
     shFreeHeadP free list. */
  struct frame_desc * fdCallerP;

  /* Line number near the beginning of fdFuncNameP */
  int fdLineNum;

  /* Total stack usage up to and including this routine */
  int fdStackUsed;

  /* Reference count for this frame_desc_t.  Can be 2 if this descriptor
     is reachable from both shCurrentP and shMaxP. */
  int fdRef;
} frame_desc_t;


/* Each stack_history is only used by one thread, so no locking is
   needed within a stack_history.  This is allocated as a single page.
 */
typedef struct stack_history
{
  /* ID of thread to which this stack_history_t belongs */
  cxiThreadId shThreadId;

  /* Bucket index in historyHash that points to this stack_history_t,
     or -1 if this stack_history_t is on an overflow list */
  int shBucketNum;

  /* Next stack_history_t in same hash overflow list or on free list */
  struct stack_history * shNextP;

  /* Pointer to the frame descriptor for the routine that most recently
     called fdEnter without a matching fdExit.  Following the fdCallerP
     pointers through these frame descriptors gives the current callback
     chain. */
  frame_desc_t * shCurrentP;

  /* Pointer to the frame descriptor that had the maximum stack usage
     seen thus far for this thread.  Following the fdCallerP pointers
     through these frame descriptors gives the callback chain with
     maximal stack usage. */
  frame_desc_t * shMaxP;

  /* Head of list of free frame_desc_t's */
  frame_desc_t * shFreeHeadP;

  /* Area that holds frame_desc_t's.  These will be linked together and
     put on the list shFreeHeadP. */
#define SH_PREFIX_LEN (sizeof(cxiThreadId) +                            \
                       sizeof(int) +                                    \
                       sizeof(struct stack_history *) +                 \
                       3*sizeof(frame_desc_t *))
#define SH_NFRAMES ((PAGE_SIZE-SH_PREFIX_LEN)/sizeof(frame_desc_t))
  frame_desc_t shFrames[SH_NFRAMES];
} stack_history_t;

/* Global structures */
struct
{
  /* Global flag controlling whether kernel stack checking is enabled.
     Initially false; set true during kernel module initialization,
     then set false again during kernel module termination. */
  Boolean shActive;

  /* Mutex protecting updates to the variables that follow.  This cannot
     be a cxiBlockMutex_t because then the stack checking routines would
     get called recursively. */
  struct semaphore shMutex;

  /* List of free stack_history_t's and count of how many free entries
     there are.  Excess stack_history_t's beyond a threshhold are freed
     back to the operating system. */
  stack_history_t * freeHeadP;
  int nFree;
#define MAX_FREE_STACK_HISTORIES 16

  /* Hash table of active stack_history_t's.  To find the entry for a
     particular thread, hash its thread id to a bucket.  If any of the
     entries in bucket[] match the desired thread id, the pointer to
     the stack_history_t can be returned without acquiring any locks.  If
     the bucket does not contain the desired thread id, look for it on
     the overflow list under protection of shMutex. */
#define HISTORY_HASH_SIZE 64
#define HISTS_PER_BUCKET 3
  struct
  {
    struct
    {
      stack_history_t * historyP;
      cxiThreadId threadId;
    } bucket[HISTS_PER_BUCKET];
    stack_history_t * overflowP;
  } historyHash[HISTORY_HASH_SIZE];

  /* List of hash values for tracebacks that have already been printed.
     Used to avoid printing the same traceback more than once.  Nothing
     is ever deleted from this table, so to find an entry start
     searching at its hash value and continue until the entry is found
     or an empty slot is encountered.  The total occupancy of the table
     is limited to MAX_TRACEBACKS to restrict the amount of searching
     that will be required, and to guarantee that searches will
     terminate. */
#define TB_HASH_SIZE 64
#define MAX_TRACEBACKS 32
  unsigned int tracebackHash[TB_HASH_SIZE];
  int nTracebackHashEntries;
} SHG;


/* Private version of DBGASSERT used only within stack checking code.
   Cannot use DBGASSERT without risking recursion. */
#ifdef DBGASSERTS
#define SH_ASSERT(_ex)                                                       \
  if (!(_ex)) {                                                              \
    printk("GPFS stack checking assert failed: " # _ex " file %s line %d\n", \
           __FILE__, __LINE__);                                              \
    DoPanic(# _ex, __FILE__, __LINE__, 0, 0, "");                            \
  } else ((void)0)
#else
#define SH_ASSERT(_ex) ((void)0)
#endif


/* Initialize and enable stack depth checking */
void shInit()
{
  /* Clear stack checking globals */
  cxiMemset(&SHG, 0, sizeof(SHG));

  /* Init mutex */
  init_MUTEX(&SHG.shMutex);

  /* Turn on stack depth checking and make sure the change is visible */
  SHG.shActive = true;
  wmb();
}


/* Turn off stack depth checking and free all allocated memory.  This does
   not have to return the global state to what it was when the module was
   first loaded, since it will not be used again. */
void shTerm()
{
  int h;
  int b;
  stack_history_t * shP;
  stack_history_t * shNextP;

  /* Turn off stack depth checking and make sure the chenge is visible */
  SHG.shActive = false;
  wmb();

  /* Get and then release mutex.  This insures that a thread that is
     in the middle of writing a traceback finishes writing it before
     we free the data structures it was using. */
  /* ?? although there could be another thread waiting for the mutex ... */
  down(&SHG.shMutex);
  up(&SHG.shMutex);

  /* Wait briefly to allow threads in the middle of the stack checking
     code to finish what they are doing */
  /* ?? Of course, this is not really safe, but this is debugging code,
     right? */
  schedule_timeout(HZ/2);

  /* Terminate mutex */
  // nothing to do

  /* Free all stack_history_t's on the free list */
  shP = SHG.freeHeadP;
  while (shP != NULL)
  {
    shNextP = shP->shNextP;
    kfree(shP);
    shP = shNextP;
  }

  /* Free all stack_history_t's in the hash table */
  for (h=0 ; h<HISTORY_HASH_SIZE ; h++)
  {
    for (b=0 ; b<HISTS_PER_BUCKET ; b++)
      if (SHG.historyHash[h].bucket[b].historyP != NULL)
        kfree(SHG.historyHash[h].bucket[b].historyP);
    shP = SHG.historyHash[h].overflowP;
    while (shP != NULL)
    {
      shNextP = shP->shNextP;
      kfree(shP);
      shP = shNextP;
    }
  }
}


/* Allocate and initialize a new stack_history_t */
static stack_history_t * shAllocInit()
{
  stack_history_t * shP;
  int f;

  up(&SHG.shMutex);
  shP = (stack_history_t *) kmalloc(sizeof(stack_history_t), GFP_KERNEL);
  SH_ASSERT(shP != NULL);
  down(&SHG.shMutex);
  cxiMemset(shP, 0, sizeof(stack_history_t));
  for (f=0 ; f<=SH_NFRAMES-2 ; f++)
    shP->shFrames[f].fdCallerP = &shP->shFrames[f+1];
  shP->shFreeHeadP = &shP->shFrames[0];
  return shP;
}


/* Get a stack_history_t off the free list or build a new one */
static stack_history_t * shGet()
{
  stack_history_t * shP;

  /* Use free list if one is available there */
  shP = SHG.freeHeadP;
  if (shP != NULL)
  {
    SHG.freeHeadP = shP->shNextP;
    SHG.nFree -= 1;
    return shP;
  }

  /* Make a new one if necessary */
  return shAllocInit();
}


/* Free a stack_history_t.  Put it on the free list if there are not
   already too many free, or else free it back to the operating system.
 */
static void shPut(stack_history_t * shP)
{
  int h;
  int b;
  stack_history_t ** shPrevPP;
  stack_history_t * p;

  /* Both call stacks should be empty */
  SH_ASSERT(shP->shCurrentP == NULL);
  SH_ASSERT(shP->shMaxP == NULL);

  /* Must hold mutex while changing the hash table */
  down(&SHG.shMutex);

  /* Clear pointer to this stack_history_t from the hash table */
  h = ((int)shP->shThreadId) & (HISTORY_HASH_SIZE-1);
  b = shP->shBucketNum;
  if (b != -1)
  {
    SH_ASSERT(SHG.historyHash[h].bucket[b].historyP == shP);
    SHG.historyHash[h].bucket[b].historyP = NULL;
    SHG.historyHash[h].bucket[b].threadId = 0;
  }
  else
  {
    shPrevPP = &SHG.historyHash[h].overflowP;
    p = *shPrevPP;
    while (p != NULL)
    {
      if (p == shP)
      {
        *shPrevPP = shP->shNextP;
        break;
      }
      shPrevPP = &p->shNextP;
      p = *shPrevPP;
    }
  }

  /* If not too many already free, add to free list */
  if (SHG.nFree < MAX_FREE_STACK_HISTORIES)
  {
    shP->shNextP = SHG.freeHeadP;
    SHG.freeHeadP = shP;
    SHG.nFree += 1;
    up(&SHG.shMutex);
    return;
  }

  /* Otherwise, really free it */
  up(&SHG.shMutex);
  kfree(shP);
}


/* Find the stack_history_t for the current thread, or allocate one if
   one does not already exist */
static stack_history_t * shFind()
{
  stack_history_t * shP;
  cxiThreadId id = current->pid;
  int h = ((int)id) & (HISTORY_HASH_SIZE-1);
  int b;

  /* Look at all entries within the bucket given by the hash of the
     thread ID.  No locking needs to be done for this search. */
  for (b=0 ; b<HISTS_PER_BUCKET ; b++)
    if (SHG.historyHash[h].bucket[b].threadId == id)
      return SHG.historyHash[h].bucket[b].historyP;

  /* Must hold mutex while changing the hash table */
  down(&SHG.shMutex);

  /* Search the overflow list */
  shP = SHG.historyHash[h].overflowP;
  while (shP != NULL)
  {
    if (shP->shThreadId == id)
      goto exit;
    shP = shP->shNextP;
  }

  /* No stack_history_t for this thread yet.  Get one off the free list
     or build one. */
  shP = shGet();
  shP->shThreadId = id;
  shP->shNextP = NULL;

  /* Find a slot for the new stack_history_t in the hash table */
  for (b=0 ; b<HISTS_PER_BUCKET ; b++)
    if (SHG.historyHash[h].bucket[b].historyP == NULL)
    {
      SHG.historyHash[h].bucket[b].historyP = shP;
      SHG.historyHash[h].bucket[b].threadId = id;
      shP->shBucketNum = b;
      goto exit;
    }

  /* No slots available; add new stack_history_t to overflow list */
  shP->shBucketNum = -1;
  shP->shNextP = SHG.historyHash[h].overflowP;
  SHG.historyHash[h].overflowP = shP;

exit:
  /* Release mutex before returning */
  up(&SHG.shMutex);
  return shP;
}


/* Allocate a frame descriptor within the given stack_history_t.  This
   cannot be allowed to fail, so if there are no more free descriptors,
   throw away the bottom frame descriptor and return that.  The reference
   count of the frame descriptor that is returned is undefined. */
static frame_desc_t * fdGet(stack_history_t * shP)
{
  frame_desc_t * fdP;
  frame_desc_t ** fdPrevPP;
  int prevRef;

  /* Look on the free list within the stack_history_t */
  fdP = shP->shFreeHeadP;
  if (fdP != NULL)
  {
    shP->shFreeHeadP = fdP->fdCallerP;
    return fdP;
  }

  /* No free descriptors; first try stealing one off the bottom of the
     current call stack */
  fdP = shP->shCurrentP;
  if (fdP != NULL)
  {
    /* Find the bottom entry of the current call stack */
    fdPrevPP = &shP->shCurrentP;
    prevRef = 1;
    while (fdP->fdCallerP != NULL)
    {
      fdPrevPP = &fdP->fdCallerP;
      prevRef = fdP->fdRef;
      fdP = *fdPrevPP;
    }

    /* Remove the bottom entry of the current call stack */
    *fdPrevPP = NULL;

    /* Reduce the reference count on the entry just removed.  The
       reference count decreases by the reference count of the frame
       that used to point to *fdP.  If *fdP is no longer referenced, no
       further work is needed.  If *fdP is still referenced from the max
       depth stack (it must be the bottom entry), we will eventually
       return it, but only after removing it from the bottom of the max
       depth stack.  We know that fdP will be returned, but we have to
       search through the max depth stack to find the pointer to *fdP.
     */
    fdP->fdRef -= prevRef;
    if (fdP->fdRef == 0)
      return fdP;
  }

  /* Still no free descriptors; steal the frame descriptor off the
     bottom of the maximum depth call stack */
  fdP = shP->shMaxP;
  if (fdP != NULL)
  {
    /* Find the bottom entry of the max depth call stack */
    fdPrevPP = &shP->shMaxP;
    while (fdP->fdCallerP != NULL)
    {
      fdPrevPP = &fdP->fdCallerP;
      fdP = *fdPrevPP;
    }

    /* Remove the bottom entry of the max depth call stack */
    *fdPrevPP = NULL;

    /* The bottom entry of the max depth call stack that was just
       removed must have a reference count of one; otherwise it would
       still be on the current call stack and removing the bottom entry
       of that stack would have reduced the reference count of some
       frame descriptor from 2 to 0. */
    SH_ASSERT(fdP->fdRef == 1);
    return fdP;
  }
  SH_ASSERT(!"cannot alloc frame_desc_t");
  return NULL;
}


/* Decrease the reference count on a frame descriptor.  If it becomes
   zero, return it to the free list */
static void fdDiscard(frame_desc_t * fdP, stack_history_t * shP)
//inline static void fdDiscard(frame_desc_t * fdP, stack_history_t * shP)
{
  if (fdP->fdRef > 1)
  {
    fdP->fdRef -= 1;
    TRACE3(TRACE_KENTRYEXIT, 11, TRCID_FDDISCARD1,
           "fdDiscard: fdP 0x%lX shP 0x%lX rtn %s refcnt now 1\n",
           fdP, shP, fdP->fdFuncNameP);
    return;
  }

  fdP->fdCallerP = shP->shFreeHeadP;
  shP->shFreeHeadP = fdP;
  TRACE3(TRACE_KENTRYEXIT, 11, TRCID_FDDISCARD2,
         "fdDiscard: fdP 0x%lX shP 0x%lX rtn %s refcnt now 0\n",
         fdP, shP, fdP->fdFuncNameP);
}


/* If the maximum stack depth exceeds the threshhold, print its
   traceback if it has not already been printed.  Reset the maximum
   depth stack to empty.  Only called when the current stack is already
   empty. */
static void shDisplay(stack_history_t * shP)
{
  frame_desc_t * fdP;
  unsigned int tbHash;
  frame_desc_t * fdNextP;
  int slot;

  SH_ASSERT(shP->shCurrentP == NULL);

  /* If the maximum stack depth is less than the threshhold, just free
     the call chain and return */
  fdP = shP->shMaxP;
  if (fdP == NULL  ||
      fdP->fdStackUsed < STACK_LIMIT_WARNING)
    goto exit;

  /* Compute a hash of the traceback call chain */
  tbHash = 0;
  while (fdP != NULL)
  {
    tbHash <<= 1;
    tbHash ^= (((unsigned int)fdP->fdStackUsed) << 15) ^ fdP->fdLineNum;
    fdP = fdP->fdCallerP;
  }

  /* Search for the hash of the call chain in the table of tracebacks that
     have already been printed.  Searching the hash table can be done without
     any locks, since entries are never deleted.  The loop must eventually
     terminate, since the table will not be allowed to fill up. */
search:
  slot = tbHash % TB_HASH_SIZE;
  while (SHG.tracebackHash[slot] != 0)
  {
    if (SHG.tracebackHash[slot] == tbHash)
      /* This traceback has already been printed */
      goto exit;
    slot = (slot+1) % TB_HASH_SIZE;
  }

  /* The hash of the current max depth traceback was not found in the
     table and should be inserted at position 'slot'.  Do this under
     protection of the mutex.  If 'slot' has been used by the time we
     get the mutex, drop the mutex and repeat the search. */
  down(&SHG.shMutex);
  if (SHG.nTracebackHashEntries >= MAX_TRACEBACKS)
    goto exitMutexHeld;
  if (SHG.tracebackHash[slot] != 0)
  {
    up(&SHG.shMutex);
    goto search;
  }
  SHG.tracebackHash[slot] = tbHash;
  SHG.nTracebackHashEntries += 1;

  /* Print the traceback */
  fdP = shP->shMaxP;
  printk("\nGPFS kernel stack for process %d(%s) used %d bytes out of %d\n",
         current->pid, current->comm, fdP->fdStackUsed, (int)THREAD_SIZE);
  printk("  stack function\n");
  printk("   used\n");
  printk("  ----- -----------------------------------------------------\n");
  while (fdP != NULL)
  {
    printk("  %5d %s at %s:%d\n",
           fdP->fdStackUsed, fdP->fdFuncNameP, fdP->fdFileNameP, fdP->fdLineNum);
    fdP = fdP->fdCallerP;
  }
  printk("  traceback signature %08X\n", tbHash);

  /* If the maximum number of allowed tracebacks has been reached, turn
     off further stack checking. */
  if (SHG.nTracebackHashEntries >= MAX_TRACEBACKS)
  {
    printk("Maximum number of GPFS deep stack tracebacks reached\n");
    printk("GPFS stack checking disabled\n");
    SHG.shActive = false;
    wmb();
  }

exitMutexHeld:
  up(&SHG.shMutex);

exit:
  /* Free all stack frame descriptors for the max depth call chain back
     to the internal free list. */
  fdP = shP->shMaxP;
  while (fdP != NULL)
  {
    SH_ASSERT(fdP->fdRef == 1);
    fdNextP = fdP->fdCallerP;
    fdP->fdCallerP = shP->shFreeHeadP;
    shP->shFreeHeadP = fdP;
    fdP = fdNextP;
  }
  shP->shMaxP = NULL;
}


/* Process routine entry */
static void fdEntry(frame_desc_t * fdP, stack_history_t * shP)
{
  frame_desc_t * popP;
  frame_desc_t * p;

  TRACE5(TRACE_KENTRYEXIT, 11, TRCID_FDENTRY,
         "fdEntry: fdP 0x%lX shP 0x%lX rtn %s shCurrentP 0x%lX used %d\n",
         fdP, shP, fdP->fdFuncNameP, shP->shCurrentP, fdP->fdStackUsed);

  /* If this is the first call by this thread, set up the two call chains */
  if (shP->shCurrentP == NULL)
  {
    SH_ASSERT(shP->shMaxP == NULL);
    shP->shCurrentP = fdP;
    shP->shMaxP = fdP;
    fdP->fdCallerP = NULL;
    fdP->fdRef = 2;
    return;
  }
  else
    SH_ASSERT(shP->shMaxP != NULL);

  /* Process routine exits implied by the number of bytes of stack that
     are currently in use.  The test needs to be for strict less than
     because inlined routines share the same stack frame as their
     caller, but both routines will do entry/exit processing. */
  popP = shP->shCurrentP;
  while (fdP->fdStackUsed < popP->fdStackUsed)
  {
    p = popP->fdCallerP;
    shP->shCurrentP = p;
    TRACE1(TRACE_KENTRYEXIT, 11, TRCID_IMPLIED_EXIT,
           "fdEntry: implied exit from rtn %s\n",
           popP->fdFuncNameP);
    fdDiscard(popP, shP);
    if (p == NULL)
    {
      /* The outermost routine returned before this call without calling
         fdExit.  Test for a large maximum stack, then reset the
         maximum. */
      shDisplay(shP);

      /* The current routine is the one and only */
      shP->shCurrentP = fdP;
      shP->shMaxP = fdP;
      fdP->fdCallerP = NULL;
      fdP->fdRef = 2;
      return;
    }
    popP = p;
  }

  /* If this is an extension of the current max depth stack, just add
     this routine to the top of both stacks */
  if (fdP->fdStackUsed > shP->shMaxP->fdStackUsed  &&
      shP->shCurrentP == shP->shMaxP)
  {
    fdP->fdCallerP = shP->shCurrentP;
    shP->shCurrentP = fdP;
    shP->shMaxP = fdP;
    fdP->fdRef = 2;
    TRACE2(TRACE_KENTRYEXIT, 11, TRCID_NEWMAX_EXTEND,
           "fdEntry: extending new max stack %d fdP 0x%lX\n",
           fdP->fdStackUsed, fdP);
    return;
  }

  /* Make this new routine be the top of the stack */
  fdP->fdCallerP = shP->shCurrentP;
  shP->shCurrentP = fdP;
  fdP->fdRef = 1;

  /* If this new routine has a greater stack depth than the previous max,
     unreference the previous max depth call chain and add additional
     references to the current one. */
  if (fdP->fdStackUsed > shP->shMaxP->fdStackUsed)
  {
    popP = shP->shMaxP;
    do
    {
      p = popP->fdCallerP;
      fdDiscard(popP, shP);
      popP = p;
    } while (popP != NULL);
    p = fdP;
    do
    {
      p->fdRef = 2;
      p = p->fdCallerP;
    } while (p != NULL);
    TRACE2(TRACE_KENTRYEXIT, 11, TRCID_NEWMAX,
           "fdEntry: new max stack %d fdP 0x%lX\n",
           fdP->fdStackUsed, fdP);
    shP->shMaxP = fdP;
  }
}


/* Process routine exit */
static void fdExit(const char * funcnameP)
{
  stack_history_t * shP;
  frame_desc_t * lastPopP;
  frame_desc_t * popP;
  frame_desc_t * p;

  /* Locate or create stack_history_t for this thread */
  shP = shFind();

  /* If call stack is already empty, there is nothing to do except free
     the stack_history_t */
  if (shP->shCurrentP == NULL)
  {
    SH_ASSERT(shP->shMaxP == NULL);
    shPut(shP);
    return;
  }

  /* Search backward on the call stack for a routine name that matches
     the one being exitted.  In C++, the ENTER/EXIT macros will pass the
     same string constant (same address) to fdEntry and fdExit.  The C
     versions of the macros may pass two different copies of the same
     string.  This loop cannot pop routines it skips off the stack, since
     the routine might never be found. */
  p = shP->shCurrentP;
  for (;;)
  {
    if (p->fdFuncNameP == funcnameP  ||
        cxiStrcmp(p->fdFuncNameP, funcnameP) == 0)
    {
      TRACE4(TRACE_KENTRYEXIT, 11, TRCID_FDEXIT,
             "fdExit: p 0x%lX shP 0x%lX rtn %s shCurrentP 0x%lX\n",
             p, shP, p->fdFuncNameP, shP->shCurrentP);
      lastPopP = p;
      break;
    }
    p = p->fdCallerP;
    if (p == NULL)
    {
      /* Routine name not found.  Do not pop stack. */
      /* printk("No entry found when exitting %s\n", funcnameP); */
      TRACE1(TRACE_KENTRYEXIT, 11, TRCID_FDEXIT_NOTFOUND,
             "No entry found when exitting %s\n", funcnameP);
      return;
    }
  }

  /* Pop all routines up to and including lastPopP */
  p = shP->shCurrentP;
  do
  {
    popP = p;
    p = popP->fdCallerP;
    fdDiscard(popP, shP);
  } while (popP != lastPopP);
  shP->shCurrentP = p;

  /* If this was the return of the outermost routine, print new maximum
     stack depth traceback and discard the stack_history_t */
  if (shP->shCurrentP == NULL)
  {
    shDisplay(shP);
    shPut(shP);
  }
}

#endif  /* KSTACK_CHECK */


#if defined(ENTRYEXIT_TRACE) || defined(KSTACK_CHECK)
void cxiTraceEntry(int level, const char * funcnameP,
                   const char * filenameP, int lineNum)
{
  int stackUsed = THREAD_SIZE - (((unsigned long)&stackUsed) & (THREAD_SIZE-1));
#ifdef KSTACK_CHECK
  stack_history_t * shP;
  frame_desc_t * fdP;
#endif  /* KSTACK_CHECK */

#ifdef ENTRYEXIT_TRACE
  /* Need to use a constant trace level in the TRACE macro call to get
     the .trclst file (and later the .trcfmt file) built correctly */
  if (_TRACE_IS_ON(TRACE_KENTRYEXIT, BASE_ENTEREXIT_LEVEL + level))
  {
    TRACE5(TRACE_KENTRYEXIT, 1, TRCID_KTRACE_LINUX_ENTER,
           "-->K %s (%s:%d) level %d stackUsed %d\n",
           funcnameP, filenameP, lineNum, level, stackUsed);
  }
#endif  /* ENTRYEXIT_TRACE */

#ifdef KSTACK_CHECK
  /* Nothing to do if kernel stack checking is disabled */
  if (!SHG.shActive)
    return;

  /* Do not attempt to keep track of stack usage in interrupt handlers */
  if (in_interrupt())
    return;

  /* Locate or create stack_history_t for this thread */
  shP = shFind();

  /* Get a new frame descriptor and fill it in */
  fdP = fdGet(shP);
  fdP->fdFuncNameP = funcnameP;
  fdP->fdFileNameP = filenameP;
  fdP->fdLineNum = lineNum;
  fdP->fdStackUsed = stackUsed;

  /* Perform stack checking for this routine entry */
  fdEntry(fdP, shP);
#endif  /* KSTACK_CHECK */
}


void cxiTraceExit(int level, const char * funcnameP)
{
#ifdef ENTRYEXIT_TRACE
  /* Need to use a constant trace level in the TRACE macro call to get
     the .trclst file (and later the .trcfmt file) built correctly */
  if (_TRACE_IS_ON(TRACE_KENTRYEXIT, BASE_ENTEREXIT_LEVEL + level))
    TRACE1(TRACE_KENTRYEXIT, 1, TRCID_KTRACE_LINUX_EXIT,
           "<--K %s\n", funcnameP);
#endif  /* ENTRYEXIT_TRACE */

#ifdef KSTACK_CHECK
  /* Nothing to do if kernel stack checking is disabled */
  if (!SHG.shActive)
    return;

  /* Do not attempt to keep track of stack usage in interrupt handlers */
  if (in_interrupt())
    return;

  /* Process routine exit */
  fdExit(funcnameP);
#endif  /* KSTACK_CHECK */
}
void cxiTraceExitRC(int level, const char * funcnameP, int rc)
{
#ifdef ENTRYEXIT_TRACE
  /* Need to use a constant trace level in the TRACE macro call to get
     the .trclst file (and later the .trcfmt file) built correctly */
  if (_TRACE_IS_ON(TRACE_KENTRYEXIT, BASE_ENTEREXIT_LEVEL + level))
    TRACE2(TRACE_KENTRYEXIT, 1, TRCID_KTRACE_LINUX_EXIT_RC,
           "<--K %s rc %d\n", funcnameP, rc);
#endif  /* ENTRYEXIT_TRACE */

#ifdef KSTACK_CHECK
  /* Nothing to do if kernel stack checking is disabled */
  if (!SHG.shActive)
    return;

  /* Do not attempt to keep track of stack usage in interrupt handlers */
  if (in_interrupt())
    return;

  /* Process routine exit */
  fdExit(funcnameP);
#endif  /* KSTACK_CHECK */
}
#endif  /* defined(ENTRYEXIT_TRACE) || defined(KSTACK_CHECK) */


#ifdef UIDREMAP
size_t cxiGetUserEnvironmentSize(void)
{
  /* Kernel threads usually don't have a user address space given
     that they call daemonize (which does exit_mm), so need to
     account for this case (specifically for gpfsSwapdKproc which
     can hit this path via cxiPutOSNode with UIDREMAP on). */
  if (current->mm)
    return (current->mm->env_end - current->mm->env_start);
  else
    return 0;
}

int cxiGetUserEnvironment(char* buf, size_t len)
{
  DBGASSERT(current->mm != NULL);
  return cxiCopyIn((char*)current->mm->env_start, buf, len);
}
#endif

Boolean cxiHasMountHelper()
{
  return false;
}

#ifndef FL_RECLAIM
#define TMP_RECLAIM 4
#endif

Boolean cxisReclaim(unsigned int l_flags)
{
#ifndef FL_RECLAIM
  /* If there is no support for FL_RECLAIM check our temp. flag */
  return (l_flags & TMP_RECLAIM);
#else
  return (l_flags & FL_RECLAIM);
#endif
}

void cxiSetReclaim(unsigned int *l_flags)
{
#ifndef FL_RECLAIM
  /* If there is no support for FL_RECLAIM setour temp. flag */
  *l_flags |= TMP_RECLAIM;
#endif
  return;
}

void cxiResetReclaim(unsigned int *l_flags)
{
#ifndef FL_RECLAIM
  /* If there is no support for FL_RECLAIM setour temp. flag */
  *l_flags &= ~TMP_RECLAIM;
#endif
  return;
}

Boolean cxisCancel(unsigned int cmd)
{
#ifdef NFS_CLUSTER_LOCKS
  return (cmd == F_CANCELLK);
#else
  return 0;
#endif
}

int cxiMaxIOsize(IntNative blkSize)
{
#define TEMP_MAXBLKSIZE (1024*1024u) // 1M

  int maxSize = TEMP_MAXBLKSIZE; // should be NFSSVC_MAXBLKSIZE ?

#ifdef P_NFS4_KVM //??? fix for KVM limit
  blkSize = (128*1024u);
  goto out;
#endif

  /* Don't use less than block size */
  if (blkSize >= maxSize)
    goto out;

  while (maxSize > blkSize) {
    blkSize = blkSize << 1;
  }
out:
  return blkSize;
}

Int32
cxiLockFile(void *flP)
{
  int error;
  struct file_lock *fl = flP;

  error = gpfs_f_lock(fl->fl_file, F_SETLKW, fl);

  return error;
}

#ifdef P_NFS4
//#define GPFS_PRINTK

static inline __be32 *
x_exp_xdr_encode_u32(__be32 *p, __u32 val)
{
  cxiSafePutInt(cpu_to_be32(val), p);
  return p + 1;
}

static inline size_t
x_exp_xdr_qbytes(size_t qwords)
{
        return qwords << 2;
}

static inline size_t
x_exp_xdr_qwords(__u32 nbytes)
{
        return (((nbytes) + (4) - 1) / (4));
}

static inline __be32 *
x_exp_xdr_reserve_space(struct gpfs_exp_xdr_stream *xdr, size_t nbytes)
{
        int *p = xdr->p;
        int *q;

        /* align nbytes on the next 32-bit boundary */
        q = p + x_exp_xdr_qwords(nbytes);
        if (unlikely(q > xdr->end || q < p))
                return NULL;
        xdr->p = q;
        return p;
}

static inline __be32 *
x_exp_xdr_reserve_qwords(struct gpfs_exp_xdr_stream *xdr, size_t qwords)
{
        return x_exp_xdr_reserve_space(xdr, x_exp_xdr_qbytes(qwords));
}

static inline __be32 *
x_exp_xdr_encode_bytes(__be32 *p, const void *ptr, __u32 nbytes)
{
  if (likely(nbytes != 0)) {
    unsigned int qwords = x_exp_xdr_qwords(nbytes);
    unsigned int padding = x_exp_xdr_qbytes(qwords) - nbytes;

    cxiCopyOut((char *)ptr, (char *)p, nbytes);
    p += qwords;
  }
  return p;
}

static inline __be32 *
x_exp_xdr_encode_opaque(__be32 *p, const void *ptr, __u32 nbytes)
{
  p = x_exp_xdr_encode_u32(p, nbytes);
  return x_exp_xdr_encode_bytes(p, ptr, nbytes);
}

static int fl_devinfo_xdr_words(const struct pnfs_filelayout_device *fdev)
{
  struct pnfs_filelayout_devaddr *fl_addr;
  struct pnfs_filelayout_multipath *mp;
  int i, j, nwords;

  /* da_addr_body length, indice length, indices,
   * multipath_list4 length */
  nwords = 1 + 1 + fdev->fl_stripeindices_length + 1;
  for (i = 0; i < fdev->fl_device_length; i++) {
          mp = &fdev->fl_device_list[i];
          nwords++; /* multipath list length */
          for (j = 0; j < mp->fl_multipath_length; j++) {
                  fl_addr = mp->fl_multipath_list;
                  nwords += 1 + x_exp_xdr_qwords(fl_addr->r_netid.len);
                  nwords += 1 + x_exp_xdr_qwords(fl_addr->r_addr.len);
          }
  }
#ifdef GPFS_PRINTK
  printk("<-- %s nwords %d\n", __func__, nwords);
#endif
  return nwords;
}

static int
x_filelayout_encode_devinfo(struct gpfs_exp_xdr_stream *xdr,
                          const struct pnfs_filelayout_device *fdev)
{
  unsigned int i, j, len = 0, opaque_words;
  u32 *p_in;
  u32 index_count = fdev->fl_stripeindices_length;
  u32 dev_count = fdev->fl_device_length;
  int error = 0;
  __be32 *p;

  opaque_words = fl_devinfo_xdr_words(fdev);
#ifdef GPFS_PRINTK
  printk("%s: Begin indx_cnt: %u dev_cnt: %u total size %u\n",
          __func__,
          index_count,
          dev_count,
          opaque_words*4);
#endif
  /* check space for opaque length */
  p = p_in = x_exp_xdr_reserve_qwords(xdr, opaque_words);
  if (!p) {
          error =  -ETOOSMALL;
          goto out;
  }

  if (!cxiIsGaneshaThread())   // must be kernel pNFS
    p++; /* Fill in length later */

  /* encode device list indices */
  p = x_exp_xdr_encode_u32(p, index_count);
  for (i = 0; i < index_count; i++)
          p = x_exp_xdr_encode_u32(p, fdev->fl_stripeindices_list[i]);

  /* encode device list */
  p = x_exp_xdr_encode_u32(p, dev_count);
  for (i = 0; i < dev_count; i++) {
    struct pnfs_filelayout_multipath *mp = &fdev->fl_device_list[i];

    p = x_exp_xdr_encode_u32(p, mp->fl_multipath_length);
    for (j = 0; j < mp->fl_multipath_length; j++) {
      struct pnfs_filelayout_devaddr *da = &mp->fl_multipath_list[j];

      /* Encode device info */
      p = x_exp_xdr_encode_opaque(p, da->r_netid.data, da->r_netid.len);
      p = x_exp_xdr_encode_opaque(p, da->r_addr.data, da->r_addr.len);
    }
  }
  /* backfill in length. Subtract 4 for da_addr_body size */
  len = (char *)p - (char *)p_in;
  if (!cxiIsGaneshaThread())   // must be kernel pNFS
    x_exp_xdr_encode_u32(p_in, len - 4);

  error = len;

out:
#ifdef GPFS_PRINTK
  printk("%s: End err %d xdrlen %d\n",
          __func__, error, len);
#endif
  return error;
}

/* convert ip address to string */
char *IPtoString(int ip, char *buf)
{
  unsigned char *a = (char *)&ip;

  sprintf(buf, "%u.%u.%u.%u", a[0], a[1], a[2], a[3]);

  return buf;
}

static void printfh(char *s, int *fh)
{
#ifdef GPFS_PRINTK
  printk("%s: %d: %08x %08x %08x %08x %08x %08x %08x %08x %08x\n",
           s, fh[0],fh[1],fh[2],fh[3],fh[4],fh[5],fh[6],fh[7],fh[8],fh[9]);
#endif
}

int cxiSetFH(int *fhP, int sid)
{
  struct knfsd_fh *fh = (struct knfsd_fh *)fhP;

printfh("cxiSetFH-1", fhP);
  if (fh->fh_size > 8) {
    fh->fh_size += 4; // fh_size + 4 for sid
    fh->fh_fsid_type += x_FSID_MAX; // got it from enum nfsd_fsid
    fhP[(fh->fh_size >> 2)] = sid;
    fh->fh_fileid_type = 7; // see code in gpfs_decode_fh()
#ifdef GPFS_PRINTK
    printk("cxiSetFH size %d fsid_type %d fileid %d\n",
           fh->fh_size, fh->fh_fsid_type, fh->fh_fileid_type);
    printfh("cxiSetFH-2", fhP);
#endif
    return 0;
  }
  return ENOENT;
}

/* Call to NFS server on MDS to recall layout */
int cxiRecallLayout(void *vfsP, void *vP, void *p)
{
  struct super_block *sbP = (struct super_block *)vfsP;
  struct inode *iP = (struct inode *)vP;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP = NULL;
  struct dentry *dentryP = NULL;
  unsigned long inoNum;
  int rc = ENOENT;
  int reason = 0;

  privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;
  if (iP == NULL && p != NULL)
  {
    unsigned int in = *((unsigned int*)p);
    inoNum = (unsigned long)in;
#ifdef GPFS_PRINTK
    printk("cxiRecallLayout sbP %p inode %lu\n", sbP, inoNum);
#endif
    if (inoNum > 2)
    {   //??? using invalid inode will crash GPFS
      dentryP = get_dentry(sbP, inoNum, 0xffffffff);
      if (dentryP == NULL || IS_ERR(dentryP))
        goto exit;
      iP = dentryP->d_inode;
#ifdef GPFS_PRINTK
      printk("cxiRecallLayout sbP %p iP %p\n", sbP, iP);
#endif
      /* inode was specified but not found just return */
      if (iP == NULL)
        goto exit;
    }
    else
      iP = NULL;
  }
  if (iP == NULL) // recall all layouts for this fs
  {
    if (p == NULL)
      reason = LAYOUT_NOTIFY_DEVICEID;
    else
      reason = LAYOUT_RECALL_ANY;

    rc = gpfs_ops.gpfsGaneshaThread(privVfsP, &reason, NULL);
  }
  else
  {
    cnP = VP_TO_CNP(iP);
    rc = gpfs_ops.gpfsGaneshaRecall(privVfsP, cnP, LAYOUT_FILE_RECALL, iP);
  }
exit:
  if (dentryP != NULL && !(IS_ERR(dentryP)))
    dput(dentryP);
#ifdef GPFS_PRINTK
  printk("cxiRecallLayout sbP %p iP %p rc %d\n", sbP, iP, rc);
#endif
  return rc;
}

/* Call to NFS server on MDS to update device list */
int cxiUpdateDevice(void *vfsP, void *p)
{
  int rc;
  // Recall all layouts for this fs or update device info.
  rc = cxiRecallLayout(vfsP, NULL, NULL);

  return rc;
}

/*
Get device info

        type         in: requested layout type.
        devid        in: requested device id
        func         in: nfsd xdr device encode function
        xdr.maxcount
                in: buffer size in bytes.
error:
        Use the same retrun codes as used for GETDEVICEINFO
*/
int
cxiGetDeviceInfo(int nDests, int *ipList, void *devidP, void *xdr)
{
  int rc=0,i=0,j=0,len=0;
  char tp[32];

  struct nfsd4_pnfs_deviceid *devid = (struct nfsd4_pnfs_deviceid *)devidP;
  struct gpfs_exp_xdr_stream *xdrP = (struct gpfs_exp_xdr_stream *)xdr;

  struct pnfs_filelayout_device fdev;
  struct pnfs_filelayout_devaddr* dev;
  struct pnfs_filelayout_multipath* mp;
  ENTER(0);

  TRACE3(TRACE_VNODE, 2, TRCID_CXI_GET_DEVICEINFO_ENTER,
        "cxiGetDeviceInfo: nDests %d xdr->p 0x%lX xdr->end 0x%lX", nDests,
         ((struct gpfs_exp_xdr_stream *)xdr)->p,
         ((struct gpfs_exp_xdr_stream *)xdr)->end);

  cxiMemset(&fdev, 0, sizeof(fdev));

  /* Allocate device list.  Note, some devices might not be valid and therefore
   * this list might be larger than the final list of usable devices
   */
  fdev.fl_device_list = (struct pnfs_filelayout_multipath *)cxiMallocUnpinned(sizeof(struct pnfs_filelayout_multipath) * nDests);
  if (fdev.fl_device_list == NULL)
  {
    rc = -ENOMEM;
    goto exit;
  }
  fdev.fl_device_length = 0;

  /* Set the devices */
  for (i = 0; i < nDests; i++)
  {
    /* TODO: check this here or when retrieved devices? */
    if (ipList[i] == -1)
      continue;

    mp = &fdev.fl_device_list[j];

    /* Currently multipathing is useless... */
    mp->fl_multipath_length = 1;

    mp->fl_multipath_list = (struct pnfs_filelayout_devaddr *)cxiMallocUnpinned(sizeof(struct pnfs_filelayout_devaddr));
    if (mp->fl_multipath_list == NULL)
    {
      rc = -ENOMEM;
      goto xerror;
    }

    IPtoString(ipList[i], tp);
    len = (cxiStrlen(tp));

    dev = &mp->fl_multipath_list[0];
    cxiMemset(dev, 0, sizeof(struct pnfs_filelayout_devaddr));

    /* Set r_addr */
    dev->r_addr.len = len + 4; /* for ".8.1" */
    dev->r_addr.data = (char *)cxiMallocUnpinned(dev->r_addr.len+1);
    if (dev->r_addr.data == NULL)
    {
      cxiFreeUnpinned(mp->fl_multipath_list);
      rc = -ENOMEM;
      goto xerror;
    }
    cxiMemcpy(dev->r_addr.data, tp, len);
    cxiStrcpy(dev->r_addr.data + len, ".8.1");  /* port 2049 = 0x801 = "8.1" */

    /* Set r_netid */
    dev->r_netid.len = 3; /*'tcp'*/
    dev->r_netid.data = (char *)cxiMallocUnpinned(dev->r_netid.len+1);
    if (dev->r_netid.data == NULL)
    {
      cxiFreeUnpinned(dev->r_addr.data);
      cxiFreeUnpinned(mp->fl_multipath_list);
      rc = -ENOMEM;
      goto xerror;
    }
    cxiStrcpy(dev->r_netid.data, "tcp");

    /* Increment number of devices */
    fdev.fl_device_length++;
    j++;

    TRACE4(TRACE_VNODE, 2, TRCID_CXI_GET_DEVICEINFO_P1,
           "cxiGetDeviceInfo index %d num %d len %d ip %s\n",
           j, fdev.fl_device_length, dev->r_addr.len, dev->r_addr.data);

#ifdef GPFS_PRINTK
    printk("xxx cxiGetDeviceInfo index %d num %d len %d ip %s\n",
           j, fdev.fl_device_length, dev->r_addr.len, dev->r_addr.data);
#endif
  }

  /* Set index information, from first to last data server */
  fdev.fl_stripeindices_length = fdev.fl_device_length;
  fdev.fl_stripeindices_list = (int*)cxiMallocUnpinned(fdev.fl_device_length * sizeof(int));
  if (fdev.fl_stripeindices_list == NULL)
  {
      rc = -ENOMEM;
      goto xerror;
  }
  for (i=0; i < fdev.fl_stripeindices_length; i++)
          fdev.fl_stripeindices_list[i] = i;

  /* Call nfsd code to encode the device */
#ifdef GPFS_PRINTK
  printk("xxx cxiGetDeviceInfo nfsd func\n");
#endif
  rc = x_filelayout_encode_devinfo(xdrP, &fdev);
  if (rc < 0)
  {
#ifdef GPFS_PRINTK
          printk("xxx cxiGetDeviceInfo NFSD device encode failed rc %d\n", rc);
#endif
  }
#ifdef GPFS_PRINTK
  printk("xxx cxiGetDeviceInfo after nfsd func\n");
#endif

xerror:
  if (fdev.fl_device_list != NULL)
  {
    for (i = 0; i < j; i++)
    {
      dev = fdev.fl_device_list[i].fl_multipath_list;
      if (dev) {
        cxiFreeUnpinned(dev->r_addr.data);
        cxiFreeUnpinned(dev->r_netid.data);
        cxiFreeUnpinned(dev);
      }
    }
    cxiFreeUnpinned(fdev.fl_device_list);
  }

exit:

  TRACE2(TRACE_VNODE, 2, TRCID_CXI_GET_DEVICEINFO_EXIT,
         "cxiGetDeviceInfo exit: rc %d len %d", rc, len);
  return rc;

}

void cxiGetDevicePnfsId(void *devId, UInt32 myAddr, UInt32 seqNo,
                       UInt32 fsid0, UInt32 fsid1)
{
  struct nfsd4_pnfs_deviceid *dev_id = devId;
  UInt32 *sbid = (UInt32 *)&dev_id->sbid;
  UInt32 *devid = (UInt32 *)&dev_id->devid;

  sbid[0] = fsid0;
  sbid[1] = fsid1;
  devid[0] = seqNo;
  devid[1] = myAddr;

  TRACE4(TRACE_VNODE, 2, TRCID_CXI_GET_DEVICEINFO,
         "cxiGetDevicePnfsId: myAddr 0x%X seqNo %d FSID 0x%X:%X",
          myAddr, seqNo, fsid0, fsid1);
}

/* get layout
        lg_type
                in: requested layout type.
                out: available lauout type.
        lg_offset
                in: requested offset.
                out: returned offset.
        lg_length
                in: requested length.
                out: returned length.
        lg_mxcnt
                in: buffer size in bytes.
        lg_llist
                in: pointer to buffer.
        lg_layout
                out: number of items returned in the buffer.

   if the file is big(?) return all nodes in layout
   if the file is small return no layout or just one node, choose one node in
   random but make sure it is the same node for the same file.
*/

int
cxiGetLayout(int nDests, unsigned int startIndex, cxiVattr_t *vattr,
             UInt32 myAddr, UInt32 seqNo, void *args, void *res, void *xdr,
             UInt32 fsid0, UInt32 fsid1)
{
  int i, rc = 0, len = 0, fhlen;
  struct nfsd4_pnfs_layoutget_arg *gl = (struct nfsd4_pnfs_layoutget_arg *)args;
  struct pnfs_filelayout_layout *resP = res;
  struct pnfs_filelayout_layout *layout = NULL;
  struct knfsd_fh fh;
  struct knfsd_fh *fh_list = NULL;
  ENTER(0);

  TRACE3(TRACE_VNODE, 2, TRCID_CXI_GET_LAYOUT_ENTER,
         "cxiGetLayout: nDests %d startindx %d myAddr %x\n", nDests, startIndex, myAddr);

  /* Set file layout response args */
  resP->lg_layout_type = x_LAYOUT_NFSV4_1_FILES;
  resP->lg_stripe_type = STRIPE_SPARSE;
  resP->lg_commit_through_mds = TRUE;
  resP->lg_stripe_unit = cxiMaxIOsize(vattr->va_blocksize); /*preferred size*/
  resP->lg_first_stripe_index = startIndex;
  resP->lg_pattern_offset = 0;
  /* Ganesha will set it with export id, just use it to return myAddr, Ganesha will
     add it to the FH.handle_mds. */
  cxiGetDevicePnfsId(&resP->device_id, myAddr, seqNo, fsid0, fsid1);

  resP->lg_fh_length = 1; // 1 if use same FH by all DSs, use nDests if use different FH

exit:
  if (layout)
    cxiFreeUnpinned(layout);
  if (fh_list)
    cxiFreeUnpinned(fh_list);

  TRACE3(TRACE_VNODE, 2, TRCID_CXI_GET_LAYOUT_EXIT,
         "cxiGetLayout exit: rc %d len %d p 0x%lX", rc, len, layout);

  return rc;

xerror:
  goto exit;
}
#endif // P_NFS4

int cxiCheckThreadState(cxiThreadId tid)
{
  struct task_struct *t, *g;
  int rc = ENOENT;

#if defined(HAS_TASKLIST_LOCK)
  TASK_READ_LOCK;
  do_each_thread(g,t)
  {
    /* We are looking for a thread with a given tid and the same parent as
       the caller (the caller must be another mmfsd thread */
    if (t->pid == tid &&
        cxiStrcmp(t->comm, current->comm) == 0)
    {
      rc = 0;
      break;
    }
  } while_each_thread(g,t);
  TASK_READ_UNLOCK;
#else
  rcu_read_lock();
  t = FIND_TASK_BY_PID(tid);
  if (t && cxiStrcmp(t->comm, current->comm) == 0)
    rc = 0;
  rcu_read_unlock();
#endif

  return rc;
}


/* Internal type used to implement synchronization between an I/O
   interrupt handler and thread-level kernel driver code */
typedef struct
{
  spinlock_t tiLock;
  unsigned long tiFlags;
} ThreadIntLock_t;


/* Initialize a lock used to synchronize between an I/O interrupt
   handler and thread-level kernel driver code.  Return ENOMEM if the
   given area is too small to hold the lock state. */
int cxiInitIntLock(void* lockAreaP, int lockAreaSize)
{
  ThreadIntLock_t* tiLockP;

  if (sizeof(ThreadIntLock_t) > lockAreaSize)
  {
    TRACE3(TRACE_VNODE, 0, TRCID_LOCK_TOO_SMALL,
           "cxiInitIntLock: area at 0x%lX len %d is too small; increase to %d\n",
           lockAreaP, lockAreaSize, sizeof(ThreadIntLock_t));
    return ENOMEM;
  }

  tiLockP = (ThreadIntLock_t*)lockAreaP;
  spin_lock_init(&tiLockP->tiLock);
  tiLockP->tiFlags = 0;
  return 0;
}


/* Terminate a thread / interrupt lock */
void cxiTermIntLock(void* lockAreaP)
{
}


/* Disable interrupt and obtain the lock */
void cxiDisableLock(void* lockAreaP)
{
  ThreadIntLock_t* tiLockP;
  unsigned long flags;

  /* Store flags in a temporary to make it obvious that the flags field
     in the ThreadIntLock_t is not changed until the lock is held */
  tiLockP = (ThreadIntLock_t*)lockAreaP;
  spin_lock_irqsave(&tiLockP->tiLock, flags);
  tiLockP->tiFlags = flags;
}


/* Unlock the lock and re-enable interrupts */
void cxiUnlockEnable(void* lockAreaP)
{
  ThreadIntLock_t* tiLockP;
  unsigned long flags;

  /* Make a temporary copy of the flags field to make sure it cannot be
     changed by another caller of cxiDisableLock before it is needed */
  tiLockP = (ThreadIntLock_t*)lockAreaP;
  flags = tiLockP->tiFlags;
  tiLockP->tiFlags = 0;
  spin_unlock_irqrestore(&tiLockP->tiLock, flags);
}

void cxiCleanupCifsFile(void *vP, int fd)
{
  struct file *fileP = (struct file *)vP;

  TRACE2(TRACE_VNODE, 1, TRCID_CLEANUP_CIFS_FILE,
         "cxiCleanupCifsFile: pid %d fileP 0x%lX", getpid(), fileP);

  if (fileP && (fileP->f_op == &gpfs_cleanup_cifs_fops))
  {
    /* Called during unregister of a process to close the associated file
       descriptor; but first remove its file operations table or we will
       recurse when it calls gpfs_f_cleanup_cifs/gpfsCleanupCifs. */

    fileP->f_op = &gpfs_null_fops;

    /* Unfortunately, the file pointer is an RCU-protected value so our update
     * may not be seen immediately, and as a result a call to close here may
     * still result in a callback to gpfsCleanupCifs/findAndRemove which will
     * detect this and return without any action when this happens.
     */

    sys_close(fd); /* fput(fileP) done by close */
  }

  return;
}

int cxiRegisterCifsCleanup(void **vPP, int *fdP)
{
  int code = 0, rc = 0;
  int fd = 0;
  struct inode *iP = NULL;
  struct file *fileP = NULL;
  struct dentry *dentryP = NULL;
  extern struct super_block *shutdownSuperP;
#if defined(USE_ALLOC_FILE)
  struct path path;
#endif

  ENTER(0);

  /* Allocate an inode struct */
  iP = new_inode(shutdownSuperP);
  if (!iP)
  {
    code = 1;
    rc = ENOMEM;
    goto xerror;
  }

  /* Set file type to something other than regular file (S_IFREG) to
     prevent the Integrity Measurement Architecture (IMA) runtime from
     counting this file and complaining about imbalance. */
  iP->i_mode = S_IFBLK;

  /* Allocate an available file descriptor */
  fd = get_unused_fd();
  if (fd < 0)
  {
    code = 2;
    rc = ENFILE;
    goto xerror;
  }

#if defined(USE_ALLOC_FILE)
  /* Allocate a dentry sruct */
#ifdef NEW_D_MAKE_ROOT
  dentryP = dget(d_make_root(iP));
#else
  dentryP = dget(d_alloc_root(iP));
#endif
  if (!dentryP)
  {
#ifdef NEW_D_MAKE_ROOT
    /* If fail, d_make_root will iput root inode itself */
    iP = NULL;
#endif
    code = 4;
    rc = ENOMEM;
    goto xerror;
  }
  /* Just chain it on the current root mount.  When
   * the file is closed its fput() will decrement
   * the mount count (hence the mntget here)
   */
  path.mnt = mntget(TASK_ROOTMNT(current));
  path.dentry = dentryP;

  /* Allocate a file struct */
  fileP = alloc_file(&path, 0, &gpfs_cleanup_cifs_fops);
  if (!fileP)
  {
    code = 3;
    rc = ENFILE;
    goto xerror;
  }
#else
  /* Allocate a file struct */
  fileP = get_empty_filp();
  if (!fileP)
  {
    code = 3;
    rc = ENFILE;
    goto xerror;
  }

  /* Allocate a dentry sruct */
#ifdef NEW_D_MAKE_ROOT
  dentryP = dget(d_make_root(iP));
#else
  dentryP = dget(d_alloc_root(iP));
#endif
  if (!dentryP)
  {
#ifdef NEW_D_MAKE_ROOT
    /* If fail, d_make_root will iput root inode itself */
    iP = NULL;
#endif
    code = 4;
    rc = ENOMEM;
    goto xerror;
  }

  /* Initialize and chain our file sructure */
  fileP->f_dentry = dentryP;
  fileP->f_op     = &gpfs_cleanup_cifs_fops;

  /* Just chain it on the current root mount.  When
   * the file is closed its fput() will decrement
   * the mount count (hence the mntget here)
   */

  fileP->f_vfsmnt = mntget(TASK_ROOTMNT(current));
#endif


  fileP->f_flags  = O_RDONLY;
#ifdef LONG_FILECOUNT
  atomic_long_set(&fileP->f_count, 1);
#else
  atomic_set(&fileP->f_count, 1);
#endif


  /* Install the descriptor so it gets "closed" upon termination */
  fd_install(fd, fileP);

  /* Set FD_CLOEXEC so that forked processes do not inherrit
   * this descriptor.
   */
#if LINUX_KERNEL_VERSION >= 2061300
  FD_SET_BIT(cleanupFD, current->files->fdt->close_on_exec);
#else
  FD_SET_BIT(cleanupFD, current->files->close_on_exec);
#endif

xerror:
  if (rc)
  {
    if (dentryP);
      dput(dentryP);

    if (fd)
      put_unused_fd(fd);

    if (fileP)
#if LINUX_KERNEL_VERSION > 2060900
      fput(fileP);
#else
      put_filp(fileP);
#endif

    /* Clear return values on error */
    fileP = NULL;
    fd = 0;

    if (iP)
      iput(iP);
  }

  /* Return file pointer and descriptors */
  *vPP = (void *)fileP;
  *fdP = fd;

  TRACE6(TRACE_VNODE, 1, TRCID_REGISTER_CIFS_CLEANUP,
         "cxiRegisterCifsCleanup: rc %d code %d pid %d name '%s' fd %d fileP 0x%lX",
         rc, code, getpid(), current->comm, fd, fileP);

  EXIT_RC(0, rc);
  return rc;
}

/* Translate the CIFS file descriptor (from a cifsThreadData_t) into vinfoP */
void * cxiGetVinfoP(int fd)
{
  int rc = 0;
  int code = 0;
  struct file *fP = NULL;
  void  *vinfoP = NULL;
  struct inode *iP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;

  ENTER(0);

  fP = fget(fd);
  if (!fP || !fP->f_dentry || !fP->f_dentry->d_inode)
  {
    rc = EINVAL;
    code = 10;
    goto xerror;
  }

  iP = fP->f_dentry->d_inode;
  if (!iP || !(privVfsP = VP_TO_PVP(iP)))
  {
    rc = EBADF;
    code = 20;
    goto xerror;
  }

  if (!GPFS_TYPE(iP))
  {
    rc = EBADF;
    code = 30;
    goto xerror;
  }

  vinfoP = (struct MMFSVInfo *)fP->private_data;

xerror:
  if (fP)
    fput(fP);

  TRACE6(TRACE_VNODE, 2, TRCID_CXI_GET_VINFO_EXIT,
         "cxiGetVinfoP exit: rc %d code %d fd %d iP 0x%lX fP 0x%lX vinfoP 0x%lX",
         rc, code, fd, iP, fP, vinfoP);

  return (rc? NULL: vinfoP);
}
