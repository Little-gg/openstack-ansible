/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)41       1.155  src/avs/fs/mmfs/ts/kernext/gpl-linux/verdep.h, mmfs, avs_rfks0, rfks01416c 4/7/14 15:11:35 */
#ifndef _h_verdep
#define _h_verdep

# include <linux/version.h>
# include <linux/buffer_head.h>
# include <linux/kdev_t.h>
# include <linux/namei.h>
# include <linux/mount.h>
# include <linux/page-flags.h>
# include <linux/security.h>
# include <linux/sched.h>
# include <linux/init.h>
# include <linux/fs.h>

# include <cxiTypes.h>
# include <cxiSystem.h>
# include <Logger-gpl.h>
# include <linux/moduleparam.h>

/* Needed for DENTRY_OPEN predefined in verdep.h */
/* path.h is newly added by 3.4 Linux kernel */
#if (LINUX_KERNEL_VERSION >= 3040000)
# include <linux/path.h>
#endif

#if (LINUX_KERNEL_VERSION >= 2061200)
#include <linux/sort.h>
#endif
#if (LINUX_KERNEL_VERSION >= 2063100)
# include <linux/nsproxy.h>
#endif

#if (LINUX_KERNEL_VERSION < 2063900)
#include <linux/smp_lock.h>
#endif

/* needed by task_active_pid_ns() */
#if (LINUX_KERNEL_VERSION >= 3110000)
#include <linux/pid_namespace.h>
#endif

/* needed by uid&gid related function, such as from_kgid() make_kuid() */
#if (LINUX_KERNEL_VERSION >= 3050000)
#include <linux/uidgid.h>
/* needed by init_user_ns */
#include <linux/cred.h>
#endif

#if (defined(SUSE_LINUX) && (LINUX_KERNEL_VERSION == 2060507) && (!defined(I_WILL_FREE)))
#error "GPFS no longer supports SLES 9 distributions eariler than SP3."
#endif

/* from 2.6.22, thread_info is moved to stack in  task_struct */
#if (LINUX_KERNEL_VERSION >= 2062200)
#define TASK_THREAD_INFO(task) ((struct thread_info *)(task)->stack)
#else 
#define TASK_THREAD_INFO(task) (task->thread_info)
#endif 

/* Distro-specific defines */
# if (defined(SUSE_LINUX) && defined(LINUX_KERNEL_VERSION) && LINUX_KERNEL_VERSION >= 2063200)
#    define SUSE_SLES11SP1
# elif (defined(SUSE_LINUX) && defined(LINUX_KERNEL_VERSION) && LINUX_KERNEL_VERSION >= 2062700)
#    define SUSE_SLES11  
# elif  (defined(SUSE_LINUX) && defined(SLE_VERSION_CODE) && SLE_VERSION_CODE >= 655872)
#    define SUSE_SLES10SP2
# endif
# if (defined(SUSE_LINUX) && defined(LINUX_KERNEL_VERSION) && LINUX_KERNEL_VERSION == 2060507)
#    define SUSE_SLES9
# endif
# if defined(REDHAT_AS_LINUX)
#   if LINUX_KERNEL_VERSION >= 3100000
#     define REDHAT_RHEL7
#   else
#     if LINUX_KERNEL_VERSION >= 2063200
/* temp code to support slightly older RHEL 6 BETAs ... will be removed */
#       define REDHAT_RHEL6
#     else
#       if defined(RHEL_RELEASE_CODE)
#         if RHEL_RELEASE_CODE >= 1536
#           define REDHAT_RHEL6
#         else
#           if RHEL_RELEASE_CODE >= 1282
#             define REDHAT_RHEL52
#             define REDHAT_RHEL5
#           endif
#           if RHEL_RELEASE_CODE >= 1283
#             define REDHAT_RHEL53
#             define REDHAT_RHEL5
#           endif
#           if RHEL_RELEASE_CODE >= 1284
#             define REDHAT_RHEL54
#             define REDHAT_RHEL5
#           endif
#           if RHEL_RELEASE_CODE >= 1285
#             define REDHAT_RHEL55
#             define REDHAT_RHEL5
#           endif
#         endif
#       endif /* if defined(RHEL_RELEASE_CODE) */
#     endif  /* if LINUX_KERNEL_VERSION >= 2063200 */
#   endif /* if LINUX_KERNEL_VERSION >= 3100000 */
# endif /* if REDHAT_AS_LINUX */  


#if defined(GPFS_ARCH_X86_64) && defined(REDHAT_AS_LINUX) && \
  !defined(REDHAT_RHEL6) && !defined(REDHAT_RHEL5) && !defined(REDHAT_RHEL7)

#define GPL_GET_FIXED_ADDRS(var1,var2,var3,var4) \
{ \
  var1 = ((char*)0x0000005100000000UL); /* page pool offset 324 GB */ \
  var3 = ((char*)0x0000005000000000UL); /* tm pool offset 320 GB */ \
  if (var4 > 0x00000000100000000) \
    var4 = 0x00000000100000000;         /* tm pool size 4 GB */ \
}

#define GPL_GET_SHARED_SEG_ADDRS(var1,var2) \
{ \
  var1 = 0x0000001000000000UL; \
  var2 = 0x0000001FFFFFFFFFUL; \
}

#else

#define GPL_GET_FIXED_ADDRS(var1,var2,var3,var4)
#define GPL_GET_SHARED_SEG_ADDRS(var1,var2)

#endif

# if defined(REDHAT_RHEL6)
#    define HAVE_COREDUMP_PARAMS
# endif

/* get_empty_filp() not exported in new kernels, use alloc_file() instead */
# if defined(REDHAT_RHEL6) || LINUX_KERNEL_VERSION >= 2063300
#    define USE_ALLOC_FILE
# endif

# if LINUX_KERNEL_VERSION >= 2063200
#   define BINFMT (current->mm->binfmt)
# else
#   define BINFMT (current->binfmt)
# endif

# if LINUX_KERNEL_VERSION >= 2063700
  /* Linux 2.6.37 killed PF_FLUSHER. Actually, we never call CURRENT_IS_PDFLUSH
   when MUST_DEFINE_SYNCFS is defined (since 2.6.31). It's okay to return false */
#   define CURRENT_IS_PDFLUSH() false
# elif LINUX_KERNEL_VERSION >= 2063200
#   define CURRENT_IS_PDFLUSH() (current->flags & PF_FLUSHER)
# else
#   define CURRENT_IS_PDFLUSH() (current_is_pdflush())
# endif

# if LINUX_KERNEL_VERSION >= 2063100
#   define BDEV_LOGICAL_BLOCK_SIZE(bdevP) (bdev_logical_block_size(bdevP))
#   define BDEV_PHYSICAL_BLOCK_SIZE(bdevP) (bdev_physical_block_size(bdevP))
# else
#   define BDEV_LOGICAL_BLOCK_SIZE(bdevP) (bdev_hardsect_size(bdevP))
#   define BDEV_PHYSICAL_BLOCK_SIZE(bdevP) (bdev_hardsect_size(bdevP))
# endif

# if LINUX_KERNEL_VERSION >= 2063200
#   define BDEV_ALIGNMENT_OFFSET(bdevP) (bdev_alignment_offset(bdevP))
# elif LINUX_KERNEL_VERSION >= 2063100
#   define BDEV_ALIGNMENT_OFFSET(bdevP) \
           (queue_alignment_offset(bdev_get_queue(bdevP)))
# else
#   define BDEV_ALIGNMENT_OFFSET(bdevP) (0)
# endif

# if (defined(SUSE_LINUX) && defined(SLE_VERSION_CODE) && SLE_VERSION_CODE >= 656128)
#    define STATFS_USES_DENTRY
# endif

/* Newer kernels fold readv and writev fops into aio_read and aio_write
   and use an iovec instead of buffer and length */
# if LINUX_KERNEL_VERSION >= 2061900
#   define KERNEL_HAS_NEW_AIO_FOPS
# endif

/* Newer kernels do not require work_struct data initialization */
# if LINUX_KERNEL_VERSION >= 2062000
# define GPFS_DECLARE_WORK(n, f) DECLARE_WORK(n, (work_func_t)f)
# else
# define GPFS_DECLARE_WORK(n, f) DECLARE_WORK(n, f, 0)
# endif

  /* Inode state indicators.
     SLES9 2.6.5-7.244+ kernels and SLES10 kernels require truncate_inode_pages
     to be called from the delete_inode sop and check for I_WILL_FREE flag, 
     RHEL4 kernels do not (thus far).  */
# if (defined(SUSE_LINUX) &&  LINUX_KERNEL_VERSION >= 2060507) || \
     (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION > 2061800) || \
     (defined(KERNEL_ORG_LINUX) && LINUX_KERNEL_VERSION > 2061300) || \
     (defined(DEBIAN_LINUX) && LINUX_KERNEL_VERSION > 2061300) || \
     (defined(FEDORA_LINUX) && LINUX_KERNEL_VERSION > 2061300)
     
#   define INODE_BEING_RELEASED (I_FREEING|I_CLEAR|I_WILL_FREE)
#   if defined(I_LOCK)
#     define INODE_INIT_INCOMPLETE (I_CLEAR|I_LOCK|I_NEW|I_WILL_FREE)
#   else
#     define INODE_INIT_INCOMPLETE (I_CLEAR|I_NEW|I_WILL_FREE)
#     define I_LOCK 0
#   endif
    /* required if file system defines delete_inode */
#   define MUST_TRUNCATE_INODE_PAGES 1
# else
#   define INODE_BEING_RELEASED (I_FREEING|I_CLEAR)
#   define INODE_INIT_INCOMPLETE (I_CLEAR|I_LOCK|I_NEW)
#   define MUST_TRUNCATE_INODE_PAGES 0
# endif

/* Sort routine not provided in all kernels */
# if defined(REDHAT_LINUX) || (LINUX_KERNEL_VERSION >= 2061200)
#   include <linux/sort.h>
#   define SORT(a,b,s,fn)   sort(a,b,s,fn,NULL)
# elif defined(SUSE_SLES9)
#   define SORT(a,b,s,fn)   qsort(a,b,s,fn)
# else
#   define SORT(a,b,s,fn)   do {} while (0)
/*  #error "No sort routine defined for this kernel" */
# endif


  /* Support for cluster-aware NFS locks in present in kernels > 2.6.22
     and backported to SLES10 SP2 and RHEL > 5.2 */
# if defined(SUSE_SLES10SP2) || defined(REDHAT_RHEL5) || \
     (LINUX_KERNEL_VERSION >= 2062200)
#   define NFS_CLUSTER_LOCKS
# endif

  /* Support for cluster-aware leases */
# if defined(SUSE_SLES10SP2) || defined(REDHAT_RHEL53) || \
     (LINUX_KERNEL_VERSION >= 2062300)
#   define CLUSTER_LEASES
# endif

  /* Call to issue POSIX setlease */
# ifdef CLUSTER_LEASES
#   ifdef REDHAT_RHEL53
#     define POSIX_SETLEASE(fP, arg, flPP)  __setlease(fP, arg, flPP)
#   else
#     define POSIX_SETLEASE(fP, arg, flPP)  generic_setlease(fP, arg, flPP)
#   endif
# else
#     define POSIX_SETLEASE(fP, arg, flPP)  0
# endif

/* linux 2.6.38 killed dcache_lock with fine-grain locks. */
# if LINUX_KERNEL_VERSION >= 2063800
# define RCU_WALK_FOR_PATH_LOOKUP
# define DCACHE_LOCK_IS_GONE
# endif

  /* Uncache a directory entry.  Must hold dcache lock. */
# ifdef DCACHE_LOCK_IS_GONE
  /* __d_drop() still requires dentry->d_lock. But since
    dcache lock is gone, gpfs code already hold d_lock before all
    occurs of this call. DBGASSERT is added to make sure about it */
# define DENTRY_DROP(DP)  \
  {  \
    DBGASSERT(spin_is_locked(&(DP)->d_lock)); \
    __d_drop(DP); \
  }
# else
# define DENTRY_DROP(DP)  \
  {  \
    spin_lock(&(DP)->d_lock); \
    __d_drop(DP); \
    spin_unlock(&(DP)->d_lock); \
  }
# endif

  /* Uncache a directory entry.  Must hold *NO* locks. */
  /* __d_drop checks state of DCACHE_UNHASHED prior to drop. */
# ifdef DCACHE_LOCK_IS_GONE
# define DENTRY_D_DROP(DP) d_drop(DP)
# else
# define DENTRY_D_DROP(DP)  \
  {  \
    spin_lock(&dcache_lock); \
    spin_lock(&(DP)->d_lock); \
    __d_drop(DP); \
    spin_unlock(&(DP)->d_lock); \
    spin_unlock(&dcache_lock); \
  }
#endif

/* Linux 2.6.37~3.10.xx uses a spin-lock to replace BKL */
/* 3.11 and RHEL7 removed lock_flocks() and unlock_flocks(), and use
   spin_lock(&inode->i_lock) and spin_unlock(&inode->i_lock) instead */
#if (LINUX_KERNEL_VERSION >= 3110000) || defined(REDHAT_RHEL7)
# define HAS_FILE_INODE
# define LOCK_FLOCKS(inodeP) spin_lock(&inodeP->i_lock) 
# define UNLOCK_FLOCKS(inodeP) spin_unlock(&inodeP->i_lock)
#elif LINUX_KERNEL_VERSION >= 2063700 && LINUX_KERNEL_VERSION < 3110000
# define LOCK_FLOCKS(inodeP) lock_flocks()
# define UNLOCK_FLOCKS(inodeP) unlock_flocks() 
#else
# define LOCK_FLOCKS(inodeP) do {} while (0)
# define UNLOCK_FLOCKS(inodeP) do {} while (0)
#endif

/* 3.11 drop unused filp argument to posix_unblock_lock */
#if (LINUX_KERNEL_VERSION >= 3110000) || defined(REDHAT_RHEL7)
# define POSIX_UNBLOCK_LOCK(filp, waiter) posix_unblock_lock(waiter)
#else
# define POSIX_UNBLOCK_LOCK(filp, waiter) posix_unblock_lock(filp, waiter)
#endif

#if LINUX_KERNEL_VERSION >= 2061300 || \
   (LINUX_KERNEL_VERSION == 2060507 && defined(SUSE_LINUX))
#define MY_INIT_LIST_HEAD(SINODES) INIT_LIST_HEAD(SINODES)
#else
#define MY_INIT_LIST_HEAD(SINODES) 
#endif

#if (LINUX_KERNEL_VERSION >= 2063100)
#define SET_SUPER_USE_SGET
#elif (LINUX_KERNEL_VERSION >= 2062400)
# define SET_SUPER_BLOCK(SBP,SOPS)                \
  {                                               \
    memset((SBP), 0, sizeof(struct super_block)); \
    (SBP)->s_op = SOPS;                           \
    (SBP)->s_flags |= MS_ACTIVE;                  \
    (SBP)->s_type = &gpfs_fs_type;                \
    MY_INIT_LIST_HEAD(&((SBP)->s_inodes));        \
  }

# define UNSET_SUPER_BLOCK(SBP)                   \
  {						  \
  }
#else
# define SET_SUPER_BLOCK(SBP,SOPS)                \
  {                                               \
    memset((SBP), 0, sizeof(struct super_block)); \
    (SBP)->s_op = SOPS;                           \
    (SBP)->s_flags |= MS_ACTIVE;                  \
    (SBP)->s_type = &gpfs_fs_type;                \
    security_sb_alloc(SBP);			  \
    MY_INIT_LIST_HEAD(&((SBP)->s_inodes));        \
  }

# define UNSET_SUPER_BLOCK(SBP)              \
  {						  \
    security_sb_free(SBP);			  \
  }
#endif

#if (LINUX_KERNEL_VERSION >= 2062500)
#define sb_entry(list)        list_entry((list), struct super_block, s_list)
#define TASK_PWD(tsP)         ((tsP)->fs ? &(tsP)->fs->pwd : NULL)
#define TASK_PWDMNT(tsP)      ((tsP)->fs ? (tsP)->fs->pwd.mnt : NULL)
#define TASK_ROOTMNT(tsP)     ((tsP)->fs ? (tsP)->fs->root.mnt : NULL)
#define NDP_TO_IP(ndP)        (ndP)->path.dentry->d_inode;
#define ND_PATH(nd)           (nd).path
#define EXP_DENTRY(expP)      (expP)->ex_path.dentry
#define PATH_PUT(ndP)         path_put(&(ndP)->path)
#else
#define TASK_PWD(tsP)         ((tsP)->fs ? (tsP)->fs->pwd : NULL)
#define TASK_PWDMNT(tsP)      ((tsP)->fs ? (tsP)->fs->pwdmnt : NULL)
#define TASK_ROOTMNT(tsP)     ((tsP)->fs ? (tsP)->fs->rootmnt : NULL)
#define NDP_TO_IP(ndP)        (ndP)->dentry->d_inode
#define ND_PATH(nd)           (nd)
#define EXP_DENTRY(expP)      (expP)->ex_dentry
#define PATH_PUT(ndP)         path_release(ndP)
#endif

#if (LINUX_KERNEL_VERSION >= 2062400)
# define PROCESS_GROUP(T)            task_pgrp_nr(T)
#else
# define PROCESS_GROUP(T)            process_group(T)
#endif


/* Kernels 2.6.30 or later introduce a new f_lock.
   RHEL5.4 kernels (2.6.18-164.11.1.el5) implement a similar change,
   but use f_ep_lock instead. */

#if LINUX_KERNEL_VERSION >= 2063000
#  define FILE_LOCK_INIT(FP) spin_lock_init(&FP->f_lock)
#elif defined(REDHAT_RHEL54)
#  define FILE_LOCK_INIT(FP) spin_lock_init(&FP->f_ep_lock)
#else
#  define FILE_LOCK_INIT(FP) NOOP
#endif


#if defined(NFS_CLUSTER_LOCKS) && !defined(REDHAT_RHEL5)
# define POSIX_LOCK_FILE(FLP1,FLP2)  posix_lock_file((FLP1),(FLP2), NULL)
# define posix_lock_file_conf        posix_lock_file
#else
# define POSIX_LOCK_FILE(FLP1,FLP2)  posix_lock_file((FLP1),(FLP2))
#endif

# define CXITIME_TO_INODETIME(CXITIME, ITIME)   \
  {                                             \
    (ITIME).tv_sec = (CXITIME).tv_sec;          \
    (ITIME).tv_nsec = (CXITIME).tv_nsec;        \
  }
# define CXITIME_FROM_INODETIME(CXITIME, ITIME) \
  {                                             \
    (CXITIME).tv_sec = (ITIME).tv_sec;          \
    (CXITIME).tv_nsec = (ITIME).tv_nsec;        \
  }

#if (LINUX_KERNEL_VERSION < 2061700)
#define NFS_FATTR_FSID(fattrP)  ((fattrP)->fsid_u.nfs4)
#else
#define HAS_NFS_SUBMOUNTS
#define NFS_FATTR_FSID(fattrP)  ((fattrP)->fsid)
#endif

#if ((LINUX_KERNEL_VERSION < 2061400) || LINUX_KERNEL_VERSION >= 3060000)
#define INTENT_OPEN_FLAGS(ndP)              (ndP)->flags
#define SET_INTENT_OPEN_FILE(ndP, fP)       do {} while (0)
#define SET_OPEN_INTENT(ndP, flags, mode)   do {} while (0)
#else
#define LOOKUP_INTENT
#ifdef SUSE_SLES9
#define INTENT_OPEN_FLAGS(ndP)       (ndP)->intent.it_flags
#define INTENT_OPEN_CREATE_MODE(ndP) (ndP)->intent.it_create_mode
#else /* SUSE_SLES9 */
#define INTENT_OPEN_FLAGS(ndP)       (ndP)->intent.open.flags
#define INTENT_OPEN_CREATE_MODE(ndP) (ndP)->intent.open.create_mode
#endif /* SUSE_SLES9 */
#define SET_INTENT_OPEN_FILE(ndP, fP) do { (ndP)->intent.open.file = fP; } while (0)
#define SET_OPEN_INTENT(ndP, flags, mode) \
  do { INTENT_OPEN_FLAGS(ndP) = flags; INTENT_OPEN_CREATE_MODE(ndP) = mode; } while (0)
#endif

#if (LINUX_KERNEL_VERSION >= 2061300)
#define NFS_CACHE_VALIDITY_FLAGS(iP)  NFS_I(iP)->cache_validity
#else
#define NFS_CACHE_VALIDITY_FLAGS(iP)  NFS_I(iP)->flags
#endif

/* module_param_string argument setting the permissions on
   prog_path and mmfsd_path, in /sys/module/mmfslinux/parameters */
#define PERM 0664

#if (LINUX_KERNEL_VERSION >= 2060700)
#define PUTNAME __putname
#else
#define PUTNAME putname
#endif

#define GPFS_KERNEL_OFFSET (UIntPtr) PAGE_OFFSET

#if LINUX_KERNEL_VERSION >= 2060600 || \
   (LINUX_KERNEL_VERSION == 2060507 && defined(SUSE_LINUX))
#define UNMAP_MAPPING_RANGE(MAPPING, START, STOP) unmap_shared_mapping_range(MAPPING, START, STOP);
#define MMAP_WRITE_ACCESS(WRITEACCESS) WRITEACCESS = true;
#elif defined(MMAP_LINUX_PATCH)
#define UNMAP_MAPPING_RANGE(MAPPING, START, STOP) invalidate_mappings(MAPPING, START);
#define MMAP_WRITE_ACCESS(WRITEACCESS) WRITEACCESS = true;
#else
#define UNMAP_MAPPING_RANGE(MAPPING, START, STOP) 
#define MMAP_WRITE_ACCESS(WRITEACCESS) WRITEACCESS = false;
#endif

#if LINUX_KERNEL_VERSION >= 2060900
#define VFS_FOLLOW_LINK(RC, ND, BUF) nd_set_link(ND, BUF); BUF = NULL
#else
#define VFS_FOLLOW_LINK(RC, ND, BUF) RC = vfs_follow_link(ND, BUF)
#endif

/* To support NFSv4 delegations at the vfs level, 3.13 and RH7(3.10.0-97)
   pass one new parameter delegated_inode to notify_change, vfs_link, 
   vfs_unlink, and vfs_rename. Simply Passing NULL to the newly added 
   parameter here, which may be appropriate for callers that expect the
   underlying filesystem not to be NFS exported. Need add more code in 
   GPFS to handle this change of kernel */
#if (LINUX_KERNEL_VERSION >= 3130000) || (defined REDHAT_RHEL7)
#define NOTIFY_CHANGE(dentryP, attrP) notify_change(dentryP, attrP, NULL)
#define BREAK_LEASE(inodeP, mode)       __break_lease(inodeP, mode, FL_LEASE)
#define VFS_LINK(vfsP, sdP, diP, tdP)         vfs_link(sdP, diP, tdP, NULL)
#define VFS_UNLINK(vfsP, diP, dP)             vfs_unlink(diP, dP, NULL)
#define VFS_RENAME(vfsP, sdiP, sdP, tdiP, tdP) vfs_rename(sdiP, sdP, tdiP, tdP, NULL)
#else
#define NOTIFY_CHANGE(dentryP, attrP) notify_change(dentryP, attrP)
#define BREAK_LEASE(inodeP, mode)       __break_lease(inodeP, mode)
#if defined(SUSE_SLES10SP2) || defined(SUSE_SLES11) || defined(UBUNTU_LINUX)
#define VFS_LINK(vfsP, sdP, diP, tdP)         vfs_link(sdP, vfsP, diP, tdP, vfsP)
#define VFS_UNLINK(vfsP, diP, dP)             vfs_unlink(diP, dP, vfsP)
#define VFS_RENAME(vfsP, sdiP, sdP, tdiP, tdP) vfs_rename(sdiP, sdP, vfsP, tdiP, tdP, vfsP)
#else
#define VFS_LINK(vfsP, sdP, diP, tdP)         vfs_link(sdP, diP, tdP)
#define VFS_UNLINK(vfsP, diP, dP)             vfs_unlink(diP, dP)
#define VFS_RENAME(vfsP, sdiP, sdP, tdiP, tdP) vfs_rename(sdiP, sdP, tdiP, tdP)
#endif
#endif

#if defined(SUSE_SLES10SP2) || defined(SUSE_SLES11) || defined(UBUNTU_LINUX)
#define VFS_MKDIR(vfsP, diP, dP, mode)        vfs_mkdir(diP, dP, vfsP, mode)
#define VFS_MKNOD(vfsP, diP, dP, mode, dev)   vfs_mknod(diP, dP, vfsP, mode, dev)
#define VFS_RMDIR(vfsP, diP, dP)              vfs_rmdir(diP, dP, vfsP)
#else
#define VFS_MKDIR(vfsP, diP, dP, mode)        vfs_mkdir(diP, dP, mode)
#define VFS_MKNOD(vfsP, diP, dP, mode, dev)   vfs_mknod(diP, dP, mode, dev)
#define VFS_RMDIR(vfsP, diP, dP)              vfs_rmdir(diP, dP)
#endif

#if (!defined(SUSE_SLES11) && !defined(UBUNTU_LINUX) && LINUX_KERNEL_VERSION >= 2062700) || defined(SUSE_SLES9)
#define VFS_SYMLINK(vfsP, diP, dP, nameP)     vfs_symlink(diP, dP, nameP);
#elif defined(SUSE_SLES10SP2) 
#define VFS_SYMLINK(vfsP, diP, dP, nameP)     vfs_symlink(diP, dP, vfsP, nameP, 0);
#elif defined(SUSE_SLES11) || defined(UBUNTU_LINUX)
#define VFS_SYMLINK(vfsP, diP, dP, nameP)     vfs_symlink(diP, dP, vfsP, nameP);
#else
#define VFS_SYMLINK(vfsP, diP, dP, nameP)     vfs_symlink(diP, dP, nameP, 0);
#endif

#if (LINUX_KERNEL_VERSION >= 3060000)
#define DOP_REVALIDATE(dP, ndP)   (dP)->d_op->d_revalidate(dP, (ndP)->flags)
#define INODE_OP_LOOKUP(dirP, dP, ndP) (dirP)->i_op->lookup(dirP, dP, (ndP)->flags)
#define VFS_CREATE(diP, dP, mode, nd)  vfs_create(diP, dP, mode, (nd).flags & LOOKUP_EXCL)
#define NEW_VFS_CREATE
#else
#define DOP_REVALIDATE(dP, ndP)   (dP)->d_op->d_revalidate(dP, ndP)
#define INODE_OP_LOOKUP(dirP, dP, ndP) (dirP)->i_op->lookup(dirP, dP, ndP)
#define VFS_CREATE(diP, dP, mode, nd)  vfs_create(diP, dP, mode, &(nd))
#endif

static inline int VFS_FSYNC(struct file *fP)
{
  struct dentry *dP = fP->f_dentry;
  int err;
#if (LINUX_KERNEL_VERSION >= 2063500)
  err = vfs_fsync(fP, 1); 
#elif (LINUX_KERNEL_VERSION >= 2062900)
  err = vfs_fsync(fP, dP, 1); 
#else
  err = filemap_fdatawrite(dP->d_inode->i_mapping);
  if (err == 0 && fP->f_op && fP->f_op->fsync)
    err = fP->f_op->fsync(fP, dP, 0);
  if (err == 0)
    err = filemap_fdatawait(dP->d_inode->i_mapping);
#endif
  return err;
}

#if LINUX_KERNEL_VERSION >= 2061000
#define MY_RLIM_CUR(WHAT) current->signal->rlim[WHAT].rlim_cur
#else
#define MY_RLIM_CUR(WHAT) current->rlim[WHAT].rlim_cur
#endif

#if LINUX_KERNEL_VERSION >= 2061000
#define GENERIC_PERMISSION_OP gpfs_i_permission_noacl
#else
#define GENERIC_PERMISSION_OP vfs_permission
#endif

#if LINUX_KERNEL_VERSION >= 2061600
#define d_child d_u.d_child
#endif

#if LINUX_KERNEL_VERSION >= 2060900
#define HAS_IOP_PUT_LINK
#endif

#if (LINUX_KERNEL_VERSION > 2061800) || defined(REDHAT_RHEL5)
#define PRVINODE i_private
#else
#define PRVINODE u.generic_ip
#endif

#define cxiDevMajor(D)       ((UInt32)((D) >> 20))
#define cxiDevMinor(D)       ((UInt32)((D) & 0xfffff))
#define cxiDevToKernelDev(D) new_decode_dev(D)
#define cxiDev32ToDev(D) \
  (cxiDev_t)((cxiDev32Major(D) << 8) | \
             (cxiDev32Minor(D) & 0xFF) | \
             ((cxiDev32Minor(D) & ~0xFF) << 12))

#if LINUX_KERNEL_VERSION >= 2062000
#define SLAB_KERNEL GFP_KERNEL
#endif

#if LINUX_KERNEL_VERSION >= 2061800
#define INODE_LOCK_NESTED(iP, flag)    mutex_lock_nested(&(iP)->i_mutex, flag)
#define INODE_LOCK(iP)    mutex_lock(&(iP)->i_mutex)
#define INODE_UNLOCK(iP)  mutex_unlock(&(iP)->i_mutex)
#elif LINUX_KERNEL_VERSION >= 2061600
#define INODE_LOCK_NESTED(iP, flag)    mutex_lock(&(iP)->i_mutex)
#define INODE_LOCK(iP)    mutex_lock(&(iP)->i_mutex)
#define INODE_UNLOCK(iP)  mutex_unlock(&(iP)->i_mutex)
#else
#define INODE_LOCK_NESTED(iP, flag)    down(&(iP)->i_sem)
#define INODE_LOCK(iP)    down(&(iP)->i_sem)
#define INODE_UNLOCK(iP)  up(&(iP)->i_sem)
#endif

#if LINUX_KERNEL_VERSION < 2061800
#define HAS_TASKLIST_LOCK
#define TASK_READ_LOCK read_lock(&tasklist_lock);
#define TASK_READ_UNLOCK read_unlock(&tasklist_lock);
#else
#include <linux/rcupdate.h>
#endif

/* FL_CLOSE was introduced in 2.6.18, but also defined in
   SLES SP2 2.6.16-60.*/
#if (LINUX_KERNEL_VERSION >= 2061600) && defined(FL_CLOSE)
#define HAS_FL_CLOSE
#endif

#if LINUX_KERNEL_VERSION >= 2061900 || \
    (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION >= 2061800)
#define INODE_USES_BLKBITS
#endif 

#if defined(INODE_USES_BLKBITS)
#define SET_INODE_BLOCKSIZE(inodeP, blocksize) \
  (inodeP)->i_blkbits = myblksize_bits((unsigned int)(blocksize));
#define GET_INODE_BLOCKSIZE(inodeP) (1 << (inodeP)->i_blkbits)
#else
#define SET_INODE_BLOCKSIZE(inodeP, blocksize) \
  (inodeP)->i_blksize = (blocksize);
#define GET_INODE_BLOCKSIZE(inodeP) ((inodeP)->i_blksize)
#endif

#if LINUX_KERNEL_VERSION < 2061700
#define HAS_PIDTYPE_TGID
#endif

#if LINUX_KERNEL_VERSION >= 2062000
#define KMEM_CACHE_T struct kmem_cache
#else
#define KMEM_CACHE_T kmem_cache_t
#endif

#if LINUX_KERNEL_VERSION >= 2062600
#define SEM_COUNT(semP)         (semP)->count
#define SEM_WAIT_TASKLIST(semP) ((semP)->wait_list)
#else
#define SEM_COUNT(semP)         atomic_read(&(semP)->count)
#define SEM_WAIT_TASKLIST(semP) ((semP)->wait.task_list)
#endif

#if LINUX_KERNEL_VERSION >= 3110000
#define FIND_TASK_BY_PID(x) (pid_task(find_pid_ns(x, task_active_pid_ns(current)), PIDTYPE_PID))
#elif LINUX_KERNEL_VERSION >= 2063100
#define FIND_TASK_BY_PID(x) (pid_task(find_pid_ns(x, current->nsproxy->pid_ns), PIDTYPE_PID))
#elif LINUX_KERNEL_VERSION >= 2062700
#define FIND_TASK_BY_PID find_task_by_vpid
#else
#define FIND_TASK_BY_PID find_task_by_pid
#endif

#if LINUX_KERNEL_VERSION >= 2062700
typedef struct request_queue request_queue_t;
#define USER_PATH(pathname, p) user_path(pathname, &(p)->path)
#define USER_LPATH(pathname, p) user_lpath(pathname, &(p)->path)
#define LONG_FILECOUNT
#else
#define FIND_TASK_BY_PID find_task_by_pid
#define USER_PATH(pathname, p) user_path_walk(pathname, p)
#define USER_LPATH(pathname, p) user_path_walk_link(pathname, p)
#endif

#if LINUX_KERNEL_VERSION >= 2063600
#define FS_STRUCT_LOCK(lock)  spin_lock(lock)
#define FS_STRUCT_UNLOCK(lock)  spin_unlock(lock)
#define FSNOTIFY_OPEN(filp) fsnotify_open(filp)
#else
#define FS_STRUCT_LOCK(lock)  read_lock(lock)
#define FS_STRUCT_UNLOCK(lock)  read_unlock(lock)
#define FSNOTIFY_OPEN(filp) fsnotify_open((filp)->f_dentry)
#endif

#if LINUX_KERNEL_VERSION >= 3010000
#define LINUX_GENERIC_PERMISSION(iP, mode, flags, check_acl)  generic_permission(iP, mode)
#elif LINUX_KERNEL_VERSION >= 2063800
#define LINUX_GENERIC_PERMISSION(iP, mode, flags, check_acl)  generic_permission(iP, mode, flags, check_acl)
#else
#define LINUX_GENERIC_PERMISSION(iP, mode, flags, check_acl)  generic_permission(iP, mode, check_acl)
#endif

/* the function signature of inode_operations.permission */
#if LINUX_KERNEL_VERSION >= 3010000
#define INODE_OPS_PERMISSION_PARAMETERS struct inode *iP, int reqMode
#elif LINUX_KERNEL_VERSION >= 2063800
#define INODE_OPS_PERMISSION_PARAMETERS struct inode *iP, int reqMode, unsigned int flags
#elif LINUX_KERNEL_VERSION >= 2062700
#define INODE_OPS_PERMISSION_PARAMETERS struct inode *iP, int reqMode
#else
#define INODE_OPS_PERMISSION_PARAMETERS struct inode *iP, int reqMode, struct nameidata *ni
#endif

#if LINUX_KERNEL_VERSION >= 2063900
#define PATH_LOOKUP(name, flags, nd) kern_path(name, flags, &(nd)->path)
#else
#define PATH_LOOKUP(name, flags, nd) path_lookup(name, flags, nd)
#endif

#if LINUX_KERNEL_VERSION >= 2062800
#define d_alloc_anon d_obtain_alias
#endif

#if LINUX_KERNEL_VERSION >= 3090000
#define VFS_GETATTR(retval, mntP, dentryP, kstatP)   \
{                                                     \
  struct path path;                                   \
  path.mnt = mntP;                                    \
  path.dentry = dentryP;                              \
  retval = vfs_getattr(&path, kstatP);               \
}
#else
#define VFS_GETATTR(retval, mntP, dentryP, kstatP)   \
  retval = vfs_getattr(mntP, dentryP, kstatP);
#endif

#if LINUX_KERNEL_VERSION >= 3060000
#define DENTRY_OPEN(fileP, dP, mntP, flags)            \
{                                                      \
  struct path path;                                    \
  path.mnt = mntP;                                     \
  path.dentry = dP;                                    \
  fileP = dentry_open(&path, flags, current->cred);    \
}
#elif LINUX_KERNEL_VERSION >= 2062900
#define DENTRY_OPEN(fileP, dP, mntP, flags)            \
{                                                      \
  fileP = dentry_open(dP, mntP, flags, current->cred); \
}
#else
#define DENTRY_OPEN(fileP, dP, mntP, flags)            \
{                                                      \
  fileP = dentry_open(dP, mntP, flags);                \
}
#endif

/* RHEL7 enabled CONFIG_UIDGID_STRICT_TYPE_CHECKS, which change
   variable type of kuid_t and kgid_t from uid_t and gid_t to struct */
#if LINUX_KERNEL_VERSION >= 3050000
#define FROM_KUID(uid) from_kuid(&init_user_ns, uid)
#define FROM_KGID(gid) from_kgid(&init_user_ns, gid)
#define UID_EQ(left, right) uid_eq(left, right)
#define GID_EQ(left, right) gid_eq(left, right)
#define FROM_KUID_MUNGED(uid) from_kuid_munged(&init_user_ns, uid)
#define FROM_KGID_MUNGED(gid) from_kgid_munged(&init_user_ns, gid)
#define MAKE_KUID(uid) make_kuid(&init_user_ns, uid)
#define MAKE_KGID(gid) make_kgid(&init_user_ns, gid)
#else
#define FROM_KUID(uid) uid
#define FROM_KGID(gid) gid
#define UID_EQ(left, right) (left == right)
#define GID_EQ(left, right) (left == right)
#define FROM_KUID_MUNGED(uid) uid
#define FROM_KGID_MUNGED(gid) gid
#define MAKE_KUID(uid) uid
#define MAKE_KGID(gid) gid
#endif

#if LINUX_KERNEL_VERSION >= 2062900
#define CRED(ctP, fl)         (ctP)->cred->fl
#define CRED_GROUPS(ctP)      (ctP)->cred->group_info
#define CRED_GRP(ctP, fl)     (ctP)->cred->group_info->fl
#else
#define CRED(ctP, fl)         (ctP)->fl
#if LINUX_KERNEL_VERSION > 2060300
#define CRED_GRP(ctP, fl)     (ctP)->group_info->fl
#define CRED_GROUPS(ctP)      (ctP)->group_info
#else
#define CRED_GRP(ctP, fl)     (ctP)->fl
#define CRED_GROUPS(ctP)      (ctP)
#endif
#endif

/* Translate to GPFS native disk format which used high and low 16 bits
 * for major/minor
 */
#define cxiDevToDev32(D) \
  (cxiDev32_t)((cxiDevMajor(D) << 16) | (cxiDevMinor(D) & 0xFFFF))

#define MAX_GPFS_KMALLOC (131072)

#if LINUX_KERNEL_VERSION < 2062100
#define RELAY_OPEN(cpu, dir, size, num, cb) relay_open(cpu, dir, size, num, cb)
#else
#define RELAY_OPEN(cpu, dir, size, num, cb) relay_open(cpu, dir, size, num, cb, NULL)
#endif

/* have no better way to identify hpc kernel, checking CONFIG_CHECKPOINT is a workaround */
#if (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION >= 2063200 && defined(CONFIG_CHECKPOINT))
#define INODE_OPERATIONS_HAS_RELINK
#endif

/* From 2.6.31, we must define sync_fs() super block ops to make explicit sync work. */
#if LINUX_KERNEL_VERSION >= 2063100
#define MUST_DEFINE_SYNCFS
#endif

/* From 2.6.32, we must define pseudo BDI for each FS to make sync_fs() work. */
#if LINUX_KERNEL_VERSION >= 2063200
#define MUST_USE_BDI
#endif

/* Linux 2.6.37 removed mutex emulation of semaphore */
#if LINUX_KERNEL_VERSION >= 2063700
#define init_MUTEX(sem)	sema_init((sem), 1)
#endif

/* d_count already switched to d_lockref.count in RH7(3.10.0-89),
   but not in RH7(3.10.0-67) */
#if (LINUX_KERNEL_VERSION >= 3110000) || defined(REDHAT_RHEL7)
#define GET_DENTRY_D_COUNT(dentryP) ((dentryP)->d_lockref.count)
#elif LINUX_KERNEL_VERSION >= 2063800
#define GET_DENTRY_D_COUNT(dentryP) ((dentryP)->d_count)
#else
#define GET_DENTRY_D_COUNT(dentryP) atomic_read(&(dentryP)->d_count)
#endif

#if LINUX_KERNEL_VERSION >= 2063800
#define DNAME_INLINE_LEN_MIN DNAME_INLINE_LEN
#endif

/* linux 2.6.37 removed big kernel lock */
#if LINUX_KERNEL_VERSION >= 2063700
#define LOCK_KERNEL()
#define UNLOCK_KERNEL()
#define KERNEL_LOCKED() false
#define CURRENT_LOCK_DEPTH -1
#else
#define LOCK_KERNEL() lock_kernel()
#define UNLOCK_KERNEL() unlock_kernel()
#define KERNEL_LOCKED() kernel_locked()
#define CURRENT_LOCK_DEPTH (current->lock_depth)
#endif

/* Since 2.6.39, per-queue plugging is replaced
   by the explicit on-stack plugging */
#if LINUX_KERNEL_VERSION < 2063900
#define PER_QUEUE_PLUGGING
#endif

#if LINUX_KERNEL_VERSION < 2063900
#define SECURITY_INODE_INIT_SECURITY(inode, dir, qstr, name, value, len) security_inode_init_security(inode, dir, name, value, len)
#elif LINUX_KERNEL_VERSION >= 3020000
#define SECURITY_INODE_INIT_SECURITY(inode, dir, qstr, name, value, len) security_old_inode_init_security(inode, dir, qstr, name, value, len)
#else
#define SECURITY_INODE_INIT_SECURITY(inode, dir, qstr, name, value, len) security_inode_init_security(inode, dir, qstr, name, value, len)
#endif

#if LINUX_KERNEL_VERSION >= 2063800
/* cloned from d_set_d_op() since d_set_d_op prints a warning if d_op is not
   NULL. In fact, the op value isn't supposed to be changed after initializing,
   but GPFS does that anyway. */
static void
set_dentry_operations(struct dentry *dentry, const struct dentry_operations *op,
                      Boolean dlockHeld)
{
  if (dlockHeld == false)
    spin_lock(&dentry->d_lock);

  dentry->d_flags &= ~(DCACHE_OP_HASH | DCACHE_OP_COMPARE |
                       DCACHE_OP_REVALIDATE | DCACHE_OP_DELETE);

  dentry->d_op = (struct dentry_operations *)op;
  if (!op)
    goto exit;

  if (op->d_hash)
    dentry->d_flags |= DCACHE_OP_HASH;
  if (op->d_compare)
    dentry->d_flags |= DCACHE_OP_COMPARE;
  if (op->d_revalidate)
    dentry->d_flags |= DCACHE_OP_REVALIDATE;
  if (op->d_delete)
    dentry->d_flags |= DCACHE_OP_DELETE;

exit:
  if (dlockHeld == false)
    spin_unlock(&dentry->d_lock);
  return;
}
#else
static void
set_dentry_operations(struct dentry *dentry, const struct dentry_operations *op,
                      Boolean dlockHeld)
{
  dentry->d_op = (struct dentry_operations *)op;
}
#endif

/* the function signature of file_operations.fsync */
#if LINUX_KERNEL_VERSION >= 3010000 || (defined(SUSE_LINUX) && (LINUX_KERNEL_VERSION >= 3000400))
#  define LINUX_COMMIT_02c24a82
#  define FILE_OPS_FSYNC_PARAMETERS struct file *fP, loff_t start, loff_t end, int datasync
#  define TRC_FSYNC_IMPLEMENTATION() return trc_fsync_internal(NULL, 0, LLONG_MAX, 0)
#elif LINUX_KERNEL_VERSION >= 2063500
#  define FILE_OPS_FSYNC_PARAMETERS struct file *fP, int datasync
#  define TRC_FSYNC_IMPLEMENTATION() return trc_fsync_internal(NULL, 0)
#else
#  define FILE_OPS_FSYNC_PARAMETERS struct file *fP, struct dentry *dP, int datasync
#  define TRC_FSYNC_IMPLEMENTATION()return trc_fsync_internal(NULL, NULL, 0);
#endif

#if LINUX_KERNEL_VERSION >= 2063700
#define INODE_HAS_I_LRU_FIELD
#else
#define INODE_HAS_I_LIST_FIELD
#endif

#if LINUX_KERNEL_VERSION >= 2063900
#define FILE_SYSTEM_TYPE_HAS_MOUNT_OP
#endif

#if LINUX_KERNEL_VERSION >= 2063900
#define  LINUX_COMMIT_0b2d0724
#endif

#if LINUX_KERNEL_VERSION >= 2063700
#define MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
#endif

#if LINUX_KERNEL_VERSION < 3010000
#define LOCK_ALLOC_LOCK() cxiMallocUnpinned(sizeof(struct file_lock))
#define LOCK_FREE_LOCK(fl) cxiFreeUnpinned(fl)
#else
#define LOCK_ALLOC_LOCK() locks_alloc_lock()
#define LOCK_FREE_LOCK(fl) locks_free_lock(fl)
#endif

#if LINUX_KERNEL_VERSION >= 3010000
#define fl_compare_owner   lm_compare_owner
#define fl_notify          lm_notify
#define fl_grant           lm_grant
#define fl_release_private lm_release_private
#define fl_break           lm_break
#define fl_change          lm_change
#endif
#if LINUX_KERNEL_VERSION < 3020000
static inline void set_nlink(struct inode *inode, unsigned int nlink)
{
  inode->i_nlink = nlink;
}
#endif

#if LINUX_KERNEL_VERSION >= 3040000
#define TOUCH_ATIME(mntP, dentryP)       \
{                                        \
  struct path path;                      \
  path.mnt = mntP;                       \
  path.dentry = dentryP;                 \
  touch_atime(&path);                    \
}
#else
#define TOUCH_ATIME(mntP, dentryP) touch_atime(mntP, dentryP)
#endif

/* hlist_for_each_entry only has three pass-in parameter since 3.9,
   and the second parameter of old is removed */
#if (LINUX_KERNEL_VERSION >= 3090000)
#define HLIST_FOR_EACH_ENTRY(tpos, head, member)   \
  hlist_for_each_entry(tpos, head, member)
#else
#define HLIST_FOR_EACH_ENTRY(tpos, head, member)   \
  struct hlist_node *pos;                          \
  hlist_for_each_entry(tpos, pos, head, member)
#endif

/* Linux kernel 3.6 switch i_dentry/d_alias from list_head to hlist_head */
#if (LINUX_KERNEL_VERSION >= 3060000)
#define LIST_FOR_I_DENTRY(dentryP, i_dentryP, d_alias)    \
  HLIST_FOR_EACH_ENTRY(dentryP, i_dentryP, d_alias)
#define I_DENTRY_EMPTY(i_dentryP)    \
	  hlist_empty(i_dentryP)
#define HLIST_I_DENTRY
#else
#define LIST_FOR_I_DENTRY(dentryP, i_dentryP, d_alias)    \
  list_for_each_entry(dentryP, i_dentryP, d_alias)
#define I_DENTRY_EMPTY(i_dentryP)    \
	  list_empty(i_dentryP)
#endif

/* 3.11 switch fl_link from list_head to hlist_node */
#if (LINUX_KERNEL_VERSION >= 3110000) || defined(REDHAT_RHEL7)
#define FL_LINK_EMPTY(fl_linkP) hlist_unhashed(fl_linkP) 
#else
#define FL_LINK_EMPTY(fl_linkP) list_empty(fl_linkP)
#endif

/* d_alloc_root() is replaced by d_make_root() after Linux kernel 3.4 */
/* d_make_root() drops the reference to inode if dentry allocation fails */
#if (LINUX_KERNEL_VERSION >= 3040000)
#define NEW_D_MAKE_ROOT
#endif

#if (LINUX_KERNEL_VERSION >= 3060000)
#define FD_SET_BIT(fd, vaddr)            \
	__set_bit(fd, vaddr)
#define SGET(typeP, testP, setP, flags, dataP)     \
	sget(typeP, testP, setP, flags, dataP)
#else
#define  FD_SET_BIT(fd, vaddr)            \
	FD_SET(fd, vaddr)
#define SGET(typeP, testP, setP, flags, dataP)     \
		sget(typeP, testP, setP, dataP)
#endif

/* struct nameidata in function parameters has removed after Linux kernel 3.6 */
#if (LINUX_KERNEL_VERSION >= 3060000)
#define NAMEIDATA_REPLACED
#endif

/* s_dirt in super_block and write_super() are removed after Linux kernel 3.6 */
#if (LINUX_KERNEL_VERSION < 3060000)
#define HAS_S_DIRT
#define HAS_WRITE_SUPER
#endif

/* int mode ==> umode_t mode */
#if (LINUX_KERNEL_VERSION >= 3030000)
#define NEW_MODE_TYPE
#endif

#if (LINUX_KERNEL_VERSION >= 3050000)
/* parameters in encode_fh() changed */
#define NEW_ENCODE_FH
/* do_mmap() removed and replace by vm_mmap()  */
/* vm_mmap() will down_write(&mm->mmap_sem) inside it */
#define DO_MMAP_REMOVED
#endif

/* end_writeback() rename to clear_inode() after Linux kernel 3.5*/
#if ((LINUX_KERNEL_VERSION >= 2063600) && (LINUX_KERNEL_VERSION < 3050000))
#define HAS_END_WRITEBACK
#endif

#if (LINUX_KERNEL_VERSION >= 2063600)
#define HAS_FMODE_NONOTIFY
#endif

/* make the same change as struct posix_acl in Linux kernel 3.1 */
#if (LINUX_KERNEL_VERSION >= 3010000)
#define ACL_RCU
#endif

/* 3.10 drop create_proc_read_entry(), and use proc_create() instead */
#if (LINUX_KERNEL_VERSION < 3100000)
#define HAS_CREATE_PROC_READ_ENTRY
#endif

/* global variable num_physpages killed in 3.11, and introduce new function get_num_physpages() */
#if (LINUX_KERNEL_VERSION >= 3110000)
#define NUM_PHYSPAGES get_num_physpages()
#else
#define NUM_PHYSPAGES num_physpages
#endif

/* pre-defined statement is_sync_kiocb() change to an inline function since 3.6 */
#if (LINUX_KERNEL_VERSION >= 3060000)
#define IS_SYNC_KIOCB_FUNCTION
#endif

/* daemonize() removed in Linux kernel 3.8, and kernel_thread()
 * does not export out since Linux kernel 3.7, so we should use
 * kthread_create() instead of kernel_thread() to create kernel thread
 */
#if (LINUX_KERNEL_VERSION >= 3070000)
#define USE_KTHREAD_CREATE
#endif

/* 3.7 pass the user namespace to posix_acl_from_xattr() and 
 posix_acl_to_xattr() */
#if (LINUX_KERNEL_VERSION >= 3070000)
#define PASS_USER_NAMESPACE_TO_POSIX_ACL_API
#endif

/* truncate removed in Linux kernel 3.8 */
#if (LINUX_KERNEL_VERSION < 3080000)
#define HAS_TRUNCATE
#endif

/* VM_RESERVED removed in Linux kernel 3.7, VM_IO could mark pages as unswappable */
#ifndef VM_RESERVED
#define VM_RESERVED VM_IO
#endif

/* getname() and putname() return struct filename* instead of char* in Linux 3.7 */
#if (LINUX_KERNEL_VERSION >= 3070000)
#define LOOKUP_ONE_LEN(nameP, base, len) \
  lookup_one_len(((struct filename *)nameP)->name, base, len)
#else
#define LOOKUP_ONE_LEN(nameP, base, len) \
  lookup_one_len((char *)nameP, base, len)
#endif

/* readdir() replaced by iterate()
 * vfs_readdir() replace by iterate_dir() since 3.11 */
#if (LINUX_KERNEL_VERSION < 3110000)
#define HAS_READDIR
#endif

/* f_vfsmnt removed in 3.9 */
#if (LINUX_KERNEL_VERSION < 3090000)
#define HAS_F_VFSMNT
#endif

/* The kernel crypto path makes use of the new crypto API, introduced after
 * 2.6.19.
 * CONFIG_CRYPTO is the Linux kernel crypto configuration define */
#if (LINUX_KERNEL_VERSION >= 2061900) && defined (CONFIG_CRYPTO)
#define HAS_NEW_CRYPTO_API
#endif

/* PMR 71280,499,000:
   The new bio_get_nr_vecs() may exceed the max hw sectors of the blk dev */
#if ((defined(KERNEL_ORG_LINUX) || defined(FEDORA_LINUX)) && LINUX_KERNEL_VERSION >= 3030000) || \
    (defined(DEBIAN_LINUX) && LINUX_KERNEL_VERSION >= 3024100) || \
    (defined(REDHAT_AS_LINUX) && LINUX_KERNEL_VERSION >= 2063200) || \
    (defined(SUSE_LINUX) && LINUX_KERNEL_VERSION >= 3005800)
#define CHECK_MAX_IO_VECS(maxIOVec, bdevP) \
  do { \
    long maxHWSecs = queue_max_hw_sectors(bdev_get_queue((struct block_device *)(bdevP))); \
    if ((long)(maxIOVec) * (PAGE_SIZE >> 9) > maxHWSecs) { \
      (maxIOVec) = maxHWSecs / (PAGE_SIZE >> 9); \
      if ((maxIOVec) == 0) (maxIOVec) = 1; \
    } \
  } while (0)
#else
#define CHECK_MAX_IO_VECS(maxIOVec, bdevP)  do { } while (0)
#endif

#endif /* _h_verdep */
