/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)76       1.2  src/avs/fs/mmfs/ts/kernext/gpl-linux/ss_ppc64.c, mmfs, avs_rfks0, rfks01416c 12/13/11 03:33:33 */

/*
 * Implementation of shared segment for GPFS daemon and GPFS kernel code.
 *
*/

#include <Shark-gpl.h>

#include <linux/types.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/types.h>

#include <verdep.h>

int
kxSaveThreadInfo(int tid, void* regP)
{
  struct task_struct *g, *t;
  int rc = ENOENT;
  unsigned long sp;

#if !defined(HAS_TASKLIST_LOCK)
  rcu_read_lock();
  t = FIND_TASK_BY_PID(tid);
  if (t)
    rc = 0;
  rcu_read_unlock();
#else
  TASK_READ_LOCK;
  do_each_thread(g,t)
  {
    if (t->pid != tid)
      continue;

    rc = 0;
    goto found_it;
  } while_each_thread(g,t);
found_it:
  TASK_READ_UNLOCK;
#endif
  if (rc == 0)
  {
    if (t->thread.regs != NULL)
      copy_to_user(regP, t->thread.regs, sizeof(struct pt_regs));
    else
    {
      /* ??? */
      sp = (unsigned long)TASK_THREAD_INFO(t) + THREAD_SIZE;
      sp -= sizeof(struct pt_regs);
      copy_to_user(regP, (void*)sp, sizeof(struct pt_regs));
    }
  }
  return rc;
} 	
