/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)47       1.26  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiVFSStats.h, mmfs, avs_rfks0, rfks01416c 2/28/14 11:38:51 */
#ifndef _h_cxiVFSStats
#define _h_cxiVFSStats

/*
 * Gather statistics for VFS operations:
 *
 * Usage:
 *  - Placing an instance of the VFS_STAT_START macro at the begining
 *    of a function and VFS_STAT_STOP macro at the end of a function
 *    will keep a count of how many times the function is called as well
 *    as the total amount of time spent in the function (elapsed time
 *    between entering and leaving the function).
 *  - Placing an instance of the VFS_INC macro inside a function will
 *    update a call count, but not keep any time statistics.
 *  - Use the command "mmfsadm vfsstats ..." to control and display
 *    vfs statistics:
 *       mmfsadm vfsstats enable    - turn on statistics gathering
 *       mmfsadm vfsstats disable   - turn off statistics gathering
 *       mmfsadm vfsstats reset     - reset all statistics counters
 *       mmfsadm vfsstats show      - display statistics
 *
 */

#include <cxiVFSStats-plat.h>

/* Enumeration of all calls for which we keep vfs statistics.  Except as
   noted, the enum value named xxxCall represents calls to the vnode or
   vfs operation named xxx. */
enum VFSStatItem
{
  // special value indicating statistics disabled
  nullCall             = -1,

  // vnode ops
  accessCall           = 0,
  closeCall            = 1,
  createCall           = 2,
  fclearCall           = 3,
  fsyncCall            = 4,
  fsync_rangeCall      = 5,
  ftruncCall           = 6,
  getattrCall          = 7,
  linkCall             = 8,
  lockctlCall          = 9,
  lookupCall           = 10,
  map_lloffCall        = 11,
  mkdirCall            = 12,
  mknodCall            = 13,
  openCall             = 14,
  readCall             = 15, // mmfs_rdwr with op == UIO_READ
  writeCall            = 16, // mmfs_rdwr with op != UIO_READ
  mmapReadCall         = 17, // mmap kproc read
  mmapWriteCall        = 18, // mmap kproc write
  readdirCall          = 19,
  readlinkCall         = 20,
  readpageCall         = 21,
  removeCall           = 22,
  renameCall           = 23,
  rmdirCall            = 24,
  setaclCall           = 25,
  setattrCall          = 26,
  symlinkCall          = 27,
  unmapCall            = 28,
  writepageCall        = 29,
  tsfattrCall          = 30,
  tsfsattrCall         = 31,
  flockCall            = 32,
  setxattrCall         = 33,
  getxattrCall         = 34,
  listxattrCall        = 35,
  removexattrCall      = 36,
  fsLocationCall       = 37,

  //export ops
  encode_fhCall        = 38,
  decode_fhCall        = 39,
  get_dentryCall       = 40,
  get_parentCall       = 41,

  // vfs ops
  mountCall            = 42,
  statfsCall           = 43,
  syncCall             = 44,
  vgetCall             = 45,

  // other counters
  localIOCall          = 46, // number of I/Os calls to the kernel
  fastOpenCount        = 47, // no of mmfs_open calls that use fast open
  fastCloseCount       = 48, // no of mmfs_close calls that use fast close
  fastLookupCount      = 49, // no of mmfs_lookup calls that use fast lookup
  fastReadCount        = 50, // no of mmfs_rdwr calls that use fast read
  fastWriteCount       = 51, // no of mmfs_rdwr calls that use fast write
  revalidateCount      = 52, // number of revalidate calls
  nSyncWrites          = 53, // total number of synchronous write calls
  nAvoidedFsyncs       = 54, // number of syncs avoided due to fsync coalescing
  nYieldSyncWriters    = 55, // number of times yield in fsync coalescing worked

  // histogram of numbers of coalesced fsyncs
  nFSync_1             = 56, // These must be contiguous
  nFSync_2             = 57,
  nFSync_3             = 58,
  nFSync_4             = 59,
  nFSync_5             = 60,
  nFSync_6             = 61,
  nFSync_7             = 62,
  nFSync_8             = 63,

  // solaris vfs ops 
  inactiveCall         = 64,
  rwlockCall           = 65,
  rwunlockCall         = 66,
  seekCall             = 67,
  realvpCall           = 68,
  ioctlCall            = 69,
  cleanupCall          = 70,
  aioReadAsyncCall     = 71, // Linux AIO call executed asynchronous
  aioWriteAsyncCall    = 72,
  aioReadSyncCall      = 73, // Linux AIO call executed synchronous
  aioWriteSyncCall     = 74,
  aioReadCompleteCall  = 75, // Linux AIO completion callback
  aioWriteCompleteCall = 76,
  readvCall            = 77,
  writevCall           = 78,

  // save
  save79               = 79,
  save80               = 80,
  save81               = 81,
  save82               = 82,
  save83               = 83,
  save84               = 84,
  save85               = 85,
  save86               = 86,
  save87               = 87,
  save88               = 88,
  save89               = 89,
  save90               = 90,
  save91               = 91,
  save92               = 92,
  save93               = 93,
  save94               = 94,
  save95               = 95,
  save96               = 96,
  save97               = 97,
  save98               = 98,
  save99               = 99,
  save100              = 100,

  // Ganesha ops, see gpfs_nfs.h
  NAME_TO_HANDLE       = 101,
  OPEN_BY_HANDLE       = 102,
  LINK_BY_FD           = 103,
  READLINK_BY_FD       = 104,
  STAT_BY_HANDLE       = 105,
  LAYOUT_TYPE          = 106,
  GET_DEVICEINFO       = 107,
  GET_DEVICELIST       = 108,
  LAYOUT_GET           = 109,
  LAYOUT_RETURN        = 110,
  INODE_UPDATE_        = 111,
  GET_XSTAT            = 112,
  SET_XSTAT            = 113,
  CHECK_ACCESS         = 114,
  OPEN_SHARE_BY_HANDLE = 115,
  GET_LOCK             = 116,
  SET_LOCK             = 117,
  THREAD_UPDATE        = 118,
  LAYOUT_COMMIT        = 119,
  DS_READ              = 120,
  DS_WRITE             = 121,
  GET_VERIFIER         = 122,
  FSYNC_               = 123,
  SHARE_RESERVE        = 124,
  GET_NODEID           = 125,
  SET_DELEGATION       = 126,
  CLOSE_FILE           = 127,
  LINK_BY_FH           = 128,
  RENAME_BY_FH         = 129,
  STAT_BY_NAME         = 130,
  GET_HANDLE           = 131,
  READLINK_BY_FH       = 132,
  UNLINK_BY_NAME       = 133,
  CREATE_BY_NAME       = 134,
  READ_BY_FD           = 135,
  WRITE_BY_FD          = 136,
  CREATE_BY_NAME_ATTR  = 137,
  GRACE_PERIOD         = 138,
  CLEAR_BY_FD          = 139,
  REOPEN_BY_FD         = 140,
  FADVISE_BY_FD        = 141,
  SEEK_BY_FD           = 142,
  TRACE_ME             = 150,
  QUOTA                = 151,

  // total number of stat items; add new items above!
  nVFSStatItems // <last item> + 1
};

#ifdef INCLUDE_VFSSTATITEMNAMESPP
/* printable names for VFSStatItem enum values */
const char *VFSStatItemNamesPP[] =
{
  "access",               // 0
  "close",                // 1
  "create",               // 2
  "fclear",               // 3
  "fsync",                // 4
  "fsync_range",          // 5
  "ftrunc",               // 6
  "getattr",              // 7
  "link",                 // 8
  "lockctl",              // 9
  "lookup",               // 10
  "map_lloff",            // 11
  "mkdir",                // 12
  "mknod",                // 13
  "open",                 // 14
  "read",                 // 15
  "write",                // 16
  "mmapRead",             // 17
  "mmapWrite",            // 18
  "readdir",              // 19
  "readlink",             // 20
  "readpage",             // 21
  "remove",               // 22
  "rename",               // 23
  "rmdir",                // 24
  "setacl",               // 25
  "setattr",              // 26
  "symlink",              // 27
  "unmap",                // 28
  "writepage",            // 29
  "tsfattr",              // 30
  "tsfsattr",             // 31
  "flock",                // 32
  "setxattr",             // 33
  "getxattr",             // 34
  "listxattr",            // 35
  "removexattr",          // 36
  "NOT_USED",             // 37

  //export ops
  "encode_fh",            // 38
  "decode_fh",            // 39
  "get_dentry",           // 40
  "get_parent",           // 41

  // vfs ops
  "mount",                // 42
  "statfs",               // 43
  "sync",                 // 44
  "vget",                 // 45

  // other counters
  "startIO",              // 46
  "fastOpen",             // 47
  "fastClose",            // 48
  "fastLookup",           // 49
  "fastRead",             // 40
  "fastWrite",            // 51
  "revalidate",           // 52
  "nSyncWrites",          // 53
  "nAvoidedFsyncs",       // 54
  "nYieldSyncWriters",    // 55

  // histogram of number of coalesced fsyncs
  "coalesce fsync 1",     // 56
  "coalesce fsync 2",     // 57
  "coalesce fsync 3",     // 58
  "coalesce fsync 4",     // 69
  "coalesce fsync 5",     // 60
  "coalesce fsync 6",     // 61
  "coalesce fsync 7",     // 62
  "coalesce fsync >= 8",  // 63
  // solaris vfs ops 
  "inactiveCall",         // 64
  "rwlockCall",           // 65
  "rwunlockCall",         // 66
  "seekCall",             // 67
  "realvpCall",           // 68
  "ioctlCall",            // 69
  "cleanupCall",          // 70
  "aio read async",       // 71
  "aio write async",      // 72
  "aio read sync",        // 73
  "aio write sync",       // 74
  "aio read complete",    // 75
  "aio write complete",   // 76
  "readv",                // 77
  "writev",               // 78

  // save
  "save79",              // 79,
  "save80",              // 80,
  "save81",              // 81,
  "save82",              // 82,
  "save83",              // 83,
  "save84",              // 84,
  "save85",              // 85,
  "save86",              // 86,
  "save87",              // 87,
  "save88",              // 88,
  "save89",              // 89,
  "save90",              // 90,
  "save91",              // 91,
  "save92",              // 92,
  "save93",              // 93,
  "save94",              // 94,
  "save95",              // 95,
  "save96",              // 96,
  "save97",              // 97,
  "save98",              // 98,
  "save99",              // 99,
  "save100",             // 100,

  // Ganesha ops, see gpfs_nfs.h
  "NAME_TO_HANDLE",       // 101,
  "OPEN_BY_HANDLE",       // 102,
  "LINK_BY_FD",           // 103,
  "READLINK_BY_FD",       // 104,
  "STAT_BY_HANDLE",       // 105,
  "LAYOUT_TYPE",          // 106,
  "GET_DEVICEINFO",       // 107,
  "GET_DEVICELIST",       // 108,
  "LAYOUT_GET",           // 109,
  "LAYOUT_RETURN",        // 110,
  "INODE_UPDATE",         // 111,
  "GET_XSTAT",            // 112,
  "SET_XSTAT",            // 113,
  "CHECK_ACCESS",         // 114,
  "OPEN_SHARE_BY_HANDLE", // 115,
  "GET_LOCK",             // 116,
  "SET_LOCK",             // 117,
  "THREAD_UPDATE",        // 118,
  "LAYOUT_COMMIT",        // 119,
  "DS_READ",              // 120,
  "DS_WRITE",             // 121,
  "GET_VERIFIER",         // 122,
  "FSYNC",                // 123,
  "SHARE_RESERVE",        // 124,
  "GET_NODEID",           // 125,
  "SET_DELEGATION",       // 126,
  "CLOSE_FILE",           // 127,
  "LINK_BY_FH",           // 128,
  "RENAME_BY_FH",         // 129,
  "STAT_BY_NAME",         // 130,
  "GET_HANDLE",           // 131,
  "READLINK_BY_FH",       // 132,
  "UNLINK_BY_NAME",       // 133,
  "CREATE_BY_NAME",       // 134,
  "READ_BY_FD",           // 135,
  "WRITE_BY_FD",          // 136,
  "CREATE_BY_NAME_ATTR",  // 137,
  "GRACE_PERIOD",         // 138,
  "CLEAR_BY_FD",          // 139,
  "REOPEN_BY_FD",         // 140,
  "FADVISE_BY_FD",        // 141,
  "SEEK_BY_FD",           // 142,
  "TRACE_ME",             // 150,
  "QUOTA",                // 151,

};
#else
extern const char *VFSStatItemNamesPP[];
#endif

/* Statistics about a vfs call */
typedef struct VFSStatData
{
  UInt32 cnt;                // total no of calls
  cxiTimeStruc_t totalTime;  // total amount of time in call
} VFSStatData_t;


typedef struct VFSStats
{
  /* Statistics updated by kernel operations.  These are always updated by
     using the VFS_STAT_START(xxxCall) and VFS_STAT_STOP macro pair, where
     xxxCall is one of the enum VFSStatItem values.  If NO_VFS_STATS is
     defined, the VFS_STAT macro will not generate any code. */
  VFSStatData_t data[nVFSStatItems];

  /* Flag indicating whether statistic gathering is currently enabled.
     Use enable/disable methods to set or clear this flag. */
  Boolean enabled;

  /* Time period over which statistics were gathered:
     startTime is the absolute time at which statistic gathering were last
     started or reset by a call to enable() or reset(), and endTime is the
     absolute time at which statistic gathering was last disabled.  If still
     enabled, endTime will be zero. */
  cxiTimeStruc_t startTime;  // absolute time in nanoseconds
  cxiTimeStruc_t endTime;    // absolute time in nanoseconds

} VFSStats_t;

/* Enable/disable statistic gathering.  Set or clears the enabled flag and
   updates startTime/endTime values accordingly.  The reset() method resets
   all statistics data but leaves the enabled flag unchanged. */
EXTERNC void VFSStats_enable(VFSStats_t *objPtr);
EXTERNC void VFSStats_disable(VFSStats_t *objPtr);
EXTERNC void VFSStats_reset(VFSStats_t *objPtr);

/* Kernel extension interface to enable, disable, reset, and/or retrieve vfs
   statistics, as indicated by the 'cmd' parameter (see #define's below).
   The 'bufP' parameter is used to return statistics to the caller. */
#ifndef GPFS_GPL /* This header should be split into VFSStats.h and cxiVFSStats.h */
EXTERNC Errno kxVFSStatCtl(int cmd, void *bufP, int bufSize);
#endif

#define VSTAT_ENABLE  0x01  // enable statistics gathering
#define VSTAT_DISABLE 0x02  // disable statistics gathering
#define VSTAT_RESET   0x04  // reset statistics
#define VSTAT_GET     0x08  // copy statistics from kernel to bufP in user
                            //   space; bufSize must be >= sizeof(VFSStats)

#ifdef _KERNEL

/* Instance of VFSStats class in the kernel */
#ifdef DEFINE_VFSSTATS_GBL_VARS
VFSStats_t vfsStats;
#else
extern VFSStats_t vfsStats;
#endif

/* Class to update vfs statistics on entering and exiting a vfs or vnode op.
   If statistic gathering is enabled, the VFSStatPoint constructor will record
   the current time; the destructor will calculate how much time has elapsed
   since the constructor was called and update VFSStats accordingly.  The
   intended use is that each function for which statistics are to be gathered
   will have a variable of type VFSStatPoint declared at the very top of
   the function (using the VFS_STAT_START macro defined below).  This way the
   VFSStatPoint constructor will be called when the function is entered and
   the destructor will be called before returning from the function
   using the VFS_STAT_STOP macro. */
typedef struct VFSStatPoint
{
  enum VFSStatItem statItem;
  cxiTimeStruc_t beginTime;
} VFSStatPoint_t;

/* OS dependent functions in implementation layer */
EXTERNC void VFSStatPoint_begin(VFSStatPoint_t *objPtr, enum VFSStatItem i);
EXTERNC void VFSStatPoint_end(VFSStatPoint_t *objPtr);

/* Psuedo constructor and destructor.  */
static inline void VFSStatPoint_create(VFSStatPoint_t *objPtr, enum VFSStatItem i)
{ 
  if (vfsStats.enabled)
    VFSStatPoint_begin(objPtr, i);
  else 
    objPtr->statItem = nullCall;
}

static inline void VFSStatPoint_destroy(VFSStatPoint_t *objPtr)
{ 
  if (vfsStats.enabled)
    VFSStatPoint_end(objPtr);
}

static inline void VFSStatPoint_destroyi(VFSStatPoint_t *objPtr, enum VFSStatItem i)
{ 
  if (vfsStats.enabled)
  {
    objPtr->statItem = i;
    VFSStatPoint_end(objPtr);
  }
}

#ifdef NO_VFS_STATS
#define VFS_STAT_START(i) NOOP
#define VFS_STAT_STOP NOOP
#define VFS_INC(i)  NOOP
#else
#define VFS_STAT_START(i) VFSStatPoint_t vsp; VFSStatPoint_create(&vsp,i)
#define VFS_STAT_DECL VFSStatPoint_t vsp
#define VFS_STAT_START_NODECL(i) VFSStatPoint_create(&vsp,i)

#define VFS_STAT_STOP VFSStatPoint_destroy(&vsp)
#define VFS_STAT_STOPI(i) VFSStatPoint_destroyi(&vsp,i)
#define VFS_INC(i)  if (vfsStats.enabled) vfsStats.data[i].cnt++; else NOOP
#endif

#endif // _KERNEL

#endif // _h_cxiVFSStats
