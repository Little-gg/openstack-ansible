/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)88       1.134  src/avs/fs/mmfs/ts/kernext/gpl-linux/opsdeclare.c, mmfs, avs_rfks0, rfks01416c 3/10/14 10:58:01 */

#include <Shark-gpl.h>

/* Linux headers */
#include <linux/module.h>
#include <linux/mm.h> /* vm operations */

#ifdef CONFIG_CHECKPOINT
#include <linux/checkpoint.h>
#endif

/* GPFS headers */
#include <linux2gpfs.h>
#include <verdep.h>


struct super_operations gpfs_sops =
{
#if (LINUX_KERNEL_VERSION < 2062500)
  read_inode:    gpfs_s_read_inode,
#endif
  write_inode:   gpfs_s_write_inode,
  put_super:     gpfs_s_put_super,        /* unmount (not force for older kernels) */
#ifdef HAS_WRITE_SUPER
  write_super:   gpfs_s_write_super,      /* sync */
#endif
  statfs:        gpfs_s_statfs,           /* statfs */
  remount_fs:    NULL,
#if (LINUX_KERNEL_VERSION >= 2063600)
  evict_inode:   gpfs_s_evict_inode,
#else
  clear_inode:   gpfs_s_clear_inode,      /* inode completely unused */
  delete_inode:  gpfs_s_delete_inode,
#endif
  umount_begin:  gpfs_s_umount_begin,     /* unmount (force for older kernels) */
  alloc_inode:	 gpfs_alloc_inode,
  destroy_inode: gpfs_destroy_inode,
#if (LINUX_KERNEL_VERSION >= 2061300)
  drop_inode:    gpfs_s_drop_inode,
#endif
#ifdef MUST_DEFINE_SYNCFS
  sync_fs: gpfs_s_sync_fs,
#endif
};

struct export_operations gpfs_export_ops =
{
  encode_fh:  gpfs_encode_fh,
#if (LINUX_KERNEL_VERSION >= 2062400)
  fh_to_dentry:  gpfs_fh_to_dentry,
  fh_to_parent:  gpfs_fh_to_parent,
  get_name: gpfs_get_name,
#else
  decode_fh:  gpfs_decode_fh,
  get_dentry:  gpfs_get_dentry,
#endif
  get_parent:  gpfs_get_dparent,
};

struct file_system_type gpfs_fs_type =
{
  .owner          = THIS_MODULE,
  .name           = "gpfs",
#ifdef FILE_SYSTEM_TYPE_HAS_MOUNT_OP
  .mount          = gpfs_mount,
#else
  .get_sb         = gpfs_get_sb,
#endif
  .kill_sb        = kill_anon_super,
};

struct super_operations null_sops =
{
};

struct file_operations gpfs_cleanup_fops =
{
  release: gpfs_f_cleanup
};

struct file_operations gpfs_cleanup_cifs_fops =
{
  release: gpfs_f_cleanup_cifs
};

struct file_operations gpfs_null_fops =
{
};


/* Inode operations for non-symlinks, non-directory with standard Unix
   permissions (no extended acls) and valid inode attributes (valid owner and
   mode cached in the Linux inode structure). */
struct inode_operations gpfs_iops_stdperm =
{
  create:      gpfs_i_create,
  // lookup:     no lookup op for non-directory
  link:        gpfs_i_link,
#ifdef INODE_OPERATIONS_HAS_RELINK
  relink:      gpfs_i_relink,
#endif
  unlink:      gpfs_i_unlink,
  symlink:     gpfs_i_symlink,
  mkdir:       gpfs_i_mkdir,
  rmdir:       gpfs_i_rmdir,
  mknod:       gpfs_i_mknod,
  rename:      gpfs_i_rename,
  readlink:    gpfs_i_readlink,
#ifdef HAS_TRUNCATE
  truncate:    gpfs_i_truncate,   /* noop (done by setattr) */
#endif
  permission:  GENERIC_PERMISSION_OP,
  setattr:     gpfs_i_setattr,
  getattr:     gpfs_i_getattr,
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
#if LINUX_KERNEL_VERSION < 2063800 && LINUX_KERNEL_VERSION >= 2063200
  fallocate:  gpfs_i_fallocate,
#endif
  removexattr: gpfs_i_removexattr
};

/* Inode operations for non-symlinks, non-directory that require a gpfs call
   to do permission checking either because the file/dir has extended acls or
   because the owner and mode cached in the Linux inode structure are not
   known to be valid. */
struct inode_operations gpfs_iops_xperm =
{
  create:      gpfs_i_create,
  // lookup:     no lookup op for non-directory
  link:        gpfs_i_link,
#ifdef INODE_OPERATIONS_HAS_RELINK
  relink:      gpfs_i_relink,
#endif
  unlink:      gpfs_i_unlink,
  symlink:     gpfs_i_symlink,
  mkdir:       gpfs_i_mkdir,
  rmdir:       gpfs_i_rmdir,
  mknod:       gpfs_i_mknod,
  rename:      gpfs_i_rename,
  readlink:    gpfs_i_readlink,
#ifdef HAS_TRUNCATE
  truncate:    gpfs_i_truncate,   /* noop (done by setattr) */
#endif
  permission:  gpfs_i_permission,
  setattr:     gpfs_i_setattr,
  getattr:     gpfs_i_getattr,
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
#if LINUX_KERNEL_VERSION < 2063800 && LINUX_KERNEL_VERSION >= 2063200
  fallocate:  gpfs_i_fallocate,
#endif
  removexattr: gpfs_i_removexattr
};

/* Inode operations for directory with standard Unix permissions
   (no extended acls) and valid inode attributes (valid owner and mode
   cached in the Linux inode structure). */
struct inode_operations gpfs_dir_iops_stdperm =
{
  create:      gpfs_i_create,
  lookup:      gpfs_i_lookup,
  link:        gpfs_i_link,
#ifdef INODE_OPERATIONS_HAS_RELINK
  relink:      gpfs_i_relink,
#endif
  unlink:      gpfs_i_unlink,
  symlink:     gpfs_i_symlink,
  mkdir:       gpfs_i_mkdir,
  rmdir:       gpfs_i_rmdir,
  mknod:       gpfs_i_mknod,
  rename:      gpfs_i_rename,
  readlink:    gpfs_i_readlink,
#ifdef HAS_TRUNCATE
  truncate:    gpfs_i_truncate,   /* noop (done by setattr) */
#endif
  permission:  GENERIC_PERMISSION_OP,
  setattr:     gpfs_i_setattr,
  getattr:     gpfs_i_getattr,
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
  removexattr: gpfs_i_removexattr
};

/* Inode operations for directory that require a gpfs call to do permission
   checking either because the file/dir has extended acls or because the owner
   and mode cached in the Linux inode structure are not known to be valid. */
struct inode_operations gpfs_dir_iops_xperm =
{
  create:      gpfs_i_create,
  lookup:      gpfs_i_lookup,
  link:        gpfs_i_link,
#ifdef INODE_OPERATIONS_HAS_RELINK
  relink:      gpfs_i_relink,
#endif
  unlink:      gpfs_i_unlink,
  symlink:     gpfs_i_symlink,
  mkdir:       gpfs_i_mkdir,
  rmdir:       gpfs_i_rmdir,
  mknod:       gpfs_i_mknod,
  rename:      gpfs_i_rename,
  readlink:    gpfs_i_readlink,
#ifdef HAS_TRUNCATE
  truncate:    gpfs_i_truncate,   /* noop (done by setattr) */
#endif
  permission:  gpfs_i_permission,
  setattr:     gpfs_i_setattr,
  getattr:     gpfs_i_getattr,
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
  removexattr: gpfs_i_removexattr
};

/* inode operations for symlinks */
struct inode_operations gpfs_link_iops =
{
  create:       gpfs_i_create,     /* create             */
// lookup:      no lookup op for symlink
  link:         gpfs_i_link,       /* link               */
#ifdef INODE_OPERATIONS_HAS_RELINK
  relink:       gpfs_i_relink,     /* relink             */
#endif
  unlink:       gpfs_i_unlink,     /* remove             */
  symlink:      gpfs_i_symlink,    /* symlink            */
  mkdir:        gpfs_i_mkdir,      /* mkdir              */
  rmdir:        gpfs_i_rmdir,      /* rmdir              */
  mknod:        gpfs_i_mknod,      /* mknod              */
  rename:       gpfs_i_rename,     /* rename             */
  readlink:     gpfs_i_readlink,   /* readlink           */
  follow_link:  gpfs_i_follow_link,/* readlink...      */
#ifdef HAS_IOP_PUT_LINK
  put_link:     gpfs_i_put_link,   /* delete link */
#endif
#ifdef HAS_TRUNCATE
  truncate:     gpfs_i_truncate,   /* noop (done by setattr) */
#endif
// permission:  no permission checking for symlink
  setattr:      gpfs_i_setattr,    /* setattr */
  getattr:      gpfs_i_getattr,    /* getattr */
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
  removexattr: gpfs_i_removexattr
  // no truncate_range
};

/* inode operations for special files with standard permissions */
struct inode_operations gpfs_special_iops_stdperm =
{
  setattr:      gpfs_i_setattr,
  getattr:      gpfs_i_getattr,    /* getattr */
  permission:  GENERIC_PERMISSION_OP,
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
  removexattr: gpfs_i_removexattr
};

/* inode operations for special files with extended attributes */
struct inode_operations gpfs_special_iops_xperm =
{
  setattr:      gpfs_i_setattr,
  getattr:      gpfs_i_getattr,    /* getattr */
  permission:  gpfs_i_permission,
  setxattr: gpfs_i_setxattr,
  getxattr: gpfs_i_getxattr,
  listxattr: gpfs_i_listxattr,
  removexattr: gpfs_i_removexattr
};

/* Default file operations, the other operations for the device
 * come from the bare device
 */
struct file_operations gpfs_fops =
{
  llseek:     gpfs_f_llseek,
  read:       gpfs_f_read,
  write:      gpfs_f_write,
#ifdef HAS_READDIR
  readdir:    gpfs_f_readdir,
#else
  iterate:    gpfs_f_readdir,
#endif
/*poll:       gpfs_f_poll,            let Linux handle poll by doing nothing */
#ifdef HAVE_UNLOCKED_IOCTL
  unlocked_ioctl: gpfs_f_unlocked_ioctl,          /* ENOSYS */
#else
  ioctl:      gpfs_f_ioctl,              /* ENOSYS */
#endif
  mmap:       gpfs_f_mmap,               /* ENOSYS */
  open:       gpfs_f_open,
  release:    gpfs_f_release,
  fsync:      gpfs_f_fsync,
  fasync:     gpfs_f_fasync,
  lock:       gpfs_f_lock,
#ifdef GPFS_FLOCK
  flock:      gpfs_f_flock,
#endif
#if defined(CLUSTER_LEASES) && !defined(REDHAT_RHEL53)
  setlease:  gpfs_f_set_lease,
#endif
#if LINUX_KERNEL_VERSION < 2062300
  sendfile:   generic_file_sendfile,
#else
  splice_read: gpfs_f_splice_read,
#endif
#ifndef KERNEL_HAS_NEW_AIO_FOPS
  readv:      gpfs_f_readv,
  writev:     gpfs_f_writev,
#endif
  aio_read:   gpfs_f_aio_read,
  aio_write:  gpfs_f_aio_write,
#if (LINUX_KERNEL_VERSION >= 2063800)
  fallocate:  gpfs_f_fallocate,
#endif
#ifdef CONFIG_CHECKPOINT
  checkpoint: generic_file_checkpoint
#endif
};

#ifdef REDHAT_RHEL53
struct file_operations_ext gpfs_fops_ext =
{
  .f_op_orig.llseek =    gpfs_f_llseek,
  .f_op_orig.read =      gpfs_f_read,
  .f_op_orig.write =     gpfs_f_write,
  .f_op_orig.readdir =   gpfs_f_readdir,
  .f_op_orig.ioctl =     gpfs_f_ioctl,              /* ENOSYS */
  .f_op_orig.mmap =      gpfs_f_mmap,               /* ENOSYS */
  .f_op_orig.open =      gpfs_f_open,
  .f_op_orig.release =   gpfs_f_release,
  .f_op_orig.fsync =     gpfs_f_fsync,
  .f_op_orig.fasync =    gpfs_f_fasync,
  .f_op_orig.lock =      gpfs_f_lock,
#ifdef GPFS_FLOCK
  .f_op_orig.flock =     gpfs_f_flock,
#endif
#if LINUX_KERNEL_VERSION < 2062300
  .f_op_orig.sendfile =  generic_file_sendfile,
#else
  .f_op_orig.splice_read =  gpfs_f_splice_read,
#endif
#ifndef KERNEL_HAS_NEW_AIO_FOPS
  .f_op_orig.readv =     gpfs_f_readv,
  .f_op_orig.writev =    gpfs_f_writev,
#endif
  .f_op_orig.aio_read =  gpfs_f_aio_read,
  .f_op_orig.aio_write = gpfs_f_aio_write,

  .setlease = gpfs_f_set_lease,
};
#endif

struct file_operations gpfs_fops_no_sendfile =
{
  llseek:     gpfs_f_llseek,
  read:       gpfs_f_read,
  write:      gpfs_f_write,
#ifdef HAS_READDIR
  readdir:    gpfs_f_readdir,
#else
  iterate:    gpfs_f_readdir,
#endif
/*poll:       gpfs_f_poll,            let Linux handle poll by doing nothing */
#ifdef HAVE_UNLOCKED_IOCTL
  unlocked_ioctl: gpfs_f_unlocked_ioctl,          /* ENOSYS */
#else
  ioctl:      gpfs_f_ioctl,              /* ENOSYS */
#endif
  mmap:       gpfs_f_mmap,               /* ENOSYS */
  open:       gpfs_f_open,
  release:    gpfs_f_release,
  fsync:      gpfs_f_fsync,
  fasync:     gpfs_f_fasync,
  lock:       gpfs_f_lock,
#ifdef GPFS_FLOCK
  flock:      gpfs_f_flock,
#endif
#if defined(CLUSTER_LEASES) && !defined(REDHAT_RHEL53)
  setlease:  gpfs_f_set_lease,
#endif
#ifndef KERNEL_HAS_NEW_AIO_FOPS
  readv:      gpfs_f_readv,
  writev:     gpfs_f_writev,
#endif
  aio_read:   gpfs_f_aio_read,
  aio_write:  gpfs_f_aio_write,
#if (LINUX_KERNEL_VERSION >= 2063800)
  fallocate:  gpfs_f_fallocate,
#endif
#ifdef CONFIG_CHECKPOINT
  checkpoint: generic_file_checkpoint
#endif
};

#ifdef REDHAT_RHEL53
struct file_operations_ext gpfs_fops_ext_no_sendfile =
{
  .f_op_orig.llseek =    gpfs_f_llseek,
  .f_op_orig.read =      gpfs_f_read,
  .f_op_orig.write =     gpfs_f_write,
  .f_op_orig.readdir =   gpfs_f_readdir,
  .f_op_orig.ioctl =     gpfs_f_ioctl,              /* ENOSYS */
  .f_op_orig.mmap =      gpfs_f_mmap,               /* ENOSYS */
  .f_op_orig.open =      gpfs_f_open,
  .f_op_orig.release =   gpfs_f_release,
  .f_op_orig.fsync =     gpfs_f_fsync,
  .f_op_orig.fasync =    gpfs_f_fasync,
  .f_op_orig.lock =      gpfs_f_lock,
#ifdef GPFS_FLOCK
  .f_op_orig.flock =     gpfs_f_flock,
#endif
#ifndef KERNEL_HAS_NEW_AIO_FOPS
  .f_op_orig.readv =     gpfs_f_readv,
  .f_op_orig.writev =    gpfs_f_writev,
#endif
  .f_op_orig.aio_read =  gpfs_f_aio_read,
  .f_op_orig.aio_write = gpfs_f_aio_write,

  .setlease = gpfs_f_set_lease,
};
#endif


/* Directory file operations are the same as regular file operations, but
   read (as opposed to readdir) is not allowed */
struct file_operations gpfs_dir_fops =
{
  llseek:     gpfs_f_llseek,
  read:       gpfs_f_dir_read,
  write:      gpfs_f_write,
#ifdef HAS_READDIR
  readdir:    gpfs_f_readdir,
#else
  iterate:    gpfs_f_readdir,
#endif
/*poll:       gpfs_f_poll,            let Linux handle poll by doing nothing */
#ifdef HAVE_UNLOCKED_IOCTL
  unlocked_ioctl: gpfs_f_unlocked_ioctl,          /* ENOSYS */
#else
  ioctl:      gpfs_f_ioctl,              /* ENOSYS */
#endif
  mmap:       gpfs_f_mmap,               /* ENOSYS */
  open:       gpfs_f_open,
  release:    gpfs_f_release,
  fsync:      gpfs_f_fsync,
  fasync:     gpfs_f_fasync,
  lock:       gpfs_f_lock,
#ifdef GPFS_FLOCK
  flock:      gpfs_f_flock,
#endif
#ifndef KERNEL_HAS_NEW_AIO_FOPS
  readv:      gpfs_f_readv,
  writev:     gpfs_f_writev,
#endif
  aio_read:   gpfs_f_aio_read,
  aio_write:  gpfs_f_aio_write,
#ifdef CONFIG_CHECKPOINT
  checkpoint: generic_file_checkpoint
#endif
};

/* dcache operations for a valid dentry:
   A valid dentry has no gpfs-specific operations defined;
   linux2gpfs.h #defines gpfs_dops_valid so that the assignement
   "d_op = &gpfs_dops_valid" will assign NULL to d_op instead of
   assigning a pointer to a table that only contains NULL function
   pointers.  This saves a few instructions on each potential call
   to one of the d_op callbacks.  The declaration below is left here
   ifdef'ed out so that a search for gpfs_dops_valid will find our
   comment here. */
#if 0
struct dentry_operations gpfs_dops_valid = { };
#endif

/* dcache operations for a valid dentry for a file that has been or will
   be unlinked shortly; a BR token revoke on the directory containing this
   entry should invalidate this entry even if it does not look like a
   negative dcache entry yet (call to d_delete has not yet happened);
   see also comment in gpfs_i_unlink.  */
#if LINUX_KERNEL_VERSION >= 2063000
const struct dentry_operations gpfs_dops_ddeletepending =
#else
struct dentry_operations gpfs_dops_ddeletepending =
#endif
{
  /* No operations defined.  There are explicit tests in the code for
     "d_op == &gpfs_dops_ddeletepending", so this structure cannot be
     removed as gpfs_dops_valid was. */
};

/* dcache operations for a dentry that has been invalidated by an inode
   token revoke on the file that this dentry refers to, or (in case of
   a negative dcache entry) by a BR token revoke on the directory
   containing this entry */
struct dentry_operations gpfs_dops_invalid =
{
  d_revalidate: gpfs_d_invalid,	
};

struct dentry_operations gpfs_dops_revalidate =
{
  d_revalidate: gpfs_d_revalidate,
};

struct dentry_operations gpfs_dops_valid_with_reval = 
{
  d_revalidate: gpfs_d_valid,
};

/* dcache operations for a positive dentry that was created for
   an inexact caseless file name match which succeeded for a Samba client.
   The d_revalidate returns "true" for subsequent Samba clients
   indicating that the dcache entry is still valid.
   It returns "false" for local or NFS clients indicating
   that the dcache entry is no longer valid which forces
   a new lookup. */
struct dentry_operations gpfs_dops_valid_if_Samba =
{
  d_revalidate: gpfs_d_valid_if_Samba,	
};
/* dcache operations for a negative dentry that was created for
   an exact file name match which failed for a local or NFS client.
   The d_revalidate returns "true" for subsequent local or NFS clients
   indicating that the negative dcache entry is still valid.
   It returns "false" for Samba clients indicating
   that the dcache entry is no longer valid which forces
   a new lookup. */
struct dentry_operations gpfs_dops_invalid_if_Samba =
{
  d_revalidate: gpfs_d_invalid_if_Samba,	
};

#ifdef GPFS_CACHE
struct dentry_operations gpfs_dops_pcache =
{
  d_revalidate: gpfs_d_revalidate,
};
#endif

struct address_space_operations gpfs_aops =
{
  readpage:       gpfs_i_readpage,
  writepage:      gpfs_i_writepage,
#ifdef PER_QUEUE_PLUGGING
  sync_page:      block_sync_page,
#endif
  direct_IO:      gpfs_f_direct_IO,
};

/* address_space_operations after inode deletion */
struct address_space_operations gpfs_aops_after_inode_delete =
{
};

/*
 * filemap nopage callback function
 */
struct vm_operations_struct gpfs_vmop = 
{
#if LINUX_KERNEL_VERSION >= 2062600
  fault:  gpfs_filemap_fault,
#else
  nopage:  gpfs_filemap_nopage,
#endif
  open:    gpfs_filemap_open,
  close:   gpfs_filemap_close,
#ifdef CONFIG_CHECKPOINT
  checkpoint: filemap_checkpoint,
#endif
};
                                                                                                 
