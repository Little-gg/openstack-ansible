/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
static char sccsid[] = "@(#)96	1.2  src/avs/fs/mmfs/ts/kernext/gpl-linux/overwrite.c, mmfs, avs_rfks0, rfks01416c 4/1/14 13:50:30";

/* Part of the GPFS trace facility for Linux.  Handles operations
   associated with the shared trace buffer used in overwrite mode.  Bound
   into the lxtrace program. */

/* Contents:
 *   heapElement_t
 *   heapInsert
 *   heapDeleteMin
 *   setBaseTime
 *   cyclesToTOD
 *   formatTOD
 *   cyclesToString
 *   buildSegmentLists
 *
 *   OverwriteTraceDaemonBody
 *   dumpOverwriteTrcBuf
 *   RecycleOverwrite
 *   RecycleOverwriteFromDump
 *   FormatOverwriteTrace
 *   DumpOverwriteFormatStats
 */

#define ROUNDUP(_addr, _align) \
   (((long)_addr + (long)_align - 1L) & ~((long)_align - 1L))

/* Added for LFS */
#define _LARGEFILE_SOURCE
#define _FILE_OFFSET_BITS 64
#include <Shark-gpl.h>

#include <sys/types.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <fcntl.h>
#include <ctype.h>
#include <assert.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <limits.h>

#include <Trace.h>
#include <lxtrace.h>

#ifndef O_DIRECT
#ifdef GPFS_ARCH_PPC64
#define O_DIRECT 0400000
#else
#define O_DIRECT 040000
#endif
#endif


/* Functions defined in lxtrace.c */
extern int GetFormatRecord(int hookid, char **cidPP, char **fmtPP,
                           i2nSpec_t **i2nPP, Int64 spaceUsed);


/* Formatting statistics: for each stream, count the number of segments,
   the number of trace records seen, and the number of trace records
   skipped */
struct
{
  int nSegmentsRead;
  Int64 nRecordsSeen;
  Int64 nRecordsSkipped;
} StreamStats[TOTAL_STREAMS];


/* Type of an element of the timestamp heap */
typedef struct
{
  /* Key: a 64 bit timestamp */
  UInt64 hKey;

  /* Stream number to which this element pertains.  Also used as a secondary
     key to break ties when hKey values are equal. */
  int hStream;

  /* Offset in current stream buffer of the record with key hKey */
  int hOffset;
} heapElement_t;


/* Timestamp heap: a heap is a binary tree in which the keys of each
   node are less than the keys of both of the children of the node.
   lxtrace uses a heap to manage timestamps of records or buffers
   when running in overwrite mode.  The heap is stored in an array, with
   the root of the tree in array element 1, and the children of the
   node with index i stored in array indices 2i and 2i+1.  Array
   index 0 is not used. */
#define MAX_HEAP_SIZE (N_KERNEL_TRACE_STREAMS + N_DAEMON_TRACE_STREAMS)
heapElement_t Heap[MAX_HEAP_SIZE+1];

/* Current number of elements in the heap */
int HeapSize = 0;

/* controls DFP debug via environment LXTRACE_DEBUG */
extern Boolean lxtraceDebug;

/* Insert an element into the heap */
static void heapInsert(UInt64 newKey, int newStream, int newOffset)
{
  int idx;
  int parentIdx;
  heapElement_t temp;

  /* Add the new element at the end of the heap array */
  assert(HeapSize < MAX_HEAP_SIZE);
  idx = HeapSize + 1;
  Heap[idx].hKey = newKey;
  Heap[idx].hStream = newStream;
  Heap[idx].hOffset = newOffset;
  HeapSize += 1;

  /* Bubble the new element up towards the root of the heap to
     re-establish the property that the keys of all nodes are less than
     the keys of their children */
  while (idx > 1)
  {
    /* If the parent already has a lower key than the new node, the
       heap is consistent */
    parentIdx = idx / 2;
    if (Heap[parentIdx].hKey < Heap[idx].hKey)
      break;
    if (Heap[parentIdx].hKey == Heap[idx].hKey  &&
        Heap[parentIdx].hStream <= Heap[idx].hStream)
      break;

    /* Swap the current node with its parent, then recurse up the tree */
    temp = Heap[idx];
    Heap[idx] = Heap[parentIdx];
    Heap[parentIdx] = temp;
    idx = parentIdx;
  }
}


/* Delete and return the heap element with the minimum key */
static heapElement_t heapDeleteMin()
{
  heapElement_t minElement;
  heapElement_t temp;
  int idx;
  int leftIdx, rightIdx;
  int minIdx;

  /* The minimum element is stored at the root.  Save that element, then
     move the element at the end of the heap array into where the root
     was previously stored. */
  assert(HeapSize > 0);
  minElement = Heap[1];
  Heap[1] = Heap[HeapSize];
  HeapSize -= 1;

  /* Rebalance the heap.  Push the element at the root down so that the
     minimum element in each subtree is at the root of the subtree. */
  idx = 1;
  while (2*idx <= HeapSize)
  {
    /* Find the minimum of the two children of idx.  There may not be a
       right child. */
    leftIdx = 2 * idx;
    minIdx = leftIdx;
    rightIdx = leftIdx + 1;
    if (rightIdx <= HeapSize  &&
        Heap[rightIdx].hKey < Heap[leftIdx].hKey)
      minIdx = rightIdx;

    /* Compare the key of element idx with the minimum key of the
       children of idx.  Swap elements so that the smallest element is
       at the root of the subtree rooted at idx. */
    if (Heap[idx].hKey < Heap[minIdx].hKey)
      break;
    if (Heap[idx].hKey == Heap[minIdx].hKey  &&
        Heap[idx].hStream <= Heap[minIdx].hStream)
      break;
    temp = Heap[idx];
    Heap[idx] = Heap[minIdx];
    Heap[minIdx] = temp;
    idx = minIdx;
  }

exit:
  return minElement;
}


/* Cycle count of the first trace record displayed and the corresponding
   TOD value */
UInt64 BaseCycles = 0;
Boolean BaseCyclesSetFromTrace = false;
int BaseSeconds = 0;
int BaseNanoseconds = 0;

/* Measured number of seconds per cycle and cycles per second */
double SecondsPerCycle = 0.0;
Int64 CyclesPerSecond = 0;

/* Set the base time to be used for timestamp conversions by cyclesToTOD
   when formatting the trace.  May be called more than once with
   different bases and formatting styles. */
static void setBaseTime(UInt64 baseCycles,
                        const SharedTraceBufferHeader_t* trbP,
                        TimestampStyle_t style)
{
  UInt64 deltaCycles;
  int deltaSecs;
  int deltaNS;

  /* Remember cycle counter for first trace */
  BaseCycles = baseCycles;

  /* If cycle counts will need to be converted to TOD seconds and
     nanoseconds, set up the base values for those conversions */
  if (style == fLocal  ||
      style == fTOD)
  {
    deltaCycles = baseCycles - trbP->trbStartTimeStamp;
    deltaSecs = deltaCycles / CyclesPerSecond;
    deltaNS = 1e9 *
              ((double)(deltaCycles % CyclesPerSecond) / CyclesPerSecond);
    BaseSeconds = trbP->trbStartTOD.tv_sec + deltaSecs;
    BaseNanoseconds = 1000*trbP->trbStartTOD.tv_usec + deltaNS;
    if (BaseNanoseconds > 1000000000)
    {
      BaseSeconds += 1;
      BaseNanoseconds -= 1000000000;
    }
  }
  else
  {
    BaseSeconds = 0;
    BaseNanoseconds = 0;
  }
}


/* Convert raw cycle counter to time-of-day seconds and nanoseconds.  Must
   have already called setBaseTime. */
static void cyclesToTOD(UInt64 cycles, int* todSecsP, int* todNSP)
{
  UInt64 deltaCycles;
  int deltaSecs;
  int deltaNS;

  deltaCycles = cycles - BaseCycles;
  deltaSecs = deltaCycles / CyclesPerSecond;
  deltaNS = 1e9 *
            ((double)(deltaCycles % CyclesPerSecond) / CyclesPerSecond);
  *todSecsP = BaseSeconds + deltaSecs;
  *todNSP = BaseNanoseconds + deltaNS;
  if (*todNSP > 1000000000)
  {
    *todSecsP += 1;
    *todNSP -= 1000000000;
  }
}


/* Convert timestamp to string format.  Returns a string that is 29
   characters long. */
static char* formatTOD(time_t timeSecs, int timeNS, char* timeStrP)
{
  extern char *ctime_r(const time_t *, char *);
  /* Convert time seconds into a string formatted like
                  111111111122222
        0123456789012345678901234
       "Mon Oct 14 09:45:43 2013\n"
     Return "unknown" on any failure. */
  if (!ctime_r(&timeSecs, timeStrP) || timeSecs == -1)
    strcpy(timeStrP, "unknown                   ");
  else
    /* Overwrite the year portion of the time by the converted nanoseconds */
    sprintf(timeStrP+19, ".%09d", timeNS);
  return timeStrP;
}


/* Convert a trace timestamp into the string that will appear in the
   formatted trace output.  Returns a pointer to the buffer that was
   provided, which must be large enough to hold the converted string. */
static char* cyclesToString(UInt64 cycles, char* timeBufP,
                            TimestampStyle_t style)
{
  UInt64 relCycles;
  double relSeconds;
  int todSecs, todNS;

  switch (style)
  {
    case fRawCycles:
    default:
      sprintf(timeBufP, "%20llu", cycles);
      break;

    case fRelCycles:
      sprintf(timeBufP, "%20llu", cycles - BaseCycles);
      break;

    case fLocal:
      cyclesToTOD(cycles, &todSecs, &todNS);
      (void)formatTOD(todSecs, todNS, timeBufP);
      break;

    case fTOD:
      cyclesToTOD(cycles, &todSecs, &todNS);
      sprintf(timeBufP, "%10d.%09d", todSecs, todNS);
      break;

    case fRelativeSecs:
      relCycles = cycles - BaseCycles;
      relSeconds = relCycles * SecondsPerCycle;
      sprintf(timeBufP, "%16.9f", relSeconds);
      break;
  }
  return timeBufP;
}


/* Examine the shared trace buffer and construct lists of buffer
   segments belonging to each trace stream.  Allocates and returns
   arrays *segsByStreamPP and *oldestIdxByStreamPP that hold the
   results. */
static void buildSegmentLists(SharedTraceBufferHeader_t* trbP,
                              int** segsByStreamPP,
                              int** oldestIdxByStreamPP)
{
  TrcSegmentIdxAndOffset_t segIdxAndOffset;
  UInt64 commonStreamStartTime;
  TrStreamDesc_t* streamP;
  TraceSegmentHdr_t* segP;
  TraceSegmentHdr_t* oldSegP;
  int* segsByStreamP;
  int* oldestIdxByStreamP;
  int nSegSlots;
  int s;
  int nextIdx;
  int nSegmentsInDumpThisStream;
  int totalSegmentsInDump;
  UInt32 currentSegmentIndex;
  UInt32 olderSegmentIndex;

  /* Allocate arrays to hold the results of this function.  The
     segsByStreamP array holds the segment indices for all streams.
     Within this array, for each stream, there will be list of segment
     numbers in increasing order of the latest timestamp in the segment,
     followed by an array slot containing NO_TRC_SEGMENT to signify the
     end of the segment list for the stream.  The oldestIdxByStreamP
     array holds, for each stream, the index in segsByStreamP where the
     index of the oldest segment belonging to that stream is held. */
  nSegSlots = trbP->trbNSegments +     /* every segment appears once */
              N_KERNEL_TRACE_STREAMS + /* every stream has an end marker */
              N_DAEMON_TRACE_STREAMS;
  segsByStreamP = (int*)malloc(nSegSlots * sizeof(int));
  memset(segsByStreamP, 0, nSegSlots * sizeof(int));
  oldestIdxByStreamP = malloc((TOTAL_STREAMS)*sizeof(int));
  memset(oldestIdxByStreamP, 0, (TOTAL_STREAMS) * sizeof(int));

  /* The earliest point in the trace that is known to contain data from
     all trace streams is the max of when daemon tracing was enabled and
     the largest time at which a segment began to be filled.  This will
     be computed later when the oldest segment for each stream has been
     determined. */
  commonStreamStartTime = trbP->trbDaemonStartTimeStamp;

  /* For each stream, walk the list of active and retired segments
     belonging to the stream and record their indices in segsByStreamP.
     The segment links go from younger to older segments, and we want
     the order of segments in the segsByStreamP array to be oldest to
     youngest.  Add segment indices to the array starting at the highest
     array index to accomplish this order reversal. */
  nextIdx = nSegSlots - 1;
  totalSegmentsInDump = 0;
  for (s=0; s<TOTAL_STREAMS; s++)
  {
    /* Place the end-of-stream marker for this stream */
    streamP = &trbP->trbStream[s];
    assert(nextIdx >= 0);
    segsByStreamP[nextIdx] = NO_TRC_SEGMENT;
    nextIdx -= 1;

    /* The youngest segment for this stream (highest timestamps) is its
       currently active segment, if any */
    segIdxAndOffset = streamP->stSegmentAndOffset;
    currentSegmentIndex = TRCWORD_2_INDEX(segIdxAndOffset);

    /* Walk the list of segments assigned to this stream and record
       the segment indices */
    nSegmentsInDumpThisStream = 0;
    while (currentSegmentIndex != NO_TRC_SEGMENT)
    {
      segP = &trbP->trbSegSpace[currentSegmentIndex].segHdr;
      assert(segP->segStream == s);
      assert(nextIdx >= 0);
      segsByStreamP[nextIdx] = currentSegmentIndex;
      nextIdx -= 1;
      nSegmentsInDumpThisStream += 1;

      /* Follow the back pointer in this segment to the next older
         segment for this stream.  The pointer may be null, or it may
         point at a segment that no longer belongs to this stream.  Once
         the oldest segment for a stream has been located, update the
         time at which all trace streams are present.  If there never
         was a segment older than the oldest one found for this stream,
         then we know that every trace ever made in that stream is
         present in the trace. */
      olderSegmentIndex = segP->segStreamOlderIdx;
      if (olderSegmentIndex == NO_TRC_SEGMENT)
        /* No need to update commonStreamStartTime; no segments for this
           stream have ever been discarded */
        break;
      oldSegP = &trbP->trbSegSpace[olderSegmentIndex].segHdr;
      if (oldSegP->segStream != s  ||
          oldSegP->segTimestamp != segP->segStreamOlderTimestamp)
      {
        commonStreamStartTime = MAX(commonStreamStartTime,
                                    segP->segTimestamp);
        break;
      }
      currentSegmentIndex = olderSegmentIndex;
    }

    /* Remember the index in the segsByStreamP array where the index of
       the oldest segment belonging to this stream resides */
    oldestIdxByStreamP[s] = nextIdx + 1;

    /* Record the number of segments that will appear in the dump
       for this stream */
    streamP->stNSegmentsDumped = nSegmentsInDumpThisStream;
    totalSegmentsInDump += nSegmentsInDumpThisStream;
  }

  /* Record total number of segments in the dump */
  trbP->trbTotalSegmentsDumped = totalSegmentsInDump;

  /* Record earliest time at which all streams contain data */
  trbP->trbAllStreamsHaveDataTimeStamp = commonStreamStartTime;

  /* Return pointers to allocated arrays */
  *segsByStreamPP = segsByStreamP;
  *oldestIdxByStreamPP = oldestIdxByStreamP;
}


/* Body of the lxtrace daemon process for overwrite tracing.  The main
   purpose of this process is to hold the trace device open until tracing
   is turned off.  This prevents the tracedev kernel module from being
   unloaded, which will also deallocate the current shared trace buffer. */
int OverwriteTraceDaemonBody(int msgQueue)
{
  int signal;
  sigset_t signals;
  int rc;
  int traceDeviceFD;
  TraceDaemonMsg_t msg;

  /* block signals */
  sigemptyset(&signals);
  sigaddset(&signals, SIGINT);
  sigaddset(&signals, SIGTERM);
  sigaddset(&signals, SIGIO);
  sigaddset(&signals, SIGALRM);
  pthread_sigmask(SIG_BLOCK, &signals, NULL);

  /* Initialize the trace device */
  traceDeviceFD = open(TRC_DEVICE, O_RDWR);
  if (traceDeviceFD < 0)
  {
    /* Device does not exist, wrong type, or already open, ... */
    DP("trace daemon: device open failed with errno %d\n", errno);
    rc = ENODEV;
    return rc;
  }
  DFP("Successfully opened trace device %s\n", TRC_DEVICE);

  /* Record the pid of this process in the tracedev kernel module so we
     can signal this process later. */
  ioctl(traceDeviceFD, TrRegisterTraceDaemon);

  /* Mark as ready for tracing. */
  ioctl(traceDeviceFD, TrStartOverwriteTrace, NULL);

  /* Initialization succeed, send message to parent */
  msg.mtype = LXTRACE_MTYPE;
  strcpy(msg.mtext, LXTRACE_INIT_OK);
  msgsnd(msgQueue, &msg, strlen(msg.mtext)+1, 0);
  DFP("trace daemon: send message to parent: %s\n", msg.mtext);

  /* Build set of signals we are willing to receive */
  sigemptyset(&signals);
  sigaddset(&signals, SIGINT);
  sigaddset(&signals, SIGTERM);
  sigaddset(&signals, SIGIO);

  /* Wait for a signal */
  while (sigwait(&signals, &signal) == 0)
  {
    switch (signal)
    {
      /* Recycle trace.  For overwrite tracing, the work has already been
         done, but still send the signal so the code in 'lxtrace recycle'
         can be common across blocking and overwrite tracing. */
      case SIGIO:
        /* Send msg acknowledging the signal to lxtrace recycle */
        msgQueue = GetMsgQueue(0);
        msg.mtype = LXTRACE_MTYPE;
        msgsnd(msgQueue, &msg, 0, IPC_NOWAIT);
        DFP("trace daemon: send recycle message %ld to %d\n",
            msg.mtype, msgQueue);
        break;

      /* Exit lxtrace daemon */
      case SIGINT:
      case SIGTERM:
        /* Send msg acknowledging the signal to lxtrace off */
        msgQueue = GetMsgQueue(0);
        msg.mtype = LXTRACE_MTYPE;
        msgsnd(msgQueue, &msg, 0, IPC_NOWAIT);
        DFP("trace daemon: send off message %ld to %d\n", msg.mtype, msgQueue);
        goto terminateDaemon;

      default:
        goto terminateDaemon;
    }
  }

terminateDaemon:
  /* Close the trace device before returning.  This will decrement the
     reference count of the tracedev module. */
  close(traceDeviceFD);
  return 0;
}

/* Dump out the data in overwrite trace buffer with the order
   needed by trace formatting. */
int dumpOverwriteTrcBuf(const char* outFileNameP,
                        const char* bufferBaseP)
{
  int rc;
  int s;
  int segIdx;
  int segIdxIdx;
  int outputFD;
  Int64 nBytesWritten;
  TrStreamDesc_t* streamP;
  TraceSegmentHdr_t* segP;
  heapElement_t minElement;
  int* segsByStreamP = NULL;
  int* oldestIdxByStreamP = NULL;
  SharedTraceBufferHeader_t* trbP;

  trbP = (SharedTraceBufferHeader_t*)bufferBaseP;
  if (trbP == NULL)
  {
    DP("The bufferBaseP is NULL\n");
    rc = -1;
    goto exit;
  }
  /* Create the output file */
  outputFD = open(outFileNameP, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  if (outputFD == -1)
  {
    DP("Cannot open trace output file. rc %d errno %d (%s)\n",
       outputFD, errno, strerror(errno));
    rc = -1;
    goto exit;
  }

  /* Build lists of buffer segments for each trace stream */
  buildSegmentLists(trbP, &segsByStreamP, &oldestIdxByStreamP);

  /* Write out the header of the shared trace buffer */
  nBytesWritten = write(outputFD, trbP, sizeof(SharedTraceBufferHeader_t));
  if (nBytesWritten != sizeof(SharedTraceBufferHeader_t))
  {
    DP("short write on header: %lld bytes written\n", nBytesWritten);
    rc = -1;
    goto exit;
  }

  /* Build a heap of buffer segment indices, with one representative for
     each stream.  Initially, the heap will contain the oldest segment
     of each stream.  As segments are added to the heap, write them
     to the output file. */
  for (s=0; s<TOTAL_STREAMS; s++)
  {
    /* Skip streams with no segments */
    segIdxIdx = oldestIdxByStreamP[s];
    segIdx = segsByStreamP[segIdxIdx];
    if (segIdx == NO_TRC_SEGMENT)
      continue;

    /* Advance cursor for this stream to its next segment */
    oldestIdxByStreamP[s] += 1;

    /* Insert an entry for this stream into the heap.  The key is the
       timestamp of the last record in the segment. */
    segP = &trbP->trbSegSpace[segIdx].segHdr;
    assert(segP->segStream == s);
    heapInsert(segP->segFillerTimestamp, s, 0);

    /* Write the segment to the output file */
    nBytesWritten = write(outputFD, segP, TRACE_BUFFER_SEGMENT_BYTES);
    if (nBytesWritten != TRACE_BUFFER_SEGMENT_BYTES)
    {
      DP("short write on segment: %lld bytes written\n", nBytesWritten);
      rc = -1;
      goto exit;
    }
  }

  /* Write out all remaining segments of the shared trace buffer, in
     the order needed by trace formatting.  During formatting, the
     trace record with the smallest timestamp will repeatedly be taken
     out of one of the buffered trace segments.  The first segment to
     be exhausted will be the one with the smallest value for the last
     timestamp within the segment, which will correspond to the heap
     element with the smallest key.  The next read during formatting
     will be for the next segment of the stream whose segment was
     exhausted. */
  while (HeapSize > 0)
  {
    minElement = heapDeleteMin();
    s = minElement.hStream;
    segIdxIdx = oldestIdxByStreamP[s];
    segIdx = segsByStreamP[segIdxIdx];
    if (segIdx == NO_TRC_SEGMENT)
      continue;

    /* Advance cursor for this stream to its next segment */
    oldestIdxByStreamP[s] += 1;

    /* Insert an entry for this stream into the heap.  The key is the
       timestamp of the last record in the segment. */
    segP = &trbP->trbSegSpace[segIdx].segHdr;
    assert(segP->segStream == s);
    heapInsert(segP->segFillerTimestamp, s, 0);

    /* Write the segment to the output file */
    nBytesWritten = write(outputFD, segP, TRACE_BUFFER_SEGMENT_BYTES);
    if (nBytesWritten != TRACE_BUFFER_SEGMENT_BYTES)
    {
      DP("short write on segment: %lld bytes written\n", nBytesWritten);
      rc = -1;
      goto exit;
    }
  }

  /* Sync and close the trace output file */
  rc = fsync(outputFD);
  if (rc != 0)
    DP("Cannot fsync trace output file.  rc %d errno %d (%s)\n",
       rc, errno, strerror(errno));

exit:
  if (outputFD >= 0)
    close(outputFD);

  return rc;
}

/* Copy the overwrite buffer to a file in response to 'lxtrace recycle'
   or 'lxtrace off'. */
int RecycleOverwrite(const char* outFileNameP, Boolean isRecycle,
                     int traceDeviceFD, int kTtraceMode)
{
  int rc;
  Int64 bufferSize;
  char* bufferBaseP;
  struct kArgs args;

  /* Get the overwrite buffer size from the kernel */
  args.arg1 = (long)&bufferSize;
  rc = ioctl(traceDeviceFD, TrQuerySharedBufferSize, &args);
  if (rc != 0)
  {
    DFP("Unable to get trace buffer size from kernel; rc %d\n", rc);
    goto exit;
  }
  if (bufferSize <= 0)
  {
    DFP("TrQuerySharedBufferSize ioctl returned invalid result %d\n",
        bufferSize);
    rc = ENOMEM;
    goto exit;
  }

  /* Map the shared buffer to get access to the trace data.  Tracing
     should have already been quiesced in the daemon/kernel with 'tsctl
     quiceceOverwriteTrace' so the buffer is in a consistent state. */
  bufferBaseP = (char *) mmap(NULL, bufferSize,
                              PROT_WRITE | PROT_READ,
                              MAP_SHARED,
                              traceDeviceFD, 0);
  if (bufferBaseP == (char *)MAP_FAILED)
  {
    DFP("Could not map trace buffer, errno %d\n", errno);
    rc = ENOMEM;
    goto exit;
  }

  /* If tracing is not already quiesced or frozen, quiesce the trace so
     that the buffer remains stable as it is dumped.  If the mmtrace
     command is used, this will have already happened via a tsctl to the
     daemon.  If 'lxtrace off' is called directly, however, we need to
     do the quiesce here, even though a running GPFS daemon may continue
     to try to make trace records.  Quiescing the trace will prevent the
     daemon from being able to write any new trace records, even if the
     daemon does not know that it cannot write any trace records. */
  if (kTtraceMode == TRACE_OVERWRITE)
  {
    args.arg1 = (long)TRACE_OVERWRITE_QUIESCED;
    rc = ioctl(traceDeviceFD, TrSetKernelTraceMode, &args);
    if (rc != 0)
    {
      DFP("Unable to quiesce overwrite trace; rc %d\n", rc);
      goto exit;
    }
    kTtraceMode = TRACE_OVERWRITE_QUIESCED;
  }

  /* dump the trace data into the output file */
  rc = dumpOverwriteTrcBuf(outFileNameP, bufferBaseP);
  if (rc != 0)
  {
    DP("Unable to dump out the trace data; rc %d errno %d\n", rc, errno);
    goto exit;
  }

  /* Reenable tracing when called from 'lxtrace recycle'.  The daemon
     trace flag will be turned back on by 'tsctl resumeOverwriteTrace'
     from mmtrace, or during the next daemon initialization. */
  if (isRecycle)
  {
    args.arg1 = (long)TRACE_OVERWRITE;
    rc = ioctl(traceDeviceFD, TrSetKernelTraceMode, &args);
    if (rc != 0)
    {
      DFP("Unable to resume overwrite trace; rc %d\n", rc);
      goto exit;
    }
  }
  else
  {
    /* Upgrade state from frozen to quiesced so the next daemon startup can
       resume tracing */
    if (kTtraceMode == TRACE_OVERWRITE_FROZEN)
    {
      args.arg1 = (long)TRACE_OVERWRITE_QUIESCED;
      rc = ioctl(traceDeviceFD, TrSetKernelTraceMode, &args);
      if (rc != 0)
      {
        DFP("Unable to unfreeze overwrite trace; rc %d\n", rc);
        goto exit;
      }
    }
  }

exit:
  if (bufferBaseP != (char *)MAP_FAILED)
    munmap(bufferBaseP, bufferSize);

  return rc;
}

/* Map the raw memory data of trace records from dump file
 * into buffer and then copy it to a file for later format.
 * e.g., the trace raw data dumped from vmcore by crash tool.
 */
int RecycleOverwriteFromDump(const char* rawDataDumpFileP,
                             const char* outFileNameP)
{
  int rc;
  int inputFD;
  Int64 bufferSize;
  char* bufferBaseP;
  struct stat inStat;

  inputFD = open(rawDataDumpFileP, O_RDONLY);
  if (inputFD == -1)
  {
    DP("Cannot open data dump file, errno %d (%s)\n",
        errno, strerror(errno));
    rc = -1;
    goto exit;
  }

  rc = fstat(inputFD, &inStat);
  if (rc != 0)
  {
    DP("Cannot stat the dump file, FD %d errno %d (%s)\n",
       inputFD, errno, strerror(errno));
    goto exit;
  }

  bufferSize = inStat.st_size;
  if (bufferSize <= 0)
  {
    DFP("The trace buffer size is invalid\n");
    rc = EINVAL;
    goto exit;
  }
  bufferBaseP = (char *) mmap(NULL, bufferSize,
                              PROT_READ | PROT_WRITE,
                              MAP_PRIVATE,
                              inputFD, 0);
  if (bufferBaseP == (char *)MAP_FAILED)
  {
    DP("Could not map trace buffer, errno %d\n", errno);
    rc = ENOMEM;
    goto exit;
  }

  /* dump the trace data into the output file */
  rc = dumpOverwriteTrcBuf(outFileNameP, bufferBaseP);
  if (rc != 0)
    DP("Unable to dump out the trace data; rc %d errno %d\n", rc, errno);

exit:
  if (bufferBaseP != (char *)MAP_FAILED)
    munmap(bufferBaseP, bufferSize);
  if (inputFD >= 0)
    close(inputFD);

  return rc;
}

int FormatOverwriteTrace(const char* trcPrefixP, FILE* outFileP,
                         int verbose,
                         Int64* totalRecordsSeenP)
{
  Int64 bytesRead;
  Int64 readOffset;
  Int64 streamBufOffset[TOTAL_STREAMS];
  Int64 totalRecordsSeen;
  Int64 nFillerRecordsSkipped;
  Int64 nRecordsSkipped;
  double traceInterval;
  heapElement_t elmt;
  struct stat statBuf;
  SharedTraceBufferHeader_t* trbP = NULL;
  TraceSegmentHdr_t* streamSegP[TOTAL_STREAMS];
  TraceRecord_t* recP;
  int recLen;
  char* compP;
  char* fmtP;
  i2nSpec_t* i2nP;
  int todSecs, todNS;
  int segOffset[TOTAL_STREAMS];
  int thisSegOffset;
  int inputFD;
  int s;
  int rc;
  char trcFileP[PATH_MAX];
  char timeBuf[36];  /* timestamp in string format */
  char hdrLine[256];
  char hdrSepLine[256];
  Boolean skipEnded = false;
  Boolean printedWarning = false;

  DFP("Called FormatOverwriteTrace\n");
  /* setlinebuf(outFileP); */

  /* Open input file */
  sprintf(trcFileP, "%s.cpu%d", trcPrefixP, 0);
  inputFD = open(trcFileP, O_RDONLY);
  if (inputFD == -1)
  {
    DP("Cannot open trace file %s\n", trcFileP);
    rc = 1;
    goto exit;
  }

  /* Allocate space for trace header and read it from the input file */
  trbP = (SharedTraceBufferHeader_t*)malloc(sizeof(SharedTraceBufferHeader_t));
  readOffset = 0;
  bytesRead = read(inputFD, trbP, sizeof(SharedTraceBufferHeader_t));
  if (bytesRead != sizeof(SharedTraceBufferHeader_t))
  {
    DP("Cannot read complete overwrite trace header; len %lld\n", bytesRead);
    rc = 1;
    goto exit;
  }
  readOffset = bytesRead;
  DFP("read header\n");

  /* Validate trace header */
  if (trbP->trbNStreams != TOTAL_STREAMS)
  {
    DP("Expected %d streams but found %d\n",
       TOTAL_STREAMS, trbP->trbNStreams);
    rc = 1;
    goto exit;
  }

  /* Print trace header */
  hdrLine[0] = '\0';
  hdrSepLine[0] = '\0';
  fprintf(outFileP, "Overwrite trace parameters:\n"
                  "  buffer size: %lld\n"
                  "  %3d kernel trace streams, indices %d-%d (selected by low bits of processor ID)\n"
                  "  %3d daemon trace streams, indices %d-%d (selected by low bits of thread ID)\n",
                  trbP->trbSize,
                  N_KERNEL_TRACE_STREAMS,
                  0,
                  N_KERNEL_TRACE_STREAMS-1,
                  N_DAEMON_TRACE_STREAMS,
                  N_KERNEL_TRACE_STREAMS,
                  N_KERNEL_TRACE_STREAMS+N_DAEMON_TRACE_STREAMS-1);
  traceInterval = (double)(trbP->trbQuiesceTOD.tv_sec - trbP->trbStartTOD.tv_sec);
  traceInterval +=
    0.000001 *
    (double)(trbP->trbQuiesceTOD.tv_usec - trbP->trbStartTOD.tv_usec);
  fprintf(outFileP,
          "Interval for calibrating clock rate was %.6f seconds and %lld cycles\n",
          traceInterval, trbP->trbQuiesceTimeStamp-trbP->trbStartTimeStamp);
  CyclesPerSecond =
    (Int64)((trbP->trbQuiesceTimeStamp-trbP->trbStartTimeStamp) / traceInterval);
  SecondsPerCycle = 1.0 / CyclesPerSecond;
  fprintf(outFileP, "Measured cycle count update rate to be %lld per second",
          (Int64)CyclesPerSecond);
  if (traceInterval >= 0)
    fprintf(outFileP, " <---- using this value\n");
  else
    fprintf(outFileP, "\n");
  fprintf(outFileP, "OS reported cycle count update rate as %lld per second",
          trbP->trbOSTimerRatePerSecond);
  /* Formating traces without quiescence, e.g., from vmcore */
  if (traceInterval < 0 && trbP->trbOSTimerRatePerSecond != 0)
  {
    fprintf(outFileP, " <---- using this value\n");
    SecondsPerCycle = 1.0 / trbP->trbOSTimerRatePerSecond;
  }
  else
    fprintf(outFileP, "\n");
  fprintf(outFileP, "Trace milestones:\n");
  fprintf(outFileP, "  kernel trace enabled  %s (TOD %d.%06d, cycles %lld)\n",
          formatTOD(trbP->trbStartTOD.tv_sec,
                    1000*trbP->trbStartTOD.tv_usec, timeBuf),
          trbP->trbStartTOD.tv_sec, trbP->trbStartTOD.tv_usec,
          trbP->trbStartTimeStamp);
  fprintf(outFileP, "  daemon trace enabled  %s (TOD %d.%06d, cycles %lld)\n",
          formatTOD(trbP->trbDaemonStartTOD.tv_sec,
                    1000*trbP->trbDaemonStartTOD.tv_usec, timeBuf),
          trbP->trbDaemonStartTOD.tv_sec, trbP->trbDaemonStartTOD.tv_usec,
          trbP->trbDaemonStartTimeStamp);

  setBaseTime(trbP->trbStartTimeStamp, trbP, fTOD);
  if (trbP->trbAllStreamsHaveDataTimeStamp == trbP->trbDaemonStartTimeStamp)
  {
    todSecs = trbP->trbDaemonStartTOD.tv_sec;
    todNS = 1000 * trbP->trbDaemonStartTOD.tv_usec;
  }
  else
    cyclesToTOD(trbP->trbAllStreamsHaveDataTimeStamp, &todSecs, &todNS);
  fprintf(outFileP, "  all streams included  %s (TOD %d.%06d, cycles %lld)"
                    " <---- useful part of trace extends from here\n",
          formatTOD(todSecs, todNS, timeBuf),
          todSecs, todNS/1000,
          trbP->trbAllStreamsHaveDataTimeStamp);

  fprintf(outFileP, "  trace quiesced        %s (TOD %d.%06d, cycles %lld)"
                    " <----   to here\n",
          formatTOD(trbP->trbQuiesceTOD.tv_sec,
                    1000*trbP->trbQuiesceTOD.tv_usec, timeBuf),
          trbP->trbQuiesceTOD.tv_sec, trbP->trbQuiesceTOD.tv_usec,
          trbP->trbQuiesceTimeStamp);
  fprintf(outFileP, "Approximate number of times the trace buffer was filled: %.3f\n",
          (double)trbP->trbNGetSegmentIoctls / trbP->trbNSegments);

  if (TimestampStyle == fRawCycles)
  {
    strcpy(hdrLine,    "     Cycle-count     ");
    strcpy(hdrSepLine, "-------------------- ");
  }
  else if (TimestampStyle == fLocal)
  {
    strcpy(hdrLine,    "          Local-time          ");
    strcpy(hdrSepLine, "----------------------------- ");
  }
  else if (TimestampStyle == fTOD)
  {
    strcpy(hdrLine,    "Seconds-since-1/1/70 ");
    strcpy(hdrSepLine, "-------------------- ");
  }
  else if (TimestampStyle == fRelCycles)
  {
    strcpy(hdrLine,    "Relative-cycle-count ");
    strcpy(hdrSepLine, "-------------------- ");
  }
  else /* TimestampStyle == fRelativeSecs */
  {
    strcpy(hdrLine,    "Relative-seconds ");
    strcpy(hdrSepLine, "---------------- ");
  }

  /* Append additional column headers to the header lines */
  strcat(hdrLine,    "  TID  ");
  strcat(hdrSepLine, "------ ");
  if (verbose)
  {
    strcat(hdrLine,    "str hookword ");
    strcat(hdrSepLine, "--- -------- ");
  }
  strcat(hdrLine,    "COMPONENT_TAG: application trace record ");
  strcat(hdrSepLine, "-------------- ------------------------ ");

  /* Allocate a stream segment buffer for each stream that has any
     segments in the trace file and read the first segment of each
     stream.  Decrement the number of segments remaining for the
     streams that were read. */
  for (s=0; s<trbP->trbNStreams; s++)
  {
    if (trbP->trbStream[s].stNSegmentsDumped == 0)
    {
      streamSegP[s] = NULL;
      segOffset[s] = TRACE_BUFFER_SEGMENT_BYTES;
      streamBufOffset[s] = 0;
      DFP("Empty stream %d\n", s);
    }
    else
    {
      DFP("Initial buffer for stream %d at offset %lld\n", s, readOffset);
      streamSegP[s] = (TraceSegmentHdr_t*)malloc(TRACE_BUFFER_SEGMENT_BYTES);
      bytesRead = read(inputFD, streamSegP[s], TRACE_BUFFER_SEGMENT_BYTES);
      if (bytesRead != TRACE_BUFFER_SEGMENT_BYTES)
      {
        DP("Short read (%lld) at offset %lld for initial segment of stream %d\n",
           bytesRead, readOffset, s);
        rc = 1;
        goto exit;
      }
      if (streamSegP[s]->segMagic != TRC_SEGMENT_MAGIC  ||
          streamSegP[s]->segStream != s)
      {
        DP("Segment format error at offset %lld\n", readOffset);
        rc = 1;
        goto exit;
      }
      segOffset[s] = sizeof(TraceSegmentHdr_t);
      streamBufOffset[s] = readOffset;
      readOffset += TRACE_BUFFER_SEGMENT_BYTES;
      trbP->trbStream[s].stNSegmentsDumped -= 1;
      StreamStats[s].nSegmentsRead += 1;
    }
  }

  /* Build the initial record heap.  There will be one record from each
     stream in the heap.  The key of each heap element will be the
     timestamp from the trace record.  Help elements also contain the
     stream number and offset within the trace segment of the beginning
     of the trace record. */
  DFP("Building heap for %d streams\n", trbP->trbNStreams);
  for (s=0; s<trbP->trbNStreams; s++)
  {
    if (streamSegP[s] != NULL)
    {
      recP = (TraceRecord_t*)((char*)streamSegP[s] + segOffset[s]);
      DFP("inserting %llu for stream %d\n", recP->oHdr.oTime, s);
      heapInsert(recP->oHdr.oTime, s, segOffset[s]);
    }
  }
  DFP("Built initial heap with %d elements\n", HeapSize);

  /* Print trace labels */
  fprintf(outFileP, "\n");
  fprintf(outFileP, "%s\n", hdrLine);
  fprintf(outFileP, "%s\n", hdrSepLine);

  /* Print a warning message about trace records from time intervals before
     all streams have valid data */
  if (HeapSize == 0)
    setBaseTime(trbP->trbStartTimeStamp, trbP, TimestampStyle);
  else
    setBaseTime(Heap[1].hKey, trbP, TimestampStyle);
  if (verbose != 0  &&
      trbP->trbAllStreamsHaveDataTimeStamp != trbP->trbDaemonStartTimeStamp)
  {
    fprintf(outFileP, " **** Warning: Until time %s, some trace streams have missing data ****\n",
            cyclesToString(trbP->trbAllStreamsHaveDataTimeStamp, timeBuf,
                           TimestampStyle));
    printedWarning = true;
  }

  /* Delete records from the heap one at a time, starting with the record
     that has the minimum timestamp.  Format and display records as they
     are deleted, then add the next record from the stream of the deleted
     record back into the timestamp heap.  If necessary, read additional
     buffer segments as they become depleted. */
  totalRecordsSeen = 0;
  nFillerRecordsSkipped = 0;
  nRecordsSkipped = 0;
  while (HeapSize > 0)
  {
    /* Find and delete record with the minimum timestamp */
    elmt = heapDeleteMin();
    totalRecordsSeen += 1;
    // DFP("deleted %llu from stream %d\n", elmt.hKey, elmt.hStream);
    s = elmt.hStream;
    StreamStats[s].nRecordsSeen += 1;
    assert(segOffset[s] < TRACE_BUFFER_SEGMENT_BYTES);
    recP = (TraceRecord_t*)((char*)streamSegP[s] + segOffset[s]);
    if (recP->oHdr.oMagic != LXTRACE_OVERWRITE_MAGIC)
    {
      assert(streamSegP[s]->segFillerTimestamp == 0);
      segOffset[s] = TRACE_BUFFER_SEGMENT_BYTES;
      goto nextRecord;
    }
    assert(recP->oHdr.oTime == elmt.hKey);
    assert(recP->oHdr.oMagic == LXTRACE_OVERWRITE_MAGIC);
    recLen = recP->oHdr.oLength;
    thisSegOffset = segOffset[s];
    segOffset[s] += recLen;

    /* Skip filler records unless verbose was specified */
    if (recP->dHdr.trHook == LXTRACE_FILLER  &&
        verbose == 0)
    {
      nFillerRecordsSkipped += 1;
      StreamStats[s].nRecordsSkipped += 1;
      goto nextRecord;
    }

    /* Skip records with timestamps before the time at which all trace
       streams had valid data, unless verbose was specified */
    if (verbose == 0  &&
        recP->oHdr.oTime < trbP->trbAllStreamsHaveDataTimeStamp)
    {
      nRecordsSkipped += 1;
      StreamStats[s].nRecordsSkipped += 1;
      goto nextRecord;
    }

    /* Set base time to the timestamp of the first record displayed */
    if (! BaseCyclesSetFromTrace)
    {
      setBaseTime(recP->oHdr.oTime, trbP, TimestampStyle);
      BaseCyclesSetFromTrace = true;
    }

    if (!skipEnded  &&
        recP->oHdr.oTime >= trbP->trbAllStreamsHaveDataTimeStamp)
    {
      skipEnded = true;
      if (printedWarning)
        fprintf(outFileP, " **** Warning: Above this point, some trace streams have missing data ****\n");
    }

    /* Format and display the timestamp and thread ID of the trace record */
    fprintf(outFileP, "%s %6d ",
            cyclesToString(recP->oHdr.oTime, timeBuf, TimestampStyle),
            recP->oHdr.oProcess);

    /* If verbose mode is enabled, display additional fields */
    if (verbose)
      fprintf(outFileP, "%3d %08X ",
               s, recP->dHdr.trHook);

    /* Find the format string associated with the hook of this trace
       record */
    if (GetFormatRecord(recP->dHdr.trHook, &compP, &fmtP, &i2nP,
                        (Int64)recLen) != 0)
    {
      fprintf(outFileP, "Unknown hook id 0x%08X stream %d segment %d\n",
              recP->dHdr.trHook, s, streamSegP[s]->segThisIndex);
      rc = 0;
    }
    else
    {
      fprintf(outFileP, "%s: ", compP);
      rc = formatOneTraceRecord(fmtP, i2nP, &recP->dataWords[0],
                                recLen - HDRSIZE, &recP->dHdr, outFileP);
      if (rc != 0)
      {
        fprintf(outFileP, "Premature end of trace format\n");
        rc = 1;
        goto exit;
      }
    }

    /* If the record just processed was the last one in its buffer segment,
       read the next buffer segment for this stream, if there is one */
nextRecord:
    if (segOffset[s] >= TRACE_BUFFER_SEGMENT_BYTES)
    {
      if (trbP->trbStream[s].stNSegmentsDumped > 0)
      {
        DFP("Reading segment at offset %lld for stream %d\n", readOffset, s);
        bytesRead = read(inputFD, streamSegP[s], TRACE_BUFFER_SEGMENT_BYTES);
        if (bytesRead != TRACE_BUFFER_SEGMENT_BYTES)
        {
          DP("Short read (%lld) for segment of stream %d\n",
             bytesRead, s);
          rc = 1;
          goto exit;
        }
        if (streamSegP[s]->segMagic != TRC_SEGMENT_MAGIC  ||
            streamSegP[s]->segStream != s)
        {
          DP("Segment format error at offset %lld\n", readOffset);
          rc = 1;
          goto exit;
        }
        streamBufOffset[s] = readOffset;
        readOffset += TRACE_BUFFER_SEGMENT_BYTES;
        segOffset[s] = sizeof(TraceSegmentHdr_t);
        trbP->trbStream[s].stNSegmentsDumped -= 1;
        StreamStats[s].nSegmentsRead += 1;
      }
      else
      {
        /* No more segments for this stream.  Free the buffer. */
        DFP("end of stream %d\n", s);
        free(streamSegP[s]);
        streamSegP[s] = NULL;
      }
    }

    /* If the stream buffer was not deallocated above, there are more
       records in this segment.  Insert the key of the next record into
       the timestamp heap. */
    if (streamSegP[s] != NULL)
    {
      recP = (TraceRecord_t*)((char*)streamSegP[s] + segOffset[s]);
      // DFP("Inserting key %llu for stream %d\n", recP->oHdr.oTime, s);
      heapInsert(recP->oHdr.oTime, s, segOffset[s]);
    }
  }  /* end of 'while more trace records' */
  fprintf(outFileP, "\nEnd of trace\n");
  fprintf(outFileP, "  %lld trace records formatted\n",
          totalRecordsSeen - nFillerRecordsSkipped - nRecordsSkipped);
  fprintf(outFileP, "  %lld filler records skipped\n", nFillerRecordsSkipped);
  fprintf(outFileP, "  %lld other trace records skipped\n", nRecordsSkipped);

exit:
  *totalRecordsSeenP = totalRecordsSeen;
  return rc;
}


/* Print per-stream formatting statistics */
void DumpOverwriteFormatStats(FILE* statFileP)
{
  int s;

  fprintf(statFileP, "\nOverwrite trace stream statistics:\n\n");
  fprintf(statFileP, "  Stream   Segments   Total records   Skipped records\n"
                     "  ------   --------   -------------   ---------------\n");
  fprintf(statFileP, "  --- Kernel trace streams ---\n");
  for (s=0; s<TOTAL_STREAMS; s++)
  {
    if (s == N_KERNEL_TRACE_STREAMS)
      fprintf(statFileP, "  --- Daemon trace streams ---\n");
    if (StreamStats[s].nSegmentsRead == 0)
      continue;

    fprintf(statFileP, "  %6d   %8d   %13lld   %15lld\n",
            s, StreamStats[s].nSegmentsRead,
            StreamStats[s].nRecordsSeen, StreamStats[s].nRecordsSkipped);
  }
}

