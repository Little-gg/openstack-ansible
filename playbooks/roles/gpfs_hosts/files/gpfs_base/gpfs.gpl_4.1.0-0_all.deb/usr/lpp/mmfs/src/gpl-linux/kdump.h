/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)65       1.8  src/avs/fs/mmfs/ts/kernext/gpl-linux/kdump.h, mmfs, avs_rfks0, rfks01416c 4/8/09 17:18:12 */
/* Definitions for program to dump kernel memory */

/* Debugging printfs.  The entire body of the printf call is the macro
   parameter. */
#ifdef DEBUG_KDUMP
#define DBG(_p) do { _p; } while (0)
#else
#define DBG(_p) do {} while (0)
#endif

/* used to disable -mregparm=3 (IMPORTED BY KBUILD OVERHUAL),
   we need to reset regparm=0 in kdump, because kdump user-space side
   will call functions defined in kernel-space side kdump-kern.c,
   we cann't use registers to pass parameters in function call */
#ifdef KDUMP_NOREGPARMS
#define RESET_KDUMP_REGPARMS __attribute__((regparm(0)))
#else
#define RESET_KDUMP_REGPARMS  
#endif

/* Symbol storage area.  Each symbol has an address, some flags, and
   a name.  Symbols are linked into a hash table by name.  Although the
   symbol array itself is not sorted, the auxiliary array SymsByAddrPP is
   sorted by address to allow fast binary search by address. */
struct Symbol
{
  unsigned long  addr;
  int            flags;
  char          *nameP;
  struct Symbol *hashNextP;
};

#define FL_TEXT     0x01
#define FL_BSS      0x02
#define FL_DATA     0x04
#define FL_RODATA   0x08
#define FL_SECTION  0x10
#define FL_KSTRTAB  0x20

struct Dwarf
{
  unsigned short boff;      /* bit offset of the member */
  unsigned short blen;      /* bit length of the member */
  char          *nameP;
  struct Dwarf  *memNextP;  /* next dwarf member of this dwarf string */
  struct Dwarf  *hashNextP; /* next dwarf entry hashed to same index */
};

struct DwarfTagNode {
  unsigned long       id;       /* dwarf id */
  unsigned long       atType;   /* dwarf type */
  unsigned long       size;     /* size */
  int                 sizeFlag; /* size flag */
  int                 offset;   /* dwarf offset */
  char                *name;    /* dwarf name */
  char                *atName;  /* dwarf name type */
  struct DwarfTagNode *member;  /* pointer to member */
  struct DwarfTagNode *next;    /* next dwarf structure */
  struct DwarfTagNode *prev;    /* prev dwarf structure */
};

/* Look up symbol by name.  Returns a pointer to the symbol table entry
   if a matching name is found, otherwise NULL. */
extern struct Symbol* RESET_KDUMP_REGPARMS LookupSymbolByName(const char* nameP);

/* Add a symbol to the table.  The symbol name must not already be present.
   Returns the address of the new symbol table entry. */
extern struct Symbol* RESET_KDUMP_REGPARMS AddUniqueSymbol(unsigned long addr, int flags, 
                                      char* nameP);

/* Add a symbol to the table.  If the symbol name is already present,
   append the address of the symbol to the symbol name to make it
   unique.  Returns the address of the new symbol table entry. */
extern struct Symbol* RESET_KDUMP_REGPARMS AddSymbol(unsigned long addr, int flags, char* nameP);

/* Look up symbol by address.  Returns a pointer to the symbol table entry
   with the largest address that is less than or equal to the given
   address.  There will always be a symbol in the table with address 0,
   so this can always return a pointer to some Symbol object. */
extern struct Symbol* RESET_KDUMP_REGPARMS LookupSymbolByAddr(unsigned long addr);

/* Look up a symbol by address.  If an exact match for the address is
   found, return a pointer to the symbol name, otherwise return a pointer
   to an empty string. */
extern const char* RESET_KDUMP_REGPARMS ExactAddrToSymbol(unsigned long addr);


/* Bounds of the initial portion of kernel virtual memory.  These are
   initialized to liberal values, then tightened by reading kernel
   variables. */
extern unsigned long LowKernelAddr;
extern unsigned long HighKernelAddr;

/* List of valid virtual memory areas outside of [LowKernelAddr..HighKernelAddr] */
struct vmStruct
{
  unsigned long startAddr;
  int areaLen;
  off_t file_offset;
  struct vmStruct* nextAreaP;
};
extern struct vmStruct* vmListHeadP;

/* Return __START_KERNEL_map or PAGE_OFFSET */
extern unsigned long RESET_KDUMP_REGPARMS GetOffset(int fMap);

/* Read kernel memory after checking the address for validity.  If the address
   is invalid, return -1, otherwise return 0. */
extern int RESET_KDUMP_REGPARMS ReadKernel(unsigned long addr, void* bufP, int len, int fMap);

/* Read the current value of a kernel symbol.  Returns 0 on success, -1
   on failure. */
extern int RESET_KDUMP_REGPARMS GetSymbolValue(const char* nameP, void* bufP, int len);

/* Wrappers around malloc and free so they can be called from modules that
   include kernel files */
extern void* RESET_KDUMP_REGPARMS kMalloc(int len);
extern void RESET_KDUMP_REGPARMS kFree(void* p);
extern int RESET_KDUMP_REGPARMS kPrintf(const char *format, ...);
extern int RESET_KDUMP_REGPARMS kErrPrintf(const char *format, ...);
extern void RESET_KDUMP_REGPARMS kAssert(int expression, char *msg, ...);

/* Conditional free.  Free storage if p is not NULL. */
extern void RESET_KDUMP_REGPARMS CondFree(void* p);

/* Dump a block of memory.  Duplicate lines are supressed. */
#define DUMPMEM_ROUND 0x10
#define DUMPMEM_I1 0x01
#define DUMPMEM_I2 0x02
#define DUMPMEM_I4 0x04
#define DUMPMEM_I8 0x08
extern void RESET_KDUMP_REGPARMS DumpMemory(char* p, int nBytes, unsigned long origin, int dumpFlags);

extern int RESET_KDUMP_REGPARMS DumpMemoryCast(unsigned long origin, char *dwarfNameP);

extern void RESET_KDUMP_REGPARMS readCore(void* bufP, int len);
extern void RESET_KDUMP_REGPARMS openCore(char* corefile);
extern void RESET_KDUMP_REGPARMS seekCore(off_t pos);

extern int isCore;
