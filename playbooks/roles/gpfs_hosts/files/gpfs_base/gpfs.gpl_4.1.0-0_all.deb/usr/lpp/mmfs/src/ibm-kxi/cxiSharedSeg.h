/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)63       1.12  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiSharedSeg.h, mmfs, avs_rfks0, rfks01416c 9/1/08 18:20:05 */

#ifndef _h_cxiSharedSeg
#define _h_cxiSharedSeg

/* Arrange to allocate storage for external variables defined in this file
 * and in sharkSeg.h if the symbol _INIT_SHAREDBASEP is defined
 */
#ifdef _INIT_SHAREDBASEP
#define EXTERN
#else
#define EXTERN extern
#endif

#ifdef GPFS_WINDOWS
/* Shared segment is limited by MAX_MALLOC_VM_SIZE */
#define MAX_SHARED_SEGMENT_SIZE MAX_MALLOC_VM_SIZE

#elif defined(__64BIT__)
/* Allow shared segment up to 256G, mapped as 3072 regions of up to 88M each */
#define MAX_SSEG_MAPPINGS 3072
#define MAX_SHARED_SEGMENT_SIZE (256LL * 1024LL * 1024LL * 1024LL)

#else
/* Limit shared segment to just under 2G, mapped as 2047 regions of 1M each */
#define MAX_SSEG_MAPPINGS 2047
#define MAX_SHARED_SEGMENT_SIZE (MAX_SSEG_MAPPINGS * 1024LL * 1024LL)
#endif

#include <cxiSharedSeg-plat.h>

#endif /* _h_cxiSharedSeg */
