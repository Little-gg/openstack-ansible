/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)52       1.4  src/avs/fs/mmfs/ts/kernext/ibm-kxi/Dynassert.h, mmfs, avs_rfks0, rfks01416c 7/29/11 16:15:51 */
/*
 * Definition of macros and symbols to control dynamic asserts.
 *
 * Conventions for assigning assert levels:
 *   - Assert levels are always non-negative.
 *   - Larger assert levels imply more expensive tests.
 *   - Assert level == 0 disables the related asserts.
 *   - Assert level == 1 enables the basic asserts.
 *   - Assert level >  1 can be used to gate specific instances of asserts, which
 *                       may be for special situations or expensive to evaluate.
 *
 */
#ifndef _h_Dynassert
#define _h_Dynassert

/* Dynamic asserts - controlled class-by-class with
     mmfsadm dynassert <class> <level> [<class> <level>] ...
   or
     mmchconfig dynassert="<class> <level> ..."

   In this initial implementation, dynamic control and levels are not
   supported, but the macros are defined so that conversion of existing
   code can begin.
 */
#ifdef DYNASSERTS
#  ifndef DYNASSERTS_FULL  /* temporary for test builds */
#    define DYNASSERTS_COMPATIBLE /* temporary - force compatibility mode. */
#  endif
#endif

/* If DBGASSERTS is defined but DYNASSERTS is not, enable DYNASSERTS
   in compatibility mode. */
#if defined(DBGASSERTS) && !defined(DYNASSERTS)
#define DYNASSERTS
#define DYNASSERTS_COMPATIBLE
#endif

/* DYNASSERTS is not in compatibility mode. Enable full implementation mode.*/
#if defined(DYNASSERTS) && !defined(DYNASSERTS_COMPATIBLE)
#  ifndef DYNASSERTS_FULL
#    define DYNASSERTS_FULL
#  endif
#endif

/* NOTICE:  Neither DEFINE_DYNASSERT_GBL_VARS nor DYNASSERT_AUTO_INIT
   should have any effect on the code unless DYNASSERTS_FULL is defined. */

/* Define each assert class standard index.  Index zero is reserved for
   future use.  The dynamic assert categories are named like trace levels:
   TRACE_xxx becomes DYN_xxx, and uses the same names in the mmfsadm
   and mmchconfig commands.
   
   DO NOT ifdef ASSERT CLASS DEFINITIONS!
*/
#define DYN_RESERVED    0   /* reserved for future features. DO NOT USE! */
#define DYN_DEFAULT     1   /* Default class for DBGASSERT */
#define DYN_AFM         2   /* Active File Management */
#define DYN_ALLOC       3   /* Disk space allocation */
#define DYN_ALLOCMGR    4   /* Allocation manager */
#define DYN_BASIC       5   /* "basic" classes */
#define DYN_BRL         6   /* byte range locks */
#define DYN_CKSUM       7   /* Checksum services */
#define DYN_CLEANUP     8   /* cleanup routines */
#define DYN_CMD         9   /* TS commands */
#define DYN_DEFRAG     10   /* defragmentation */
#define DYN_DENTRYEXIT 11   /* daemon routine entry/exit */
#define DYN_DISK       12   /* physical disk I/O */
#define DYN_DLEASE     13   /* disk lease */
#define DYN_DMAPI      14   /* Data Management */
#define DYN_DS         15   /* data shipping */
#define DYN_EEXP       16   /* events exporter. */
#define DYN_ERRLOG     17   /* error logging */
#define DYN_FILE       18   /* file_operations */
#define DYN_FS         19   /* file system */
#define DYN_FSCK       20   /* online multinode fsck */
#define DYN_IALLOC     21   /* inode allocation */
#define DYN_IO         22   /* physical I/O */
#define DYN_KENTRYEXIT 23   /* kernel routine entry/exit */
#define DYN_KERNEL     24   /* kernel */
#define DYN_KLOCKL     25   /* low-level locks in VFS code */
#define DYN_KSVFS      26   /* generic VFS kernel stuff */
#define DYN_LOCK       27   /* interprocess locking */
#define DYN_LOG        28   /* recovery log */
#define DYN_MALLOC     29   /* MemoryPool alloc and dealloc */
#define DYN_MB         30   /* mailbox message handling */
#define DYN_MMPMON     31   /* mmpmon */
#define DYN_MNODE      32   /* metanode operations */
#define DYN_MSG        33   /* calls to routines in SharkMsg.h */
#define DYN_MUTEX      34   /* mutexes and condition variables */
#define DYN_NSD        35   /* network shared disk */
#define DYN_PCACHE     36   /* panache */
#define DYN_PERFMON    37   /* performance monitor code */
#define DYN_PGALLOC    38   /* page allocator */
#define DYN_PIN        39   /* pinning to real memory */
#define DYN_PIT        40   /* Parallel Inode Traversal */
#define DYN_QUOTA      41   /* quota management */
#define DYN_RDMA       42   /* rdma */
#define DYN_SANERGY    43   /* SANergy */
#define DYN_SCSI       44   /* SCSI services */
#define DYN_SEC        45   /* Cluster Security Specific */
#define DYN_SHARED     46   /* shared memory */
#define DYN_SMB        47   /* SMB Open and Op Locks */
#define DYN_SP         48   /* cluster management and RPCs */
#define DYN_TASKING    49   /* tasking system but not Thread operations */
#define DYN_THREAD     50   /* operations in Thread class */
#define DYN_TS         51   /* cluster management and RPCs */
#define DYN_TSTM       52   /* token manager (formerly DYN_CETM) */
#define DYN_VBHVL      53   /* Behaviorals */
#define DYN_VDB        54   /* Perseus debugger and related loadables */
#define DYN_VDISK      55   /* Perseus (NSD RAID, aka 'vdisk') */
#define DYN_VHOSP      56   /* Perseus disk hospital */
#define DYN_VNODE      57   /* vnode layer of VFS kernel support */
#define DYN_VNOP       58   /* one line per VNOP with all important info */

#define MAX_DYN_CLASSES 64  /* MUST BE LARGEST.  Keep incremented if new
                               classes are added beyond this index. */
/* DO NOT ifdef ASSERT CLASS DEFINITIONS! */

/* Dynamic assert levels work similarly to trace levels.
   In the daemon, DYNASSERT macros always reference the dynassert flags through
   the pointer AssertFlagsP.  There is a copy of this pointer in the GPFS
   daemon, that initially points to PrivateAssertFlagsArray.  After the
   shared segment has been initialized, the contents of this array are
   copied into Shared.assertFlags and AssertFlagsP is changed to point to
   this shared copy.  In the kernel, AssertFlagsP is an array of assert
   levels.  This is kept in sync with Shared.assertFlags by the
   kxSetAssertLevel kernel call whenever 'mmfsadm dynassert foo n' changes
   any assert flags.  */
#ifdef DYNASSERTS_FULL
#  ifdef DEFINE_DYNASSERT_GBL_VARS
#    ifdef _KERNEL
char AssertFlagsP[MAX_DYN_CLASSES] = { 0 };
#    else
char PrivateAssertFlagsArray[MAX_DYN_CLASSES] = { 0 };
char *AssertFlagsP = PrivateAssertFlagsArray;

#      ifdef DYNASSERT_AUTO_INIT
/* For standalone programs and GPFS command modules, automatically
   enable standard DYNASSERT levels. */
class DynassertInitializer
{
  int i;
public:
  DynassertInitializer() {
    for (i=0; i<MAX_DYN_CLASSES; i++)
      PrivateAssertFlagsArray[i] = 1;
  }

  ~DynassertInitializer() { }
};

static DynassertInitializer dyn_xrgq_82361453_DynassertInitializer;
#      endif /*  DYNASSERT_AUTO_INIT */

#    endif  /* _KERNEL */
#  else
#    ifdef _KERNEL
extern char AssertFlagsP[MAX_DYN_CLASSES];
#    else
extern char PrivateAssertFlagsArray[MAX_DYN_CLASSES];
extern char *AssertFlagsP;
#    endif  /* _KERNEL */
#  endif  /* DEFINE_DYNASSERT_GBL_VARS */
#endif /* DYNASSERTS_FULL */


/* DYNASSERTs are generally used without an assert level.  The assert
   is either on or off.  The macros are built on a platform that will
   support assert levels for those special (likely customer) cases where
   assert levels will come in handy.  But typcial programming use will
   not bother with assert levels. */

#if defined(DYNASSERTS_COMPATIBLE) || defined(DYNASSERTS_FULL)
/* For testing if the DYNASSERT is enabled for a particular class at a
   given level.  DynAssertFlags is a vector of char managed similarly to
   how TraceFlagsP is for traces.*/
#  ifdef DYNASSERTS_COMPATIBLE
     /* Initial implementation does not support dynamic control or levels */
#    define DYN_IS_ON(_cl, _lvl) 1
#  else
     /* Dynamic assert is enabled if the feature is enabled and the assert 
        level for the given class is >= that set by the user. */
#    define DYN_IS_ON(_cl, _lvl) (AssertFlagsP[(_cl)] >= (_lvl))
#  endif

/* For testing if the DYNASSERT is enabled for a particular class at all. */
#define DYN_ENABLED(_cl) DYN_IS_ON(_cl, 1)

/* The following macro set supports assert levels. */
#define DYNASSERTL(_cl, _lvl, _ex) DYNASSERTRCL(_cl, _lvl, _ex, 0, 0, 0)

#define REMOTE_DYNASSERTL(_cl, _lvl, _cc, _node, _ex) \
  do { if (DYN_IS_ON(_cl, _lvl))                      \
         REMOTE_LOGASSERT(_cc, _node, _ex); } while (0)

#ifdef __64BIT__
#define DYNASSERTRCL(_cl, _lvl, _ex, _rc, _rea, _tag) \
  do { if (DYN_IS_ON(_cl, _lvl))                      \
         LOGASSERTRC(_ex, (IntPtr)(_rc), _rea, _tag); \
       else VCWARN_ASSERT(_ex); } while (0)

#define REMOTE_DYNASSERTRCL(_cl, _lvl, _cc, _node, _ex, _rc, _rea, _tag) \
  do { if (DYN_IS_ON(_cl, _lvl))                                         \
         REMOTE_LOGASSERTRC(_cc, _node, _ex, (IntPtr)(_rc), _rea, _tag); \
  } while (0)

#else
#define DYNASSERTRCL(_cl, _lvl, _ex, _rc, _rea, _tag) \
  do { if (DYN_IS_ON(_cl, _lvl))                      \
         LOGASSERTRC(_ex, _rc, _rea, _tag);           \
       else VCWARN_ASSERT(_ex); } while (0)

#define REMOTE_DYNASSERTRCL(_cl, _lvl, _cc, _node, _ex, _rc, _rea, _tag) \
  do { if (DYN_IS_ON(_cl, _lvl))                                         \
         REMOTE_LOGASSERTRC(_cc, _node, _ex, _rc, _rea, _tag);           \
  } while (0)
#endif /* __64BIT__ */

#define DYNASSERTFL(_cl, _lvl, _ex, _str) \
  do { if (DYN_IS_ON(_cl, _lvl))          \
         LOGASSERTF(_ex, _str);           \
       else VCWARN_ASSERT(_ex); } while (0)

/* Disabling DYNASSERTS in site.mcr will allow the compiler to optimize
   away all DYNASSERTxxx code.  It will compatibly take DBGASSERTxxx code
   out also if we're in DYNASSERTS_FULL mode. */
#else  /* neither DYNASSERTS_COMPATIBLE nor DYNASSERTS_FULL */
#  define DYN_IS_ON(_cl, _lvl) 0
#  define DYN_ENABLED(_cl) 0
#  define DYNASSERTL(_cl, _lvl, _ex) VCWARN_ASSERT(_ex)
#  define REMOTE_DYNASSERTL(_cl, _lvl, _cc, _node, _ex) NOOP
#  define DYNASSERTRCL(_cl, _lvl, _ex, _rc, _rea, _tag) VCWARN_ASSERT(_ex)
#  define REMOTE_DYNASSERTRCL(_cl, _lvl, _cc, _node, _ex, _rc, _rea, _tag) NOOP
#  define DYNASSERTFL(_cl, _lvl, _ex, _str) VCWARN_ASSERT(_ex)
#endif /* DYNASSERTS_COMPATIBLE or DYNASSERTS_FULL */


/* The new macros - without levels.  These are generally used in GPFS code. */
#define DYNASSERT(_cl, _ex) DYNASSERTL(_cl, 1, _ex)

#define REMOTE_DYNASSERT(_cl, _cc, _node, _ex) \
  REMOTE_DYNASSERTL(_cl, 1, _cc, _node, _ex)

#define DYNASSERTRC(_cl, _ex, _rc, _rea, _tag) \
  DYNASSERTRCL(_cl, 1, _ex, _rc, _rea, _tag)

#define REMOTE_DYNASSERTRC(_cl, _cc, _node, _ex, _rc, _rea, _tag) \
  REMOTE_DYNASSERTRCL(_cl, 1, _cc, _node, _ex, _rc, _rea, _tag)

#define DYNASSERTF(_cl, _ex, _str) DYNASSERTFL(_cl, 1, _ex, _str)


#ifdef DYNASSERTS_FULL
/* Table of assert class names, indexed by DYN_... constants above.
   The generation of this table is controlled by the #define variable
   DEFINE_ASSERT_CLASS_NAME_TABLE, which is generally only set in the module
   that parses commands to change trace settings. */
struct AssertNameTableEntry
{
  const char *name;
  const char *desc;
};


#  ifndef _KERNEL
extern int dynassertCommand(char *args, int verify);

/* Subroutine for setting asserts given a string of assert names and values */
extern const struct AssertNameTableEntry AssertNamesP[MAX_DYN_CLASSES + 1];

#   ifdef DEFINE_ASSERT_CLASS_NAME_TABLE
const AssertNameTableEntry AssertNamesP[MAX_DYN_CLASSES + 1] =
{
  /*  0 */  { " rsvd ",     "reserved" },   // MUST BE ZERO! 
  /*  1 */  { "default",    "default class" }, // MUST BE 1!
  /*  2 */  { "afm",        "Active File Management"},
  /*  3 */  { "alloc",      "disk space allocation" },
  /*  4 */  { "allocmgr",   "allocation manager" },
  /*  5 */  { "basic",      "'basic' classes" },
  /*  6 */  { "brl",        "byte range locks" },
  /*  7 */  { "cksum",      "checksum services" },
  /*  8 */  { "cleanup",    "cleanup routines" },
  /*  9 */  { "cmd",        "TS commands" },
  /* 10 */  { "defrag",     "defragmentation" },
  /* 11 */  { "dentryexit", "daemon routine entry/exit" },
  /* 12 */  { "disk",       "physical disk I/O" },
  /* 13 */  { "disklease",  "disk lease"},
  /* 14 */  { "dmapi",      "data management" },
  /* 15 */  { "ds",         "data shipping" },
  /* 16 */  { "eventsExporter", "events exporter"},
  /* 17 */  { "errlog",     "error logging" },
  /* 18 */  { "file",       "file_operations" },
  /* 19 */  { "fs",         "file system" },
  /* 20 */  { "fsck",       "online multinode fsck" },
  /* 21 */  { "ialloc",     "inode allocation" },
  /* 22 */  { "io",         "physical I/O" },
  /* 23 */  { "kentryexit", "kernel routine entry/exit" },
  /* 24 */  { "kernel",     "kernel"},
  /* 25 */  { "klockl",     "low-level VFS locking" },
  /* 26 */  { "ksvfs",      "generic kernel VFS stuff" },
  /* 27 */  { "lock",       "interprocess locking" },
  /* 28 */  { "log",        "recovery log" },
  /* 29 */  { "malloc",     "malloc/free in shared segment" },
  /* 30 */  { "mb",         "mailbox message handling" },
  /* 31 */  { "mmpmon",     "mmpmon"},
  /* 32 */  { "mnode",      "mnode operations" },
  /* 33 */  { "msg",        "calls to routines in SharkMsg.h" },
  /* 34 */  { "mutex",      "mutexes and condition variables" },
  /* 35 */  { "nsd",        "network shared disk"},
  /* 36 */  { "pcache",     "panache" },
  /* 37 */  { "perfmon",    "performance monitors" },
  /* 38 */  { "pgalloc",    "page allocator tracing" },
  /* 39 */  { "pin",        "pinning to real memory" },
  /* 40 */  { "pit",        "parallel inode traversal" },
  /* 41 */  { "quota",      "quota management" },
  /* 42 */  { "rdma",       "rdma"},
  /* 43 */  { "sanergy",    "SANergy"},
  /* 44 */  { "scsi",       "SCSI services"},
  /* 45 */  { "sec",        "cluster security"},
  /* 46 */  { "shared",     "shared memory" },
  /* 47 */  { "smb",        "SMB Locks"},
  /* 48 */  { "sp",         "cluster management and RPCs" },
  /* 49 */  { "tasking",    "tasking system but not Thread operations" },
  /* 50 */  { "thread",     "operations in Thread class" },
  /* 51 */  { "ts",         "cluster management and RPCs" },
  /* 52 */  { "tstm",       "token manager (formerly DYN_CETM)" },
  /* 53 */  { "vbhvl",      "behaviorals" },
  /* 54 */  { "vdb",        "vdisk debugger"},
  /* 55 */  { "vdisk",      "vdisk"},
  /* 56 */  { "vhosp",      "vdisk hospital"},
  /* 57 */  { "vnode",      "vnode layer of VFS kernel support" },
  /* 58 */  { "vnop",       "concise vnop description" },
 
  /* Add new assert class names above here. */
  /* DO NOT ifdef ASSERT CLASS DEFINITIONS! */
  { 0, 0 }
};
#   endif /* of ifdef DEFINE_ASSERT_CLASS_NAME_TABLE */
#  endif /* not _KERNEL */
#endif /*  DYNASSERTS_FULL */


#endif  /* _h_Dynassert */
