/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)64       1.168.1.1  src/avs/fs/mmfs/ts/kernext/gpl-linux/cxiCache.c, mmfs, avs_rfks0, rfks01416c 4/17/14 09:54:39 */
/*
 * Cache operations
 *
 * Contents:
 *   cxiCacheInit
 *   cxiCacheExit
 *   cxiCacheLookupRoot
 *   cxiCacheLookup
 *   cxiCacheOpen
 *   cxiCacheClose
 *   cxiCacheCreate
 *   cxiCacheRemove
 *   cxiCacheLink
 *   cxiCacheSymlink
 *   cxiCacheGetattr
 *   cxiCacheSetattr
 *   cxiCacheReaddir
 *   cxiCacheRead
 *   cxiCacheWrite
 *   cxiCacheRename
 *   cxiCacheReadlink
 *   cxiCacheHomeOpen
 *   cxiCacheGetFilename
 */

#include <Shark-gpl.h>
#include <Trace.h>
#include <linux2gpfs.h>
#include <cxiSystem.h>
#include <linux/file.h>
#include <linux/nfs_fs.h>
#include <linux/nfs_mount.h>
#include <linux/fadvise.h>

typedef struct pcache_vfs_ops
{
  int type;
  int (*inode2pattr)(struct inode *inodeP, pcacheAttr_t *pattrP);
  struct inode * (*iget)(struct vfsmount *mntP, pcacheAttr_t *pattrP, int newFlag);
  void (*invalidate)(struct inode *iP);
  UInt32 (*rsize)(struct inode *iP);
  int (*close)(struct file *fP);
} pcache_vfs_ops;

static struct pcache_vfs_ops pcache_ops[];

/* Array of fs-specific iget functions to get a linux inode 
   Initialized with call to cxiCacheRegisterFs */
static struct inode *(*fs_iget[PCACHE_NUM_VFS])(struct super_block *, ...);

typedef struct pcacheVfsData_t
{
  /* next on chain of all home mounted vfs */
  struct pcacheVfsData_t *nextPcacheVfsDataP;

  /* pointer to vfs mount */
  struct vfsmount *mntP;

  /* pointer to root dentry - may be different from mnt_root */
  struct dentry *rootP;

  /* pointer to fs-specific ops */
  struct pcache_vfs_ops *opsP;
} pcacheVfsData_t;

#define PCACHE_PVP(vP)   ((pcacheVfsData_t *)(vP))
#define PCACHE_MNTP(vP)  (PCACHE_PVP(vP)->mntP)
#define PCACHE_ROOTP(vP) (PCACHE_PVP(vP)->rootP)
#define PCACHE_OPS(vP)   (PCACHE_PVP(vP)->opsP)
#define PCACHE_VFS_TYPE(vP) (PCACHE_OPS(vP)->type)
#define PCACHE_VFS_IS_GPFS(vP)  (PCACHE_VFS_TYPE(vP) == PCACHE_VFS_GPFS)

static pcacheVfsData_t pcacheVfsData = { 0 };

static void pcache_set_creds(uid_t uid, gid_t gid)
{
#if (LINUX_KERNEL_VERSION >= 2062900)
  if (!GID_EQ(current_fsgid(), MAKE_KGID(gid)) || !UID_EQ(current_fsuid(), MAKE_KUID(uid)))
  {
    struct cred *new;
    new = prepare_creds();
    if (new)
    {
      new->fsuid = MAKE_KUID(uid);
      new->fsgid = MAKE_KGID(gid);
      new->cap_effective = cap_raise_fs_set(new->cap_effective,
                                            new->cap_permitted);
      commit_creds(new);
    }
  }
#else
  current->fsuid = uid;
  current->fsgid = gid;
#if (LINUX_KERNEL_VERSION >= 2062700)
  cap_raise_fs_set(current->cap_effective, current->cap_permitted);
#else
  cap_raise(current->cap_effective, CAP_FS_MASK);
#endif /* 2062700 */
#endif /* 2062900 */
}

static void pcache_set_context(void *vfsP)
{
  struct group_info *info = CRED_GROUPS(current);
  if (PCACHE_VFS_IS_GPFS(vfsP) &&
      (!info ||
       info->ngroups == 0 ||
       !GID_EQ(GROUP_AT(info, info->ngroups-1), MAKE_KGID(PCACHE_NATIVE_GID))))
  {
    int i, rc;
    int ngroups = info ? info->ngroups : 0;
    struct group_info *gi = groups_alloc(ngroups+1);
    if (!gi) goto oom;
    for (i = 0; i < ngroups; i++)
      GROUP_AT(gi, i) = GROUP_AT(info, i);
    GROUP_AT(gi, ngroups) = MAKE_KGID(PCACHE_NATIVE_GID);
#if (LINUX_KERNEL_VERSION >= 2062900)
    {
      struct cred *new = prepare_creds();
      if (!new) goto oom;
      rc = set_groups(new, gi);
      put_group_info(gi);
      if (rc < 0)
        abort_creds(new);
      else
        commit_creds(new);
    }
#else
    rc = set_current_groups(gi);
    put_group_info(gi);
#endif
  }
  return;
oom:
  printk("pcache_set_context: malloc failure\n");
  return;
}
  
static void pcache_reset_context(void *vfsP)
{
  struct group_info *info = CRED_GROUPS(current);
  if (PCACHE_VFS_IS_GPFS(vfsP) &&
      (info &&
       info->ngroups > 0 &&
       GID_EQ(GROUP_AT(info, info->ngroups-1), MAKE_KGID(PCACHE_NATIVE_GID))))
  {
   int i, rc;
    struct group_info *gi = groups_alloc(info->ngroups-1);
    if (!gi) goto oom;
    for (i = 0; i < info->ngroups-1; i++)
      GROUP_AT(gi, i) = GROUP_AT(info, i);
#if (LINUX_KERNEL_VERSION >= 2062900)
    {
      struct cred *new;
      new = prepare_creds();
      if (!new) goto oom;
      rc = set_groups(new, gi);
      put_group_info(gi);
      if (rc < 0)
        abort_creds(new);
      else
        commit_creds(new);
    }
#else
    rc = set_current_groups(gi);
    put_group_info(gi);
#endif
  }
  return;
oom:
  printk("pcache_set_context: malloc failure\n");
  return;
}
  
/* Fill up home file attributes from the inode */
static int inode2pattr(void *vfsP, struct inode *inodeP, pcacheAttr_t *pattrP)
{
  cxiFH_t *fhP = &pattrP->pa_fh;
  __u32 *fh = (__u32 *)fhP->data;
  int rc;
 
  rc = PCACHE_OPS(vfsP)->inode2pattr(inodeP, pattrP);
  if (rc != 0)
    goto out;
  
  pattrP->pa_mode = inodeP->i_mode;
  pattrP->pa_uid = FROM_KUID(inodeP->i_uid);
  pattrP->pa_gid = FROM_KGID(inodeP->i_gid);
  pattrP->pa_rdev = cxiDevToDev32(inodeP->i_rdev);
  pattrP->pa_nlink = inodeP->i_nlink;
  pattrP->pa_size = inodeP->i_size;
  CXITIME_FROM_INODETIME(pattrP->pa_mtime, inodeP->i_mtime);
  CXITIME_FROM_INODETIME(pattrP->pa_ctime, inodeP->i_ctime);
  CXITIME_FROM_INODETIME(pattrP->pa_atime, inodeP->i_atime);

  TRACE13(TRACE_PCACHE, 9, TRCID_CACHE_INODE2PATTR,
          "inode2pattr: inode 0x%lX mode 0%o uid %d gid %d rdev %d inode %lld "
          "size %d mtime %ld.%ld ctime %ld.%ld atime.nsec %lx fhsize %d",
          inodeP, inodeP->i_mode, FROM_KUID(inodeP->i_uid), FROM_KGID(inodeP->i_gid), inodeP->i_rdev,
          pattrP->pa_ino, inodeP->i_size, inodeP->i_mtime.tv_sec,
          inodeP->i_mtime.tv_nsec,inodeP->i_ctime.tv_sec,
          inodeP->i_ctime.tv_nsec, pattrP->pa_atime.tv_nsec, fhP->size);
out:
  TRACE10(TRACE_PCACHE, 9, TRCID_CACHE_INODE2PATTR_2,
         "inode2pattr: fh: size %u %08x %08x %08x %08x %08x %08x %08x %08x %08x",
         fhP->size, fh[0], fh[1], fh[2], fh[3], fh[4], fh[5], fh[6], fh[7], fh[8]);
  return rc;
}

/* Revalidate a dentry that is found in the cache. Depending on the
   intent specified in the nameidata, this may cause the file to be
   opened at the server */
static inline struct dentry *
cache_revalidate(struct dentry *dP, struct nameidata *ndP)
{
  int rc = 0;

  if (dP->d_op && dP->d_op->d_revalidate)
  {
    rc = DOP_REVALIDATE(dP, ndP);
    if (rc > 0)
      goto out;
    if (rc == 0)
    {
      if (!d_invalidate(dP))
      {
        dput(dP);
        dP = NULL;
      }
    }
    else
    {
      dput(dP);
      dP = ERR_PTR(rc);
    }
  }
 out:
  TRACE2(TRACE_PCACHE, 4, TRCID_CACHE_REVALIDATE,
         "cache_revalidate exit: dP 0x%lX rc %d",
         dP, rc);
  return dP;
}

static struct file *
cache_alloc_file(struct vfsmount *mntP, struct dentry *dP, struct nameidata *ndP)
{
  struct file *fileP;
  
#if defined(USE_ALLOC_FILE)
  struct path path;
  
  path.mnt = mntP;
  path.dentry = dP;
  fileP = alloc_file(&path, INTENT_OPEN_FLAGS(ndP), NULL);
  if (fileP)
  {
    /* Clear out fields initialized by alloc_file since we want
       lookup to fill them in */
    fileP->f_dentry = NULL;
    fileP->f_mapping = NULL;
    fileP->f_mode = 0;
    fileP->f_op = NULL;
  }
#else
  fileP = get_empty_filp();
#endif
  return fileP;
}

/* Lookup a dentry given its name and the inode of the parent directory.
   Returns with a hold on the dentry.  This is similar to Linux's generic
   do_lookup() but that is not exported for use by external modules */
static struct dentry *
cache_lookup(struct vfsmount *mntP, struct dentry *ddP, const char *nameP, struct nameidata *ndP, int create)
{
  struct dentry *dP = NULL;
  struct inode *dirP = ddP->d_inode;
  struct file *fileP = NULL;
  struct qstr name;
  int code = 0;
  struct nameidata nd = { };

  TRACE3(TRACE_PCACHE, 4, TRCID_CACHE_LOOKUP_ENTRY,
         "cache_lookup enter: ddP 0x%lX  ddP->d_parent 0x%lX name %s",
          ddP, ddP?ddP->d_parent:0, nameP);

  /* If the name starts with a '/', we are probably looking up '.' */
  while (*nameP == '/')
    nameP++;
 
  /* avoid sending the lookup request on .. to home, as it can get the
   * E_LOOP and lookup will fail */
  if(*nameP == '.' && *(nameP+1) == '.' && !*(nameP+2))
  {
    dP = cache_revalidate(dget(ddP->d_parent), &nd);
    code = 7;
    if (dP == NULL)
    {
      dP = ERR_PTR(-ESTALE);
      code = 71;
    }
    goto out;
  }

  if (!*nameP || (*nameP == '.' && !*(nameP+1)))
  {
    nd.flags = LOOKUP_REVAL; /* forces revalidation */
    dP = cache_revalidate(dget(ddP), &nd);
    code = 1;
    if (dP == NULL)
    {
      /* If we fail to revalidate the root, return ESTALE */
      dP = ERR_PTR(-ESTALE);
      code = 11;
    }
    goto out;
  }

  name.name = nameP;
  name.len = strlen(nameP);
  name.hash = full_name_hash(name.name, name.len);

  INODE_LOCK(dirP);

  /* Check if the dentry exists in the dcache */
  dP = d_lookup(ddP, &name);
  if (dP != NULL)
  {
    INODE_UNLOCK(dirP);
    TRACE2(TRACE_PCACHE, 4, TRCID_CACHE_LOOKUP_1,
          "cache_lookup: found cached dentry 0x%lX for %s",
          dP, nameP);
    /* home only supports OPEN on regular files */
    if (dP->d_inode != NULL &&
        S_ISREG(dP->d_inode->i_mode) &&
        (ndP->flags & LOOKUP_OPEN))
    {
      fileP = cache_alloc_file(mntP, dP, ndP);
      if (fileP == NULL)
      {
        dput(dP);
        dP = ERR_PTR(-ENFILE); /* FIX: ENOENT instead? */
        code = 2;
        goto out;
      }
      SET_INTENT_OPEN_FILE(ndP, fileP);
      dP = cache_revalidate(dP, ndP);
    }
    else
    {
      nd.flags = LOOKUP_REVAL; /* forces revalidation */
      dP = cache_revalidate(dP, &nd);
    }
    if (dP == NULL)
      INODE_LOCK(dirP);
  }

  /* Check again for dP since revalidate may have invalidated it */
  if (dP == NULL)
  {
    /* Redo the cached lookup since the dentry may have been 
       created while we were waiting for the dir mutex */
    dP = d_lookup(ddP, &name);
    if (dP != NULL)
      INODE_UNLOCK(dirP);
  }

  if (dP == NULL)
  {
    struct dentry *newP = NULL;

    newP = d_alloc(ddP, &name);
    if (newP == NULL)
    {
      dP = ERR_PTR(-ENOMEM);
      code = 4;
      goto out;
    }
    newP->d_op = ddP->d_op;
    /* Allocate a file struct for open */
    if (ndP->flags & LOOKUP_OPEN)
    {
      fileP = cache_alloc_file(mntP, ddP, ndP);
      if (fileP == NULL)
      {
        dput(newP);
        dP = ERR_PTR(-ENFILE);  /* FIX: ENOENT instead? */
        code = 3;
        goto out;
      }
      SET_INTENT_OPEN_FILE(ndP, fileP);
    }

    DBGASSERT(dirP->i_op->lookup != NULL);
    dP = INODE_OP_LOOKUP(dirP, newP, ndP);
    if (dP)
    {
      dput(newP);
#if (LINUX_KERNEL_VERSION >= 2061800)
      if (!IS_ERR(dP) && dP->d_inode != NULL && S_ISDIR(dP->d_inode->i_mode))
      {
        /* If the lookup returns an "anonymous" (no-name) dentry, we need
           to re-fill it with the name being looked up. This happens for
           directory dentries that are created from attribute lookup using
           d_alloc_anon */
        struct dentry *resP;

        TRACE5(TRACE_PCACHE, 3, TRCID_CACHE_LOOKUP_ANON,
               "cache_lookup: found existing anon dentry 0x%lX flags 0x%X inode 0x%lX name %s for %s",
               dP, dP->d_flags, dP->d_inode, dP->d_name.name, nameP);
        /* We need to allocate a new dentry with the name being looked up,
           because i_op->lookup trashed it */
        newP = d_alloc(ddP, &name);
        if (newP == NULL)
        {
          dput(dP);
          dP = ERR_PTR(-ENOMEM);
          code = 6;
          goto out;
        }
        newP->d_op = ddP->d_op;

        /* Need to put a hold on the inode before calling d_materialise_unique 
           which will do an iput */
        igrab(dP->d_inode);
        resP = d_materialise_unique(newP, dP->d_inode); 
        if (resP)
          dput(newP);
        else
          resP = newP;
        TRACE3(TRACE_PCACHE, 3, TRCID_CACHE_LOOKUP_ANON2,
               "cache_lookup: repaired into dentry 0x%lX inode 0x%lX name %s",
               resP, resP->d_inode, resP->d_name.name);
        dput(dP);
        dP = resP;
      }
#endif
    }
    else
      dP = newP;
    INODE_UNLOCK(dirP);
  }

  /* Is this a negative dentry? */
  if (!create && !IS_ERR(dP) && dP->d_inode == NULL)
  {
#if defined(USE_ALLOC_FILE)
    /* Drop the write count added by alloc_file
       FIX: Is this sufficient? Ideally we'd like to do an fput() here
       but we cannot because there's no inode and fput() tries to dereference 
       it. There is no exported release function to go with alloc_file() so
       we might be leaving behind a file struct here */
    if (fileP != NULL && (INTENT_OPEN_FLAGS(ndP) & FMODE_WRITE))
    {
      file_release_write(fileP);
      mnt_drop_write(mntP);
    }
#endif
    dput(dP);
    dP = ERR_PTR(-ENOENT);
    code = 5;
  }

 out:
  TRACE5(TRACE_PCACHE, 4, TRCID_CACHE_LOOKUP,
         "cache_lookup exit: ddP 0x%lX name %s flags 0x%X ret dP 0x%lX code %d",
         ddP, nameP, ndP->flags, dP, code);
  if (fileP)
    TRACE4(TRACE_PCACHE, 6, TRCID_CACHE_LOOKUP_EXIT1,
           "cache_lookup exit: fileP 0x%lX f_dentry 0x%lX mode %d open %d",
           fileP, fileP->f_dentry, fileP->f_mode, ndP->flags & LOOKUP_OPEN ? 1 : 0);
  return dP;
}

/**
 * @dentry: the directory in which to find a name
 * @name:   a pointer to a %NAME_MAX+1 char buffer to store the name
 * @child:  the dentry for the child directory.
 *
 * calls readdir on the parent until it finds an entry with
 * the same inode number as the child, and returns that.
 */
struct getdents_callback
{
#if !defined(HAS_READDIR)
  struct dir_context ctx;
#endif
  char *nameP;
  unsigned long ino;
  int found;
  int sequence;
};

static int filldir_one(void * __bufP, const char * nameP, int len,
                       loff_t pos, u64 ino, unsigned int d_type)
{
  struct getdents_callback *bufP = __bufP;
  int result = 0;

  bufP->sequence++;
  if (bufP->ino == ino) 
  {
    memcpy(bufP->nameP, nameP, len);
    bufP->nameP[len] = '\0';
    bufP->found = 1;
    result = -1;
  }
  return result;
}

/* Do a readdir on the parent to find the matching name */
static int cache_get_name(struct vfsmount *mntP, struct dentry *dentryP,
                          char *nameP, struct dentry *childP)
{
  struct inode *dirP = dentryP->d_inode;
  int error = 0;
  struct file *fileP = NULL;
  struct getdents_callback buffer = {
#if !defined(HAS_READDIR)
    .ctx.actor = filldir_one
#endif
  };

  error = -ENOTDIR;
  if (!dirP || !S_ISDIR(dirP->i_mode))
    goto out;
  error = -EINVAL;
  DBGASSERT(dirP->i_fop != NULL);

  /* Open the directory ... */
  DENTRY_OPEN(fileP, dget(dentryP), mntP, O_RDONLY);
  if (IS_ERR(fileP))
  {
    error = PTR_ERR(fileP);
    goto out;
  }
#ifdef HAS_READDIR
  DBGASSERT(fileP->f_op->readdir != NULL);
#else
  DBGASSERT(fileP->f_op->iterate != NULL);
#endif

  buffer.nameP = nameP;
  buffer.ino = childP->d_inode->i_ino;
  buffer.found = 0;
  buffer.sequence = 0;
  while (1) 
  {
    int old_seq = buffer.sequence;
#ifdef HAS_READDIR
    error = vfs_readdir(fileP, (filldir_t)filldir_one, &buffer);
#else
    error = iterate_dir(fileP, &buffer.ctx);
#endif

    if (error < 0)
      break;

    error = 0;
    if (buffer.found)
      break;
    error = -ENOENT;
    if (old_seq == buffer.sequence)
      break;
  }
  fput(fileP);

out:
  TRACE4(TRACE_PCACHE, 4, TRCID_CACHE_GET_NAME,
         "cache_get_name exit: parent dP 0x%lX ino %ld found name %s err %d",
         dentryP, childP->d_inode->i_ino, nameP, error);
  return error;
}

/* Find a dentry associated with the specified inode.
   Must be called with a hold on the inode,
   on successful return the hold is transferred to the dentry
   on error, the hold on the inode is released
   - if parentP is given, use it to find the correct one
   - if nameP is given, use it to find the matching name */
static struct dentry *
cache_find_dentry(struct vfsmount *mntP, struct dentry *parentP,
                  struct inode *inodeP, const char *nameP)
{
  struct dentry *resP = NULL;
  struct dentry *dirP = NULL;
  int noprogress = 0;
  int err = 0;

  /* If name is specified, try to find the right dentry */
  if (nameP != NULL)
  {
    struct dentry *ldP;
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&inodeP->i_lock);
#else
    spin_lock(&dcache_lock);
#endif
    LIST_FOR_I_DENTRY(ldP, &inodeP->i_dentry, d_alias)
    {
      /* Check if the name matches */
      if (nameP && cxiMemcmp(ldP->d_name.name, nameP, ldP->d_name.len) == 0)
      {
#ifdef DCACHE_LOCK_IS_GONE
        resP = dget(ldP);
#else
        resP = dget_locked(ldP);
#endif
        if (resP != NULL)
          iput(inodeP); /* transfer the hold to dentry */
        break;
      }
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&inodeP->i_lock);
#else
    spin_unlock(&dcache_lock);
#endif
    if (resP == NULL && parentP != NULL) /* didn't find it */
    {
      struct qstr q;

      q.name = nameP;
      q.len = strlen(nameP);
      q.hash = full_name_hash(q.name, q.len);
      resP = d_alloc(parentP, &q);
      if (resP != NULL)
        d_add(resP, inodeP);
    }
  }

  if (resP == NULL)
  {
    resP = d_alloc_anon(inodeP);

    /* Return error if we couldn't get a valid dentry;
       need to release hold on inode */
    if (resP == NULL)
    {
      resP = ERR_PTR(-ENOENT);
      iput(inodeP);
    }
  }
  if (IS_ERR(resP))
    goto out;

  /* If we created an anonymous dentry, then set the d_op from the root */
  if (resP->d_op == NULL)
    resP->d_op = mntP->mnt_root->d_op;

  TRACE5(TRACE_PCACHE, 4, TRCID_CACHE_FIND_DENTRY_ANON,
         "cache_find_dentry: inode 0x%lX ino %lld "
         "found or created dentry 0x%lX name %s flags 0x%X",
         inodeP, inodeP->i_ino, resP, resP->d_name.name, resP->d_flags);

  if (S_ISDIR(resP->d_inode->i_mode) && (resP->d_flags & DCACHE_DISCONNECTED))
  {
    /* the directory is not connected, we must connect it */
    ;
  }
  else
    goto out;

  dirP = dget(resP);

  /* Note: The following code is similar in concept to find_exported_dentry
     used by exportfs */

  /* Now we need to make sure that dirP is properly connected.
   * It may already be, as the flag isn't always updated when connection
   * happens.
   * So, we walk up parent links until we find a connected directory,
   * or we run out of directories.  Then we find the parent, find
   * the name of the child in that parent, and do a lookup.
   * This should connect the child into the parent
   * We then repeat.
   */
  while ((dirP->d_flags & DCACHE_DISCONNECTED) && noprogress++ < 10)
  {
    struct dentry *pdP = dirP;

    dget(pdP);
    spin_lock(&pdP->d_lock);
    while (!IS_ROOT(pdP) && (pdP->d_parent->d_flags & DCACHE_DISCONNECTED))
    {
      struct dentry *pddP = pdP->d_parent;
      dget(pddP);
      spin_unlock(&pdP->d_lock);
      dput(pdP);
      pdP = pddP;
      spin_lock(&pdP->d_lock);
    }
    spin_unlock(&pdP->d_lock);

    if (!IS_ROOT(pdP))
    {
      /* found a connected parent */
      spin_lock(&pdP->d_lock);
      pdP->d_flags &= ~DCACHE_DISCONNECTED;
      spin_unlock(&pdP->d_lock);
      noprogress = 0;
    }
    else
    {
      /* Note: This code is intentionally duplicated pending the fix below */
      /* FIX: We really need to check here if we are at the root of the home
       * mount with something like (pdP == mntP->mnt_sb->s_root) but with
       * kernels > 2.6.18, the home superblock is shared by all mounts to a server
       * so the condition may not work
       */
      spin_lock(&pdP->d_lock);
      pdP->d_flags &= ~DCACHE_DISCONNECTED;
      spin_unlock(&pdP->d_lock);
      noprogress = 0;
    }
    dput(pdP);
  }

  if (dirP->d_flags & DCACHE_DISCONNECTED)
  {
    /* something went wrong - oh-well */
    dput(resP);
    resP = ERR_PTR(-ESTALE);
    goto out_dput;
  }

  /* if we weren't after a directory, have one more step to go */
  if (resP != dirP)
  {
    char *buf;
    struct dentry *nresP;

    buf = (char *) __get_free_page(GFP_USER);
    if (buf == NULL)
    {
      dput(resP);
      resP = ERR_PTR(-ENOMEM);
      goto out_dput;
    }

    err = cache_get_name(mntP, dirP, buf, resP);
    if (!err)
    {
      INODE_LOCK(dirP->d_inode);
      nresP = lookup_one_len(buf, dirP, strlen(buf));
      INODE_UNLOCK(dirP->d_inode);
      if (!IS_ERR(nresP))
      {
        if (nresP->d_inode)
        {
          dput(resP);
          resP = nresP;
        }
        else
          dput(nresP);
      }
    }
    free_page((unsigned long) buf);
  }

 out_dput:
  dput(dirP);
 out:
  TRACE3(TRACE_PCACHE, 9, TRCID_CACHE_FIND_DENTRY_EXIT,
         "cache_find_dentry: inode %lld name %s ret dentry 0x%lX",
         inodeP->i_ino, nameP, resP);
  return resP;
}

/* Open a file using the dentry - a file struct may have been preallocated */
static struct file *
cache_dentry_open(struct dentry *dentryP, struct vfsmount *mntP, int flags, struct file *fileP)
{
  struct inode *inodeP;
  struct file *fP = fileP;
  struct file *tmpfP;
  int err;

  if (fP == NULL)
  {
    DENTRY_OPEN(tmpfP, dentryP, mntP, flags);
    return tmpfP;
  }

  /* Fill existing file */
  fP->f_flags = flags;
  fP->f_mode = ((flags+1) & O_ACCMODE) | FMODE_LSEEK |
               FMODE_PREAD | FMODE_PWRITE;
  inodeP = dentryP->d_inode;
  DBGASSERT(inodeP != NULL);

  fP->f_mapping = inodeP->i_mapping;
  fP->f_dentry = dentryP;
#ifdef HAS_F_VFSMNT
  fP->f_vfsmnt = mntP;
#else
  fP->f_path.mnt = mntP;
#endif
  fP->f_pos = 0;

  if (fP->f_mode & FMODE_WRITE)
  {
    err = get_write_access(inodeP);
    if (err)
      goto out;
  }

  fP->f_op = fops_get(inodeP->i_fop);
  DBGASSERT(fP->f_op != NULL);
  err = fP->f_op->open(inodeP, fP);
  if (err == 0)
  {
    fP->f_flags &= ~(O_CREAT | O_EXCL | O_NOCTTY | O_TRUNC);
#if LINUX_KERNEL_VERSION >= 2061800
    file_ra_state_init(&fP->f_ra, fP->f_mapping->host->i_mapping);
#endif
    return fP;
  }

  /* Error */
  fops_put(fP->f_op);
  if (fP->f_mode & FMODE_WRITE)
    put_write_access(inodeP);
  fP->f_op = NULL;
out:
  fput(fP);
  return ERR_PTR(err);
}

/* Get home dentry from filehandle and attributes.
   name (and parent dentry) is used to find the matching dentry
   Returns with a hold on the dentry */
static struct dentry *
pcache_dget_name(void *vfsP, struct dentry *parentP,
                 const char *nameP, pcacheAttr_t *pattrP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct inode *inodeP = NULL;
  struct dentry *dentryP = ERR_PTR(-ENOENT);

  inodeP = PCACHE_OPS(vfsP)->iget(mntP, pattrP, true);
  if (!IS_ERR(inodeP))
  {
    dentryP = cache_find_dentry(mntP, parentP, inodeP, nameP);
    if (!IS_ERR(dentryP))
    {
      struct kstat stat;
      int rc = 0;
      /* We need to refresh the inode since we used a (possibly stale) fh
         to construct the dentry from it */
      VFS_GETATTR(rc, vfsP, dentryP, &stat);
      TRACE3(TRACE_PCACHE, 4, TRCID_PCACHE_VFS_GETATTR,
             "pcache_dget_name: vfs_getattr inode 0x%lX name %s ret %d",
             inodeP, dentryP->d_name.name, rc);
      if (rc != 0)
      {
        dput(dentryP);
        dentryP = ERR_PTR(rc);
      }
    }
  }
  else
    dentryP = (struct dentry *)inodeP; /* err */

  return dentryP;
}

/* Get home dentry from filehandle and attributes.
   Returns with a hold on the dentry */
static inline struct dentry *
pcache_dget(void *vfsP, pcacheAttr_t *pattrP)
{
  return pcache_dget_name(vfsP, NULL, NULL, pattrP);
}


int cxiCacheUpdateAttrs(pcacheRemoteAttr_t *rpattrP)
{
  struct nameidata nd;
  struct dentry *dp;
  int rc = 0;
  pcacheAttr_t *pattrP = &rpattrP->attr;
  __u32 *fh = (__u32 *)&pattrP->pa_fh.data;
  const unsigned char GaneshaFHVersion = 0x41; /* Fixed by Ganesha */

  if (rpattrP->fsType != PCACHE_VFS_NFS)
  {
    rc = EINVAL;
    goto out;
  }

  memset(&pattrP->pa_fh, 0, sizeof(pattrP->pa_fh));
  rc = PATH_LOOKUP(rpattrP->fileName, LOOKUP_FOLLOW | LOOKUP_DIRECTORY, &nd);
  if (rc != 0)
    goto out;

  dp = ND_PATH(nd).dentry;
  if (dp && dp->d_inode)
  {
    struct nfs_fh *fhP = NFS_FH(dp->d_inode);
    pattrP->pa_fh.size = fhP->size;
    memcpy(&pattrP->pa_fh.data, &fhP->data, fhP->size);

    // Get server supported read size
    if (pcache_ops[rpattrP->fsType].rsize)
      rpattrP->nfsReadSize = pcache_ops[rpattrP->fsType].rsize(dp->d_inode);
    else
      rpattrP->nfsReadSize = 128 * 1024; /* 128 KB */

    if (*(unsigned char*)fh == GaneshaFHVersion)
      rpattrP->nfsType = PCACHE_NFS_GANESHA;
    else
      rpattrP->nfsType = PCACHE_NFS_KNFS;
    rpattrP->inodeNum = dp->d_inode->i_ino;
  }
  else
    rc = EINVAL;
out_put:
  PATH_PUT(&nd);
  
out:
  TRACE13(TRACE_PCACHE, 9, TRCID_CACHE_GETNFSATTRS,
         "cxiCacheUpdateAttrs: rc %d, nfsReadSize %u, nfsType %s, fh: size %u %08x %08x %08x %08x %08x %08x %08x %08x %08x",
         rc, rpattrP->nfsReadSize, rpattrP->nfsType, pattrP->pa_fh.size, fh[0], fh[1], fh[2], fh[3], fh[4], fh[5], fh[6], fh[7], fh[8]);
  return rc;
}

/*
 * Cache operations
 */

int cxiCacheRegisterFs(int type, void *addrP)
{
  if (type < 0 || type >= PCACHE_NUM_VFS)
    return -EINVAL;
  fs_iget[type] = addrP;
  TRACE2(TRACE_PCACHE, 4, TRCID_CACHE_REGISTER,
         "cxiCacheRegiterFs: register addr 0x%lX for type %s",
         addrP, PcacheFsTypeToString(type));
  return 0;
}

/* Initialization routine called at mount time to establish link
   between a fileset and home vfsmount. Returns with a hold on
   the home mount so it doesn't disappear under us.*/
int cxiCacheInit(const char *mntPathP, int fsType, Boolean hold, void **vfsPP)
{
  struct nameidata nd;
  pcacheVfsData_t *vfsP = NULL;
  int rc, code = 0;

  /* Sanity check */
  if (fsType < 0 || fsType >= PCACHE_NUM_VFS)
  {
    code = 1;
    rc = -EINVAL;
    goto out;
  }
  
  rc = PATH_LOOKUP(mntPathP, LOOKUP_FOLLOW | LOOKUP_DIRECTORY, &nd);
  if (rc != 0)
  {
    code = 2;
    goto out;
  }

  /* Make sure the mount path is in the target fs */
  if (strcmp((char *)ND_PATH(nd).dentry->d_sb->s_type->name,
             PcacheFsTypeToString(fsType)) != 0)
  {
    code = 3;
    rc = -ENODEV;
    goto out_put;
  }
  
  /* Allocate a new vfs data */
  vfsP = kmalloc(sizeof(pcacheVfsData_t), GFP_KERNEL);
  if (vfsP == NULL)
    goto out_put;

  vfsP->opsP = &pcache_ops[fsType];
  vfsP->mntP = ND_PATH(nd).mnt;
  vfsP->rootP = ND_PATH(nd).dentry;

  /* Put a hold on the root */
  if (hold)
  {
    mntget(vfsP->mntP);
    dget(vfsP->rootP);
  }
  
  *vfsPP = vfsP;
  rc = 0;

out_put:
  PATH_PUT(&nd);

out:
  TRACE5(TRACE_PCACHE, 4, TRCID_CXICACHE_INIT,
         "cxiCacheInit: pathP %s remote type %s vfsP 0x%lX rc %d code %d",
         mntPathP, PcacheFsTypeToString(fsType), *vfsPP, rc, code);
  return -rc;
}

/* Exit routine called at umount time to release the hold on
   the home mount established at GPFS mount time. Also closes the special file */
int cxiCacheExit(void *vfsP, void *fileP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *rootP = PCACHE_ROOTP(vfsP);

  DBGASSERT(mntP != NULL);

  if (fileP != NULL)
    cxiCacheClose(vfsP, fileP, NULL);
  dput(rootP);
  mntput(mntP);
  kfree(vfsP);
  TRACE2(TRACE_PCACHE, 4, TRCID_CXICACHE_EXIT,
         "cxiCacheExit: vfsP 0x%lX xattr fileP 0x%lX", vfsP, fileP);
  return 0;
}

/* Return remote fh and attrs of root */
int
cxiCacheLookupRoot(void *vfsP, pcacheAttr_t *pattrP)
{
  struct dentry *rootP = PCACHE_ROOTP(vfsP);
  int rc = -ENOENT;

  if (rootP && rootP->d_inode)
    rc = inode2pattr(vfsP, rootP->d_inode, pattrP);

  TRACE4(TRACE_PCACHE, 4, TRCID_CXICACHE_LOOKUP_ROOT,
         "cxiCacheLookupRoot: returned ino %lld mntP 0x%lX rootP 0x%lX rc %d",
         pattrP->pa_ino, PCACHE_MNTP(vfsP), rootP, rc);
  return -rc;
}

/* Do lookup on a name, given the parent fh and attrs,
   and if successful, return resulting fh and attrs */
int
cxiCacheLookup(void *vfsP, pcacheAttr_t *pattrP, char *nameP, pcacheAttr_t *cpattrP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *ddP = NULL, *dP = NULL;
  struct nameidata nd = {};
  int rc = 0;

  pcache_set_context(vfsP);
  /* Get dentry of parent */
  if (*nameP == '/')
    ddP = dget(PCACHE_ROOTP(vfsP));
  else
    ddP = pcache_dget(vfsP, pattrP);
  if (IS_ERR(ddP))
  {
    rc = PTR_ERR(ddP);
    goto out;
  }

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = ddP;  /* We already have a hold on ddP */

  DBGASSERTRC(S_ISDIR(ddP->d_inode->i_mode), ddP->d_inode->i_ino, 0, 0);
  if (!S_ISDIR(ddP->d_inode->i_mode))
  {
    TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_LOOKUP_BADDIR,
           "cxiCacheLookup: pattrP 0x%lX points to a non-dir ddP 0x%lX "
           "inode 0x%lX ino %lld mode 0%o",
           pattrP, ddP, ddP->d_inode, ddP->d_inode->i_ino, ddP->d_inode->i_mode);
    rc = -EBADF;
    goto out_dput;
  }

  dP = cache_lookup(mntP, ddP, nameP, &nd, 0);
  if (IS_ERR(dP))
  {
    rc = PTR_ERR(dP);
    goto out_dput;
  }

  rc = inode2pattr(vfsP, dP->d_inode, cpattrP);
  dput(dP);

 out_dput:
  PATH_PUT(&nd);
 out:
  pcache_reset_context(vfsP);
  TRACE4(TRACE_PCACHE, 4, TRCID_CXICACHE_LOOKUP,
         "cxiCacheLookup: name %s, dir %lld, returned ino %lld rc %d",
          nameP, (pattrP != NULL)?pattrP->pa_ino:-1LL, (cpattrP != NULL)?cpattrP->pa_ino:-1LL, rc);
  return -rc;
}

/* Open a file identified by name, fh and attrs (including parent's) */
int
cxiCacheOpen(void *vfsP, pcacheAttr_t *parentPattrP, const char *nameP, int flags,
             int mode,  uid_t uid, gid_t gid,  
             pcacheAttr_t *pattrP, void **filePP, loff_t *fileSizeP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *ddP = NULL, *dP = NULL;
  struct nameidata nd;
  struct file *fileP = NULL;
  char *fileNameP = NULL;
  int namei_flags = 0, lookup_flags = 0, rc = 0;

  TRACE3(TRACE_PCACHE, 4, TRCID_CXICACHE_OPEN_IN,
         "cxiCacheOpen: pattrP 0x%lX name %s flags 0%o",
         parentPattrP, nameP, flags);

  /* Init return values */
  *filePP = NULL;
  *fileSizeP = 0;

  pcache_set_context(vfsP);
  if (nameP == NULL || *nameP == '\0')
  {
    dP = pcache_dget(vfsP, parentPattrP);
    if (IS_ERR(dP))
    {
      rc = PTR_ERR(dP);
      goto out;
    }
    ddP = dget(dP->d_parent);
    fileNameP = (char *)dP->d_name.name;
  }
  else
  {
    /* Lookup up the dentries from the filehandle/attributes */
    ddP = pcache_dget(vfsP, parentPattrP);
    if (IS_ERR(ddP))
    {
      rc = PTR_ERR(ddP);
      goto out;
    }
    fileNameP = (char *)nameP;
    DBGASSERTRC(S_ISDIR(ddP->d_inode->i_mode), ddP->d_inode->i_ino, 0, 0);
    if (!S_ISDIR(ddP->d_inode->i_mode))
    {
      TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_OPEN_BADDIR,
             "cxiCacheOpen: pattrP 0x%lX points to a non-dir ddP 0x%lX "
             "inode 0x%lX ino %lld mode 0%o",
             parentPattrP, ddP, ddP->d_inode, ddP->d_inode->i_ino, ddP->d_inode->i_mode);
      rc = -EBADF;
      dput(ddP);
      goto out;
    }
  }

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = ddP; /* We already have a hold on ddP */

  /* We always want to support large files */
  flags |= O_LARGEFILE;

  /* Map open flags to open intent flags */
  namei_flags = flags;
  if ((namei_flags+1) & O_ACCMODE)
    namei_flags++;

  lookup_flags = LOOKUP_FOLLOW;
  if (flags & O_NOFOLLOW)
    lookup_flags &= ~LOOKUP_FOLLOW;
  if (flags & O_DIRECTORY)
    lookup_flags |= LOOKUP_DIRECTORY;

  nd.flags = lookup_flags | LOOKUP_OPEN;

  SET_OPEN_INTENT(&nd, namei_flags, mode);
  /* Note: file struct below will be allocated by cache_lookup, because
     we do not want to do a open revalidate for directories */
  SET_INTENT_OPEN_FILE(&nd, NULL);

  if (dP == NULL)
  {
    dP = cache_lookup(mntP, ddP, fileNameP, &nd, (flags & O_CREAT));
    if (IS_ERR(dP))
    {
      rc = PTR_ERR(dP);
      goto out_release;
    }
    /* Don't allow open on symlinks */
    if (dP->d_inode != NULL && S_ISLNK(dP->d_inode->i_mode))
    {
      rc = -EINVAL;
      goto out_dput;
    }
    if ((dP->d_inode == NULL) && (flags & O_CREAT))
    {
      /* if we are here then O_CREAT flag is already set */
      INODE_LOCK(ddP->d_inode);
      rc = VFS_CREATE(ddP->d_inode, dP, mode, nd);
      INODE_UNLOCK(ddP->d_inode);
      if (rc != 0)
      {
        rc = -ENOENT;
        goto out_dput; 
      }
      if (uid != 0 || gid != 0)
      {
        /* FIX: This check needs to be updated when we create as non-root user.
           If we run in the context of the caller, then no attribute update is required.
           Until then, if a non-root user performed the original create, we need
           to update remote uid/gid */
        struct iattr iattr;
        iattr.ia_valid = ATTR_UID|ATTR_GID;
        iattr.ia_uid = MAKE_KUID(uid);
        iattr.ia_gid = MAKE_KGID(gid);
        rc = dP->d_inode->i_op->setattr(dP, &iattr);
      }
    }
  }

  /* Initialize fileP if it hasn't already been done */
#ifdef LOOKUP_INTENT
  fileP = nd.intent.open.file;
#endif
  if (fileP == NULL || fileP->f_dentry == NULL)
  {
    fileP = cache_dentry_open(dget(dP), mntget(mntP), flags, fileP);
    if (IS_ERR(fileP))
    {
      rc = PTR_ERR(fileP);
      goto out_dput;
    }
  }

  *filePP = fileP;
  *fileSizeP = dP->d_inode->i_size;
  if (pattrP != NULL)
    rc = inode2pattr(vfsP, dP->d_inode, pattrP);

 out_dput:
  dput(dP);
 out_release:
  PATH_PUT(&nd);
 out:
  pcache_reset_context(vfsP);
  TRACE7(TRACE_PCACHE, 4, TRCID_CXICACHE_OPEN,
         "cxiCacheOpen: parent ino %lld name %s flags 0x%X ret ino %lld fileP 0x%lX size %lld rc %d",
         parentPattrP->pa_ino, (fileNameP != NULL) ? fileNameP : "NULL", flags,
         (rc == 0 && dP && dP->d_inode) ? dP->d_inode->i_ino : -1LL, fileP, *fileSizeP, rc);
  return -rc;
}

static int
pcache_create(struct vfsmount *mntP, struct inode *diP, struct dentry *dP,
              struct nameidata *ndP, int mode, uid_t uid, gid_t gid, cxiDev_t rdev)
{
  dev_t dev;
  int rc;
  
  switch (mode & S_IFMT)
  {
    case S_IFREG:
      /* Need to pass in a valid nameidata since the underlying VFS may look at the flags */
      ndP->flags = LOOKUP_CREATE;
      SET_OPEN_INTENT(ndP, FMODE_READ | FMODE_WRITE | O_CREAT | O_EXCL, mode);
      rc = VFS_CREATE(diP, dP, mode, *ndP);
      break;

    case S_IFDIR:
      rc = VFS_MKDIR(mntP, diP, dP, mode);
      break;

    case S_IFCHR:
    case S_IFBLK:
    case S_IFIFO:
    case S_IFSOCK:
      dev = ((rdev>>16)<<20)|(rdev & 0xFFFF);
      rc = VFS_MKNOD(mntP, diP, dP, mode, dev);
      break;

    default:
      rc = -EINVAL;
  }
  TRACE7(TRACE_PCACHE, 6, TRCID_CXICACHE_CREATE1,
         "pcache_create: mode 0%o dir %ld uid %d gid %d (running as %d %d) rc %d",
         mode, diP->i_ino, uid, gid, FROM_KUID(CRED(current, fsuid)), FROM_KGID(CRED(current, fsgid)), rc);
  return rc;
}

/* Create a new object and return its fh and attrs */
int
cxiCacheCreate(void *vfsP, pcacheAttr_t *parentPattrP, char *nameP, int mode,
               uid_t uid, gid_t gid, cxiDev_t rdev, pcacheAttr_t *cpattrP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *ddP = NULL, *dP = NULL;
  struct qstr name;
  struct nameidata nd = {};
  int umask;
  int code = 0, rc = 0;

  pcache_set_context(vfsP);
  /* Get dentry of parent */
  ddP = pcache_dget(vfsP, parentPattrP);
  if (IS_ERR(ddP))
  {
    rc = PTR_ERR(ddP);
    code = 1;
    goto out;
  }

  name.name = nameP;
  name.len = strlen(nameP);
  name.hash = full_name_hash(name.name, name.len);

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = ddP; /* We already have a hold on ddP */

  if (!S_ISDIR(ddP->d_inode->i_mode))
  {
    rc = -ENOTDIR;
    code = 2;
    goto out_put;
  }

  dP = cache_lookup(mntP, ddP, nameP, &nd, 1);
  if (IS_ERR(dP))
  {
    code = 3;
    rc = PTR_ERR(dP);
    goto out_put;
  }

  if (dP->d_inode != NULL)
  {
    if (cpattrP)
      rc = inode2pattr(vfsP, dP->d_inode, cpattrP);
    dput(dP);
    code = 4;
    rc = -EEXIST;
    goto out_put;
  }

  INODE_LOCK(ddP->d_inode);
  
  /* Use umask of 0 instead of process umask */
  umask = current->fs->umask;
  current->fs->umask = 0;

  /* Try with user credentials first */
  pcache_set_creds(uid, gid);
  rc = pcache_create(mntP, ddP->d_inode, dP, &nd, mode, uid, gid, rdev);
  pcache_set_creds(0, 0);
  if (rc == -EACCES)
  {
    /* Retry as root */
    rc = pcache_create(mntP, ddP->d_inode, dP, &nd, mode, uid, gid, rdev);
    if (uid != 0 || gid != 0)
    {
      /* If we run in the context of the caller, then no attribute update is required.
         Otherwise, if a non-root user performed the original create, we need
         to update remote uid/gid */
      struct iattr iattr;
      iattr.ia_valid = ATTR_UID|ATTR_GID;
      iattr.ia_uid = MAKE_KUID(uid);
      iattr.ia_gid = MAKE_KGID(gid);
      rc = dP->d_inode->i_op->setattr(dP, &iattr);
    }
  }

  /* Reset umask */
  current->fs->umask = umask;

  INODE_UNLOCK(ddP->d_inode);
  
  if (rc == 0 && cpattrP)
    rc = inode2pattr(vfsP, dP->d_inode, cpattrP);
  dput(dP);

out_put:
  PATH_PUT(&nd);

out:
  pcache_reset_context(vfsP);
  TRACE7(TRACE_PCACHE, 4, TRCID_CXICACHE_CREATE,
         "cxiCacheCreate: name %s mode 0%o dir %ld uid %d gid %d rc %d code %d",
         nameP, mode, parentPattrP->pa_ino, uid, gid, rc, code);
  return -rc;
}

/* Remove an object, given its name and parent's fh and attrs */
int
cxiCacheRemove(void *vfsP, pcacheAttr_t *parentPattrP, char *nameP, int type)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *ddP = NULL;
  struct dentry *dP = NULL;
  struct nameidata nd = {};
  int code = 0, rc = 0;

  pcache_set_context(vfsP);
  /* Get dentry of parent */
  ddP = pcache_dget(vfsP, parentPattrP);
  if (IS_ERR(ddP))
  {
    rc = PTR_ERR(ddP);
    code = 1;
    goto out;
  }

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = ddP; /* We already have a hold on ddP */

  DBGASSERTRC(S_ISDIR(ddP->d_inode->i_mode), ddP->d_inode->i_ino, 0, 0);
  if (!S_ISDIR(ddP->d_inode->i_mode))
  {
    TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_REMOVE_BADDIR,
           "cxiCacheRemove: pattrP 0x%lX points to a non-dir ddP 0x%lX "
           "inode 0x%lX ino %lld mode 0%o",
           parentPattrP, ddP, ddP->d_inode, ddP->d_inode->i_ino, ddP->d_inode->i_mode);
    rc = -EBADF;
    goto out_dput;
  }

  dP = cache_lookup(mntP, ddP, nameP, &nd, 0);
  if (IS_ERR(dP))
  {
    rc = PTR_ERR(dP);
    code = 2;
    goto out_dput;
  }

  INODE_LOCK(ddP->d_inode);
  switch (type)
  {
    case S_IFREG:
    case S_IFCHR:
    case S_IFBLK:
    case S_IFIFO:
    case S_IFSOCK:
      rc = VFS_UNLINK(mntP, ddP->d_inode, dP);
      break;

    case S_IFDIR:
      rc = VFS_RMDIR(mntP, ddP->d_inode, dP);
      break;

    default:
      code = 3;
      rc = -EINVAL;
  }
  INODE_UNLOCK(ddP->d_inode);
  dput(dP);

 out_dput:
  PATH_PUT(&nd);

 out:
  pcache_reset_context(vfsP);
  TRACE5(TRACE_PCACHE, 4, TRCID_CXICACHE_REMOVE,
         "cxiCacheRemove: name %s type 0x%X dir %lld, rc %d code %d",
         nameP, type, parentPattrP->pa_ino, rc, code);
  return -rc;
}

/* Create a hard link to an object identified by fh and attrs */
int
cxiCacheLink(void *vfsP, pcacheAttr_t *parentPattrP, pcacheAttr_t *pattrP, char *nameP)
{
  void *mntP = PCACHE_MNTP(vfsP);
  struct dentry *ddP = NULL, *sdP = NULL, *tdP = NULL;
  struct nameidata nd = {};
  int code = 0, rc = 0;

  pcache_set_context(vfsP);
  /* Get dentry of parent and source */
  ddP = pcache_dget(vfsP, parentPattrP);
  if (IS_ERR(ddP))
  {
    rc = PTR_ERR(ddP);
    code = 1;
    goto out;
  }

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = ddP; /* We already have a hold on ddP */

  DBGASSERTRC(S_ISDIR(ddP->d_inode->i_mode), ddP->d_inode->i_ino, 0, 0);
  if (!S_ISDIR(ddP->d_inode->i_mode))
  {
    TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_LINK_BADDIR,
           "cxiCacheLink: pattrP 0x%lX points to a non-dir ddP 0x%lX "
           "inode 0x%lX ino %lld mode 0%o",
           parentPattrP, ddP, ddP->d_inode, ddP->d_inode->i_ino, ddP->d_inode->i_mode);
    rc = -EBADF;
    goto out_ddput;
  }

  /* We don't have the source name, so can't call pcache_dget_name */
  sdP = pcache_dget(vfsP, pattrP);
  if (IS_ERR(sdP))
  {
    rc = PTR_ERR(sdP);
    code = 2;
    goto out_ddput;
  }

  tdP = cache_lookup(mntP, ddP, nameP, &nd, 1);
  if (IS_ERR(tdP))
  {
    rc = PTR_ERR(tdP);
    code = 3;
    goto out_sdput;
  }

  INODE_LOCK(ddP->d_inode);
  rc = VFS_LINK(mntP, sdP, ddP->d_inode, tdP);
  INODE_UNLOCK(ddP->d_inode);
  if (rc == 0)
    rc = inode2pattr(vfsP, sdP->d_inode, pattrP);
  dput(tdP);

out_sdput:
  dput(sdP);
out_ddput:
  PATH_PUT(&nd);

out:
  pcache_reset_context(vfsP);
  TRACE4(TRACE_PCACHE, 4, TRCID_CXICACHE_LINK,
         "cxiCacheLink: ino %ld, new name %s, rc %d code %d",
         pattrP->pa_ino, nameP, rc, code);
  return -rc;
}

/* Create a symlink to an object identified by name and parent's fh and attrs */
int
cxiCacheSymlink(void *vfsP, pcacheAttr_t *parentPattrP,
                char *targetNameP, char *newNameP, pcacheAttr_t *cpattrP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *ddP = NULL;
  struct dentry *dP = NULL;
  struct nameidata nd = {};
  int umask;
  int code = 0, rc = 0;

  pcache_set_context(vfsP);
  /* Get dentry of parent */
  ddP = pcache_dget(vfsP, parentPattrP);
  if (IS_ERR(ddP))
  {
    rc = PTR_ERR(ddP);
    code = 1;
    goto out;
  }

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = ddP; /* We already have a hold on ddP */

  DBGASSERTRC(S_ISDIR(ddP->d_inode->i_mode), ddP->d_inode->i_ino, 0, 0);
  if (!S_ISDIR(ddP->d_inode->i_mode))
  {
    TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_SYMLINK_BADDIR,
           "cxiCacheSymlink: pattrP 0x%lX points to a non-dir ddP 0x%lX "
           "inode 0x%lX ino %lld mode 0%o",
           parentPattrP, ddP, ddP->d_inode, ddP->d_inode->i_ino, ddP->d_inode->i_mode);
    rc = -EBADF;
    goto out_put;
  }

  if (newNameP == NULL || *newNameP == '\0')
    /* We don't have the source name, so can't call cache_lookup */
    dP = pcache_dget(vfsP, cpattrP);
  else
    dP = cache_lookup(mntP, ddP, newNameP, &nd, 1);

  if (IS_ERR(dP))
  {
    rc = PTR_ERR(dP);
    code = 2;
    goto out_put;
  }

  INODE_LOCK(ddP->d_inode);
  /* Use umask of 0 instead of process umask */
  umask = current->fs->umask;
  current->fs->umask = 0;
  rc = VFS_SYMLINK(mntP, ddP->d_inode, dP, targetNameP);
  /* Reset umask */
  current->fs->umask = umask;
  INODE_UNLOCK(ddP->d_inode);

  if (rc == 0 && cpattrP != NULL)
    rc = inode2pattr(vfsP, dP->d_inode, cpattrP);
  dput(dP);

out_put:
  PATH_PUT(&nd);

out:
  pcache_reset_context(vfsP);
  TRACE5(TRACE_PCACHE, 4, TRCID_CXICACHE_SYMLINK,
         "cxiCacheSymlink: dir %lld target name %s new name %s, rc %d code %d",
         parentPattrP->pa_ino, targetNameP, newNameP, rc, code);
  return -rc;
}

/* Get attributes on an object identified by fh and attrs
   Use a flag to optionally force an update of attributes from the
   remove server */
int
cxiCacheGetattr(void *vfsP, pcacheAttr_t *pattrP, Boolean forceFlag)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct inode *iP = NULL;
  int rc = 0;
  struct kstat stat;
  struct dentry dentry;
  const char *fsname = mntP->mnt_sb->s_type->name;

  pcache_set_context(vfsP);
  /* Get inode of object */
  iP = PCACHE_OPS(vfsP)->iget(mntP, pattrP, true);
  if (IS_ERR(iP))
  {
    rc = PTR_ERR(iP);
    goto out;
  }

  /* Force attr invalid to refresh from server */
  if (forceFlag && PCACHE_OPS(vfsP)->invalidate)
    PCACHE_OPS(vfsP)->invalidate(iP);

  /* Sufficient to just fill in inode for dentry */
  dentry.d_inode = iP;
  VFS_GETATTR(rc, mntP, &dentry, &stat);
  if (rc == 0)
    rc = inode2pattr(vfsP, iP, pattrP);
  iput(iP);

 out:
  pcache_reset_context(vfsP);
  TRACE3(TRACE_VNODE, 4, TRCID_CACHE_GETATTR,
         "cxiCacheGetattr: ino %lld force %d rc %d",
         pattrP->pa_ino, forceFlag, rc);
  return -rc;
}

/* Set attributes on an object identified by fh and attrs.
 * Refresh pattrP with latest attributes. */
int
cxiCacheSetattr(void *vfsP, pcacheAttr_t *pattrP, int attrset, long arg1, long arg2)
{
  struct dentry *dP = NULL;
  struct iattr iattr;
  struct timespec now = current_fs_time(PCACHE_MNTP(vfsP)->mnt_sb);
  int rc = 0;

  pcache_set_context(vfsP);
  /* Get inode of object */
  dP = pcache_dget(vfsP, pattrP);
  if (IS_ERR(dP))
  {
    rc = PTR_ERR(dP);
    goto out;
  }
  TRACE6(TRACE_PCACHE, 4, TRCID_CXICACHE_SETATTR_0,
         "cxiCacheSetattr: ino %lld attrset 0x%X mode 0%o uid %d gid %d size %ld",
         pattrP->pa_ino, attrset, pattrP->pa_mode,
         pattrP->pa_uid, pattrP->pa_gid, pattrP->pa_size);

  if (attrset == (ATTR_MODE | ATTR_SIZE | ATTR_UID | ATTR_GID))
  {
    /* called during recovery - pick attributes from attr */
    iattr.ia_mode = pattrP->pa_mode;
    iattr.ia_size = pattrP->pa_size;
    iattr.ia_uid = MAKE_KUID(pattrP->pa_uid);
    iattr.ia_gid = MAKE_KGID(pattrP->pa_gid);
  }
  else if (attrset == (ATTR_MODE | ATTR_SIZE | ATTR_UID | ATTR_GID | ATTR_MTIME_SET))
  {
    /* called during recovery - pick attributes from attr */
    iattr.ia_mode = pattrP->pa_mode;
    iattr.ia_size = pattrP->pa_size;
    iattr.ia_uid = MAKE_KUID(pattrP->pa_uid);
    iattr.ia_gid = MAKE_KGID(pattrP->pa_gid);
    CXITIME_TO_INODETIME(pattrP->pa_mtime, iattr.ia_mtime);
  }
  else if (attrset & ATTR_MODE)
    iattr.ia_mode = (umode_t)arg1;
  else if (attrset & ATTR_SIZE)
    iattr.ia_size = (loff_t)arg1;
  else if (attrset & (ATTR_UID|ATTR_GID))
  {
    if (attrset & ATTR_UID)
      iattr.ia_uid = MAKE_KUID((uid_t)arg1);
    if (iattr.ia_valid & ATTR_GID)
      iattr.ia_gid = MAKE_KGID((gid_t)arg2);
  }
  else if (attrset & ATTR_MTIME_SET)
  {
    CXITIME_TO_INODETIME(pattrP->pa_mtime, iattr.ia_mtime);
  }
  else if (attrset & ATTR_MTIME)
    iattr.ia_mtime = now;

  if (attrset & ATTR_ATIME)
    iattr.ia_atime = now;

  /* Make sure we are not setting size for a directory */
  if (S_ISDIR(pattrP->pa_mode))
    attrset &= ~ATTR_SIZE;

  /* FIX: we really need to call notify_change() here but it requires a
     valid dentry, else dnotify_parent() will oops the kernel. For now,
     it appears sufficient to just call setattr instead */
  iattr.ia_valid = attrset;
  rc = dP->d_inode->i_op->setattr(dP, &iattr);
  if (rc == 0)
    /* Update attributes that _may_ be returned on a successful setattr (such as nfsv4) */
    rc = inode2pattr(vfsP, dP->d_inode, pattrP);

  dput(dP);

 out:
  pcache_reset_context(vfsP);
  TRACE5(TRACE_PCACHE, 4, TRCID_CXICACHE_SETATTR,
         "cxiCacheSetattr: ino %lld attrset %d args 0x%lX 0x%lX rc %d",
         pattrP->pa_ino, attrset, arg1, arg2, rc);
  return -rc;
}

/* Close a file */
int
cxiCacheClose(void *vfsP, void *fP, pcacheAttr_t *pattrP)
{
  struct file *fileP = (struct file *)fP;
  struct inode *inodeP = fileP->f_dentry->d_inode;
  int rc = 0;

  if (!igrab(inodeP))
    DBGASSERT(0);

  pcache_set_context(vfsP);
  if (PCACHE_OPS(vfsP)->close)
    rc = PCACHE_OPS(vfsP)->close(fileP);
  else
    rc = filp_close(fileP, current->files);
  pcache_reset_context(vfsP);

  if (rc == 0 && pattrP != NULL)
    rc = inode2pattr(vfsP, inodeP, pattrP);

  iput(inodeP);

  TRACE3(TRACE_PCACHE, 4, TRCID_CXICACHE_CLOSE,
         "cxiCacheClose: fP 0x%lX name %s, rc %d",
         fileP, (fileP->f_dentry) ? (char *)fileP->f_dentry->d_name.name : "null", rc);
  return -rc;
}

/* Perform READDIR operation on a dir */
int
cxiCacheReaddir(void *vfsP, void *fP, void *fnP, void *argP)
{
  struct file *fileP = (struct file *)fP;
  int rc;

  pcache_set_context(vfsP);
#ifdef HAS_READDIR
  rc = vfs_readdir(fileP, fnP, argP);
#endif
  pcache_reset_context(vfsP);
  TRACE5(TRACE_PCACHE, 4, TRCID_CXICACHE_READDIR,
         "cxiCacheReaddir: fP 0x%lX name %s flags 0%o mode %d rc %d",
         fileP, fileP->f_dentry->d_name.name, fileP->f_flags, fileP->f_mode, rc);
  return -rc;
}

/* Read a file (already open) starting at offsetP */
int cxiCacheRead(void *vfsP, void *fP, char *bufP, size_t bufSize,
                 offset_t *offsetP, ssize_t *bytesRead, Boolean isUserBuf)
{
  struct file *fileP = (struct file *)fP;
  ssize_t rc = 0;
  int err = 0;

  DBGASSERT(fileP != NULL);
  *bytesRead = 0;

  pcache_set_context(vfsP);
  if (isUserBuf)
    rc = vfs_read(fileP, (char __user *)bufP, bufSize, offsetP);
  else
    rc = kernel_read(fileP, *offsetP, bufP, bufSize);
  pcache_reset_context(vfsP);

  if (rc > 0)
  {
    *offsetP += rc;
    *bytesRead = rc;
    fileP->f_pos = *offsetP;
  }
  else
    err = -rc;

  TRACE8(TRACE_PCACHE, 4, TRCID_CXICACHE_READ,
         "cxiCacheRead: fileP 0x%lX ino %lld flags 0%o mode %d offset %lld desired %lld read %lld rc %d",
         fileP, fileP->f_dentry->d_inode->i_ino, fileP->f_flags,
         fileP->f_mode, *offsetP, bufSize, *bytesRead, err);
  return err;
}

/* Write to a file (already opened) starting at offsetP
   Return updated attributes */
int cxiCacheWrite(void *vfsP, void *fP, char *bufP, size_t bufSize,
                  offset_t *offsetP, ssize_t *bytesWritten, Boolean isUserBuf)
{
  struct file *fileP = (struct file *)fP;
  mm_segment_t old_fs;
  loff_t pos = *offsetP;
  ssize_t rc = 0;
  int err = 0;

  DBGASSERT(fP != NULL);

  pcache_set_context(vfsP);
  if (isUserBuf)
    rc = vfs_write(fileP, (void __user *)bufP, bufSize, &pos);
  else
  {
    old_fs = get_fs();
    set_fs(get_ds());
    /* The cast to a user pointer is valid due to the set_fs() */
    rc = vfs_write(fileP, (void __user *)bufP, bufSize, &pos);
    set_fs(old_fs);
  }
  pcache_reset_context(vfsP);

  *bytesWritten = 0;
  if (rc > 0)
  {
    *offsetP += rc;
    *bytesWritten = rc;
    fileP->f_pos = pos;
  }
  else
    err = -rc;

  TRACE8(TRACE_PCACHE, 4, TRCID_CACHE_CXIWRITE,
         "cxiCacheWrite: fileP 0x%lX ino %lld flags 0%o mode %d offset %lld "
         "desired %lld written %lld rc %d",
         fileP, fileP->f_dentry->d_inode->i_ino, fileP->f_flags,
         fileP->f_mode, *offsetP, bufSize, *bytesWritten, err);
  return err;
}

/* Rename a file, given names, fh's and attrs */
int
cxiCacheRename(void *vfsP, pcacheAttr_t *sDirPattrP, pcacheAttr_t *sPattrP, char *sNameP,
               pcacheAttr_t *tDirPattrP, pcacheAttr_t *tPattrP, char *tNameP)
{
  struct vfsmount *mntP = PCACHE_MNTP(vfsP);
  struct dentry *sdP = NULL, *sddP = NULL, *tdP = NULL, *tddP = NULL, *trap;
  struct nameidata nd = {};
  int rc = 0, code = 0;

  pcache_set_context(vfsP);
  sddP = pcache_dget(vfsP, sDirPattrP);
  if (IS_ERR(sddP))
  {
    rc = PTR_ERR(sddP);
    code = 1;
    goto out;
  }

  ND_PATH(nd).mnt = mntget(mntP);
  ND_PATH(nd).dentry = sddP; 

  DBGASSERTRC(S_ISDIR(sddP->d_inode->i_mode), sddP->d_inode->i_ino, 0, 0);
  if (!S_ISDIR(sddP->d_inode->i_mode))
  {
    TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_RENAME_BADDIR,
           "cxiCacheRename: pattrP 0x%lX points to a non-dir ddP 0x%lX "
           "inode 0x%lX ino %lld mode 0%o",
           sDirPattrP, sddP, sddP->d_inode, sddP->d_inode->i_ino, sddP->d_inode->i_mode);
    rc = -EBADF;
    goto out_sddput;
  }

  sdP = cache_lookup(mntP, sddP, sNameP, &nd, 0);
  if (IS_ERR(sdP))
  {
    rc = PTR_ERR(sdP);
    code = 3;
    goto out_sddput;
  }
  DBGASSERT(sddP == sdP->d_parent);

  if (tDirPattrP != NULL)
  {
    tddP = pcache_dget(vfsP, tDirPattrP);
    if (IS_ERR(tddP))
    {
      rc = PTR_ERR(tddP);
      code = 2;
      goto out_sdput;
    }
    ND_PATH(nd).dentry = tddP;
    DBGASSERTRC(S_ISDIR(tddP->d_inode->i_mode), tddP->d_inode->i_ino, 0, 0);
    if (!S_ISDIR(tddP->d_inode->i_mode))
    {
      TRACE5(TRACE_PCACHE, 1, TRCID_CXICACHE_RENAME_BADDIR2,
             "cxiCacheRename: pattrP 0x%lX points to a non-dir tddP 0x%lX "
             "inode 0x%lX ino %lld mode 0%o",
             tDirPattrP, tddP, tddP->d_inode, tddP->d_inode->i_ino, tddP->d_inode->i_mode);
      rc = -EBADF;
      goto out_tddput;
    }
  }
  else
    tddP = sddP;

  tdP = cache_lookup(mntP, tddP, tNameP, &nd, 1);
  if (IS_ERR(tdP))
  {
    code = 6;
    rc = PTR_ERR(tdP);
    goto out_tddput;
  }

  /* Make sure deadlock protective ordering */
  trap = lock_rename(sddP, tddP);

  if (trap == sdP)
  {
    unlock_rename(sddP, tddP);
    goto out_tddput;
  }
  rc = VFS_RENAME(mntP, sddP->d_inode, sdP, tddP->d_inode, tdP);

  unlock_rename(sddP, tddP);

  /* Hack: there is a problem with renames of directories where
     the target dir exists and the dentry name is not inline.
     A subsequent lookup finds the dentry by name although it should
     have been unhashed. Until this problem is found, clear the name
     so it's not found by a subsequent lookup */
  if (rc == 0 && tPattrP != NULL && S_ISDIR(sdP->d_inode->i_mode) &&
      sdP->d_name.len >= DNAME_INLINE_LEN_MIN)
    cxiMemcpy((void *)tdP->d_name.name, (void *)sdP->d_name.name, tdP->d_name.len);

  dput(tdP);

out_tddput:
  if (tddP && tDirPattrP != NULL)
    dput(sddP);
out_sdput:
  dput(sdP);
out_sddput:
  PATH_PUT(&nd);

out:
  pcache_reset_context(vfsP);
  TRACE6(TRACE_PCACHE, 4, TRCID_CXICACHE_RENAME,
         "cxiCacheRename: source %s target %s srcdir %lld tgtdir %lld, rc %d code %d",
         sNameP, tNameP, sDirPattrP->pa_ino, (tDirPattrP != NULL) ? tDirPattrP->pa_ino : -1LL,
         rc, code);
  return -rc;
}

/* Perform READLINK operation given the attributes and target name */
int
cxiCacheReadlink(void *vfsP, pcacheAttr_t *pattrP, char *targetP)
{
  struct dentry *dentryP = NULL;
  struct nameidata nd = {};
  mm_segment_t oldfs;
  char *linkP = (char *) __get_free_page(GFP_USER);
  int len = 0, rc = 0;

  if (linkP == NULL)
  {
    rc = -ENOMEM;
    goto out;
  }

  pcache_set_context(vfsP);
  dentryP = pcache_dget(vfsP, pattrP);
  if (IS_ERR(dentryP))
  {
    rc = PTR_ERR(dentryP);
    goto out_free;
  }

  oldfs = get_fs(); set_fs(KERNEL_DS);
  len = dentryP->d_inode->i_op->readlink(dentryP, linkP, PAGE_SIZE);
  set_fs(oldfs);

  if (len < 0)
    rc = len;
  else if (len > CXI_PATH_MAX)
    /* FIX: we don't support symlinks > CXI_PATH_MAX */
    rc = -ENAMETOOLONG;
  else
  {
    strncpy(targetP, linkP, len);
    targetP[len] = '\0';
    rc = 0;
  }
  dput(dentryP);

 out_free:
  free_page((unsigned long)linkP);
 out:
  pcache_reset_context(vfsP);
  TRACE3(TRACE_PCACHE, 4, TRCID_CXICACHE_READLINK,
         "cxiCacheReadLink: targetP %s rc %d len %d", targetP, rc, len);
  return -rc;
}

/*
 * Other helper routines 
 */

/* Get parent inode and file name used at open time from struct file */
int cxiCacheOpenState(void *dP, cxiNode_t **cnP, char *nameP)
{
  struct inode *inodeP = NULL;
  struct dentry *dentryP = dP;
  int rc = -ENOENT;

  if (dentryP == NULL)
    goto out;

  if (IS_ROOT(dentryP))
  {
    /* Make sure this is a directory for which we can return . as the name
       The caller can do an OPEN on "." with itself as the parent */
    if (dentryP->d_inode != NULL && !S_ISDIR(dentryP->d_inode->i_mode))
      goto out;
    *nameP = '.';
    *((char *)nameP+1) = '\0';
  }
  else
  {
    char *dnameP = (char *)dentryP->d_name.name;
    if (dnameP == NULL || *dnameP == '\0' || dentryP->d_parent == NULL)
      goto out;
    cxiStrcpy(nameP, dnameP);
  }

  inodeP = (void *)dentryP->d_parent->d_inode;
  if (inodeP == NULL)
    goto out;

  *cnP = VP_TO_CNP(inodeP);
  rc = 0;

out:
  TRACE3(TRACE_PCACHE, 4, TRCID_CXICACHE_OPEN_EXIT,
         "cxiCacheOpenState: dentryP 0x%lX name %s rc %d", dentryP, nameP, rc);
  return -rc;
}

/* Obtain the number of blocks and file size for a given inode.
   Also return fs read size */
int
cxiDataSize(void *vfsP, pcacheAttr_t *pattrP,
                 UInt64 *dataSizeP, UInt64 *fileSizeP, UInt32 *readSizeP)
{
  struct inode *iP = NULL;
  int rc = 0;

  pcache_set_context(vfsP);
  if (PCACHE_OPS(vfsP)->rsize)
    *readSizeP = PCACHE_OPS(vfsP)->rsize(PCACHE_ROOTP(vfsP)->d_inode);
  else
    *readSizeP = 1024 * 1024 *1024; /* 1MB */

  if (pattrP == NULL)
    goto out;

  /* Get inode of object */
  iP = PCACHE_OPS(vfsP)->iget(PCACHE_MNTP(vfsP), pattrP, false);
  if (IS_ERR(iP))
  {
    rc = PTR_ERR(iP);
    goto out;
  }

  /* Number of block is for blocks that are 512 bytes in size */
  *dataSizeP = iP->i_blocks * 512; /* GET_INODE_BLOCKSIZE(iP);*/
  *fileSizeP = iP->i_size;

  TRACE6(TRACE_VNODE, 3, TRCID_SET_DATASIZE,
         "cxiDataSize: ino %lld blksize 0x%X blocks %d dsize %llu fsize %llu rsize %u",
         iP->i_ino, GET_INODE_BLOCKSIZE(iP), iP->i_blocks,
         *dataSizeP, *fileSizeP, *readSizeP);
  iput(iP);

 out:
  pcache_reset_context(vfsP);
  return -rc;
}

/* Open a file over NFS given its parent attributes and name
   and return a file descriptor (that can be used in user space to
   do regular fs operations). The caller must call close(fd).
   mntPathP points to the root of the NFS mount */
int
cxiCacheOpenByAttr(void *vfsP, pcacheAttr_t *pattrP, const char *nameP, int flags, int *fdP)
{
  struct file *fileP = NULL;
  loff_t fileSize = 0;
  int fd = get_unused_fd();
  int rc = 0, code = 0;

  if (fd < 0)
  {
    rc = fd;
    code = 1;
    goto out;
  }

  rc = cxiCacheOpen(vfsP, pattrP, nameP, flags, 0, 0, 0, 
                    NULL, (void *)&fileP, &fileSize);
  if (rc != 0)
  {
    code = 3;
    goto out;
  }

  /* fsnotify_open(fileP->f_dentry); */
  fd_install(fd, fileP);
  *fdP = fd;

out:
  TRACE6(TRACE_PCACHE, 4, TRCID_CACHE_OPEN_BY_ATTR,
         "cxiCacheOpenByAttr: parent ino %lld name %s flags %d "
         "fd %d code %d rc %d",
         pattrP->pa_ino, nameP, flags, fd, code, rc);
  return rc;
}

int
cxiCacheFadvise(void* fP, int advice, loff_t len)
{
  int rc = 0;
  struct file *fileP = (struct file *)fP;
  struct address_space *mappingP = fileP->f_mapping;
  struct backing_dev_info *bdiP = NULL;
  loff_t endbyte = 0, offset = 0;
  pgoff_t start_index = 0, end_index = 0;
  unsigned long nrpages = 0;

  if (!fileP)
  {
    rc = -EBADF;
    goto out;
  }

  if (S_ISFIFO(fileP->f_dentry->d_inode->i_mode))
  {
    rc = -ESPIPE;
    goto out;
  }

  if (!mappingP)
  {
    rc = -EINVAL;
    goto out;
  }

  /* len == 0 means "as much as possible" */
  endbyte = offset + len;
  if (!len || endbyte < len)
	  endbyte = -1;
  else
	  endbyte--;

  bdiP = mappingP->backing_dev_info;

  switch(advice)
  {
  case POSIX_FADV_SEQUENTIAL:
    fileP->f_ra.ra_pages = bdiP->ra_pages * 2;
#if LINUX_KERNEL_VERSION >= 2063200
    spin_lock(&fileP->f_lock);
    fileP->f_mode &= ~FMODE_RANDOM;
    spin_unlock(&fileP->f_lock);
#endif
    break;
#if LINUX_KERNEL_VERSION >= 2061800
  case POSIX_FADV_DONTNEED:
    if (!bdi_write_congested(mappingP->backing_dev_info))
      filemap_flush(mappingP);
 
    /* First and last FULL page! */
    start_index = (offset + (PAGE_CACHE_SIZE-1)) >> PAGE_CACHE_SHIFT;
    end_index = (endbyte >> PAGE_CACHE_SHIFT);
 
    if (end_index >= start_index)
      invalidate_mapping_pages(mappingP, start_index, end_index);
    break;
#endif
#if LINUX_KERNEL_VERSION >= 2063200
  case POSIX_FADV_WILLNEED:
/*
    start_index = offset >> PAGE_CACHE_SHIFT;
    end_index = endbyte >> PAGE_CACHE_SHIFT;
    nrpages = end_index - start_index + 1;
    if (!nrpages)
      nrpages = ~0UL;
    rc = force_page_cache_readahead(mappingP, fileP, start_index, nrpages);
*/
    page_cache_sync_readahead(mappingP, &fileP->f_ra, fileP, offset, len);

    if (rc > 0)
      rc = 0;
    break;
#endif
  default:
    rc = -EINVAL;
  }

out:
  TRACE4(TRACE_PCACHE, 6, TRCID_CACHE_FADVISE,
         "cxiCacheFadvise: fp 0x%X advice %d len %lld rc %d",
         fP, advice, len, rc);
  return -rc;
}

/********************* NFS *******************/
#if LINUX_KERNEL_VERSION < 2063000
/* Mapping of S_IF* to NFS types */
static UInt32 cache_ftypes[] = 
{
        NFNON,  NFFIFO, NFCHR, NFNON,
        NFDIR,  NFNON,  NFBLK, NFNON,
        NFREG,  NFNON,  NFLNK, NFNON,
        NFSOCK, NFNON,  NFLNK, NFNON,
};
#endif

static inline void pcache_gpfs_invalidate(struct inode *iP)
{
  cxiInvalidateAttr((cxiNode_t *)VP_TO_CNP(iP), CXI_IC_ATTR);
}

static inline void pcache_nfs_invalidate(struct inode *iP)
{
  NFS_CACHE_VALIDITY_FLAGS(iP) |= NFS_INO_INVALID_ATTR;
}

static UInt32 pcache_nfs_rsize(struct inode *iP)
{
  return NFS_SERVER(iP)->rsize;
}

static int pcache_gpfs_close(struct file *fileP)
{
   int rc = 0;

   /* If we know the file was opened in read-only mode or DIO for write,
     there is no need to flush on close */
   if ((fileP->f_flags & O_DIRECT) || !(fileP->f_flags & O_WRONLY))
     return filp_close(fileP, current->files);

   /* for GPFS backend, we need to flush the data to disk otherwise
      a failure can cause inmemory data to be lost at home resulting
      in data mismatch between cache and home.  This is not a issue
      for NFS v3 due to it performing stable write at close time. */
   rc = VFS_FSYNC(fileP);
   TRACE1(TRACE_PCACHE, 4, TRCID_PCACHE_GPFS_CLOSE,
          "pcache_gpfs_close: vfs_fsync rc %d\n", rc);

   return filp_close(fileP, current->files);
}
static int pcache_nfs_close(struct file *fileP)
{
  /* If we know the file was opened in read-only mode or DIO for write,
     there is no need to flush on close. Turn off NFS_INO_INVALID_ATTR bit
     and read_cache_jiffies values on inode so that clinet will not try to
     revalidate with home (see nfs_revalidate_inode in NFS).
     Not only is this unnecessary but can block if the home is disconnected */
  if ((fileP->f_flags & O_DIRECT) || !(fileP->f_flags & O_WRONLY))
  {
    struct inode *inodeP = fileP->f_dentry->d_inode;
    NFS_I(inodeP)->cache_validity &= ~NFS_INO_INVALID_ATTR;
    NFS_I(inodeP)->read_cache_jiffies = jiffies;
    TRACE1(TRACE_PCACHE, 6, TRCID_PCACHE_NFS_CLOSE,
          "pcache_nfs_close resetting cache_validity and read_cache_jiffies"
          " for file 0x%llp", fileP);
  }

  return filp_close(fileP, current->files);
}

/* Copy NFS filehandle; identical to nfs_copy_fh which isn't present on all kernels */
static inline void
nfs_cache_copy_fh(struct nfs_fh *targetP, const struct nfs_fh *sourceP)
{
  targetP->size = sourceP->size;
  memcpy(targetP->data, sourceP->data, sourceP->size);
}

/* Compare two NFS filehandles */
static inline int
nfs_cache_compare_fh(const struct nfs_fh *a, const struct nfs_fh *b)
{
  return a->size != b->size || cxiMemcmp(a->data, b->data, a->size) != 0;
}

/* Convert pcache attr to NFS fattr */
static void
nfs_pattr2fattr(struct super_block *sbP, pcacheAttr_t *pattrP, struct nfs_fattr *fattrP)
{
  u32 time[2];

#if LINUX_KERNEL_VERSION < 2063000
  fattrP->type = cache_ftypes[(pattrP->pa_mode & S_IFMT) >> 12];
  DBGASSERT(fattrP->type != NFNON);
#endif
  fattrP->valid = NFS_ATTR_FATTR | NFS_ATTR_FATTR_V3;
  if (NFS_PROTO(sbP->s_root->d_inode)->version == 4)
    fattrP->valid |= NFS_ATTR_FATTR_V4;
  fattrP->nlink = pattrP->pa_nlink;
  /* FIX: There are cases where we are called for a file that's locally deleted
     (for example to replay a remove). In these cases nlink will be 0 but
     NFS will complain, so we set it to 1 */
  if (fattrP->nlink == 0)
  {
    fattrP->nlink = 1;
  }
  fattrP->fileid = (u64)pattrP->pa_ino;
  fattrP->mode = pattrP->pa_mode;
  fattrP->size = pattrP->pa_size;
#ifdef HAS_NFS_SUBMOUNTS
  /* We don't store server-provided fsid in GPFS, so use the one from the NFS sb */
  memcpy(&NFS_FATTR_FSID(fattrP), &NFS_SB(sbP)->fsid, sizeof(NFS_SB(sbP)->fsid));
  fattrP->time_start = 0;
#else
  NFS_FATTR_FSID(fattrP).major = NFS_FATTR_FSID(fattrP).minor = 0; /* unused */
#endif
  fattrP->rdev = ((pattrP->pa_rdev>>16)<<20)|(pattrP->pa_rdev & 0xFFFF);
  //CXITIME_TO_INODETIME(pattrP->pa_atime, fattrP->atime);
  CXITIME_TO_INODETIME(pattrP->pa_mtime, fattrP->mtime);
  CXITIME_TO_INODETIME(pattrP->pa_ctime, fattrP->ctime);
  time[0] = (u32)pattrP->pa_ctime.tv_sec;
  time[1] = (u32)pattrP->pa_ctime.tv_nsec;
  memcpy(&fattrP->change_attr, &time, sizeof(u64));
  fattrP->uid = MAKE_KUID(pattrP->pa_uid);
  fattrP->gid = MAKE_KGID(pattrP->pa_gid);
  //fattrP->du.nfs3.used = (u64)pattrP->pa_blocks << 9;
}

static int pcache_nfs_inode2pattr(struct inode *inodeP, pcacheAttr_t *pattrP)
{
  struct nfs_inode *nfsiP = NULL;
  cxiFH_t *fhP = &pattrP->pa_fh;

  nfsiP = NFS_I(inodeP);
  pattrP->pa_ino = (cxiInoSys_t)nfsiP->fileid;
  nfs_cache_copy_fh((void *)fhP, NFS_FH(inodeP));
  return 0;
}

struct nfs_find_desc
{
  cxiIno64_t ino;
  struct nfs_fh *fhP;
};
  
static int
nfs_find_inode(struct inode *inodeP, void *opaqueP)
{
  struct nfs_find_desc *descP = (struct nfs_find_desc *)opaqueP;
  struct nfs_fh *fhP = descP->fhP;
  cxiIno64_t ino = descP->ino;
  
  if (inodeP->i_ino != ino ||
      nfs_cache_compare_fh(NFS_FH(inodeP), fhP) ||
      is_bad_inode(inodeP) ||
      NFS_STALE(inodeP))
    return 0;
  return 1;
}
  
/* Get NFS inode from filehandle and attributes
   Returns with a hold on the inode */
static struct inode *
pcache_nfs_iget(struct vfsmount *mntP, pcacheAttr_t *pattrP, int getNew)
{
  struct nfs_fh *fhP = (struct nfs_fh *)&pattrP->pa_fh;
  struct nfs_fattr fattr;
  struct inode *inodeP = ERR_PTR(-ENOENT);
  __u32 *fh = (__u32 *)fhP->data;
  struct nfs_find_desc desc = 
  {
    .fhP = fhP,
    .ino = pattrP->pa_ino
  };

  DBGASSERT(fs_iget[PCACHE_VFS_NFS] != NULL);
  if (fhP->size == 0)
    goto out;

  /* We don't want to call nfs_iget() directly here before checking if the inode
     is in the cache. If we do, a cached inode with (valid) attributes will
     be updated with the ones we are passing to nfs_iget(). We only want to use
     the local cached attributes to help construct a new inode. So we check first
     if there is a cached inode. If we find one, we return it directly - it will
     be revalidated later */
  inodeP = ilookup5(mntP->mnt_sb, desc.ino, nfs_find_inode, &desc);
  if (inodeP == NULL && getNew)
  {
    nfs_pattr2fattr(mntP->mnt_sb, pattrP, &fattr);
    inodeP = fs_iget[PCACHE_VFS_NFS](mntP->mnt_sb, fhP, &fattr);
  }
  /* When given inode is another mount point at Home,
     Home side NFS server can return different FSID for the given inodeP.
     In this case, i_fop for the inodeP can be NULL. */
  if (inodeP == NULL)
    inodeP = ERR_PTR(-ENOENT);
  else if(inodeP->i_fop == NULL)
  {
    iput(inodeP);
    inodeP = ERR_PTR(-ENOENT);
  }

 out:
  TRACE3(TRACE_PCACHE, 4, TRCID_NFS_IGET,
         "nfs_iget: inode %lld, fh size %d, inodeP 0x%lX",
         pattrP->pa_ino, fhP->size, inodeP);
  TRACE10(TRACE_PCACHE, 9, TRCID_NFS_IGET_FH,
         "nfs_iget: fh: size %u %08x %08x %08x %08x %08x %08x %08x %08x %08x",
         fhP->size, fh[0], fh[1], fh[2], fh[3], fh[4], fh[5], fh[6], fh[7], fh[8]);
  return inodeP;
}

/********************* EXT3 *******************/
static inline void
ext3_cache_copy_fh(struct nfs_fh *targetP, unsigned long ino)
{
  targetP->size = sizeof(UInt64);
  memcpy(targetP->data, &ino, sizeof(unsigned long));
}

static int pcache_ext3_inode2pattr(struct inode *inodeP, pcacheAttr_t *pattrP)
{
  cxiFH_t *fhP = &pattrP->pa_fh;
  pattrP->pa_ino = inodeP->i_ino;
  ext3_cache_copy_fh((void *)fhP, pattrP->pa_ino);
  return 0;
}

static struct inode *
pcache_ext3_iget(struct vfsmount *mntP, pcacheAttr_t *pattrP, int getNew)
{
  struct inode *inodeP = ERR_PTR(-ENOENT);

  inodeP = fs_iget[PCACHE_VFS_EXT3](mntP->mnt_sb, pattrP->pa_ino);
  TRACE3(TRACE_PCACHE, 4, TRCID_EXT3_IGET,
         "ext3_iget: mntP 0x%lX inode %lld inodeP 0x%lX",
         mntP, pattrP->pa_ino, inodeP);
  return inodeP;
}

/********************* GPFS *******************/
static int pcache_gpfs_inode2pattr(struct inode *inodeP, pcacheAttr_t *pattrP)
{
  cxiFH_t *fhP = &pattrP->pa_fh;
  int rc;

  pattrP->pa_ino = inodeP->i_ino;
  rc = gpfs_ops.gpfsEncodePcacheFH(VP_TO_PVP(inodeP), VP_TO_CNP(inodeP), fhP);
  return rc;
}

static struct inode *
pcache_gpfs_iget(struct vfsmount *mntP, pcacheAttr_t *pattrP, int getNew)
{
  struct gpfsVfsData_t *privVfsP = (struct gpfsVfsData_t *) mntP->mnt_sb->s_fs_info;
  struct inode *inodeP;
  int rc;

  rc = gpfs_ops.gpfsDecodePcacheFH(privVfsP, &pattrP->pa_fh, (void **)&inodeP);
  if (rc != 0)
    inodeP = (struct inode *)ERR_PTR(-rc);

  TRACE3(TRACE_PCACHE, 4, TRCID_GPFS_IGET,
         "gpfs_iget: mntP 0x%lX inode %lld inodeP 0x%lX",
         mntP, pattrP->pa_ino, inodeP);
  return inodeP;
}

/********************* CIFS *******************/
static int pcache_cifs_inode2pattr(struct inode *inodeP, pcacheAttr_t *pattrP)
{
  /* not implemented */
  return -ENOSYS;
}

static struct inode *
pcache_cifs_iget(struct vfsmount *mntP, pcacheAttr_t *pattrP, int getNew)
{
  struct inode *inodeP = ERR_PTR(-ENOSYS);

  /* not implemented */

  return inodeP;
}

/* Array of fs-specific pcache operations */
static struct pcache_vfs_ops pcache_ops[] = {
  { 
    .type        = PCACHE_VFS_NFS,
    .inode2pattr = pcache_nfs_inode2pattr,
    .iget        = pcache_nfs_iget,
    .invalidate  = pcache_nfs_invalidate,
    .rsize       = pcache_nfs_rsize,
    .close       = pcache_nfs_close,
  },
  {
    .type        = PCACHE_VFS_CIFS,
    .inode2pattr = pcache_cifs_inode2pattr,
    .iget        = pcache_cifs_iget,
 /* .invalidate  = NULL, */
 /* .rsize       = NULL, */
 /* .close       = NULL, */
  },
  {
    .type        = PCACHE_VFS_EXT3,
    .inode2pattr = pcache_ext3_inode2pattr,
    .iget        = pcache_ext3_iget,
 /* .invalidate  = NULL, */
 /* .rsize       = NULL, */
 /* .close       = NULL, */
  },
  {
    .type        = PCACHE_VFS_GPFS,
    .inode2pattr = pcache_gpfs_inode2pattr,
    .iget        = pcache_gpfs_iget,
    .invalidate  = pcache_gpfs_invalidate,
 /* .rsize       = NULL, */
    .close       = pcache_gpfs_close, 
  },
};
