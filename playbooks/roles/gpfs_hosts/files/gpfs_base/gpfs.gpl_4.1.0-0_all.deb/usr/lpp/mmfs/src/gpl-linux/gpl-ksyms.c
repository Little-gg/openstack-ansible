/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)41       1.239  src/avs/fs/mmfs/ts/kernext/gpl-linux/gpl-ksyms.c, mmfs, avs_rfks0, rfks01416c 3/15/14 17:45:54 */
/*
 * Export symbols for module (mmfslinux)
 *
 * Define new global variables with GPFS_EXPORT_SYMBOL(varname).
 * Define new functions with GPFS_EXPORT_FUNC(varname).
 *
 * The latter will automatically spit out a generic function
 * prototype. The prototype format doesn't matter here, but
 * it is important to let the compiler know that something
 * is really a function (or else incorrect code is spewed out
 * on IA64 for the relocation entry which trips up insmod;
 * the i386 platform doesn't have this feature).
 *
 * NOTE: C++ function names / methods are generally mangled and
 * you need to use the managled symbol name. The mangled name can
 * be found by scanning the appropriate object file w/
 * "objdump --syms <file> | grep <original symbol name>", or just
 * try to load the module and shove the undefined reference names
 * in here.
 * These mangled names seem to be architecture independant so far.
 *
 */


#include <Shark-gpl.h>
#include <Logger-gpl.h>
#include <cxiTypes.h>
#include <cxiIOBuffer.h>
#include <cxiDmapi.h>
#include <cxiMmap.h>
#include <cxiSharedSeg.h>
#include <cxiVFSStats.h>
#include <cxiTSFattr.h>
#include <Trace.h>
#include <linux2gpfs.h>

#include <linux/version.h>
#include <linux/module.h>
#if LINUX_KERNEL_VERSION > 2060300
#include <linux/kernel.h>
#endif

/* ************************************************************* */
/* Various kludge definitions that are are needed with C++ code. */
/* ************************************************************* */

#ifdef MODULE

void terminate__Fv() { printk("??? terminate() called ???\n"); };

int errno = 0;

#endif /* MODULE */

#ifdef GPFS_ARCH_PPC64
int __gxx_personality_v0 = 0;
void _Unwind_Resume() { printk("??? ._Unwind_Resume called ???\n"); };
#endif

/* ********************** */
/* Export symbols section */
/* ********************** */

#if defined(MODULE) && defined(GPFS_EXPORT_KSYMS)

#if LINUX_KERNEL_VERSION > 2061000
#define GPFS_EXPORT_SYMBOL(VAR) EXPORT_SYMBOL(VAR);
#define EXPORT_SYMBOL_NOVERS(VAR) EXPORT_SYMBOL(VAR);
#define GPFS_EXPORT_FUNC(FNAME) /* extern void FNAME (); */ \
                                EXPORT_SYMBOL(FNAME);
#else
/* Use GPFS_EXPORT_SYMBOL for exporting a variable */
/* Use GPFS_EXPORT_FUNC for exporting a function */
#define GPFS_EXPORT_SYMBOL(VAR) /* extern VAR;*/ EXPORT_SYMBOL_NOVERS(VAR);
#define GPFS_EXPORT_FUNC(FNAME) /* extern void FNAME (); */ \
                                EXPORT_SYMBOL_NOVERS(FNAME);
#endif
/* Only use native EXPORT_SYMBOL_NOVERS when you need to explicitly
 * define something or initialize it here. */

/* cxiIOBuffer.C */
GPFS_EXPORT_FUNC(cxiAttachIOBuffer);
GPFS_EXPORT_FUNC(cxiDetachIOBuffer);
GPFS_EXPORT_FUNC(cxiUXfer);
GPFS_EXPORT_FUNC(cxiXmemXfer);
GPFS_EXPORT_FUNC(cxiKXfer);
#ifdef GPFS_ENC
GPFS_EXPORT_FUNC(cxiKXferXmem);
#endif /* GPFS_ENC */
GPFS_EXPORT_FUNC(cxiKZero);
GPFS_EXPORT_FUNC(cxiMapDiscontiguousRW);
GPFS_EXPORT_FUNC(cxiUnmapDiscontiguousRW);
GPFS_EXPORT_FUNC(cxiMapContiguousRO);
GPFS_EXPORT_FUNC(cxiUnmapContiguousRO);
GPFS_EXPORT_FUNC(cxiInitIORendezvous);
GPFS_EXPORT_FUNC(cxiAllocIORendezvous);
GPFS_EXPORT_FUNC(cxiFreeIORendezvous);
GPFS_EXPORT_FUNC(cxiResetIORendezvous);
GPFS_EXPORT_FUNC(cxiAwakenIORendezvous);
GPFS_EXPORT_FUNC(cxiStartIO);
GPFS_EXPORT_FUNC(cxiWaitIO);
GPFS_EXPORT_FUNC(cxiWaitIOInterruptible);
GPFS_EXPORT_FUNC(cxiCleanIO);
GPFS_EXPORT_FUNC(cxiAssignAsyncIO);
GPFS_EXPORT_FUNC(cxiSignalCompletion);
GPFS_EXPORT_FUNC(cxiPinMM);
GPFS_EXPORT_FUNC(cxiUnpinMM);
GPFS_EXPORT_FUNC(cxiAllocPageList);
GPFS_EXPORT_FUNC(cxiMapAndRecordPages);
GPFS_EXPORT_FUNC(cxiReleaseAndForgetPages);
GPFS_EXPORT_FUNC(cxiMapUserBuffer);
GPFS_EXPORT_FUNC(cxiDeallocPageList);

/* cxiVFSStats.C */
GPFS_EXPORT_SYMBOL(vfsStats);
GPFS_EXPORT_FUNC(VFSStatPoint_begin);
GPFS_EXPORT_FUNC(VFSStatPoint_end);
#ifdef KCSTRACE
GPFS_EXPORT_FUNC(cxiKcsTraceInfo);
#endif

/* cxiIOBuffer.C */
GPFS_EXPORT_FUNC(GetDiskInfoX);

/* cxiSystem.C */
/* cxiSystem.h */
GPFS_EXPORT_FUNC(cxiSetNlink);
GPFS_EXPORT_FUNC(cxiDataSize);
GPFS_EXPORT_FUNC(cxiFcntlUnblock);
GPFS_EXPORT_FUNC(cxiFcntlLock);
GPFS_EXPORT_FUNC(cxiFcntlReset);
GPFS_EXPORT_FUNC(cxiTrace);
GPFS_EXPORT_FUNC(cxiFlockToVFS);
GPFS_EXPORT_FUNC(cxiVFSToFlock);
GPFS_EXPORT_FUNC(cxiVFSCallback);
GPFS_EXPORT_FUNC(cxiCheckTypes);
GPFS_EXPORT_FUNC(cxiOpenNFS);
GPFS_EXPORT_FUNC(cxiCloseNFS);
GPFS_EXPORT_FUNC(cxiSetNFSCluster);
GPFS_EXPORT_FUNC(cxiGetNFSCluster);
GPFS_EXPORT_FUNC(cxiGetInodeNum);
GPFS_EXPORT_FUNC(cxiGetInodeNumber);
GPFS_EXPORT_FUNC(cxiGetNfsP);
GPFS_EXPORT_FUNC(cxiSetNfsP);
GPFS_EXPORT_FUNC(cxiGetCnP);
GPFS_EXPORT_FUNC(cxiGetPvP);
GPFS_EXPORT_FUNC(cxiGNPtoVP);
GPFS_EXPORT_FUNC(cxiIsGpfsVP);
GPFS_EXPORT_FUNC(cxiStartKProc);
GPFS_EXPORT_FUNC(cxiStopKProc);
GPFS_EXPORT_FUNC(cxiSleep);
GPFS_EXPORT_FUNC(cxiUsleep);
GPFS_EXPORT_FUNC(cxiUnInerruptibleSleep);
GPFS_EXPORT_FUNC(cxiPanic);
GPFS_EXPORT_FUNC(cxiGetKernelBoundary);
GPFS_EXPORT_FUNC(cxiGetKernelPageSize);
GPFS_EXPORT_FUNC(cxiGetFixedAddrs);
GPFS_EXPORT_FUNC(cxiHoldsBKL);
#ifdef SMB_LOCKS
GPFS_EXPORT_FUNC(cxiBreakOplock);
GPFS_EXPORT_FUNC(cxiInitBreakQ);
GPFS_EXPORT_FUNC(cxiTermBreakQ);
GPFS_EXPORT_FUNC(cxiSendBreakMsg);
GPFS_EXPORT_FUNC(cxiWaitForBreak);
#endif /* SMB_LOCKS */
GPFS_EXPORT_FUNC(cxiClearBit);
GPFS_EXPORT_FUNC(cxiSetBit);
GPFS_EXPORT_FUNC(cxiTestBit);
GPFS_EXPORT_FUNC(cxiRegisterCleanup);
#ifdef NFS4_ACL
GPFS_EXPORT_FUNC(cxiAuditWrite);
#endif /* NFS4_ACL */
GPFS_EXPORT_FUNC(cxiGetCred);
GPFS_EXPORT_FUNC(cxiPutCred);
#if defined(ENTRYEXIT_TRACE) || defined(KSTACK_CHECK)
GPFS_EXPORT_FUNC(cxiTraceEntry);
GPFS_EXPORT_FUNC(cxiTraceExit);
GPFS_EXPORT_FUNC(cxiTraceExitRC);
#endif  /* defined(ENTRYEXIT_TRACE) || defined(KSTACK_CHECK) */
GPFS_EXPORT_FUNC(cxiInitIntLock);
GPFS_EXPORT_FUNC(cxiTermIntLock);
GPFS_EXPORT_FUNC(cxiDisableLock);
GPFS_EXPORT_FUNC(cxiUnlockEnable);
GPFS_EXPORT_FUNC(cxiGetVinfoP);

/* cxiSystem-plat.h */
GPFS_EXPORT_FUNC(cxiIsTSPcacheThread);
GPFS_EXPORT_FUNC(cxiIsGPFSThread);
GPFS_EXPORT_FUNC(cxiIsCriticalThread);
GPFS_EXPORT_FUNC(cxiIsGpfsSwapdThread);
GPFS_EXPORT_FUNC(cxiGetThreadId);
#ifdef QOSIO
GPFS_EXPORT_FUNC(cxiGetQosId);
#endif
GPFS_EXPORT_FUNC(cxiGetFcntlOwner);
GPFS_EXPORT_FUNC(cxiUiomove);
GPFS_EXPORT_FUNC(cxiMallocPinned);
GPFS_EXPORT_FUNC(cxiFreePinned);
GPFS_EXPORT_FUNC(cxiBigMalloc);
GPFS_EXPORT_FUNC(cxiBigFree);
GPFS_EXPORT_FUNC(cxiCopyIn);
GPFS_EXPORT_FUNC(cxiCopyOut);
GPFS_EXPORT_FUNC(cxiCopyInstr);
GPFS_EXPORT_FUNC(cxiSafeGetLong);
GPFS_EXPORT_FUNC(cxiSafePutLong);
GPFS_EXPORT_FUNC(cxiSafeGetInt);
GPFS_EXPORT_FUNC(cxiSafePutInt);
#if defined(GPFS_ARCH_X86_64) || defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_S390X)
GPFS_EXPORT_FUNC(cxiIS64U);
#endif
GPFS_EXPORT_FUNC(cxiStackAddrToThreadId);
GPFS_EXPORT_FUNC(cxiThreadPtrToThreadId);
GPFS_EXPORT_FUNC(cxiIsSuperUser);
#ifdef LOCK_TRACING
GPFS_EXPORT_FUNC(cxiGetCPUId);
#endif
GPFS_EXPORT_FUNC(cxiGetMaxFileSize);
GPFS_EXPORT_FUNC(cxiSendSigThread);
GPFS_EXPORT_FUNC(cxiWaitEventHasWaiters);
GPFS_EXPORT_FUNC(cxiWaitEventInit);
GPFS_EXPORT_FUNC(cxiGetTOD);
GPFS_EXPORT_FUNC(cxiIsNFSThread);
GPFS_EXPORT_FUNC(cxiIsNFS4Thread);
GPFS_EXPORT_FUNC(cxiIsLockdThread);
GPFS_EXPORT_FUNC(cxiIsGaneshaThread);
GPFS_EXPORT_FUNC(cxiFcntlCancel);
GPFS_EXPORT_FUNC(cxiLockFile);
GPFS_EXPORT_FUNC(cxiIsKupdateThread);
GPFS_EXPORT_FUNC(cxiBlockingMutexInit);
GPFS_EXPORT_FUNC(cxiBlockingMutexAcquire);
GPFS_EXPORT_FUNC(cxiBlockingMutexAcquireFast);
GPFS_EXPORT_FUNC(cxiBlockingMutexRelease);
GPFS_EXPORT_FUNC(cxiBlockingMutexReleaseFast);
GPFS_EXPORT_FUNC(cxiBlockingMutexTerm);
GPFS_EXPORT_FUNC(cxiBlockingMutexHeldByCaller);
GPFS_EXPORT_FUNC(cxiBlockingMutexHasWaiters);
GPFS_EXPORT_FUNC(cxiYield);
GPFS_EXPORT_FUNC(cxiSetPageoutThread);
GPFS_EXPORT_FUNC(cxiClearPageoutThread);
#ifdef INSTRUMENT_LOCKS
GPFS_EXPORT_SYMBOL(BlockingMutexStatsTable);
#endif
GPFS_EXPORT_FUNC(cxiWaitEventWait);
GPFS_EXPORT_FUNC(cxiWaitEventSignal);
GPFS_EXPORT_FUNC(cxiWaitEventWakeupOne);
GPFS_EXPORT_FUNC(cxiWaitEventBroadcast);
GPFS_EXPORT_FUNC(cxiWaitEventBroadcastRC);
/* misc stuff */
GPFS_EXPORT_FUNC(getpid);
GPFS_EXPORT_FUNC(geteuid);
GPFS_EXPORT_FUNC(getuid);
GPFS_EXPORT_FUNC(cxiPruneDCacheEntry);
GPFS_EXPORT_FUNC(cxiInvalidateDCacheEntry);
GPFS_EXPORT_FUNC(cxiInvalidateNegDCacheEntry);
GPFS_EXPORT_FUNC(cxiInvalidatePerm);
GPFS_EXPORT_FUNC(cxiUpdateInode);
GPFS_EXPORT_FUNC(cxiSameInode);
GPFS_EXPORT_FUNC(cxiInitVFS);
GPFS_EXPORT_FUNC(cxiGetKernelStackSize);

/* GPFS_ENC */
#ifdef GPFS_ENC
GPFS_EXPORT_FUNC(cxiKEncryptDecrypt);
GPFS_EXPORT_FUNC(cxiInitKernelCrypto);
#endif


#ifndef KTRACE
/* misc trace stuff */
GPFS_EXPORT_SYMBOL(TraceFlagsP);
#endif

#ifdef DYNASSERTS_FULL
GPFS_EXPORT_SYMBOL(AssertFlagsP);
#endif

#ifdef SMB_LOCKS
GPFS_EXPORT_FUNC(cxiIsSambaThread);
GPFS_EXPORT_FUNC(cxiIsSambaOrLockdThread);
GPFS_EXPORT_FUNC(setSMBOpenLockControl);
GPFS_EXPORT_FUNC(setSMBOplock);
/* GPFS_EXPORT_FUNC(breakSMBOplock); */
GPFS_EXPORT_FUNC(cxiCheckOpen);
GPFS_EXPORT_FUNC(kxGetShare);
GPFS_EXPORT_FUNC(kxGetDelegation);
GPFS_EXPORT_FUNC(cxiRegisterCifsCleanup);
GPFS_EXPORT_FUNC(cxiCleanupCifsFile);
GPFS_EXPORT_FUNC(cxiGetProcessId);
#endif

#ifdef GPFS_CACHE
GPFS_EXPORT_FUNC(cxiIsPcacheLsThread);
GPFS_EXPORT_FUNC(cxiIsPcacheRmThread);
GPFS_EXPORT_FUNC(cxiIsPcacheStatThread);
GPFS_EXPORT_FUNC(cxiIsPcacheListdirtyThread);
GPFS_EXPORT_FUNC(cxiIsPcacheNativeThread);
#endif

/* ss.c */
GPFS_EXPORT_SYMBOL(ss_ioctl_op);
GPFS_EXPORT_FUNC(cxiCalcMaxSharedSegment);
GPFS_EXPORT_FUNC(cxiAllocSharedMemory);
GPFS_EXPORT_FUNC(cxiFreeSharedMemory);
GPFS_EXPORT_FUNC(cxiAttachSharedMemory);
GPFS_EXPORT_FUNC(cxiDetachSharedMemory);
GPFS_EXPORT_FUNC(cxiRecordSharedMemory);
GPFS_EXPORT_FUNC(cxiInitPtrSwizzling);

/* kx.c */
GPFS_EXPORT_FUNC(kxGetACL);
GPFS_EXPORT_FUNC(kxPutACL);
GPFS_EXPORT_FUNC(tsstat);
GPFS_EXPORT_FUNC(tsfstat);
GPFS_EXPORT_FUNC(tsfattr);
GPFS_EXPORT_FUNC(tsattr);
GPFS_EXPORT_FUNC(tsfsattr);
GPFS_EXPORT_FUNC(kxPoll);
GPFS_EXPORT_FUNC(cxiGetPrivVfsP);
GPFS_EXPORT_FUNC(kxMadvise);
GPFS_EXPORT_FUNC(kxGetThreadID);
GPFS_EXPORT_FUNC(kxUMount);
GPFS_EXPORT_FUNC(kxQuotactl);
GPFS_EXPORT_FUNC(kxWinOps);
GPFS_EXPORT_FUNC(kxSetTimes);
#ifdef FILESETMAPPING_API
GPFS_EXPORT_FUNC(kxGetFilesetId);
#endif
GPFS_EXPORT_FUNC(kxGetRealFileName);
#ifdef CLONE_FILE
GPFS_EXPORT_FUNC(kxCloneFile);
GPFS_EXPORT_FUNC(kxDeclone);
#endif
#ifdef GANESHA
GPFS_EXPORT_FUNC(kxGanesha);
GPFS_EXPORT_FUNC(cxiCheckInode);
GPFS_EXPORT_FUNC(cxiSetGaneshaPid);
GPFS_EXPORT_FUNC(cxiGetGaneshaPid);
#endif
#ifdef LIGHT_WEIGHT_EVENT
GPFS_EXPORT_FUNC(kxlweCreateSession);
GPFS_EXPORT_FUNC(kxlweDestroySession);
GPFS_EXPORT_FUNC(kxlweGetAllSession);
GPFS_EXPORT_FUNC(kxlweQuerySession);
GPFS_EXPORT_FUNC(kxlweGetEvents);
GPFS_EXPORT_FUNC(kxlweRespondEvent);
#endif
GPFS_EXPORT_FUNC(kxFtruncate);
GPFS_EXPORT_FUNC(kxAioComplete);
/* super.c */
GPFS_EXPORT_FUNC(cxiSetMountInfo);
GPFS_EXPORT_FUNC(cxiUnmount);
GPFS_EXPORT_FUNC(cxiReactivateOSNode);
GPFS_EXPORT_FUNC(cxiNewOSNode);
GPFS_EXPORT_FUNC(cxiFreeOSNode);
GPFS_EXPORT_FUNC(cxiDeleteMmap);
GPFS_EXPORT_FUNC(cxiReinitOSNode);
GPFS_EXPORT_FUNC(cxiRefOSNode);
GPFS_EXPORT_FUNC(cxiRefOSNodeNoWait);
GPFS_EXPORT_FUNC(cxiInactiveOSNode);
GPFS_EXPORT_FUNC(cxiPutOSNode);
GPFS_EXPORT_FUNC(cxiDestroyOSNode);
GPFS_EXPORT_FUNC(cxiSetOSNodeType);
GPFS_EXPORT_FUNC(cxiSetOSNode);
GPFS_EXPORT_FUNC(cxiCanUncacheOSNode);
GPFS_EXPORT_FUNC(cxiDumpOSNode);
GPFS_EXPORT_FUNC(cxiAddOSNode);
GPFS_EXPORT_FUNC(cxiPrintInode);

/* gplInit.C */
GPFS_EXPORT_SYMBOL(gpfs_ops);
GPFS_EXPORT_FUNC(gpfs_init);
GPFS_EXPORT_FUNC(cxiExportModuleStruct);
GPFS_EXPORT_FUNC(cxiIncModuleCounter);
GPFS_EXPORT_FUNC(gpfs_clean);
GPFS_EXPORT_FUNC(reset_gpfs_operations);

/* mmap.c */
GPFS_EXPORT_FUNC(IoDone);
GPFS_EXPORT_FUNC(VM_Attach);
GPFS_EXPORT_FUNC(VM_Detach);
GPFS_EXPORT_FUNC(getFilePos);
GPFS_EXPORT_FUNC(getVp);
GPFS_EXPORT_FUNC(mmapKill);
GPFS_EXPORT_FUNC(EnableMmap);
GPFS_EXPORT_FUNC(cxiMmapRegister);
GPFS_EXPORT_FUNC(cxiMmapUnregister);
GPFS_EXPORT_FUNC(cxiMmapFlush);
GPFS_EXPORT_FUNC(cxiMmapGetPage);
GPFS_EXPORT_FUNC(cxiMmapReleasePage);

#ifdef DISK_LEASE_DMS
GPFS_EXPORT_FUNC(cxiInitDMS);
GPFS_EXPORT_FUNC(cxiShutdownDMS);
GPFS_EXPORT_FUNC(cxiStartDMS);
GPFS_EXPORT_FUNC(cxiStopDMS);
#endif

#ifdef GPFS_CACHE
GPFS_EXPORT_FUNC(cxiCacheRegisterFs);
GPFS_EXPORT_FUNC(cxiCacheInit);
GPFS_EXPORT_FUNC(cxiCacheExit);
GPFS_EXPORT_FUNC(cxiCacheLookupRoot);
GPFS_EXPORT_FUNC(cxiCacheLookup);
GPFS_EXPORT_FUNC(cxiCacheOpen);
GPFS_EXPORT_FUNC(cxiCacheClose);
GPFS_EXPORT_FUNC(cxiCacheReaddir);
GPFS_EXPORT_FUNC(cxiCacheRead);
GPFS_EXPORT_FUNC(cxiCacheWrite);
GPFS_EXPORT_FUNC(cxiCacheCreate);
GPFS_EXPORT_FUNC(cxiCacheRemove);
GPFS_EXPORT_FUNC(cxiCacheRename);
GPFS_EXPORT_FUNC(cxiCacheLink);
GPFS_EXPORT_FUNC(cxiCacheSymlink);
GPFS_EXPORT_FUNC(cxiCacheReadlink);
GPFS_EXPORT_FUNC(cxiCacheGetattr);
GPFS_EXPORT_FUNC(cxiCacheSetattr);
GPFS_EXPORT_FUNC(cxiCacheOpenState);
GPFS_EXPORT_FUNC(cxiCacheOpenByAttr);
GPFS_EXPORT_FUNC(cxiCacheFadvise);
GPFS_EXPORT_FUNC(cxiCacheUpdateAttrs);
#endif

/* ****************************************************** */
/* Various kludges that are are needed with C++ code.     */
/* ****************************************************** */

/* General C++ kludges */
EXPORT_SYMBOL_NOVERS(terminate__Fv);
EXPORT_SYMBOL_NOVERS(errno);

/* PPC64 hacks */
#ifdef GPFS_ARCH_PPC64
EXPORT_SYMBOL_NOVERS(__gxx_personality_v0);
EXPORT_SYMBOL_NOVERS(_Unwind_Resume);
#endif

/* dmapi.c */
GPFS_EXPORT_FUNC(cxiPathToVfsP);
GPFS_EXPORT_FUNC(cxiPathRel);
GPFS_EXPORT_FUNC(cxiIsReadOnlyMnt);
GPFS_EXPORT_FUNC(cxiGetFileAndVp);
GPFS_EXPORT_FUNC(cxiReleaseFile);
GPFS_EXPORT_FUNC(cxiGetMountedOverOSNode);
GPFS_EXPORT_FUNC(cxiMountedOverVfsType);
GPFS_EXPORT_FUNC(cxiGetRootInode);

#ifdef UIDREMAP
GPFS_EXPORT_FUNC(cxiGetUserEnvironmentSize);
GPFS_EXPORT_FUNC(cxiGetUserEnvironment);
#endif

GPFS_EXPORT_FUNC(cxiHasMountHelper);
GPFS_EXPORT_FUNC(cxisReclaim);
GPFS_EXPORT_FUNC(cxiSetReclaim);
GPFS_EXPORT_FUNC(cxiResetReclaim);
GPFS_EXPORT_FUNC(cxisCancel);

#ifdef P_NFS4
GPFS_EXPORT_FUNC(cxiSetFH);
GPFS_EXPORT_FUNC(cxiRecallLayout);
GPFS_EXPORT_FUNC(cxiUpdateDevice);
GPFS_EXPORT_FUNC(cxiGetDeviceInfo);
GPFS_EXPORT_FUNC(cxiGetLayout);
GPFS_EXPORT_FUNC(cxiSetPNFSmds);
GPFS_EXPORT_FUNC(cxisPNFSmds);
#endif

GPFS_EXPORT_FUNC(cxiMaxIOsize);
GPFS_EXPORT_FUNC(cxiCheckThreadState);
GPFS_EXPORT_FUNC(cxiCheckProductVersion);

GPFS_EXPORT_FUNC(cxiInitInodeSecurity);
GPFS_EXPORT_FUNC(cxiInitInodeSecurityCleanup);
GPFS_EXPORT_FUNC(cxiIsLSMEnabled);

#ifdef TS_RPC_PERF
GPFS_EXPORT_FUNC(kxGetTscKhz);
#endif

#endif /* MODULE && GPFS_EXPORT_KSYMS */
