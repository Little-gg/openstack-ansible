/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
#ifndef _h_cxiAclUser
#define _h_cxiAclUser
#define __LINUX_POSIX_ACL_H
#define __LINUX_NFSACL_H
/* @(#)02       1.45  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiAclUser.h, mmfs, avs_rfks0, rfks01416c 10/30/13 13:09:43 */
/****************************************************************************
 *
 * Acl User data
 *
 * Contains Tiger Shark Access Control List definitions.
 * Some of the definitions in this file are exportable data items,
 * if POSIX compliance is claimed.
 *
 ***************************************************************************/

#include <cxiCred.h>

/* An ACL entry's permission set is defined as a set of 8 bits.
   Bits seven and eight are currently unused.
   Bits six, five, and four are delete, insert, and control access.
   Bits three, two, and one are read, write, and execute/search access.
   If any of these bits are set, the corresponding access is granted.
   Otherwise, access is denied.
   Note: This data type is non-exportable data. */
typedef unsigned char acl_permset_t;

/* This data type is used to distinguish different types of ACLs.
   Note: This data type is exportable data. */
typedef unsigned char  internal_acl_type_t;
#define ACL_TYPE_ACCESS            1
#define ACL_TYPE_DEFAULT           2

#ifdef NFS4_ACL_TEST
// For testing NFS4 ACLS only
#define ACL_TYPE_NFS4_ACL_TEST   250
#define ACL_TYPE_NFS4_ACL_TEST_SIZE 14
#endif /* NFS4_ACL_TEST */

// The following are for internal use only
#define ACL_TYPE_SID_MAPPING     250 /* SID-to-Unix ID mapping */
#define ACL_TYPE_NFS4            251 /* an NFSv4 ACL */
#define ACL_TYPE_ACCESS_DELETE   252
#define ACL_TYPE_DEFAULT_DELETE  253
#define EXTENDED_ACCESS_ONLY     254
#define INTERNAL_FORMAT          255

/* acl_permset_t bits
 */
#define ACL_PERM_EXECUTE  001
#define ACL_PERM_WRITE    002
#define ACL_PERM_READ     004
#define ACL_PERM_CONTROL  010
#define ACL_PERM_INSERT   020   /* Version 2 ACL permission only     */
#define ACL_PERM_DELETE   040   /* Version 2 ACL permission only     */

#define ACL_PERM_LOOKUP(credP) ACL_PERM_EXECUTE
#define ACL_PERM_MASK     077   /* Mask includes all permissions     */

#define ACL_PERM_UMODE    007   /* Mask includes only UNIX mode bits */

/* VNOP extended access modes that can be checked (gpfs_v_access()).
 */
#define C_ACC   ACL_PERM_CONTROL
#define I_ACC   ACL_PERM_INSERT
#define D_ACC   ACL_PERM_DELETE

/* An ACL entry's tag type is defined as a one byte value.
   It is used to distinguish different types of ACL entries.
   Note: This data type is exportable data. */
typedef unsigned char  acl_tag_t;
#define ACL_USER_OBJ        1   /* aceShort ACL entry */
#define ACL_GROUP_OBJ       2   /* aceShort ACL entry */
#define ACL_OTHER           3   /* aceShort ACL entry */
#define ACL_MASK            4   /* aceShort ACL entry */
#define ACL_USER            5   /* aceShort ACL entry */
#define ACL_GROUP           6   /* aceShort ACL entry */
#define ACL_UDEFINED_TAG  255

/* An ACL entry consists of a fixed part - ACL entry length, permission set,
   entry tag type, entry qualifier (uid or gid), and followed by an optional
   character string.
   Note: This data type is non-exportable data. */
typedef struct
{
  UInt16          aceLength;
  acl_permset_t   acePermissions;
  acl_tag_t       aceTagType;
  cxiUid_t        aceQualifier;
  char            aceComments[1];
} acl_entry_t;

/* SHORT here refers to the situation once upon a time when there used
   to be two kinds of ACEs, short (V1) and long (V2).  Only short ACEs
   remain today, but to minimize unnecessary code changes, old macro
   name is kept. */ 
#define SHORT_ACE_SIZE PTR_TO_INT32(&(((acl_entry_t *) 0)->aceComments[0]))

struct aclv1
{
  acl_entry_t   aclEntry[1];
};

/* NFSv4 ACL structures:
 * Internally, GPFS stores all ACLs in its "ACL" structure which includes a
 * variable-length area where aclVersion-specific information is stored.
 * For NFSv4 ACLs, this variable area contains a list of acl4_entry_t structures.
 * The following types and defines are used in the acl4_entry_t structure.
 */

/* Allowing for the NFSv4 ACE to be variable length. */
typedef UInt16 ace4_length_t; /* Length of an individual ACE */

typedef UInt16 ace4_type_t; /* The type of mask in the ACE */
/* See gpfs.h for defintions for this field. */

typedef unsigned int ace4_flag_t;

#define ACE4_FLAG_EXTERNAL        0x000000FF

/* The following ACE IFLAG values are not externalized. */
#define ACE4_IFLAG_EXCLUDE_FILES  0x40000000
#define ACE4_IFLAG_EXCLUDE_DIRS   0x20000000
#define ACE4_IFLAG_EXTERNAL       0x80000000
#define ACE4_IFLAG_WIN_AUTOGEN_ID 0x00100000


/* Variations to permit/deny/audit/alarm. */
typedef unsigned int ace4_mask_t; 
/* See gpfs.h for defintions for this field. */

/* NFSv4 "who" strings are translated by nfsd4 to locally-defined ids.
 * These can be a uid, a gid (if ACE4_FLAG_GROUP_ID is specified), or one 
 * of the "special identifiers" (if ACE4_IFLAG_SPECIAL_ID is specified).
 */
typedef cxiUid_t ace4_who_t;
/* See gpfs.h for SPECIAL_ID defintions for this field.
   The following ACE special who values are not supported (AIX does not
   provide the required information in the cred. */
#define ACE4_SPECIAL_INTERACTIVE        4
#define ACE4_SPECIAL_NETWORK            5
#define ACE4_SPECIAL_DIALUP             6
#define ACE4_SPECIAL_BATCH              7
#define ACE4_SPECIAL_ANONYMOUS          8
#define ACE4_SPECIAL_AUTHENTICATED      9
#define ACE4_SPECIAL_SERVICE           10

/* ACEs can be chained together (for speed of processing reasons) by
 * including the offset to the next ACE in the chain. */
typedef Int32 ace4_link_t;



#ifdef NFS4_ACL_DEBUG
#define ACE4_IFLAG_USER_OBJ       0x10000000
#define ACE4_IFLAG_GROUP_OBJ      0x08000000
#define ACE4_IFLAG_OTHER          0x04000000
#define ACE4_IFLAG_MASK           0x02000000
#define ACE4_IFLAG_USER           0x01000000
#define ACE4_IFLAG_GROUP          0x00800000
#else
#define ACE4_IFLAG_USER_OBJ       0x00000000
#define ACE4_IFLAG_GROUP_OBJ      0x00000000
#define ACE4_IFLAG_OTHER          0x00000000
#define ACE4_IFLAG_MASK           0x00000000
#define ACE4_IFLAG_USER           0x00000000
#define ACE4_IFLAG_GROUP          0x00000000
#endif /* NFS4_ACL_DEBUG */

/* These are the supported iherit flags.  aceFlags can be OR'ed against
 * this combination to see if any of the inherit flags are specified.
 */
#define ACE4_FLAG_INHERIT (ACE4_FLAG_FILE_INHERIT | ACE4_FLAG_DIR_INHERIT |\
                           ACE4_FLAG_INHERIT_ONLY)

#define ACE4_SUPPORTED_FLAGS (ACE4_FLAG_INHERIT | ACE4_FLAG_GROUP_ID |\
                              ACE4_FLAG_SUCCESSFUL | ACE4_FLAG_FAILED |\
                              ACE4_FLAG_NO_PROPAGATE | ACE4_FLAG_INHERITED)

/* Other IFlags are internal-only */
#ifdef NFS4_ACL_DEBUG
#define ACE4_SUPPORTED_IFLAGS (ACE4_IFLAG_SPECIAL_ID | ACE4_IFLAG_EXCLUDE_FILES |\
                               ACE4_IFLAG_EXCLUDE_DIRS | ACE4_IFLAG_USER_OBJ |\
                               ACE4_IFLAG_GROUP_OBJ | ACE4_IFLAG_OTHER |\
                               ACE4_IFLAG_MASK | ACE4_IFLAG_USER |\
                               ACE4_IFLAG_GROUP | ACE4_IFLAG_WIN_AUTOGEN_ID)
#else
#define ACE4_SUPPORTED_IFLAGS (ACE4_IFLAG_SPECIAL_ID | ACE4_IFLAG_EXCLUDE_FILES |\
                               ACE4_IFLAG_EXCLUDE_DIRS | \
                               ACE4_IFLAG_WIN_AUTOGEN_ID)
#endif


/* GPFS commonly used mask combinations */
/* READ/WRITE of NAMED ATTRIBUTES are not covered yet */
#define ACE4_POSIX_READ        (ACE4_MASK_READ)
#define ACE4_POSIX_WRITE       (ACE4_MASK_WRITE | ACE4_MASK_APPEND)
#define ACE4_POSIX_EXECUTE     (ACE4_MASK_EXECUTE)
#define ACE4_POSIX_CONTROL     (ACE4_MASK_WRITE_ACL)
#define ACE4_POSIX_READ_DIR    (ACE4_MASK_LIST_DIR)
#define ACE4_POSIX_WRITE_DIR   (ACE4_MASK_ADD_FILE | ACE4_MASK_ADD_SUBDIR |\
                                ACE4_MASK_DELETE_CHILD)
#define ACE4_POSIX_EXECUTE_DIR (ACE4_MASK_SEARCH)
#define ACE4_POSIX_CONTROL_DIR (ACE4_MASK_WRITE_ACL)
#define ACE4_POSIX_OWNER       (ACE4_MASK_WRITE_ACL  | ACE4_MASK_WRITE_ATTR | ACE4_MASK_WRITE_NAMED)
#define ACE4_POSIX_EVERYONE    (ACE4_MASK_READ_ATTR  | ACE4_MASK_READ_ACL   |\
                                ACE4_MASK_READ_NAMED | ACE4_MASK_SYNCHRONIZE)

/* Some mask values are represented in posix by permissions on the parent. */
#define ACE4_POSIX_PARENT      (ACE4_MASK_DELETE)

/* Some mask values should always be cleared out in a Posix-derived DENY ACE */
#define ACE4_POSIX_NEVER_DENY  (ACE4_POSIX_PARENT | ACE4_MASK_WRITE_OWNER |\
                                ACE4_MASK_READ_NAMED | ACE4_MASK_WRITE_NAMED)

#define ACE4_WIN_NEVER_DENY    (ACE4_POSIX_PARENT | ACE4_MASK_WRITE_OWNER)

/* Extra access bits needed on Windows.  These usually share the
   same bitword with ACE4_MASK_ bits. */
#define WIN_ACCMASK_SYSTEM_SECURITY 0x01000000
#define WIN_ACCMASK_MAXIMUM_ALLOWED 0x02000000

/* Convenience macros for testing the NFSv4 flags, masks, and special who values.
 * Note that these macros are bilingual.  If a local-endian ACL is available, an
 * ACEP can be provided.  Reading of an ACL directly from the disk buffer is also
 * possible given the AclLocalEndian (ALE) object.  While most use of the ACL 
 * (such as iaccess checks) is done via the ALE, user read/write of the ACL is
 * done via the AclLocalEndian::exportAcl method with subsequent interpretation
 * of the ACL then done using the byteSwapped ACL.
 */

#define USE_ALE ((acl4_entry_t *)NULL)    /* Dummy ACEP */

#define getV4Who(ACEP,ALE)    (ACEP)? ((ACEP)->aceWho)   : ((ALE).aceWho())
#define getV4Type(ACEP,ALE)   (ACEP)? ((ACEP)->aceType)  : ((ALE).aceType())
#define getV4Flags(ACEP,ALE)  (ACEP)? ((ACEP)->aceFlags) : ((ALE).aceFlags())
#define getV4IFlags(ACEP,ALE) (ACEP)? ((ACEP)->aceIFlags): ((ALE).aceIFlags())
#define getV4Mask(ACEP,ALE)   (ACEP)? ((ACEP)->aceMask)  : ((ALE).aceMask())

#define isV4Bit(WORD, BIT)      (0 != ((WORD) & (BIT)))
#define isV4AllBits(WORD, BITS) (BITS == ((WORD) & (BITS)))

#define isV4Type(ACEP, ALE, VALUE) ((getV4Type(ACEP, ALE)) == (VALUE))
#define isV4Who(ACEP, ALE, VALUE)  ((getV4Who(ACEP, ALE)) == (VALUE))

#define isV4Allow(ACEP,ALE)        isV4Type(ACEP, ALE, ACE4_TYPE_ALLOW)
#define isV4Deny(ACEP,ALE)         isV4Type(ACEP, ALE, ACE4_TYPE_DENY)
#define isV4Audit(ACEP,ALE)        isV4Type(ACEP, ALE, ACE4_TYPE_AUDIT)
#define isV4Alarm(ACEP,ALE)        isV4Type(ACEP, ALE, ACE4_TYPE_ALARM)

#define isV4FileInherit(ACEP,ALE)  isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_FILE_INHERIT)
#define isV4DirInherit(ACEP,ALE)   isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_DIR_INHERIT)
#define isV4NoPropagate(ACEP,ALE)  isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_NO_PROPAGATE)
#define isV4InheritOnly(ACEP,ALE)  isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_INHERIT_ONLY)
#define isV4AuditSuccess(ACEP,ALE) isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_SUCCESSFUL)
#define isV4AuditFailure(ACEP,ALE) isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_FAILED)
#define isV4GroupId(ACEP,ALE)      isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_GROUP_ID)
#define isV4Inherit(ACEP,ALE)      isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_INHERIT)
#define isV4Inherited(ACEP,ALE)    isV4Bit(getV4Flags(ACEP,ALE),ACE4_FLAG_INHERITED)

#define isV4SpecialId(ACEP,ALE)    isV4Bit(getV4IFlags(ACEP,ALE),ACE4_IFLAG_SPECIAL_ID)
#define isV4FileApplicable(ACEP, ALE) \
        (!isV4Bit(getV4IFlags(ACEP,ALE),ACE4_IFLAG_EXCLUDE_FILES))
#define isV4DirApplicable(ACEP, ALE)  \
        (!isV4Bit(getV4IFlags(ACEP,ALE),ACE4_IFLAG_EXCLUDE_DIRS))
#define isV4WinAutogenId(ACEP,ALE) isV4Bit(getV4IFlags(ACEP,ALE),ACE4_IFLAG_WIN_AUTOGEN_ID)

/* Inherit entries may have originally been identified as FILE_INHERIT or
 * DIR_INHERIT.  When such an ACL becomes a default, the entries become
 * applicable to the object in addition to being inherittable.  Such entries
 * may then need to be marked as not being applicable for files or dirs.
 * When returning such an ACL, non-applicable entries are removed (they are
 * here only so there can be a single, common, default ACL).
 *
 * The ACE is applicable if
 * 1) The object is a directory and the entry is either directly applicable
 *    to directories, OR it is inherittable by files.
 * 2) The object is a file and the entry is directly applicable to files AND
 *    it is not an InheritOnly entry.
 */

#define isV4Applicable(ACEP, ALE, ISDIR) \
        (( ISDIR && (isV4DirApplicable(ACEP,ALE) || isV4FileInherit(ACEP,ALE))) || \
         (!ISDIR && (isV4FileApplicable(ACEP,ALE) && !isV4InheritOnly(ACEP,ALE))))

#define isV4Read(ACEP,ALE)        isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_READ)
#define isV4List(ACEP,ALE)        isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_LIST_DIR)
#define isV4Write(ACEP,ALE)       isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_WRITE)
#define isV4AddFile(ACEP,ALE)     isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_ADD_FILE)
#define isV4Append(ACEP,ALE)      isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_APPEND)
#define isV4AddSubdir(ACEP,ALE)   isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_ADD_SUBDIR)
#define isV4ReadNamed(ACEP,ALE)   isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_READ_NAMED)
#define isV4WriteNamed(ACEP,ALE)  isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_WRITE_NAMED)
#define isV4Execute(ACEP,ALE)     isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_EXECUTE)
#define isV4Search(ACEP,ALE)      isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_SEARCH)
#define isV4DeleteChild(ACEP,ALE) isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_DELETE_CHILD)
#define isV4ReadAttr(ACEP,ALE)    isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_READ_ATTR)
#define isV4WriteAttr(ACEP,ALE)   isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_WRITE_ATTR)
#define isV4Delete(ACEP,ALE)      isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_DELETE)
#define isV4ReadAcl(ACEP,ALE)     isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_READ_ACL)
#define isV4WriteAcl(ACEP,ALE)    isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_WRITE_ACL)
#define isV4WriteOwner(ACEP,ALE)  isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_WRITE_OWNER)
#define isV4Synchronize(ACEP,ALE) isV4Bit(getV4Mask(ACEP,ALE),ACE4_MASK_SYNCHRONIZE)

#define isV4Owner(ACEP,ALE)       isV4Who(ACEP,ALE,ACE4_SPECIAL_OWNER)
#define isV4Group(ACEP,ALE)       isV4Who(ACEP,ALE,ACE4_SPECIAL_GROUP)
#define isV4Everyone(ACEP,ALE)    isV4Who(ACEP,ALE,ACE4_SPECIAL_EVERYONE)
#define isV4Interactive(ACEP,ALE) isV4Who(ACEP,ALE,ACE4_SPECIAL_INTERACTIVE)
#define isV4Network(ACEP,ALE)     isV4Who(ACEP,ALE,ACE4_SPECIAL_NETWORK)
#define isV4Dialup(ACEP,ALE)      isV4Who(ACEP,ALE,ACE4_SPECIAL_DIALUP)
#define isV4Batch(ACEP,ALE)       isV4Who(ACEP,ALE,ACE4_SPECIAL_BATCH)
#define isV4Anonymous(ACEP,ALE)   isV4Who(ACEP,ALE,ACE4_SPECIAL_ANONYMOUS)
#define isV4Authentic(ACEP,ALE)   isV4Who(ACEP,ALE,ACE4_SPECIAL_AUTHENTICATED)
#define isV4Service(ACEP,ALE)     isV4Who(ACEP,ALE,ACE4_SPECIAL_SERVICE)

/* Flag values for gpfs_getacl/NFSv4_getMode */
#define GETACL_NFSV4          0x00000001
#define GETACL_POSIX          0x00000002
#define GETACL_NATIVE         0x00000004
#define GETACL_OWNER_IN_GROUP 0x00000008
#define GETACL_DONOT_BLD_ACL  0x00000010
#define GETACL_V4FLAGS        0x00000080 /* Allow tsgetacl to obtain aclFlags */
#define GETACL_WINACL         0x00000100
#define GETACL_COMMAND        0X00000200 /* Call originated from tsgetacl */

/* The non-opaque/external ACL struct should be used in the
 * gpfs_getacl and gpfs_putacl calls.  While these are defined
 * in gpfs.h along with the interfaces, we are reserving the
 * bits here as well in this list of internal-only flags just
 * to make sure they don't get reused.
 */
#define GETACL_STRUCT_RESERVED 0X00000020
#define PUTACL_STRUCT_RESERVED 0X00000020
#define GETACL_SAMBA_RESERVED  0X00000040


typedef struct
{
  ace4_length_t   aceLength;
  ace4_type_t     aceType;   /* allow, deny, audit, alarm */
  ace4_flag_t     aceFlags;  /* V4 flags */
  ace4_flag_t     aceIFlags; /* Internal (GPFS flags) */
  ace4_mask_t     aceMask;   /* extended "mode" bits */
  ace4_who_t      aceWho;    /* uid, gid, or special identifier */
  ace4_link_t     aceNextAA; /* Next Audit or Alarm ACE */
} acl4_entry_t;

struct aclv4
{
  Int32         aceCount;          // Total number of ACEs
  ace4_link_t   aaListOffset;      // Offset to first Audit/Alarm ACE
  acl4_entry_t  aclEntry[1];       // zero or more ACL entries
};

/* Windows Security Identifier (SID).  In theory, it should be treated as an
   opaque struct, but in reality the SID structure is well documented and is
   widely exploited.  In general, a SID is a binary object of variable size.
 */ 
#define GPFS_SID_REVISION 1
 
typedef struct gpfs_sid
{
  UChar  sidRevision;
  UChar  sidSubAuthorityCount;
  UChar  sidIdentifierAuthority[6];
  UInt32 sidSubAuthority[1]; /* really has sidSubAuthorityCount entries */
} gpfs_sid_t;

#define GPFS_SID_HDR_LEN  OFFSET_OF(sidSubAuthority, gpfs_sid_t)
#define GPFS_SID_LEN(_sidP)  (GPFS_SID_HDR_LEN + \
                              ((_sidP)->sidSubAuthorityCount * sizeof(UInt32)))
#define MAX_SUBAUTHORITY_COUNT (15)

/* The maximum size of an in-memory SID object */
#define MAX_SID_BUF_SIZE  (GPFS_SID_HDR_LEN + MAX_SUBAUTHORITY_COUNT * \
                           sizeof(UInt32))

/* The maximum size of a text SID representation (S-R-A-...) */
#define MAX_SID_STR_BUF_SIZE (2 + 4 + 16 + MAX_SUBAUTHORITY_COUNT * 10 + 1)


/* SID-to-UnixID remapping entry.  All security pricipal IDs are stored
   as 32-bit numeric IDs in GPFS metadata (inode header, ACEs).  Windows
   operates with SIDs, so a conversion between these two formats is 
   necessary.  The Windows node that is carrying out the operation that
   requires such a conversion is in charge of finding (or creating) a
   SID-to-ID mapping, and storing the mapping in the GPFS ACL file for
   future use. 
 */
typedef struct gpfs_sid_mapping
{
  Int32 sidMapMagic;

  Int16 sidMapLen;
  UChar sidMapRevision;
  UChar sidMapReserved;

  Int16 sidMapGeneration; /* always 0 at this time */
  Int16 sidMapFlags;

  Int32 sidMapId;
  gpfs_sid_t sidMapSid;
} gpfs_sid_mapping_t;

#define SID_MAPPING_MAGIC 0xAA2006FF
#define SID_MAPPING_REVISION 1

#define GPFS_SID_MAPPING_IS_GROUP_ID   0x0001
#define GPFS_SID_MAPPING_AUTOGENERATED 0x0002
#define GPFS_SID_MAPPING_NEGATIVE      0x0004
#define GPFS_SID_MAPPING_IS_SUPERCEDED 0x0008
#define GPFS_SID_MAPPING_IS_SUSPECT    0x0010

/* An ACL consists of header information (length, type, etc.).
   followed by at least three, but may be more, ACL entries.
   The three required entries must be ACL_USER_OBJ, ACL_GROUP_OBJ,
   and ACL_OTHER. The first four bytes of the ACL header must always
   be the length of the entire ACL.
   Note: This data type is non-exportable data. */
typedef struct
{
  UInt32            aclLength;          // total length (hdr + acl entries)
  UInt16            aclVersion;         // version number
  internal_acl_type_t aclType;          // type of ACL
 
  /* The rest of the entry contents depends on aclType.  
     For the ACL_TYPE_SID_MAPPING type, the buffer
     storing gpfs_sid_mapping begins here. */
  union
  {
    char            aclBuf[1];          // ACL type-dependent buffer
    acl_permset_t   aclMask;            // ACL_MASK entry
    acl_permset_t   aclGroupObj;        // ACL_GROUP_OBJ entry
  };
  cxiMode_t         aclMode;            // file mode (at acl create time)
  UInt32            aclUserAceCnt;      // number of ACL_USER entries
  UInt32            aclGroupAceCnt;     // number of ACL_GROUP entries
  UInt32            aclFlags;

  /* See the ACL4_FLAG_ defines in gpfs.h */
#define ACL_NEW_MODE_ATTR_BIT 0x00000001 // if set, replace the current mode
#define ACL_GROUP_CONTROL_BIT 0x00000002 // ACL_GROUP_OBJ control bit
#define ACL_OTHER_CONTROL_BIT 0x00000004 // ACL_OTHER     control bit
#define ACL_MASK_CONTROL_BIT  0X00000008 // ACL_MASK      control bit

  union
  {
    struct aclv1  v1;
#ifdef NFS4_ACL
    struct aclv4  v4;
#endif /* NFS4_ACL */
  };
} ACL_t;

/* The following is used as a pointer to an ACL in working storage.
   Note: This data type is non-exportable data. */
typedef ACL_t *acl_t;

#define ACL_HEADER_SIZE_V1   PTR_TO_INT32(&(((acl_t) 0)->v1.aclEntry[0]))

#ifdef NFS4_ACL
/* Offset to gpfs_ace4_t structs in the NFSv4 ACL we externalize */
#define ACL_EXT_HEADER_SIZE_V4 PTR_TO_INT32(&(((acl_t) 0)->aclBuf[0])) 

/* Offset to gpfs_ace4_t structs in the NFSv4/GPFS_ACL_LEVEL_V4FLAGS ACL */
#define ACL_EXT_HEADER_SIZE_V4L1 PTR_TO_INT32(&(((acl_t) 0)->v4)) 

/* Offset to acl4_entry_t structs in our internal ACL format. */
#define ACL_HEADER_SIZE_V4 PTR_TO_INT32(&(((acl_t) 0)->v4.aclEntry[0]))

/* Next ACE in an NFSv4 ACL (internal, local-endian format only) */
#define ACL4_ENTRY_NEXT(ACEP) (acl4_entry_t *)((caddr_t)ACEP + ACEP->aceLength) 

#define ACL_ENTRY_START(ACLP,VER) \
          (acl_entry_t *)((VER == GPFS_ACL_VERSION_NFS4) ? \
            (caddr_t)ACLP + ACL_HEADER_SIZE_V4 :  \
            (caddr_t)ACLP + ACL_HEADER_SIZE_V1)
#else
#define ACL_ENTRY_START(ACLP,VER) \
          (acl_entry_t *)((caddr_t)ACLP + ACL_HEADER_SIZE_V1)
#endif /* NFS4_ACL */

/* Upper bound on the size of a base acl (header + 4 entries for base
   permissions and mask).  The correct value would be
     ACL_HEADER_SIZE + 4*SHORT_ACE_SIZE
   However, ACL_BASE_SIZE_MAX needs to be a compile-time constant, because
   it is used to declare a char array on the stack as temporary buffer for
   assembling a base acl.  Unfortunately, the compiler does not accept the
   offset calculations in the ACL_HEADER_SIZE and SHORT_ACE_SIZE macros as
   constants.  The definition below slightly over-estimates the base acl size,
   but is sufficient for our purpose, since we only need an upper bound. */
#define ACL_BASE_SIZE_MAX (sizeof(ACL_t) + 3*sizeof(acl_entry_t))

/* acl format versions */
#define ACL_FIRST_VERSION     1

#ifdef NFS4_ACL
#define ACL_VERSION           4
#else
#define ACL_VERSION           1
#endif /* NFS4_ACL */

#ifdef NFS4_ACL
#define GPFS_ACL_VERSION_NFS4 4
#endif /* NFS4_ACL */

#define DEFAULT_ACLMASK_V1    017       // rwxc

#define MASK_SET           0x80

/* Mapping for the index tables used by the verifyTSAcl routine.
   Note: This data type is non-exportable data. */
typedef struct
{
  acl_entry_t     *aceP;
  cxiUid_t         key;
  caddr_t          nxt;
} aceIndxTable_t;

/* Macro to test whether the ACL_MASK is explicitly set */
#define ACLMASK_SET(_aclMask) (((_aclMask) & MASK_SET) != 0)

#define REM_STAT_REMOTE_FS 1

typedef struct
{
  UInt32 flags;
  UInt32 sgUIDHigh;
  UInt32 sgUIDLow;
  UInt32 reserved;     // Unused, formerly inum field
  UInt32 mode;
  UInt32 uid;
  UInt32 gid;
} rem_stat_t;
  

#endif /* _h_cxiAclUser */

