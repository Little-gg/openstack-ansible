/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)42       1.22  src/avs/fs/mmfs/ts/kernext/gpl-linux/tracedev-ksyms.c, mmfs, avs_rfks0, rfks01416c 10/30/13 13:22:44 */
/*
 * Export symbols for tracing module (tracedev)
 *
 * Define new global variables with GPFS_EXPORT_SYMBOL(varname).
 * Define new functions with GPFS_EXPORT_FUNC(varname).
 *
 * The latter will automatically spit out a generic function
 * prototype. The prototype format doesn't matter here, but
 * it is important to let the compiler know that something
 * is really a function (or else incorrect code is spewed out
 * on IA64 for the relocation entry which trips up insmod;
 * the i386 platform doesn't have this feature).
 *
 *
 */

#ifndef KTRACE

/* If trace is built into kernel, pick up GPFS flag definitions from a file
   rather than requiring them to be defined on the command line. Also, put
   trace global variables here rather than in GPFS kernel module so that
   they can be referenced by code in kernel. */
#ifndef MODULE
#define DEFINE_TRACE_GBL_VARS
#endif

#include <linux/version.h>
#include <linux/module.h>
#define GPFS_GPL

#ifdef GPFS_EXPORT_KSYMS

/* Use GPFS_EXPORT_SYMBOL for exporting a variable */
/* Use GPFS_EXPORT_FUNC for exporting a function */

#if LINUX_KERNEL_VERSION > 2061300
#define GPFS_EXPORT_SYMBOL(VAR) EXPORT_SYMBOL(VAR);
#define GPFS_EXPORT_FUNC(FNAME) extern void FNAME (); \
                                EXPORT_SYMBOL(FNAME);
#else
#define GPFS_EXPORT_SYMBOL(VAR) EXPORT_SYMBOL_NOVERS(VAR);
#define GPFS_EXPORT_FUNC(FNAME) extern void FNAME (); \
                                EXPORT_SYMBOL_NOVERS(FNAME);
#endif

/* Duplicate definition of TraceGBLS_t.  See ibm-linux/Trace-plat.h. */
typedef struct
{
  /* Current trace mode.  Takes on one of the TRACE_xxx values in
     TraceMode_t. */
  int tMode;

  /* Padding.  Unused. */
  int tPadding;

  /* Base address of the buffer used for overwrite tracing, or NULL if
     overwrite tracing is not enabled or quiesced.  This will be a
     page-aligned address.  The type of this buffer is actually
     SharedTraceBufferHeader_t. */
  char* tBufferBaseP;

  /* Size of the shared trace buffer whose address is in tBufferBaseP.  This
     will be 0 if bufferBaseP is NULL. */
  long long tBufferSize;
} TraceGBLS_t;

extern TraceGBLS_t KTrace;

/* ************** */
/* Export section */
/* ************** */
#ifndef GPFS_PRINTF
GPFS_EXPORT_FUNC(_STrace);
GPFS_EXPORT_FUNC(_STraceNB);
GPFS_EXPORT_FUNC(_XTrace);
GPFS_EXPORT_FUNC(_XTraceNB)
GPFS_EXPORT_FUNC(_DTrace0);
GPFS_EXPORT_FUNC(_DTrace1); 
GPFS_EXPORT_FUNC(_DTrace2);
GPFS_EXPORT_FUNC(_DTrace3);
GPFS_EXPORT_FUNC(_DTrace4);
GPFS_EXPORT_FUNC(_DTrace5);
GPFS_EXPORT_FUNC(_DTrace6);
GPFS_EXPORT_FUNC(_DTrace7);
GPFS_EXPORT_FUNC(_DTrace8);
GPFS_EXPORT_FUNC(_DTrace9);
GPFS_EXPORT_FUNC(_DTrace10);
GPFS_EXPORT_FUNC(_DTrace11);
GPFS_EXPORT_FUNC(_DTrace12);
GPFS_EXPORT_FUNC(_DTrace13);
GPFS_EXPORT_FUNC(_DTrace14);
GPFS_EXPORT_SYMBOL(KTrace);
GPFS_EXPORT_FUNC(trc_fsync);
#ifndef MODULE
EXPORT_SYMBOL_NOVERS(TraceFlagsP);
#endif
#endif /* ! GPFS_PRINTF */

#endif /* GPFS_EXPORT_KSYMS */
#endif /* ! KTRACE */
