/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)94       1.81  src/avs/fs/mmfs/ts/kernext/gpl-linux/dir.c, mmfs, avs_rfks0, rfks01416c 9/5/13 11:56:54 */

#define __NO_VERSION__

#ifndef __KERNEL__
#define __KERNEL__
#endif

#include <Shark-gpl.h>

#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_KERNEL_VERSION >= 2063000
#include <linux/fs_struct.h>
#endif

#include <linux2gpfs.h>
#include <cxiSystem.h>
#include <cxiTypes.h>
#include <cxiIOBuffer.h>
#include <cxiSharedSeg.h>
#include <cxiCred.h>
#include <cxi2gpfs.h>
#include <Trace.h>
#include <verdep.h>


/* About dcache revalidation:

   The Linux directory cache (dcache) is used to cache the result of name
   lookups.  Linux caches positive as well as negative lookup results in its
   dcache entries (struct dentry): if the file existed at the time the last
   lookup was done (positive lookup), dentry->d_inode will point to the struct
   inode of the file; if the file did not exist (negative lookup),
   dentry->d_inode will be null.

   When a directory is modified on the local node, Linux will update its
   dcache entries accordingly.  When the directory is modified on another
   node, however, we need to invalidate local dcache entries:

    - A negative dcache entry becomes invalid when a file by the same name is
      created on another node.  This requires an exclusive byte-range token on
      the directory block in which the lookup was done that resulted in the
      dcache entry.  Hence, when we lose a byte-range token on a directory, we
      invalidate all negative dcache entries for lookups that were done in
      that directory.  This is done by a call to kxinvalidateOSNode with
      KXIVO_NEGDCACHE, which will result in a call to
      cxiInvalidateNegDCacheEntry() implemented here.

    - A positive dcache entry becomes invalid when the file it refers to
      is deleted, moved, or renamed on another node.  All of these operations
      require an exclusive inode lock.  Hence we invalidate a positive dcache
      entry when we lose the inode token for the file.  This more selective
      invalidation of positive dcache entries is more efficient than simply
      invalidating all dcache entries when we lose a byte-range token on the
      directory.  The invalidation is done by a call to kxinvalidateOSNode
      with CXI_IC_DCACHE, which will result in a call to
      cxiInvalidateDCacheEntry() implemented here.

   To invalidate a dcache entry Linux defines a d_revalidate function in the
   dentry_operations table.  This function is supposed to check whether the
   dcache entry is still valid and return 'true' or 'false' accordingly.
   If no d_revalidate function is given in the dentry_operations table,
   Linux assumes the dentry is valid.  Hence the most efficient way
   of marking a dentry as valid or invalid is to have the d_ops field in
   the dentry point to one of two different dentry_operations tables:
   one where the d_revalidate field is NULL (means the dentry is valid),
   and one where d_revalidate points at a function that always returns false
   (means the dentry is invalid). */


/* This call handles pruning off all unheld dentries pointing at an 
 * inode. Normally pruning is not done by any daemon thread directly 
 * (ie. token revoke) because d_prune_aliases may initiate a string of 
 * callbacks due to iput.  These callbacks may need to communicate back 
 * to the daemon which can be problematic if there is a mailbox shortage. 
 * Hence most dentry invalidation marks the cxiNode as needing a dentry 
 * prune and the GPFS swapd is notified to call cxiPruneDCacheEntry in a 
 * separate thread.
 *
 * Caller must be prepared to receive iput() callback into GPFS.
 * Caller must have a reference on cxiNode_t to ensure it doesn't 
 * go away during processing.
 */
int
cxiPruneDCacheEntry(cxiNode_t *cnP)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  struct dentry *dentry;
  Boolean hasSubdirs = false, hasRefs;

  ENTER(0);
  TRACE3(TRACE_VNODE, 5, TRCID_PRUNE_DCACHE,
         "cxiPruneDCacheEntry: iP 0x%lX inode %lld i_count %d", 
         iP, iP->i_ino, atomic_read(&iP->i_count));

  /* About to prune it so flag is no longer needed */
  ClearCtFlag(cnP, pruneDCacheNeeded);

  /* Traverse the list of all dentries that still refer to this file. */
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&iP->i_lock);
#else
  spin_lock(&dcache_lock);
#endif
  LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
  {
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&dentry->d_lock);
#endif
    hasSubdirs = !list_empty(&dentry->d_subdirs);

    TRACE5N(TRACE_VNODE, 4, TRCID_PRUNE_DCACHE_ALIAS,
           "cxiPruneDCacheEntry: ip 0x%lX inode %lld alias dentry 0x%lX "
           "hasSubdirs %d name '%s'", iP, iP->i_ino, dentry, 
           hasSubdirs, dentry->d_name.name);

    /* Attempt to prune unused children.  Helps keep stat cache manageable */
    if (hasSubdirs)
    {
#ifdef DCACHE_LOCK_IS_GONE
      dget_dlock(dentry);
      spin_unlock(&dentry->d_lock);
      spin_unlock(&iP->i_lock);
#else
      dget_locked(dentry);
      spin_unlock(&dcache_lock);
#endif

      /* This call walks the tree starting at this parent dentry and 
       * will successfully uncache child dentries that aren't held by
       * user programs and iput their associated inodes (resulting in 
       * many cases of the inode i_count going to 0.  iput() may however
       * just put these inodes on the unused list if they are still 
       * valid (i_nlink > 0) and linked on i_hash.  Thus in many cases while
       * the dentries immediately disappear their associated inode don't
       * have an immediate clear_inode() called on them.  Subsequent 
       * pruning (by kswapd) should shrink the icache for unused inodes
       * resulting in the gpfs_s_clear_inode callback for these inodes.
       */
      shrink_dcache_parent(dentry);
      dput(dentry);
 
      /* For directories we don't support hard links so we shouldn't
       * have multiple dentries that need to be pruned.  Hence
       * after having dropped the dcache lock we break out of this
       * for loop.
       */
      break;
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&dentry->d_lock);
#endif
  }
  if (!hasSubdirs)
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&iP->i_lock);
#else
    spin_unlock(&dcache_lock);
#endif

  /* This call prunes any unheld dentries pointing at the inode */
  d_prune_aliases(iP);

  hasRefs = !I_DENTRY_EMPTY(&iP->i_dentry);

  TRACE4(TRACE_VNODE, 4, TRCID_PRUNE_DCACHE_EXIT,
         "cxiPruneDCacheEntry: ip 0x%lX inode %lld i_count %d hasRefs %d",
         iP, iP->i_ino, atomic_read(&iP->i_count), hasRefs);

  EXIT(0);
  return hasRefs;
}

/* Mark the dentry as needing a revalidate.  Called after losing
 * a token protecting the attributes of this dcache entry.
 */
int
cxiInvalidateDCacheEntry(cxiNode_t *cnP, int flags)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  struct dentry *dentry;
  int refCount = 0;

  /* Traverse the list of all dentries that refer to this file. */
  ENTER(0);
  TRACE3(TRACE_VNODE, 4, TRCID_INVAL_DCACHE,
         "cxiInvalidateDCacheEntry: ip 0x%lX inode %lld flags 0x%X", iP, iP->i_ino, flags);

#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&iP->i_lock);
#else
  spin_lock(&dcache_lock);
#endif

  LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
  {
    refCount++;
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&dentry->d_lock);
#endif

    /* Mark the entry as needing revalidation by setting the d_op 
     * function table to gpfs_dops_revalidate.  Since this dentry
     * is staying in the vfs we can't declare it invalid, or a legitimate
     * stat on it may return ESTALE.  
     * Scenario: node a) mkdir foo; cd foo
     *           node b) chmod 500 foo
     *           node a) ls -al
     * must succeed.
     */
    set_dentry_operations(dentry, &gpfs_dops_revalidate, true);

    TRACE6N(TRACE_VNODE, 4, TRCID_INVAL_DCACHE_ALIAS,
           "cxiInvalidateDCacheEntry: ip 0x%lX inode %lld "
           "alias dentry 0x%lX ctFlags %d d_flags %d name '%s'",
           iP, iP->i_ino, dentry, cnP->ctFlags, dentry->d_flags, dentry->d_name.name);

    /* unlink or cxiCloseNFS may call to drop disconnected dentries
       that originated via d_alloc_anon call in gpfs_nfsd_iget_dentry */

    if ((flags == CXI_INVALIDATE_DISCONNECTED_ONLY) &&
        !(dentry->d_flags & DCACHE_DISCONNECTED))
    {
#ifdef DCACHE_LOCK_IS_GONE
      spin_unlock(&dentry->d_lock);
#endif
      continue;
    }

    if (TestCtFlag(cnP, destroyIfDelInode))  
    {
      /* If the file was deleted, marking the dentry invalid is not
       * sufficient.  If we leave the dentry in the cache marked as
       * invalid, it will remain in the cache until:
       *
       *  a) if it has a zero d_count then the scheduled GPFS swapd 
       *     d_prune_aliases will get rid of it
       *  b) if it has a nonzero d_count (it's open) then d_prune_aliases
       *     would not prune it and it would stay in the cache until the
       *     next lookup finds it and calls d_invalidate, which might not
       *     ever happen.
       *
       * Thus we drop the dentry and the final close or schedule 
       * d_prune_aliases will remove it.
       */
      DENTRY_DROP(dentry);
    }

#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&dentry->d_lock);
#endif

    /* Dentries for this cxiNode_t should be pruned by GPFS swapd thread
     * which will be signalled by the caller of this routine.
     */
    SetCtFlag(cnP, pruneDCacheNeeded);
  }
#ifdef DCACHE_LOCK_IS_GONE
  spin_unlock(&iP->i_lock);
#else
  spin_unlock(&dcache_lock);
#endif

  EXIT(0);
  return refCount;
}

/* The following function is called to remove invalid dcache entries for a
   file when the file is deleted on this node.
     Such invalid dcache entries occur when a file is renamed on another node
   before it is deleted here.  The rename revokes the inode token, which marks
   the dcache entry invalid, but does not remove it from the cache on this
   node.  When the file is deleted, the delete operation on this node will
   look up the file under its new name and turn the (new) dcache entry into a
   negative dcache entry, but since the file was renamed, it will not find or
   process the old, invalid dcache entry (the one referring to the old file
   name).  This function is called during delete (when the link count goes to
   zero) to remove old, invalid dcache entries, so the file can be destroyed.
     The function is similar to cxiInvalidateDCacheEntry, with the following
   differences: (1) it is only called on files that are being deleted (link
   count zero and destroyIfDelInode flag already set), (2) it does not mark
   any dcache entries as invalid; instead, it (3) only drops dcache entries
   that are already marked as invalid.  In particular, we do not want to
   invalidate the dcache entry referring to the current name being unlinked,
   because unlink will turn this into a valid, negative dcache entry. */
void
cxiDropInvalidDCacheEntry(cxiNode_t *cnP)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  struct dentry *dentry;
  int holdCount;

  ENTER(0);
  TRACE2(TRACE_VNODE, 4, TRCID_DROP_INVAL_DCACHE,
         "cxiDropInvalidDCacheEntry: iP 0x%lX i_inode %lld",
         iP, iP->i_ino);

  DBGASSERT(TestCtFlag(cnP, destroyIfDelInode));

  /* Traverse the list of all dentries that still refer to this file. */
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&iP->i_lock);
#else
  spin_lock(&dcache_lock);
#endif

  LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
  {

#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&dentry->d_lock);
#endif
    /* Check whether this dentry mas been marked invalid */
    if (dentry->d_op == &gpfs_dops_invalid ||
        dentry->d_op == &gpfs_dops_revalidate)
    {
      TRACE4N(TRACE_VNODE, 4, TRCID_DROP_INVAL_DCACHE_ALIAS,
             "cxiDropInvalidDCacheEntry: ip 0x%lX inode %lld "
             "removing dentry 0x%lX name '%s'\n",
             iP, iP->i_ino, dentry, dentry->d_name.name);

      /* Drop the dcache entry.  See details in cxiInvalidateDCacheEntry */
      DENTRY_DROP(dentry);

      /* Dentries for this cxiNode_t should be pruned */
      SetCtFlag(cnP, pruneDCacheNeeded);
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&dentry->d_lock);
#endif
  }

#ifdef DCACHE_LOCK_IS_GONE
  spin_unlock(&iP->i_lock);
#else
  spin_unlock(&dcache_lock);
#endif
  EXIT(0);
}

/* Drop case-insensitive dcache entries associated with a deleted inode.
   Called from unlink so that any Samba-instantiated dentry for the inode 
   will be removed as well. */
void
cxiDropSambaDCacheEntry(cxiNode_t *cnP)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  struct dentry *dentry;
  Boolean pruneNeeded = false;

  ENTER(0);
  TRACE2(TRACE_VNODE, 4, TRCID_DROP_DCACHE,
         "cxiDropSambaDCacheEntry: ip 0x%lX inode %lld\n", iP, iP->i_ino);

  /* Traverse the list of all dentries that refer to this file. */
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&iP->i_lock);
#else
  spin_lock(&dcache_lock);
#endif

  LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
  {
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&dentry->d_lock);
#endif
    if (dentry->d_op == &gpfs_dops_valid_if_Samba)
    {
       TRACE1N(TRACE_VNODE, 5, TRCID_DROP_DCACHE2,
               "cxiDropSambaDCacheEntry: name '%s'\n", dentry->d_name.name);
       DENTRY_DROP(dentry);
       pruneNeeded = true;
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&dentry->d_lock);
#endif
  }
  if (pruneNeeded)
    SetCtFlag(cnP, pruneDCacheNeeded);

#ifdef DCACHE_LOCK_IS_GONE
  spin_unlock(&iP->i_lock);
#else
  spin_unlock(&dcache_lock);
#endif
  EXIT(0);
  return;
}

/* The following function is called to invalidate negative dcache entries for
   all files in a directory when we lose the BR token for the directory. */
int
cxiInvalidateNegDCacheEntry(cxiNode_t *cnP)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  struct list_head *cListP, *cHeadP;
  struct dentry *dentry, *child, *pruneParent = NULL, *prunePending;
  int refCount = 0;
  int pruneTarget = 0;
  int nInval;
  Boolean dlockHeld = false;

  ENTER(0);
  TRACE3(TRACE_VNODE, 4, TRCID_INVAL_NEG_DCACHE,
         "cxiInvalidateNegDCacheEntry: iP 0x%lX inode %lld i_nlink %d",
         iP, iP->i_ino, iP->i_nlink);

  /* Traverse the list of all dentries that refer to this directory.
     Note: since we don't support hard links to directories, we normally
     expect there to be exactly one dentry on this list.  The exception are
     directories in a snapshot, which are potentially reachable through two
     different paths: from .snapshots in the root directory and from the
     hidden .snapshots entry in the corresponding directory in the active file
     system.*/
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&iP->i_lock);
#else
  spin_lock(&dcache_lock);
#endif

  LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
  {
    refCount++;
#ifdef DCACHE_LOCK_IS_GONE
   spin_lock(&dentry->d_lock);
#endif

    /* traverse the list of all children of this dentry */
    cHeadP = &dentry->d_subdirs;
    nInval = 0;
    for (cListP = cHeadP->next; cListP != cHeadP; cListP = cListP->next)
    {
      /* If this child is a negative dentry (d_inode pointer is NULL),
         mark the entry invalid by setting the dop function table to
         gpfs_dops_invalid, which contains a d_revalidate function that
         always returns false.  Also handle dcache entries that are
         about to be deleted (unlink operation pending but not yet complete).
         These entries still have a non-null d_inode pointer, but are
         marked as "delete pending" by having a different d_op table.
         We should not mark the latter as invalid, because we don't know
         yet whether the delete operation is going to succeed, so we mark
         those dentries as "needing revalidation".  (see also comments
         in gpfs_i_unlink and gpfs_i_rmdir). */
      child = list_entry(cListP, struct dentry, d_child);
      if (!child->d_inode || child->d_op == &gpfs_dops_ddeletepending)
      {
        Boolean doInval = (child->d_inode == NULL && !d_unhashed(child));

#if LINUX_KERNEL_VERSION >= 2063800
        spin_lock_nested(&child->d_lock, DENTRY_D_LOCK_NESTED);
        set_dentry_operations(child, doInval ? &gpfs_dops_invalid :
                              &gpfs_dops_revalidate, true);
        spin_unlock(&child->d_lock);
#else
        set_dentry_operations(child, doInval ? &gpfs_dops_invalid :
                              &gpfs_dops_revalidate, false);
#endif
        if (doInval)
          nInval++;

        TRACE8N(TRACE_VNODE, 4, TRCID_INVAL_NEG_DUNCACHE,
                "cxiInvalidateNegDCacheEntry: ip 0x%lX d_count %d nInval %d "
                  "%s dentry 0x%lX name '%s' d_count %d unhashed %d",
                iP, GET_DENTRY_D_COUNT(dentry), nInval,
                doInval ? "inval" : "reval",
                child, child->d_name.name,
                GET_DENTRY_D_COUNT(child),
                d_unhashed(child));
      }
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&dentry->d_lock);
#endif

    /* If we have accumulated a large number of invalid, negative dcache
       entries, remember to try to get rid of them, so subsequent calls to
       this routine don't have to traverse the same long list again.  We will
       only prune negative dcache entries to avoid complications that might
       arise if one of the dcache entries refers to a deleted file (link count
       zero) or to a subdirectory that contains a deleted file, because that
       might require sending MBInodeDelete msgs to the daemon to complete the
       file destroys.  For the same reason, we avoid pruning altogether, if
       the parent directory itself has link count zero. */
    if (nInval > 64 &&
        nInval > pruneTarget &&
        iP->i_nlink > 0)
    {
      pruneTarget = nInval;
      pruneParent = dentry;
    }
  }

  if (!pruneTarget)
  {
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&iP->i_lock);
#else
    spin_unlock(&dcache_lock);
#endif
  }
  else
  {
    TRACE3N(TRACE_VNODE, 4, TRCID_INVAL_NEG_DPRUNE,
            "cxiInvalidateNegDCacheEntry: pruning parent 0x%lX d_count %d "
              "target %d",
            pruneParent, GET_DENTRY_D_COUNT(pruneParent), pruneTarget);

#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&pruneParent->d_lock);
    dlockHeld = true;
    dget_dlock(pruneParent);
#else
    dget_locked(pruneParent);
#endif
    cHeadP = &pruneParent->d_subdirs;
    prunePending = NULL;
    for (cListP = cHeadP->next;
         cListP != cHeadP && pruneTarget > 0;
         cListP = cListP->next)
    {
      child = list_entry(cListP, struct dentry, d_child);
      if (child->d_inode == NULL && child->d_op == &gpfs_dops_invalid)
      {
        /* We found a candidate; put a hold on it. */
#ifdef DCACHE_LOCK_IS_GONE
        DBGASSERT(dlockHeld);

        spin_lock_nested(&child->d_lock, DENTRY_D_LOCK_NESTED);
        dget_dlock(child);
        spin_unlock(&child->d_lock);
#else
        dget_locked(child);
#endif
        pruneTarget--;

        /* To remove the child, we have to drop the dcache_lock.  Before
           doing so, look for the next candidate and put a hold on it, so we
           have a safe place to resume the list traversal after re-acquiring
           the dcache_lock.  In the meantime, remember the candidate we just
           found in 'prunePending'.  If 'prunePending' already contains a
           candidate we found in a previous loop iteration, now is the time to
           process that pending candidate. */
        if (prunePending)
        {
          Boolean doInval = (prunePending->d_parent == pruneParent &&
                             prunePending->d_inode == NULL &&
                             prunePending->d_op == &gpfs_dops_invalid);
#ifdef DCACHE_LOCK_IS_GONE
          spin_unlock(&pruneParent->d_lock);
          dlockHeld = false;
          spin_unlock(&iP->i_lock);
#else
          spin_unlock(&dcache_lock);
#endif
          TRACE2(TRACE_VNODE, 4, TRCID_DISCARD_NEG_DCACHE1,
                 "cxiInvalidateNegDCacheEntry: dentry 0x%lX discarding %d",
                 prunePending, doInval);
          if (doInval)
            d_invalidate(prunePending);
          dput(prunePending);
          prunePending = NULL;
#ifdef DCACHE_LOCK_IS_GONE
          spin_lock(&iP->i_lock);
#else
          spin_lock(&dcache_lock);
#endif

          /* Since we put a hold on the child, it should not have been
             removed, but as a sanity check, verify it's still attached to
             the same parent. */
          if (child->d_parent != pruneParent || list_empty(&child->d_child))
          {
            prunePending = child;  // arrange for dput
            break;
          }
#ifdef DCACHE_LOCK_IS_GONE
          spin_lock(&pruneParent->d_lock);
          dlockHeld = true;
#endif
        }

        prunePending = child;
      }
    }
#ifdef DCACHE_LOCK_IS_GONE
    if (dlockHeld)
      spin_unlock(&pruneParent->d_lock);
#endif

    /* Process the last candidate we found */
    if (prunePending)
    {
      Boolean doInval = (prunePending->d_parent == pruneParent &&
                         prunePending->d_inode == NULL &&
                         prunePending->d_op == &gpfs_dops_invalid);
#ifdef DCACHE_LOCK_IS_GONE
      spin_unlock(&iP->i_lock);
#else
      spin_unlock(&dcache_lock);
#endif
      TRACE2(TRACE_VNODE, 4, TRCID_DISCARD_NEG_DCACHE2,
             "cxiInvalidateNegDCacheEntry: dentry 0x%lX discarding %d",
             prunePending, doInval);
      if (doInval)
        d_invalidate(prunePending);
      dput(prunePending);
      prunePending = NULL;
    }
    else
#ifdef DCACHE_LOCK_IS_GONE
      spin_unlock(&iP->i_lock);
#else
      spin_unlock(&dcache_lock);
#endif

    /* release the hold on the parent */
    dput(pruneParent);
  }

  EXIT(0);
  return refCount;
}

/* dentry_operations */

/* The d_revalidate function is expected to check whether the directory entry
 * cached in the given dentry struct is still valid.  
 */
#ifdef NAMEIDATA_REPLACED
int
gpfs_d_invalid(struct dentry *dentry, unsigned int flags)
#else /* LINUX_KERNEL_VERSION < 3060000 */
int
gpfs_d_invalid(struct dentry *dentry, struct nameidata *ni)
#endif
{
  TRACE3(TRACE_VNODE, 4, TRCID_DIR_001,
         "gpfs_d_invalid: dentry 0x%lX d_inode 0x%lX name '%s' is invalid",
         dentry, dentry->d_inode, dentry->d_name.name);
  return false;
}

#ifdef NAMEIDATA_REPLACED
int
gpfs_d_valid(struct dentry *dentry, unsigned int flags)
#else
int
gpfs_d_valid(struct dentry *dentry, struct nameidata *ni)
#endif
{
  TRACE3(TRACE_VNODE, 5, TRCID_D_VALID,
         "gpfs_d_valid: dentry 0x%lX d_inode 0x%lX name '%s' is valid",
         dentry, dentry->d_inode, dentry->d_name.name);
  return true;
}

#ifdef NAMEIDATA_REPLACED
int
gpfs_d_revalidate(struct dentry *dentry, unsigned int flags)
#else
int
gpfs_d_revalidate(struct dentry *dentry, struct nameidata *ni)
#endif
{
  int rc = 0;
  cxiNode_t *dcnP = NULL;
  cxiNode_t *cnP = NULL;
  struct dentry *dparentP;
  struct inode *diP = NULL;
  struct inode *newInodeP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct dentry *retP = NULL;
  UInt32 intent;
#ifdef GPFS_CACHE
  Boolean revalNeeded = false;
#endif

#ifdef RCU_WALK_FOR_PATH_LOOKUP
#ifdef NAMEIDATA_REPLACED
  if (flags & LOOKUP_RCU)
#else
  if (ni && (ni->flags & LOOKUP_RCU))
#endif
    return -ECHILD;
#endif

  ENTER(0);
  TRACE6(TRACE_VNODE, 4, TRCID_DIR_REVALIDATE,
         "gpfs_d_revalidate enter: dentry 0x%lX "
         "d_inode 0x%lX inum %lld parent 0x%lX cwd 0x%lX d_name '%s'",
         dentry, dentry->d_inode,
         dentry->d_inode ? dentry->d_inode->i_ino : INVALID_INODE_NUMBER,
         dentry->d_parent, TASK_PWD(current), dentry->d_name.name);

  /* We're going to need to revalidate this according to its name.
   * The scenario that caused us problems is:
   *  
   *   Node a) mkdir dir1; touch dir1/file1
   *   Node b) mv dir1 dir2
   *   Node a) ls -al dir1
   *
   * This code used to just revalidate the inode (gpfs_i_revalidate)
   * which would succeed since the dir1 inode is indeed still valid.
   * However its name has now changed to dir2 and thus this lookup
   * with its last known name is performed.  We don't perform this
   * lookup for the root inode.  We didn't have to do this before
   * RH 2.4.18-5 (unusual fix for NFS is in that kernel) but now 
   * we have to go thru these machinations.  Most of this is a 
   * tradeoff and doesn't give exactly correct semantics.  
   *
   * For instance normally on a local node directory rename the dentry
   * gets moved over to its new position via d_move.  However in our 
   * case we don't know what the new name is since we've just lost 
   * the token and have no other info.  If a process is sitting in this
   * renamed directory structure then it has to remain valid for that
   * process but none other.  We unhash the directory so no other 
   * process can step into that subtree but continue to say its valid
   * if (d_count > 1).  At that point the only process calling d_revalidate
   * would be a process with it's current working directory in that 
   * subtree.  However this breaks down if the process needs to back
   * up into a parent directory, since d_revalidate starts from outside
   * the renamed subtree and can't proceed into the unhashed directory.
   * Thus you get an odd 
   *   getcwd: cannot access parent directories: No such file or directory
   * ancillary message but you can cd backwards correctly.
   *
   * Another idea attempted was looking at the process' cwd in the 
   * task struct and answering whether the dentry was valid on a 
   * per process basis.  This gave odd semantics because a process
   * could list the parent directory and not see the renamed child
   * but could still cd into it (because it was still hashed).  That
   * breaks down completely if another node makes a directory of the
   * old name in the parent.
   *
   * So if we can't use d_move...which it doesn't appear possible to
   * do, at a minimum you have to unhash the directory if it no 
   * longer has the correct name or inode.  
   *
   * Note that once a process steps out of the renamed dentry then
   * the final dput will kill the dentry.
   */
  if (dentry->d_inode != NULL &&
      dentry->d_inode->i_ino != INODENUM_ROOTDIR_FILE)
  {
    rc = getCred(&eCred, &eCredP);
    if (rc)
      goto xerror;

    privVfsP = VP_TO_PVP(dentry->d_inode);
    DBGASSERT(privVfsP != NULL);

    dparentP = dget_parent(dentry);
    LOGASSERT(dparentP != NULL);
    diP = dparentP->d_inode;
    dcnP = VP_TO_CNP(diP);

#ifdef NAMEIDATA_REPLACED
    intent = LOOKUP_FLAGS_TO_INTENT(flags);
#else
    intent = (ni != NULL) ? LOOKUP_FLAGS_TO_INTENT(ni->flags) : 0;
#endif
    rc = gpfs_ops.gpfsLookup(privVfsP, (void *)diP, dcnP,
                             NULL, NULL, (char *)dentry->d_name.name,
                             intent, (void **)&newInodeP, &cnP, &iNum,
                             NULL, NULL, eCredP, IS_CASE_SENSITIVE(),
                             (void **)&retP, NULL, NULL, NULL);
    if (rc == 0)
    {
#ifdef GPFS_CACHE
      revalNeeded = TestCtFlag(cnP, revalidateNeeded);
#endif
      iput(newInodeP);

      if (iNum != dentry->d_inode->i_ino)
        rc = ESTALE;
    }

    /* The name is either no longer valid or has been renamed
     * and recreated with a different inode.  We need to drop
     * the dentry from the hash list so another process can't 
     * proceed into that tree.
     */
    if (rc)
    {
      DENTRY_D_DROP(dentry);

      d_prune_aliases(dentry->d_inode);

      /* If the dentry still has processes sitting underneath
       * it we'll still claim its valid.
       */
      if (GET_DENTRY_D_COUNT(dentry) > 1)
        rc = 0;
    }
    dput(dparentP);
  }

  if (rc == 0)
    rc = gpfs_i_revalidate(dentry);


xerror:
  putCred(&eCred, &eCredP);

  if (rc == 0)
#ifdef GPFS_CACHE
    /* We still want to continue revalidating for pcache to detect home changes */
    if (!revalNeeded)
#endif
      set_dentry_operations(dentry, &gpfs_dops_valid_with_reval, false);

  TRACE2(TRACE_VNODE, 4, TRCID_DIR_REVALIDATE_EX,
         "gpfs_d_revalidate exit: dentry 0x%lX rc %d\n",
         dentry, rc);
  EXIT(0);
  if (rc)
    return false;
  else
    return true;
}

/* The d_revalidate function checks whether the directory entry
   cached in the given dentry struct is still valid.
   Any dentry referencing this operation is
   a positive dentry that was created for
   an inexact caseless file name match for a Samba client.
   The d_revalidate returns "true" for subsequent Samba clients
   indicating that the positive dcache entry is still valid.
   It returns "false" for local or NFS clients indicating
   that the dcache entry is no longer valid which forces
   a new lookup. */
#ifdef NAMEIDATA_REPLACED
int
gpfs_d_valid_if_Samba(struct dentry *dentry, unsigned int flags)
#else
int
gpfs_d_valid_if_Samba(struct dentry *dentry, struct nameidata *ni)
#endif
{
  TRACE4(TRACE_VNODE, 4, TRCID_DIR_VALID_IF_SAMBA,
         "gpfs_d_valid_if_Samba: dentry 0x%lX "
           "d_inode 0x%lX (name '%s') returns %s\n",
         dentry, dentry->d_inode, dentry->d_name.name,
         (cxiIsSambaThread() ? "true" : "false"));
  return cxiIsSambaThread();
}

/* The d_revalidate function checks whether the directory entry
   cached in the given dentry struct is still valid.
   Any dentry referencing this operation is
   a negative dentry that was created for
   an exact file name match which failed for a local or NFS client.
   The d_revalidate returns "true" for subsequent local or NFS clients
   indicating that the negative dcache entry is still valid.
   It returns "false" for Samba clients indicating
   that the dcache entry is no longer valid which forces
   a new lookup. */
#ifdef NAMEIDATA_REPLACED
int
gpfs_d_invalid_if_Samba(struct dentry *dentry, unsigned int flags)
#else
int
gpfs_d_invalid_if_Samba(struct dentry *dentry, struct nameidata *ni)
#endif
{
  TRACE4(TRACE_VNODE, 4, TRCID_DIR_INVALID_IF_SAMBA,
         "gpfs_d_invalid_if_Samba: dentry 0x%lX "
           "d_inode 0x%lX (name '%s') returns %s\n",
         dentry, dentry->d_inode, dentry->d_name.name,
         (cxiIsSambaThread() ? "false" : "true"));
  return !cxiIsSambaThread();
}
