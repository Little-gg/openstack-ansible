/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)66       1.37  src/avs/fs/mmfs/ts/kernext/gpl-linux/ktrccalls.c, mmfs, avs_rfks0, rfks01416c 1/10/14 13:00:04 */

/*
 * Common kernel trace functions
 *
 * Contents:
 *   __readCycleCounter
 *   getCPUId_ltrc
 *
 *   DTRACE_BLOCKING_PREFIX
 *   DTRACE_BLOCKING_COPY
 *   DTRACE_BLOCKING_SUFFIX
 *   _DTrace0Blocking
 *   _DTrace1Blocking
 *   _DTrace2Blocking
 *   _DTrace3Blocking
 *   _DTrace4Blocking
 *   _DTrace5Blocking
 *   _DTrace6Blocking
 *   _DTrace7Blocking
 *   _DTrace8Blocking
 *   _DTrace9Blocking
 *   _DTrace10Blocking
 *   _DTrace11Blocking
 *   _DTrace12Blocking
 *   _DTrace13Blocking
 *   _DTrace14Blocking
 *   _kTraceMemcpy
 *   STRACE_BLOCKING_BODY
 *   _STraceBlocking
 *   _STraceBlockingNB
 *
 *   DTRACE_PREFIX
 *   DTRACE_COPY
 *   DTRACE_SUFFIX
 *   insertTODTrace
 *   kAssignSharedBufferSpace
 *   _DTrace0
 *   _DTrace1
 *   _DTrace2
 *   _DTrace3
 *   _DTrace4
 *   _DTrace5
 *   _DTrace6
 *   _DTrace7
 *   _DTrace8
 *   _DTrace9
 *   _DTrace10
 *   _DTrace11
 *   _DTrace12
 *   _DTrace13
 *   _DTrace14
 *
 *   STRACE_BODY
 *   _STrace
 *   _STraceNB
 *
 *   _XTrace
 *   _XTraceNB
 */

#ifndef GPFS_PRINTF

#ifndef __KERNEL__
#  define __KERNEL__
#endif

#ifdef GPFS_LINUX

#ifndef GPL_KBUILD
/* We have to define __SMALL_STACK for s390x kernels with 8K stacks, otherwise
   THREAD_SIZE will be set wrong. Without a correct THREAD_SIZE, in_interrupt()
   will return wrong results.
   Since we use our own build environment we have to do this by ourself. The
   kernel configuration is automatically included via -include when compiling
   this source file. */
#if defined(GPFS_ARCH_S390X) && defined(CONFIG_SMALL_STACK)
#  define __SMALL_STACK
#endif
#endif /* GPL_KBUILD */

#include <Shark-gpl.h>

#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/slab.h>
#include <stdarg.h>
#include <linux/string.h>

#include <Trace.h>
#include <lxtrace.h>
#include <verdep.h>
#include <cxiAtomic.h>

extern void rl_trc_write(const char *bufP, size_t nBytes, int nb);
extern int isRLEnabled();

#if LINUX_KERNEL_VERSION > 2060900
#include <linux/hardirq.h>
#else
#include <asm/hardirq.h>
#endif  /* LINUX_KERNEL_VERSION */
#endif  /* GPFS_LINUX */

/* Macro to compute the ceiling of the quotient of X and Y */
#define DIVROUND(X,Y) ( ((X)+(Y)-1) / (Y) )

/* Macro to round integer X up to the next integral multiple of integer Y */
#define ROUNDUP(X,Y) ( (Y) * ( ((X)+(Y)-1) / (Y) ) )


/* Global variables exported from tracelin.c */
extern TraceGBLS_t KTrace;
TraceRecord_t DummyKernelTraceRecord;

/* Function to allocate a new buffer segment for overwrite mode */
extern int getBufferSegmentInternal(int trStreamIdx);


/* Get the current clock cycle count. Duplicated in tracelin.c */
static inline UInt64 __readCycleCounter()
{
#if defined(GPFS_ARCH_X86_64)
  UInt32 low, high;
  __asm__ __volatile__("rdtsc" : "=a" (low), "=d" (high));
  return (low | ((UInt64)(high) << 32));
#elif defined(GPFS_ARCH_PPC64) 
  UInt64 val;
  __asm__ __volatile__("mftb %0" : "=r" (val));
  return val;
#elif defined(GPFS_ARCH_S390X)
  UInt64 val;
  __asm__ __volatile__("stck 0(%1)" : "=m" (val) : "a" (&val) : "cc");
  return val;
#else
  #error "Can't get CPU count for this linux architecture"
#endif  /* GPFS_ARCH_X86_64 */
}

#define rdtscall(val) \
  ((val) = __readCycleCounter())


/* Get the current CPU ID that the current process is running on */
#define INITIAL_APIC_ID_BITS 0xFF000000
inline UChar getCPUId_ltrc()
{
#if defined(GPFS_ARCH_X86_64)
  UInt32 x = 0;
  __asm__ __volatile__ ("movl $1, %%eax;"
                        "cpuid;"
                        "movl %%ebx, %0;"
                        :"=r"(x)
                        :
                        :"%eax", "%ebx", "%ecx", "%edx"
                        );
  return (UChar) ((x & INITIAL_APIC_ID_BITS) >> 24);
#else
  return 0;
#endif  /* GPFS_ARCH_X86_64 */
}


/* The following macros are used to form the bodies of the functions
   named _DTrace<n>Blocking */

#define DTRACE_BLOCKING_PREFIX(_n)                        \
  const int nArgs = (_n);                                 \
  int trRecLen;                                           \
  struct kArgs args;                                      \
  TraceRecord_t tr;                                       \
                                                          \
  if (! isRLEnabled())                                    \
    return;                                               \
                                                          \
  /* Initialize trace header */                           \
  tr.dHdr.trHook = hookword;                              \
  tr.dHdr.trNArgs = nArgs;                                \
  tr.dHdr.trSPos = _TR_FORMAT_I;                          \
  tr.dHdr.trSLen = 0;

#define DTRACE_BLOCKING_COPY(_n) tr.dataWords[(_n)-1] = a##_n

#define DTRACE_BLOCKING_SUFFIX()                          \
  trRecLen = sizeof(trc_datahdr_t) + nArgs*ARGLEN;        \
  rl_trc_write((const char*)&tr.dHdr, trRecLen, 0);


/* Trace functions used in blocking mode that take only integer arguments */

static void _DTrace0Blocking(int hookword)
{
  DTRACE_BLOCKING_PREFIX(0);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace1Blocking(int hookword, Int64 a1)
{
  DTRACE_BLOCKING_PREFIX(1);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace2Blocking(int hookword, Int64 a1, Int64 a2)
{
  DTRACE_BLOCKING_PREFIX(2);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace3Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3)
{
  DTRACE_BLOCKING_PREFIX(3);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace4Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                             Int64 a4)
{
  DTRACE_BLOCKING_PREFIX(4);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace5Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                             Int64 a4, Int64 a5)
{
  DTRACE_BLOCKING_PREFIX(5);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace6Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                             Int64 a4, Int64 a5, Int64 a6)
{
  DTRACE_BLOCKING_PREFIX(6);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace7Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                             Int64 a4, Int64 a5, Int64 a6, Int64 a7)
{
  DTRACE_BLOCKING_PREFIX(7);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace8Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                             Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8)
{
  DTRACE_BLOCKING_PREFIX(8);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace9Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                             Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8,
                             Int64 a9)
{
  DTRACE_BLOCKING_PREFIX(9);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_COPY(9);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace10Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                              Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8,
                              Int64 a9, Int64 a10)
{
  DTRACE_BLOCKING_PREFIX(10);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_COPY(9);
  DTRACE_BLOCKING_COPY(10);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace11Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                              Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8,
                              Int64 a9, Int64 a10, Int64 a11)
{
  DTRACE_BLOCKING_PREFIX(11);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_COPY(9);
  DTRACE_BLOCKING_COPY(10);
  DTRACE_BLOCKING_COPY(11);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace12Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                              Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8,
                              Int64 a9, Int64 a10, Int64 a11, Int64 a12)
{
  DTRACE_BLOCKING_PREFIX(12);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_COPY(9);
  DTRACE_BLOCKING_COPY(10);
  DTRACE_BLOCKING_COPY(11);
  DTRACE_BLOCKING_COPY(12);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace13Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                              Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8,
                              Int64 a9, Int64 a10, Int64 a11, Int64 a12,
                              Int64 a13)
{
  DTRACE_BLOCKING_PREFIX(13);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_COPY(9);
  DTRACE_BLOCKING_COPY(10);
  DTRACE_BLOCKING_COPY(11);
  DTRACE_BLOCKING_COPY(12);
  DTRACE_BLOCKING_COPY(13);
  DTRACE_BLOCKING_SUFFIX();
}

static void _DTrace14Blocking(int hookword, Int64 a1, Int64 a2, Int64 a3,
                              Int64 a4, Int64 a5, Int64 a6, Int64 a7, Int64 a8,
                              Int64 a9, Int64 a10, Int64 a11, Int64 a12,
                              Int64 a13, Int64 a14)
{
  DTRACE_BLOCKING_PREFIX(13);
  DTRACE_BLOCKING_COPY(1);
  DTRACE_BLOCKING_COPY(2);
  DTRACE_BLOCKING_COPY(3);
  DTRACE_BLOCKING_COPY(4);
  DTRACE_BLOCKING_COPY(5);
  DTRACE_BLOCKING_COPY(6);
  DTRACE_BLOCKING_COPY(7);
  DTRACE_BLOCKING_COPY(8);
  DTRACE_BLOCKING_COPY(9);
  DTRACE_BLOCKING_COPY(10);
  DTRACE_BLOCKING_COPY(11);
  DTRACE_BLOCKING_COPY(12);
  DTRACE_BLOCKING_COPY(13);
  DTRACE_BLOCKING_COPY(14);
  DTRACE_BLOCKING_SUFFIX();
}


/* Copy memory.  Used to copy strings into the trace buffer.  The target
   will always be aligned on a word boundary, and the source string is
   likely to be aligned.  The length will be strlen+1, rounded up to a
   multiple of the word size.  Copy a word at a time if possible. */
static inline void _kTraceMemcpy(ARGTYPE* targetP, const char* sourceP,
                                 int roundedLen)
{
  const ARGTYPE* sourceWordP;
  char* targetCharP;

  /* If source is aligned on a word boundary, copy by words */
  if ((((IntPtr)sourceP) & (ARGLEN-1)) == 0)
  {
    sourceWordP = (const ARGTYPE*)sourceP;
    while (roundedLen >= ARGLEN)
    {
      *targetP = *sourceWordP;
      targetP += 1;
      sourceWordP += 1;
      roundedLen -= ARGLEN;
    }
  }

  /* Otherwise, copy by bytes */
  else
  {
    targetCharP = (char*)targetP;
    while (roundedLen > 0)
    {
      *targetCharP = *sourceP;
      targetCharP += 1;
      sourceP += 1;
      roundedLen -= 1;
    }
  }

  /* The caller will add the NUL terminator */
}


/* Code that appears in both _STraceBlocking and _STraceBlockingNB */
#define STRACE_BLOCKING_BODY()                                              \
  ARGTYPE tmpint;                                                           \
  char *p;                                                                  \
  const char* strP;                                                         \
  int i, len;                                                               \
  int stringLen;                                                            \
  int trRecLen;                                                             \
  struct kArgs args;                                                        \
  TraceRecord_t tr;                                                         \
                                                                            \
  if (in_interrupt())                                                       \
    return;                                                                 \
                                                                            \
  /* Initialize trace header */                                             \
  tr.dHdr.trHook = hookword;                                                \
  tr.dHdr.trNArgs = nArgs;                                                  \
  tr.dHdr.trSPos = pos;                                                     \
  tr.dHdr.trSLen = 0;                                                       \
                                                                            \
  p = (char*)&tr.dataWords[0];                                              \
  len = 0;                                                                  \
                                                                            \
  /* Append arguments */                                                    \
  if (pos < LXTRACE_MAX_FORMAT_SUBS)                                        \
  {                                                                         \
    /* Items (if any) preceeding the string argument */                     \
    for (i=0; i<pos; i++)                                                   \
    {                                                                       \
      tmpint = va_arg(vargs, ARGTYPE);                                      \
      cxiMemcpy(p, &tmpint, ARGLEN);                                        \
      p += ARGLEN;                                                          \
      len += ARGLEN;                                                        \
    }                                                                       \
                                                                            \
    /* Copy the string, making sure it does not overflow the buffer */      \
    strP = va_arg(vargs, char*);                                            \
    if (strP < (char*)4096)                                                 \
    {                                                                       \
      if (strP == NULL)                                                     \
        strP = "(NULL)";                                                    \
      else                                                                  \
        strP = "<bad address>";                                             \
    }                                                                       \
    stringLen = strlen(strP);                                               \
    stringLen = MIN(stringLen,                                              \
                    sizeof(tr.dataWords) - (nArgs*ARGLEN) - 1 - (ARGLEN-1));\
    cxiMemcpy(p, strP, stringLen);                                          \
    p[stringLen] = '\0';                                                    \
    tr.dHdr.trSLen = ROUNDUP(stringLen+1, ARGLEN);                          \
    p += tr.dHdr.trSLen;                                                    \
    len += tr.dHdr.trSLen;                                                  \
                                                                            \
    /* Append items following string argument */                            \
    for (i=pos; i<nArgs; i++)                                               \
    {                                                                       \
      tmpint = va_arg(vargs, ARGTYPE);                                      \
      cxiMemcpy(p, &tmpint, ARGLEN);                                        \
      p += ARGLEN;                                                          \
      len += ARGLEN;                                                        \
    }                                                                       \
  }                                                                         \
  else /* !IS_SFORMAT */                                                    \
  {                                                                         \
    /* Place the fixed parameters in the temporary trace buffer */          \
    for (i=0; i<nArgs; i++)                                                 \
    {                                                                       \
      tmpint = va_arg(vargs, ARGTYPE);                                      \
      cxiMemcpy(p, &tmpint, ARGLEN);                                        \
      p += ARGLEN;                                                          \
      len += ARGLEN;                                                        \
    }                                                                       \
  }                                                                         \
                                                                            \
  if (pos == _TR_FORMAT_F)                                                  \
  {                                                                         \
    /* Although the argument is really a double, don't tell the compiler,   \
       so that it will not generate code using floating point hardware      \
       that is not supposed to be used in the kernel. */                    \
    /* double tmpdbl = va_arg(vargs, double); */                            \
    unsigned long long tmpdbl = va_arg(vargs, unsigned long long);          \
                                                                            \
    /* Append the float argument */                                         \
    cxiMemcpy(p, &tmpdbl, sizeof(tmpdbl));                                  \
    p += sizeof(tmpdbl);                                                    \
    len += sizeof(tmpdbl);                                                  \
  }                                                                         \
  trRecLen = HDRSIZE + len;


/* Inner function to do string tracing when in blocking mode.  Allowed to
   block.  */
static void _STraceBlocking(int hookword, int nArgs, UInt32 pos, va_list vargs)
{
  STRACE_BLOCKING_BODY();
  rl_trc_write((const char*)&tr.dHdr, trRecLen, 0);
}


/* Inner function to do string tracing when in blocking mode.  Not
   allowed to block.  */
static void _STraceBlockingNB(int hookword, int nArgs, UInt32 pos,
                              va_list vargs)
{
  STRACE_BLOCKING_BODY();
  rl_trc_write((const char*)&tr.dHdr, trRecLen, 1);
}


/* The following macros are used to form the bodies of the functions
   named _DTrace<n> */

#define DTRACE_PREFIX(_n)                                     \
  if (in_interrupt())                                         \
    /* Cannot trace from interrupt handler because */         \
    /* current->pid not available */                          \
    return;                                                   \
  if (KTrace.tMode == TRACE_OVERWRITE)                        \
  {                                                           \
    const int nArgs = (_n);                                   \
    TraceRecord_t* recP;                                      \
    int trRecLen = HDRSIZE + nArgs*sizeof(Int64);             \
                                                              \
    recP = kAssignSharedBufferSpace(trRecLen);                \
    recP->oHdr.oMagic = LXTRACE_OVERWRITE_MAGIC;              \
    recP->oHdr.oLength = trRecLen;                            \
    recP->oHdr.oProcess = current->pid;                       \
    recP->dHdr.trHook = hookword;                             \
    recP->dHdr.trNArgs = nArgs;                               \
    recP->dHdr.trSPos = _TR_FORMAT_I;                         \
    recP->dHdr.trSLen = 0  /* no semicolon */

#define DTRACE_COPY(_n) recP->dataWords[(_n)-1] = a##_n

#define DTRACE_SUFFIX()                                       \
    return;                                                   \
  }


/* Returns a pointer to a contiguous area within the shared trace buffer
   capable of holding a trace record of the indicated size.  Fills in
   the timestamp within the area assigned.  If the space remaining in
   the currently assigned trace buffer segment is not large enough to
   hold the new trace record, this function will first append a dummy
   record to use up the remaining space, then obtain a fresh buffer
   segment so it can return contiguous space starting at the beginning
   of the new buffer segment.

   Also inserts TOD records at regular intervals. */
TraceRecord_t* kAssignSharedBufferSpace(int bytesNeeded)
{
  SharedTraceBufferHeader_t* trbP;
  TrStreamDesc_t* streamP;
  TraceSegmentHdr_t* segP;
  TraceRecord_t* recP;
  TrcSegmentIdxAndOffset_t segIdxAndOffset;
  UInt32 currentSegmentIndex;
  UInt32 relOffset;
  int reserveLen;
  int trStreamIdx;
  int rc;

  /* Round trace record size up to an even boundary */
  reserveLen = ROUNDUP(bytesNeeded, TRACE_ROUND);
  trbP = (SharedTraceBufferHeader_t*)KTrace.tBufferBaseP;

  /* Loop until space for the current record can be acquired */
  for (;;)
  {
    /* Locate the descriptor of the stream to be used by this trace entry */
#if 1
    trStreamIdx = smp_processor_id() % N_KERNEL_TRACE_STREAMS;
#else
    trStreamIdx = current->pid % N_KERNEL_TRACE_STREAMS;
#endif
    streamP = &trbP->trbStream[trStreamIdx];

    /* Increment the append pointer for the selected stream and cache
       the segment index and offset within the current assigned
       segment where the next trace record should be appended.  Does
       not use ATOMIC_ADDLP on pLinux because fetch_and_addlp uses
       cxiSafeGetLong, which is not defined in tracedev.ko. */
#ifdef GPFS_ARCH_X86_64
    segIdxAndOffset = ATOMIC_ADDLP(&streamP->stSegmentAndOffset, reserveLen);
    currentSegmentIndex = TRCWORD_2_INDEX(segIdxAndOffset);
    relOffset = TRCWORD_2_OFFSET(segIdxAndOffset);
#else
    segIdxAndOffset = streamP->stSegmentAndOffset;
    for (;;)
    {
      UInt32 newOffset;
      TrcSegmentIdxAndOffset_t newSegIdxAndOffset;
      Boolean csSuccess;

      /* Calculate what the new offset would be after appending the
         requested size */
      currentSegmentIndex = TRCWORD_2_INDEX(segIdxAndOffset);
      relOffset = TRCWORD_2_OFFSET(segIdxAndOffset);
      newOffset = relOffset + reserveLen;
      newSegIdxAndOffset = IDX_AND_OFFSET_2_TRCWORD(currentSegmentIndex, newOffset);

      /* Attempt the offset increment */
      csSuccess = ATOMIC_SWAP64((atomic_p)&streamP->stSegmentAndOffset,
                                &segIdxAndOffset, newSegIdxAndOffset);
      if (csSuccess)
        break;
    }
#endif

    /* Calculate the address of where to place the next trace record.
       Note that we have not yet checked that currentSegmentIndex is
       valid, so it is possible that the record address being computed
       is garbage.  However, if there is no buffer segment assigned to
       the current stream then relOffset will be set such that we will
       call getBufferSegmentInternal to obtain a buffer segment. */
    segP = &trbP->trbSegSpace[currentSegmentIndex].segHdr;
    recP = (TraceRecord_t*) ((char*)segP + relOffset);

    /* If there is enough room in the current buffer segment to hold
       the new trace record and at least the header of a filler record,
       timestamp the new trace record, and return its address to the
       caller.  Note that if there is exactly enough space to hold the
       new record, but not enough space for a filler record, this will
       fall into the code to get a new segment.  This guarantees that
       all retired segments contain filler records, and therefore that
       segFillerTimestamp is always set for such segments. */
    if (relOffset + reserveLen <=
        TRACE_BUFFER_SEGMENT_BYTES - MIN_TRACE_RECORD)
    {
      rdtscall(recP->oHdr.oTime);
      return recP;
    }

    /* Current record does not fit */

    /* If there was any room at all in the current segment, build a filler
       record to use up all remaining space.  Record the timestamp of
       this filler record in the segment header. */
    if (relOffset <= TRACE_BUFFER_SEGMENT_BYTES-MIN_TRACE_RECORD)
    {
      rdtscall(recP->oHdr.oTime);
      segP->segFillerTimestamp = recP->oHdr.oTime;
      recP->oHdr.oMagic = LXTRACE_OVERWRITE_MAGIC;
      recP->oHdr.oLength = TRACE_BUFFER_SEGMENT_BYTES - relOffset;
      recP->oHdr.oProcess = current->pid;
      recP->dHdr.trHook = LXTRACE_FILLER;
      recP->dHdr.trNArgs = 0;
      recP->dHdr.trSPos = _TR_FORMAT_I;
      recP->dHdr.trSLen = 0;
    }

    /* Assign a new segment to this stream.  Return the address of a
       dummy static trace record if anything goes wrong, so that callers
       do not have to check for success of this function. */
    rc = getBufferSegmentInternal(trStreamIdx);
    if (rc != 0)
      return &DummyKernelTraceRecord;
  }  /* end of loop to find space for a trace record */
}


void _DTrace0(int hookword)
{
  DTRACE_PREFIX(0);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace0Blocking(hookword);
}

void _DTrace1(int hookword, Int64 a1)
{
  DTRACE_PREFIX(1);
  DTRACE_COPY(1);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace1Blocking(hookword, a1);
}

void _DTrace2(int hookword, Int64 a1, Int64 a2)
{
  DTRACE_PREFIX(2);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace2Blocking(hookword, a1, a2);
}

void _DTrace3(int hookword, Int64 a1, Int64 a2, Int64 a3)
{
  DTRACE_PREFIX(3);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace3Blocking(hookword, a1, a2, a3);
}

void _DTrace4(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4)
{
  DTRACE_PREFIX(4);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace4Blocking(hookword, a1, a2, a3, a4);
}

void _DTrace5(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5)
{
  DTRACE_PREFIX(5);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace5Blocking(hookword, a1, a2, a3, a4, a5);
}

void _DTrace6(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
              Int64 a6)
{
  DTRACE_PREFIX(6);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace6Blocking(hookword, a1, a2, a3, a4, a5, a6);
}

void _DTrace7(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
              Int64 a6, Int64 a7)
{
  DTRACE_PREFIX(7);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace7Blocking(hookword, a1, a2, a3, a4, a5, a6, a7);
}

void _DTrace8(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
              Int64 a6, Int64 a7, Int64 a8)
{
  DTRACE_PREFIX(8);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace8Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8);
}

void _DTrace9(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
              Int64 a6, Int64 a7, Int64 a8, Int64 a9)
{
  DTRACE_PREFIX(9);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_COPY(9);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace9Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8, a9);
}

void _DTrace10(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
               Int64 a6, Int64 a7, Int64 a8, Int64 a9, Int64 a10)
{
  DTRACE_PREFIX(10);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_COPY(9);
  DTRACE_COPY(10);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace10Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10);
}

void _DTrace11(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
               Int64 a6, Int64 a7, Int64 a8, Int64 a9, Int64 a10, Int64 a11)
{
  DTRACE_PREFIX(11);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_COPY(9);
  DTRACE_COPY(10);
  DTRACE_COPY(11);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace11Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11);
}

void _DTrace12(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
               Int64 a6, Int64 a7, Int64 a8, Int64 a9, Int64 a10, Int64 a11,
               Int64 a12)
{
  DTRACE_PREFIX(12);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_COPY(9);
  DTRACE_COPY(10);
  DTRACE_COPY(11);
  DTRACE_COPY(12);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace12Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10,
                      a11, a12);
}

void _DTrace13(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
               Int64 a6, Int64 a7, Int64 a8, Int64 a9, Int64 a10, Int64 a11,
               Int64 a12, Int64 a13)
{
  DTRACE_PREFIX(13);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_COPY(9);
  DTRACE_COPY(10);
  DTRACE_COPY(11);
  DTRACE_COPY(12);
  DTRACE_COPY(13);
  DTRACE_SUFFIX();
  if (KTrace.tMode == TRACE_BLOCKING)
    _DTrace13Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10,
                      a11, a12, a13);
}

void _DTrace14(int hookword, Int64 a1, Int64 a2, Int64 a3, Int64 a4, Int64 a5,
               Int64 a6, Int64 a7, Int64 a8, Int64 a9, Int64 a10, Int64 a11,
               Int64 a12, Int64 a13, Int64 a14)
{
  DTRACE_PREFIX(14);
  DTRACE_COPY(1);
  DTRACE_COPY(2);
  DTRACE_COPY(3);
  DTRACE_COPY(4);
  DTRACE_COPY(5);
  DTRACE_COPY(6);
  DTRACE_COPY(7);
  DTRACE_COPY(8);
  DTRACE_COPY(9);
  DTRACE_COPY(10);
  DTRACE_COPY(11);
  DTRACE_COPY(12);
  DTRACE_COPY(13);
  DTRACE_COPY(14);
  DTRACE_SUFFIX();
  _DTrace14Blocking(hookword, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11,
                    a12, a13, a14);
}

/* Code that appears in both _STrace and _STraceNB */
#define STRACE_BODY()                                                      \
  if (KTrace.tMode == TRACE_OVERWRITE)                                     \
  {                                                                        \
    /* Calculate the number of bytes needed to hold the record.  If        \
       there is a string parameter, this will include finding the length   \
       of the string. */                                                   \
    va_list vargs;                                                         \
    const char* strP = NULL;                                               \
    TraceRecord_t* recP;                                                   \
    char* p;                                                               \
    int i;                                                                 \
    int stringLen = 0;                                                     \
    int roundedStringLen = 0;                                              \
    int trRecLen = HDRSIZE + nArgs*ARGLEN; /* not including string or float */ \
    int stringWordLen = 0;                                                 \
    ARGTYPE tmpint;                                                        \
    unsigned long long tmpdbl;                                             \
                                                                           \
    /* If there is a string parameter, it is not included in nArgs.        \
       Adjust required record length. */                                   \
    if (pos < LXTRACE_MAX_FORMAT_SUBS)                                     \
    {                                                                      \
      va_start(vargs, pos);                                                \
      /* Skip parameters before string pointer */                          \
      for (i=0; i<pos; i++)                                                \
        (void)va_arg(vargs, ARGTYPE);                                      \
      strP = va_arg(vargs, const char*);                                   \
      if (strP < (char*)4096)                                              \
      {                                                                    \
        if (strP == NULL)                                                  \
          strP = "(NULL)";                                                 \
        else                                                               \
          strP = "<bad address>";                                          \
      }                                                                    \
      stringLen = cxiStrlen(strP);                                         \
      stringLen = MIN(stringLen,                                           \
                      LXTRACE_MAX_DATA - trRecLen - 1 - (ARGLEN-1));       \
      stringWordLen = DIVROUND(stringLen+1, ARGLEN);                       \
      roundedStringLen = ROUNDUP(stringLen+1, ARGLEN);                     \
      trRecLen += roundedStringLen;                                        \
      va_end(vargs);                                                       \
    }                                                                      \
    else if (pos == _TR_FORMAT_F)                                          \
      trRecLen += sizeof(double);                                          \
                                                                           \
    /* Allocate space to hold the record and fill in its header */         \
    recP = kAssignSharedBufferSpace(trRecLen);                             \
    recP->oHdr.oMagic = LXTRACE_OVERWRITE_MAGIC;                           \
    recP->oHdr.oLength = trRecLen;                                         \
    recP->oHdr.oProcess = current->pid;                                    \
    recP->dHdr.trHook = hookword;                                          \
    recP->dHdr.trNArgs = nArgs;                                            \
    recP->dHdr.trSPos = pos;                                               \
    recP->dHdr.trSLen = roundedStringLen;  /* format needs rounded length */\
                                                                           \
    /* Copy parameters into the shared trace buffer */                     \
    va_start(vargs, pos);                                                  \
    if (pos < LXTRACE_MAX_FORMAT_SUBS)                                     \
    {                                                                      \
      /* Items preceding the string argument */                            \
      for (i=0; i<pos; i++)                                                \
      {                                                                    \
        tmpint = va_arg(vargs, ARGTYPE);                                   \
        recP->dataWords[i] = tmpint;                                       \
      }                                                                    \
                                                                           \
      /* Fetch and discard string pointer; it is already in strP */        \
      (void)va_arg(vargs, char*);                                          \
                                                                           \
      /* Copy string into trace buffer and be sure it is NUL-terminated */ \
      p = (char*)&recP->dataWords[pos];                                    \
      _kTraceMemcpy(&recP->dataWords[pos], strP, roundedStringLen);        \
      p[stringLen] = '\0';                                                 \
                                                                           \
      /* Copy items following the string argument */                       \
      for (i=pos; i<nArgs; i++)                                            \
      {                                                                    \
        tmpint = va_arg(vargs, ARGTYPE);                                   \
        recP->dataWords[i+stringWordLen] = tmpint;                         \
      }                                                                    \
    }                                                                      \
    else                                                                   \
    {                                                                      \
      /* No string parameter; just copy all parameters into the buffer */  \
      for (i=0; i<nArgs; i++)                                              \
      {                                                                    \
        tmpint = va_arg(vargs, ARGTYPE);                                   \
        recP->dataWords[i] = tmpint;                                       \
      }                                                                    \
    }                                                                      \
                                                                           \
    /* If there is a floating-point argument, it must be last.  It         \
       was not included in nArgs, and there cannot also be a string        \
       parameter */                                                        \
    if (pos == _TR_FORMAT_F)                                               \
    {                                                                      \
      /* Although the argument is really a double, don't tell the compiler,\
         so that it will not generate code using floating point hardware   \
         that is not supposed to be used in the kernel. */                 \
      /* tmpdbl = va_arg(vargs, double); */                                \
      tmpdbl = va_arg(vargs, unsigned long long);                          \
      cxiMemcpy((char*)&recP->dataWords[nArgs], &tmpdbl, sizeof(tmpdbl));  \
    }                                                                      \
                                                                           \
    va_end(vargs);                                                         \
    return;                                                                \
  }

/* Trace function that takes nArgs integer arguments and 0 or 1 string
   arguments.  Can block when in  in blocking mode. */
void _STrace(int hookword, int nArgs, UInt32 pos, ...)
{
  if (in_interrupt())
    return;

  STRACE_BODY();

  if (KTrace.tMode == TRACE_BLOCKING)
  {
    va_list vargs;
    va_start(vargs, pos);
    _STraceBlocking(hookword, nArgs, pos, vargs);
    va_end(vargs);
  }
}


/* Trace function that takes nArgs integer arguments and 0 or 1 string
   arguments.  Can never block. */
void _STraceNB(int hookword, int nArgs, UInt32 pos, ...)
{
  if (in_interrupt())
    return;

  STRACE_BODY()  /* ends with 'else', so no semicolon here */

  if (KTrace.tMode == TRACE_BLOCKING)
  {
    va_list vargs;
    va_start(vargs, pos);
    _STraceBlockingNB(hookword, nArgs, pos, vargs);
    va_end(vargs);
  }
}


/* General trace.  Code is identical to _XTraceNB except for the non-blocking
   parameter to rl_trc_write. */
void _XTrace(int hookword, const char *fmt, ...)
{
  TraceRecord_t* recP;
  va_list vargs;
  char* p;
  int stringLen;
  int trRecLen;
  int roundedStringLen;
  struct kArgs args;
  TraceRecord_t tr;

  if (in_interrupt())
    /* Cannot trace from interrupt handler because */
    /* current->pid not available */
    return;

  /* Format data into a local buffer, being careful not to run off the
     end of the buffer */
  va_start(vargs, fmt);
  p = (char*)&tr.dataWords[0];
  stringLen = vsnprintf(p, sizeof(tr.dataWords), fmt, vargs);
  if (stringLen >= sizeof(tr.dataWords))
  {
    p[sizeof(tr.dataWords)-1] = '\0';
    stringLen = sizeof(tr.dataWords) - 1;
  }
  roundedStringLen = ROUNDUP(stringLen+1, ARGLEN);
  trRecLen = HDRSIZE + roundedStringLen;
  va_end(vargs);

  if (KTrace.tMode == TRACE_OVERWRITE)
  {
    /* Allocate space to hold the record and fill in its header */
    recP = kAssignSharedBufferSpace(trRecLen);
    recP->oHdr.oMagic = LXTRACE_OVERWRITE_MAGIC;
    recP->oHdr.oLength = trRecLen;
    recP->oHdr.oProcess = current->pid;
    recP->dHdr.trHook = hookword;
    recP->dHdr.trNArgs = 0;
    recP->dHdr.trSPos = _TR_FORMAT_X;
    recP->dHdr.trSLen = roundedStringLen;  // lxtrace format needs rounded length

    /* Copy the formatted string into the shared buffer.  Since the buffer
       already contains the NUL-terminator, this copy can be done entire
       words at a time using memcpy. */
    _kTraceMemcpy(&recP->dataWords[0], (const char*)&tr.dataWords[0],
                  roundedStringLen);
    return;
  }

  /* Initialize trace header */
  if (KTrace.tMode == TRACE_BLOCKING)
  {
    tr.dHdr.trHook = hookword;
    tr.dHdr.trNArgs = 0;
    tr.dHdr.trSPos = _TR_FORMAT_X;
    tr.dHdr.trSLen = roundedStringLen;

    rl_trc_write((const char*)&tr.dHdr, trRecLen, 0);
  }
}


/* General trace.  Code is identical to _XTrace except for the non-blocking
   parameter to rl_trc_write. */
void _XTraceNB(int hookword, const char *fmt, ...)
{
  TraceRecord_t* recP;
  va_list vargs;
  char* p;
  int stringLen;
  int trRecLen;
  int roundedStringLen;
  struct kArgs args;
  TraceRecord_t tr;

  if (in_interrupt())
    /* Cannot trace from interrupt handler because current->pid not
       available */
    return;

  /* Format data into a local buffer, being careful not to run off the
     end of the buffer */
  va_start(vargs, fmt);
  p = (char*)&tr.dataWords[0];
  stringLen = vsnprintf(p, sizeof(tr.dataWords), fmt, vargs);
  if (stringLen >= sizeof(tr.dataWords))
  {
    p[sizeof(tr.dataWords)-1] = '\0';
    stringLen = sizeof(tr.dataWords) - 1;
  }
  roundedStringLen = ROUNDUP(stringLen+1, ARGLEN);
  trRecLen = HDRSIZE + roundedStringLen;
  va_end(vargs);

  if (KTrace.tMode == TRACE_OVERWRITE)
  {
    /* Allocate space to hold the record and fill in its header */
    recP = kAssignSharedBufferSpace(trRecLen);
    recP->oHdr.oMagic = LXTRACE_OVERWRITE_MAGIC;
    recP->oHdr.oLength = trRecLen;
    recP->oHdr.oProcess = current->pid;
    recP->dHdr.trHook = hookword;
    recP->dHdr.trNArgs = 0;
    recP->dHdr.trSPos = _TR_FORMAT_X;
    recP->dHdr.trSLen = roundedStringLen;  // lxtrace format needs rounded length

    /* Copy the formatted string into the shared buffer.  Since the buffer
       already contains the NUL-terminator, this copy can be done entire
       words at a time using memcpy. */
    _kTraceMemcpy(&recP->dataWords[0], (const char*)&tr.dataWords[0],
                  roundedStringLen);
    return;
  }

  /* Initialize trace header */
  if (KTrace.tMode == TRACE_BLOCKING)
  {
    tr.dHdr.trHook = hookword;
    tr.dHdr.trNArgs = 0;
    tr.dHdr.trSPos = _TR_FORMAT_X;
    tr.dHdr.trSLen = roundedStringLen;

    rl_trc_write((const char*)&tr.dHdr, trRecLen, 1);
  }
}

#endif  /* GPFS_PRINTF */

