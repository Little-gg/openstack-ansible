/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
#ifndef GCRYPTODEFSKERN_H_
#define GCRYPTODEFSKERN_H_

/* @(#)01       1.3  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiGcryptoDefs.h, mmfs, avs_rfks0, rfks01416c 10/18/13 12:35:00 */

/* max length of encryption key */
#define GCRYPTO_MAX_KEYLEN 32 /* true for AES, modify in the future if other
                                 ciphers are used */
#define GCRYPTO_MAX_WRPKEYLEN GCRYPTO_MAX_KEYLEN

/* cipher block size */
#define GCRYPTO_AES_BLOCKLEN 16
#define GCRYPTO_MAX_BLOCKLEN GCRYPTO_AES_BLOCKLEN /* modify in the future
                                                   * if other ciphers are used
                                                   * */
#define GCRYPTO_MAX_IVLEN GCRYPTO_MAX_BLOCKLEN
#define GCRYPTO_RNDID_LENGTH 8


/* block cipher algorithms */
#define GCRYPTO_CIPHER_AES 1

/* mode of operations */
#define GCRYPTO_CIPHER_MODE_CBC 1
#define GCRYPTO_CIPHER_MODE_XTS 2
#define GCRYPTO_CIPHER_MODE_ECB 3

#define GCRYPTO_PAD_NONE 1
#define GCRYPTO_PAD_PKCS5 2

/* Return values for querying kernel crypto status */
#define GCRYPTO_KERN_CRYPTO_OK 1
#define GCRYPTO_KERN_CRYPTO_OK_FIPS 2
#define GCRYPTO_KERN_CRYPTO_NOT_PRESENT -1	

/* The basic encryption block size. That should correspond to the
   sector size, which is currently 512 bytes. We might want to keep this
   value even as sector sizes increase, to allow encrypted files to be
   portable across disks of different sector sizes. */
#define ENC_BASIC_BLOCK_SIZE  512

/* FIXME: define ENC_BASIC_BLOCK_SIZE as DEF_SECTOR_SIZE?  If so, need to
   include Disk.h */

/*
 * gcrypto structs
 */
struct gcryptoCtxSt
{
  UInt32 keyLen;
  UInt32 cipherBlockSize;
  unsigned char key[GCRYPTO_MAX_KEYLEN]; /* source key TODO: consider 
                                            removing */
  union 
  { 
    struct { /* in all modes except XTS */
      unsigned char enc[GCRYPTO_MAX_KEYLEN]; /* derived key */
      unsigned char iv[GCRYPTO_MAX_KEYLEN]; /* derived key */
    } key;
    unsigned char encIVkey[2*GCRYPTO_MAX_KEYLEN]; /* derived keys (concatenated) for XTS */
  } der;

  UInt16 cipher;
  UInt16 cipherMode;
  UInt16 kdfMode;

  unsigned char rndFileIDBytes[GCRYPTO_MAX_IVLEN]; /* the IV or tweak */
  UInt16 rndFileIDLen;
};

typedef struct gcryptoCtxSt gcryptoCtx_t;

#endif /* GCRYPTODEFSKERN_H_ */
