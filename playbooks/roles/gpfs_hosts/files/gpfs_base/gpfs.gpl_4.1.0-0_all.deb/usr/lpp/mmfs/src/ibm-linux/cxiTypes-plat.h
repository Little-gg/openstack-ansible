/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)09       1.177  src/avs/fs/mmfs/ts/kernext/ibm-linux/cxiTypes-plat.h, mmfs, avs_rfks0, rfks01416c 12/17/13 12:18:22 */
/*
 * Definitions for system dependent types, Linux version
 *
 * Contents:
 *   system dependent types
 *
 */


#ifndef _h_cxiTypes_plat
#define _h_cxiTypes_plat

#ifndef _h_cxiTypes
#error Platform header (XXX-plat.h) should not be included directly
#endif

/* Use system types.h except in portability kernel code */
#if !defined(GPFS_GPL) || !defined(_KERNEL)
#include <sys/types.h>
#endif


/* Suffix of a routine declaration to tell GCC to pass parameters in
   registers */
#define REGPARMS

/* Maxinum file name length */
#define CXI_D_NAME_MAX   1024  

/* Inline functions to byte-swap integers of various sizes.  These use
   assembler helpers on some architectures.  If the input parameter is
   a constant, the GCC compiler will generate better code by compile-time
   optimization of a (complicated) expression involving shifts and masks
   rather than calling the inline asm code. */
  static inline UInt16 ByteSwap16(UInt16 val)
  {
    return _ByteSwap16(val);
  }

#if defined(GPFS_ARCH_X86_64)
  static inline UInt32 _asm_swap32(UInt32 val)
  {
    __asm__("bswap %0  # _asm_swap32"   \
            : "=r" (val)                \
            : "0" (val));
    return val;
  }
  static inline UInt32 ByteSwap32(UInt32 val)
  {
    return __builtin_constant_p(val)
      ? _ByteSwap32(val)
      : _asm_swap32(val);
  }
#else
  static inline UInt32 ByteSwap32(UInt32 val)
  {
    return _ByteSwap32(val);
  }
#endif


#if defined(GPFS_ARCH_X86_64)
  static inline UInt64 ByteSwap64(UInt64 val)
  {
    UInt64 swapval = val;
    __asm__("bswap %0"
            : "=r"(swapval)
            : "0"(swapval) );
    return swapval;
  }
#else
  static inline UInt64 ByteSwap64(UInt64 val)
  {
    return  _ByteSwap64(val);
  }
#endif  /* GPFS_ARCH_X86_64 */


/* GPFS stores special file device numbers as 32 bit values
 * (the original AIX dev_t size).  The cxiDev_t type is 64 bits
 * since this is the size of the user space dev_t and the prevalent
 * type that we're always presented with from the stat structure.
 */
typedef UInt64  cxiDev_t;        /* user space dev_t definition */

typedef int cxiVmid_t;          // dummy on Linux
typedef UIntPtr cxiVmhandle_t;  // try this for now

/* Time types equivalent to linux definitions of time_t 
 * and suseconds_t.
 */
typedef long int cxiNSec_t;
typedef long int cxiTime_t;

/* Type used as parameter of ATOMIC_ADD, etc.  */
typedef int    *atomic_p;
/* Type used as parameter of ATOMIC_ADDLP, etc.  */
typedef long   *atomic_l;

/* File offset */
typedef long long offset_t;

/* Cross-memory descriptor */
typedef struct
{
  /* Really a pointer to a cxiPageList_t */
  void* pageListP;
} cxiXmem_t;


/* Struct that records the mapping within
 * the daemon address space.  A group of these are allocated
 * as an array in the shared seg and the memory descriptor
 * vindex points to the appropriate element.
 */
struct cxiMemoryMapping_t
{
  char *vaddr;        /* daemon address mapping */
  char *kvaddr;       /* kernel address of memory area (shared segment only) */
  int kBytes;         /* size of the area in kilobytes */
  int vindex;         /* index in shared segment mapping array */
  cxiXmem_t xmemDesc; /* cross-memory descriptor */
};


/* Describes address space of a cxiUio_t buffer.
 * User address space buffers get extra validity 
 * checking to ensure they are indeed in user space.
 */
#define UIO_SYSSPACE  1
#define UIO_USERSPACE 0

/* Structure with data required to complete a Linux AIO async. */
struct cxiAio_t
{
  /* Data saved in gpfs_f_aio_read and gpfs_f_aio_write */
  struct kiocb         *aio_kiocbP;        /* aio_complete(kiocbP..) */
  struct cxiIovec_t     aio_liov;          /* local iov */
  int                   aio_op;            /* CXI_READ_AIO or CXI_WRITE_AIO */

  /* Data saved in gpfsRead and gpfsWrite */
  int                   aio_whatLocked;    /* file WhatLocked */
  void                 *aio_ofP;           /* OpenFile ptr */
  int                   aio_sli;           /* Segment lock index corresponding to IO submission thread */
  int                   aio_fastPathEnabled;  /* Indicate if fastpath is exercised on IO submission */

  /* Data saved in kSFSRead and kSFSWrite */
  void                 *aio_dioLHandleP;   /* ByteRange lock handle */
  UInt64                aio_dioRangeStart; /* ByteRange lock start */
  UInt64                aio_dioRangeEnd;   /* ByteRange lock end */
  int                   aio_dioBRLockUsed; /* ByteRange lock used */
  cxiThreadId           aio_dioThreadId;   /* Thread owing Byte Range lock */
  UInt32                aio_seconds;       /* IO time stamp */
  UInt32                aio_nanoseconds;   /* IO time stamp */
  int                   aio_flockHave;     /* Type of lock on file */

  /* Data saved in dioRdWr */
  cxiXmem_t             aio_xmem;          /* cross memory page list */

  /* Data saved in kDoDirectio */
  void                 *aio_renP;          /* IORendezvous ptr */
  void                 *aio_iopqP;         /* IOParmsQueue ptr */
  void                 *aio_chunkHeadP;    /* Buffer chunklist head */
};

/* Structure representing a buffer in user space that needs to be accessed
   from kernel code. */
struct cxiUio_t
{
  struct cxiIovec_t  *uio_iov;    /* ptr to array of iovec structs */
  unsigned long       uio_iovcnt; /* #iovec elements remaining to be processed */
  unsigned long       uio_iovdcnt;/* #iovec elements already processed */
  offset_t            uio_offset; /* byte offset in file/dev to read/write */
  long                uio_resid;  /* #bytes left in data area */
  long                uio_total_len; /* total bytes of this request */
  short               uio_segflg; /* description of which address space in use */
  long                uio_fmode;  /* copy of file modes from open file struct */
  cxiXmem_t          *uio_xmem;   /* dummy field for AIX compatibility */
  struct cxiUioAio_t *uio_uioaio; /* data used for aio completion */
};

struct cxiUioAioList_t
{
  struct cxiUioAioList_t *nextP;
  struct cxiUioAioList_t *prevP;
};

/* Allocated pinned in the gpfs_f_aio_read and gpfs_f_aio_write fileops and
   freed by the AIO completion thread. */
struct cxiUioAio_t
{
  /* list of AIO waiting for completion processing */
  struct cxiUioAio_t *nextP;          /* For non-replicated file */
  struct cxiUioAioList_t uncompList;  /* For replicated file */
  struct cxiUio_t uioaio_uio;
  struct cxiAio_t uioaio_aio;
};

#define UIO_XMEM 0


/* First parameter on return call to cxiFillDir().  This structure
 * describes the operating systems' filldir() routine and any uninterpreted
 * arguments that need to be passed back to it.   The cxiFillDir() routine
 * has a static set of parameters that are passed to it, whereas the 
 * Linux filldir() routine has changed signatures for different kernel
 * levels.  We thus use cxiFillDir() in the portability layer to map
 * the arguments correctly to the Linux filldir().
 */
typedef struct cxiFillDirArg_t 
{
  void *fnP;
  void *argP;
} cxiFillDirArg_t;


/* Advisory locking types and defines */
typedef cxiFlock_t eflock_t;

/* Define analagous kernel types here for now */
/* These should ONLY be used for typecasting kernel service call parms */
typedef cxiPid_t gpfs_Kpid_t;

/* GPFS file types.  These match the AIX vtype definitions from vnode.h */
enum cxiVtype { cxiVNON, cxiVREG, cxiVDIR, cxiVBLK, cxiVCHR, cxiVLNK,
                cxiVSOCK, cxiVBAD, cxiVFIFO, cxiVMPC };
#define cxiVUNDEF cxiVNON   /* undefined is same as nothing */
typedef enum cxiVtype cxiVtype_t;

/* Maximum size defined within Linux kernel for spinlock_t
 * We abstract this class to just a hunk of storage and let the OS
 * specific piece handle the implementation.
 */
#ifdef DEBUG_SPINLOCK
#  if defined(GPFS_ARCH_PPC64)
#    define SPINLOCK_T_SIZE 16
#  elif defined(GPFS_ARCH_X86_64)
#    if defined(PREEMPT_RT_LINUX_PATCH)
#      define SPINLOCK_T_SIZE 56
#    else
#      define SPINLOCK_T_SIZE 8
#    endif
#  elif defined(GPFS_ARCH_S390X)
#    define SPINLOCK_T_SIZE 24
#  endif
#else
   #if defined(GPFS_ARCH_PPC64)
     #define SPINLOCK_T_SIZE 8
   #elif defined(GPFS_ARCH_X86_64) 
     /* Same size as DEBUG_SPINLOCK 
      * Changing this size requires an adjustment of CXINODE_SIZE
      */
     #if defined(PREEMPT_RT_LINUX_PATCH)
       #define SPINLOCK_T_SIZE 56
     #else
       #define SPINLOCK_T_SIZE 8
     #endif
   #elif defined(GPFS_ARCH_S390X)
     #define SPINLOCK_T_SIZE 8
   #else
     #define SPINLOCK_T_SIZE 4
   #endif
#endif

/* Base VFS node class portion that is OS specific.  
 * Consult gpfsNode_t for full definition 
 */
typedef struct cxiNode_t
{
  void *osNodeP;         /* pointer to operating system specific inode */
  enum cxiVtype nType;   /* directory, link, file, dev */
  int mapReadCount;      /* count of map for read  */
  int mapWriteCount;     /* count of map for write */
  int readCount;         /* total opens for read   */
  int icValid;           /* CXI_IC_XXX flags (see definitions below) */
  int xinfo;             /* Extended info bits (see va_xinfo definition) */
  void *nfsP;            /* nfs information */
  unsigned long ctFlags; 
  cxiThreadId createRaceLoserThreadId; /* Set if file exist */
} cxiNode_t;

/* various ctFlags.  These are set/checked using routines that follow
   Linux set_bit/test_bit semantics, i.e. accept bit _number_ rather
   than bit value as input. */
#define mmapFlush         1    /* nopage/mmFlush in progress */
#define destroyIfDelInode 2    /* file should be destroyed
                                  in gpfs_s_delete_inode */
#define invalidateCalled  3    /* OSNode on hash chain has
                                  been invalidated on this pass. */
#define pruneDCacheNeeded 4    /* Swapd has to prune dcache entries
                                  associated with with OSNode */
#define invalidateDentryCalled 5 /* Dentry for this node has been 
                                    invalidated */
#define revalidateNeeded  6    /* OSNode revalidation is needed */
#define NoDmLockNeeded    7    /* No dmapi lock required. */
#define homeChanged       8    /* file has been changed at home, lookup required */
#define pcacheLookupInProg 9 /* dentry instantiation deferred, pcache lookup in progress*/

#define SetCtFlag(cnP, flag_bit)   cxiSetBit(&(cnP)->ctFlags, flag_bit)
#define ClearCtFlag(cnP, flag_bit) cxiClearBit(&(cnP)->ctFlags, flag_bit)
#define TestCtFlag(cnP, flag_bit)  cxiTestBit(&(cnP)->ctFlags, flag_bit)

#ifdef GPFS_CACHE
#define PCACHE_SIZE   (3 * sizeof(cxiTime_t))
#else
#define PCACHE_SIZE   0
#endif

/* Account for larger fileId and parentInfo when InodeNumber is 64-bit */
# if defined(GPFS_ARCH_X86_64)
#define INODE64_EXTRA 16
# elif defined(GPFS_ARCH_PPC64)
#define INODE64_EXTRA 16
# elif defined(GPFS_ARCH_S390X)
#define INODE64_EXTRA 16
# else
#error Unknown Linux architecture
# endif 

/* Size of a full gpfsNode_t */

#ifdef GPFS_ARCH_PPC64
#  define CXINODE_SIZE (232 + SPINLOCK_T_SIZE + PCACHE_SIZE + INODE64_EXTRA)
#endif

#ifdef GPFS_ARCH_X86_64
   /* Changing the non-debug size of SPINLOCK_T_SIZE
    * requires an adjustment of CXINODE_SIZE in order
    * to account for padding due to single or double word 
    * alignment requirements of the architecture.
    */
#  ifdef PREEMPT_RT_LINUX_PATCH
    /* To do: determine correct CXINODE_SIZE w/ padding. */
#    define CXINODE_SIZE (256 + SPINLOCK_T_SIZE + PCACHE_SIZE + INODE64_EXTRA)
#  else
#    define CXINODE_SIZE (232 + SPINLOCK_T_SIZE + PCACHE_SIZE + INODE64_EXTRA)
#  endif
#endif

#ifdef GPFS_ARCH_S390X
#    define CXINODE_SIZE (232 + SPINLOCK_T_SIZE + PCACHE_SIZE + INODE64_EXTRA)
#endif

/* Access OS dependent portion of cxiNode */
#define GNP_IS_DIR(GNP)       ((GNP)->nType == cxiVDIR)
#define GNP_IS_FILE(GNP)      ((GNP)->nType == cxiVREG)
#define GNP_IS_LINK(GNP)      ((GNP)->nType == cxiVLNK)

#define GNP_IS_STEALABLE(GNP)  ((GNP)->osNodeP == NULL)
#define GNP_RDCOUNT(GNP)       ((GNP)->readCount)
#define GNP_EXCOUNT(GNP)       0
#define GNP_MAP_RDCOUNT(GNP)   ((GNP)->mapReadCount)
#define GNP_MAP_WRCOUNT(GNP)   ((GNP)->mapWriteCount)
#define GNP_MAP_SEG(GNP)       0
#define GNP_CHANNEL(GNP)       0
#define GNP_TO_VP(GNP)         ((struct inode *)((GNP)->osNodeP))
#define GP_TO_GNP(x) ((gpfsNode_t *)((x)))

/* d_off and name length of Linux struct dirent */
#define CXI_DIR_D_OFFSET(deP)             deP->d_off 
#define CXI_DIR_D_NAMLEN(deP)             strlen(deP->d_name)

/* Flags in cxiIGetArg_t */
#define SKIP_BEING_FREED   0x01
#define INODE_BEING_FREED  0x02
#define INODE_REVALIDATE   0x04

/* Parameter passed to find_actor and read_inode2 through iget4 */
typedef struct cxiIGetArg_t
{
  cxiIno_t extInodeNum;
  InodeNumber inodeNum; 
  UInt32 snapId;
  UInt32 filesetId;
  UInt32 flags;
  struct cxiVattr_t *vattrP;
  Boolean readInodeCalled;
} cxiIGetArg_t;

typedef struct cxiWaitList_t
{
  struct cxiWaitList_t *nextP;
  struct cxiWaitList_t *prevP; 
} cxiWaitList_t;

typedef struct cxiWaitEvent_t 
{
  /* List of wait elements. Wakeup is FIFO ordered with entries
   * entering the list at prevP and the first to be awaken at 
   * nextP.
   */
  cxiWaitList_t waitList;

  char lword[SPINLOCK_T_SIZE];

} cxiWaitEvent_t;

/* Kernel-only mutexes.  Largest possible size (including debug) */
#ifdef GPFS_ARCH_PPC64
#define GPFS_LINUX_SEM_SIZE 32
#endif
#ifdef GPFS_ARCH_X86_64
#  ifdef PREEMPT_RT_LINUX_PATCH
#    define GPFS_LINUX_SEM_SIZE 56
#  else
#    define GPFS_LINUX_SEM_SIZE 32
#  endif
#endif
#ifdef GPFS_ARCH_S390X
#define GPFS_LINUX_SEM_SIZE (SPINLOCK_T_SIZE+24)
#endif

#ifdef GPFS_LINUX_SEM_SIZE
typedef struct cxiBlockingMutex_t
{
  /* Space to store a Linux struct semaphore.  If a semaphore does not fit
     in the space provided, the implementation should use this space as a
     pointer to a dynamically-allocated semaphore. */
  char bmSem[GPFS_LINUX_SEM_SIZE];

  /* Pointer into stack of owning thread.  This is sufficient to compute
     which thread owns the mutex. */
  char* bmOwnerP;

  /* Index of the name of this mutex */
  int lockNameIndex;
} cxiBlockingMutex_t;
#endif

typedef struct ucontext cxiSigContext_t;

/* Type that should always correspond to the system ino_t */
typedef InodeNumber cxiInoSys_t;

/* type to store disable_lock result.  On Linux this is a machine 
   state word, and should be unsigned long */
typedef unsigned long cxiIntrState_t;

/* Work request for mmap pager kproc */
typedef struct _cxibuf_t
{
  struct  _cxibuf_t *av_forw;   /* forward pointer */
  struct  _cxibuf_t *av_back;   /* backward pointer */
  struct page *pageP;           /* pointer to the page being processed */
  struct cxiNode_t *b_vp;
  struct MMFSVInfo *vinfoP;     /* used by sendfile */
  struct gpfsVfsData_t *privVfsP;
  caddr_t b_baddr;              /* not used */
  unsigned long b_flags;        /* operation flag: see definitions below */
  unsigned long b_blkno;        /* file offset in PAGE_SIZE units */
  int     b_bcount;
  int     b_error;
  void    *b_inodeP;
} cxibuf_t;

/*  b_flags flags. */
#define B_WRITE     (long)0x0000    /* non-read pseudo-flag */
#define B_READ      (long)0x0001    /* read when I/O occurs */
#define B_ERROR     (long)0x0004    /* error detected */
#define B_ASYNC     (long)0x0100    /* don't wait for I/O completion */
#define B_PFSTORE   (long)0x2000    /* store operation */
#define B_PFPROT    (long)0x4000    /* protection violation */
#define B_PFEOF     (long)0x10000   /* check for ref. beyond end-of-file */
#define B_SENDFILE  (long)0x20000   /* read from sendfile */


/* Define macros to cause code to be placed far away from the spot
   where it normally would be generated.  This is typically used on
   whichever branch of an if is expected not to be executed in the common
   case.  Moving rarely executed code away from the mainline code can help
   reduce I-cache misses, and therefore improve performance.  Every
   BEGIN_FAR_CODE directive must be matched by an END_FAR_CODE directive,
   and they may not be nested.  If FAR_CODE is not #defined, these macros
   are NOOPs.  Use of the FAR_CODE option is not compatible with -g, and
   requires compiler options -fno-exceptions and -fno-defer-pop to insure
   that correct code is generated. */
#ifdef FAR_CODE
# define BEGIN_FAR_CODE
# define END_FAR_CODE
#else
# define BEGIN_FAR_CODE
# define END_FAR_CODE
#endif  /* FAR_TRACE */

#endif /* _h_cxiTypes_plat */
