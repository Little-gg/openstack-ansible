/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)03       1.34  src/avs/fs/mmfs/ts/kernext/ibm-linux/Trace-plat.h, mmfs, avs_rfks0, rfks01416c 10/30/13 13:22:55 */
/*
 * Linux-specific trace definitions
 *
 */

#ifndef _h_Trace_plat
#define _h_Trace_plat

#ifndef _h_Trace
#error Platform header (XXX-plat.h) should not be included directly
#endif

#ifdef GPFS_PRINTF
#  ifdef __KERNEL__
#    ifdef __cplusplus
       extern "C"
       {
         int printk(const char * fmt, ...)
                    __attribute__ ((format (printf, 1, 2)));
       }
#    else  /* !__cplusplus */
       extern int printk(const char * fmt, ...)
                         __attribute__ ((format (printf, 1, 2)));
#    endif  /* __cplusplus */
#  endif  /* __KERNEL__ */
#endif  /* GPFS_PRINTF */


#ifdef _KERNEL
#  define GPFS_NOTICE "<5>"
#endif

/* Structure contining global variables used by the trace code.  There
   is one copy of this in the kernel (KTrace) and another in the daemon
   (DTrace).  The two structures should be logically identical, but they
   may diverge briefly during transitions of the trace mode.  Since the
   trace buffer is mapped at different addresses in the daemon and in
   the kernel, the tBufferBaseP fields will not be binary identical even
   when they both point to the same buffer area.  The instances of this
   class will be aligned on cache-line boundaries, to avoid false sharing
   of this read-almost-always cache line.

   There is another copy of this type declaration in tracedev-ksyms.c. */
typedef struct
{
  /* Current trace mode.  Takes on one of the TRACE_xxx values in
     TraceMode_t. */
  int tMode;

  /* Padding.  Unused. */
  int tPadding1;

  /* Base address of the buffer used for overwrite tracing, or NULL if
     overwrite tracing is not enabled or quiesced.  This will be a
     page-aligned address.  The type of this buffer is actually
     SharedTraceBufferHeader_t. */
  char* tBufferBaseP;

  /* Size of the shared trace buffer whose address is in tBufferBaseP.  This
     will be 0 if bufferBaseP is NULL. */
  long long tBufferSize;

  /* Padding to a cache line boundary */
  char tPadding2[CACHE_LINE_SIZE -
                 (2*sizeof(int) + sizeof(char*) + sizeof(long long))];
} TraceGBLS_t;


/* Global check for whether tracing is enabled */
#ifndef _GBL_TRC_IS_ON
# ifdef _KERNEL
    extern TraceGBLS_t KTrace;
#   define _GBL_TRC_IS_ON (KTrace.tMode >= TRACE_OVERWRITE)
# else
    extern TraceGBLS_t DTrace;
#   define _GBL_TRC_IS_ON (DTrace.tMode >= TRACE_OVERWRITE)
# endif /* _KERNEL */
#endif /* _GBL_TRC_IS_ON */

/* In the daemon, trace macros always reference the trace flags through
   the pointer TraceFlagsP.  There is a copy of this pointer in the GPFS
   daemon, that initially points to PrivateTraceFlagsArray.  After the
   shared segment has been initialized, the contents of this array are
   copied into Shared.traceFlags and TraceFlagsP is changed to point to
   this shared copy.  In the kernel, TraceFlagsP is an array of trace
   levels.  This is kept in sync with Shared.traceFlags by the
   kxSetTraceLevel kernel call whenever 'mmfsadm trace foo n' changes
   any trace flags.  */
#ifdef DEFINE_TRACE_GBL_VARS
# ifdef _KERNEL
    char TraceFlagsP[MAX_TRACE_CLASSES] = { 0 };
# else
    char PrivateTraceFlagsArray[MAX_TRACE_CLASSES] = { 0 };
    char* TraceFlagsP = PrivateTraceFlagsArray;
# endif
#else
# ifdef _KERNEL
    extern char TraceFlagsP[MAX_TRACE_CLASSES];
# else
    extern char PrivateTraceFlagsArray[MAX_TRACE_CLASSES];
    extern char* TraceFlagsP;
# endif
#endif  /* DEFINE_TRACE_GBL_VARS */


/* Define macros for code that is generated before and after the actual
   trace call.  
   
   It used to have assembly routine for x86 when FAR_TRACE is defined.
   But since 4.1, it's no-op in Linux.

   Keep this old comment that is applicable for only x86 platform for reference:
   If FAR_TRACE is #defined, the actual call to the trace
   subroutine will be placed far away from the test of whether or not
   tracing is turned on.  When tracing is turned off, this technique
   reduces the number of I-cache misses, thereby improving performance
   significantly (5-10%).  Use of the FAR_TRACE option is not compatible
   with -g, and requires compiler options -fno-exceptions and
   -fno-defer-pop to insure that correct code is generated. */

# define _TR_BEFORE
# define _TR_AFTER


#ifdef _KERNEL
# define PDEBUG(_c, _l, _fmt, args...) \
    if (_TRACE_IS_ON(_c, _l)) printk( GPFS_NOTICE "kp %X:" _fmt, cxiGetThreadId() ,## args); else NOOP
#else
#     ifdef __cplusplus
  extern "C" int ktrace(const char *fmt, ...);
#     else  /* !__cplusplus */
  extern  int ktrace(const char *fmt, ...);
#     endif
# define PDEBUG(_c, _l, _fmt, args...) \
    if (_TRACE_IS_ON(_c, _l)) ktrace(_fmt, args); else NOOP
#endif  /* _KERNEL */


#ifdef GPFS_PRINTF

#define TRACE0(_c,_l,_id,_fmt) \
  PDEBUG((_c),(_l),_fmt,1)
#define TRACE1(_c,_l,_id,_fmt,a1) \
  PDEBUG((_c),(_l),_fmt,a1)
#define TRACE2(_c,_l,_id,_fmt,a1,a2) \
  PDEBUG((_c),(_l),_fmt,a1,a2)
#define TRACE3(_c,_l,_id,_fmt,a1,a2,a3) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3)
#define TRACE4(_c,_l,_id,_fmt,a1,a2,a3,a4) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4)
#define TRACE5(_c,_l,_id,_fmt,a1,a2,a3,a4,a5) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5)
#define TRACE6(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6)
#define TRACE7(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7)
#define TRACE8(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8)
#define TRACE9(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9)
#define TRACE10(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10)
#define TRACE11(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11)
#define TRACE12(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)
#define TRACE13(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13)
#define TRACE14(_c,_l,_id,_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14) \
  PDEBUG((_c),(_l),_fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14)

#endif /* GPFS_PRINTF */


/* Special values for pos field in _STrace calls */
#define _TR_FORMAT_I 250   /* all integer arguments */
#define _TR_FORMAT_F 251   /* all integer arguments, plus the last argument
                              is a float */
#define _TR_FORMAT_X 252   /* preformatted string from TRACEnX */


#ifndef GPFS_PRINTF

/* NOTE: following _TRACExxx macros are used by the tracing facility but
   should NOT be explicitly used in the gpfs source code. These are
   intended to keep trcid.h from getting too large. */

/* Define the trace hook macros used by the generated code in trcid.h for
   all-integer calls */
#define _TRACE0D(hw) _DTrace0(hw)
#define _TRACE1D(hw, a1) _DTrace1(hw, a1)
#define _TRACE2D(hw, a1, a2) _DTrace2(hw, a1, a2);
#define _TRACE3D(hw, a1, a2, a3) _DTrace3(hw, a1, a2, a3);
#define _TRACE4D(hw, a1, a2, a3, a4) _DTrace4(hw, a1, a2, a3, a4);
#define _TRACE5D(hw, a1, a2, a3, a4, a5) _DTrace5(hw, a1, a2, a3, a4, a5);
#define _TRACE6D(hw, a1, a2, a3, a4, a5, a6) _DTrace6(hw, a1, a2, a3, a4, a5, a6);
#define _TRACE7D(hw, a1, a2, a3, a4, a5, a6, a7) _DTrace7(hw, a1, a2, a3, a4, a5, a6, a7);
#define _TRACE8D(hw, a1, a2, a3, a4, a5, a6, a7, a8) _DTrace8(hw, a1, a2, a3, a4, a5, a6, a7, a8);
#define _TRACE9D(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9) _DTrace9(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9);
#define _TRACE10D(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10) _DTrace10(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10);
#define _TRACE11D(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11) _DTrace11(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11);
#define _TRACE12D(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) _DTrace12(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12);
#define _TRACE13D(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13) _DTrace13(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13);
#define _TRACE14D(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14) _DTrace14(hw, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14);

#ifdef LTRACE_FUTURE
#define TRCGENT(0, hookid, trcid, len, trcTemp) (void)0
#endif

/* non blocking versions */
#define _TRACE0D_NB(hw)           _STraceNB(hw, 0, _TR_FORMAT_I, 1)
#define _TRACE1D_NB(hw, args...)  _STraceNB(hw, 1, _TR_FORMAT_I,##args)
#define _TRACE2D_NB(hw, args...)  _STraceNB(hw, 2, _TR_FORMAT_I,##args)
#define _TRACE3D_NB(hw, args...)  _STraceNB(hw, 3, _TR_FORMAT_I,##args)
#define _TRACE4D_NB(hw, args...)  _STraceNB(hw, 4, _TR_FORMAT_I,##args)
#define _TRACE5D_NB(hw, args...)  _STraceNB(hw, 5, _TR_FORMAT_I,##args)
#define _TRACE6D_NB(hw, args...)  _STraceNB(hw, 6, _TR_FORMAT_I,##args)
#define _TRACE7D_NB(hw, args...)  _STraceNB(hw, 7, _TR_FORMAT_I,##args)
#define _TRACE8D_NB(hw, args...)  _STraceNB(hw, 8, _TR_FORMAT_I,##args)
#define _TRACE9D_NB(hw, args...)  _STraceNB(hw, 9, _TR_FORMAT_I,##args)
#define _TRACE10D_NB(hw, args...) _STraceNB(hw, 10, _TR_FORMAT_I,##args)
#define _TRACE11D_NB(hw, args...) _STraceNB(hw, 11, _TR_FORMAT_I,##args)
#define _TRACE12D_NB(hw, args...) _STraceNB(hw, 12, _TR_FORMAT_I,##args)
#define _TRACE13D_NB(hw, args...) _STraceNB(hw, 13, _TR_FORMAT_I,##args)

#define _TRACE14D_NB(hw, args...) _STraceNB(hw, 14, _TR_FORMAT_I,##args)
#define _TRACE15D_NB(hw, args...) _STraceNB(hw, 15, _TR_FORMAT_I,##args)
#define _TRACE16D_NB(hw, args...) _STraceNB(hw, 16, _TR_FORMAT_I,##args)
#define _TRACE17D_NB(hw, args...) _STraceNB(hw, 17, _TR_FORMAT_I,##args)
#define _TRACE18D_NB(hw, args...) _STraceNB(hw, 18, _TR_FORMAT_I,##args)
#define _TRACE19D_NB(hw, args...) _STraceNB(hw, 19, _TR_FORMAT_I,##args)
#define _TRACE20D_NB(hw, args...) _STraceNB(hw, 20, _TR_FORMAT_I,##args)

#define _TRACE1F(hw, args...) _STrace(hw, 0, _TR_FORMAT_F,##args)
#define _TRACE2F(hw, args...) _STrace(hw, 1, _TR_FORMAT_F,##args)
#define _TRACE3F(hw, args...) _STrace(hw, 2, _TR_FORMAT_F,##args)
#define _TRACE4F(hw, args...) _STrace(hw, 3, _TR_FORMAT_F,##args)
#define _TRACE5F(hw, args...) _STrace(hw, 4, _TR_FORMAT_F,##args)
#define _TRACE6F(hw, args...) _STrace(hw, 5, _TR_FORMAT_F,##args)
#define _TRACE7F(hw, args...) _STrace(hw, 6, _TR_FORMAT_F,##args)
#define _TRACE8F(hw, args...) _STrace(hw, 7, _TR_FORMAT_F,##args)
#define _TRACE9F(hw, args...) _STrace(hw, 8, _TR_FORMAT_F,##args)
#define _TRACE10F(hw, args...) _STrace(hw, 9, _TR_FORMAT_F,##args)

#define _TRACE1F_NB(hw, args...) _STraceNB(hw, 0, _TR_FORMAT_F,##args)
#define _TRACE2F_NB(hw, args...) _STraceNB(hw, 1, _TR_FORMAT_F,##args)
#define _TRACE3F_NB(hw, args...) _STraceNB(hw, 2, _TR_FORMAT_F,##args)
#define _TRACE4F_NB(hw, args...) _STraceNB(hw, 3, _TR_FORMAT_F,##args)
#define _TRACE5F_NB(hw, args...) _STraceNB(hw, 4, _TR_FORMAT_F,##args)
#define _TRACE6F_NB(hw, args...) _STraceNB(hw, 5, _TR_FORMAT_F,##args)
#define _TRACE7F_NB(hw, args...) _STraceNB(hw, 6, _TR_FORMAT_F,##args)
#define _TRACE8F_NB(hw, args...) _STraceNB(hw, 7, _TR_FORMAT_F,##args)
#define _TRACE9F_NB(hw, args...) _STraceNB(hw, 8, _TR_FORMAT_F,##args)

#endif /* GPFS_PRINTF */

#endif  /* _h_Trace_plat */
