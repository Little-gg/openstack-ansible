/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)97	1.15  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiAtomic.h, mmfs, avs_rfks0, rfks01416c 12/18/12 11:43:15 */

/*
 * Support for platform independant SMP synchronization operations
 *
 */

#ifndef _h_cxiAtomic
#define _h_cxiAtomic

/* Include platform specific interfaces */
#include <cxiAtomic-plat.h>

/* Platform independant interface */

/* 32-bit invariant atomic operations */
#define ATOMIC_ADD(_v,_i) fetch_and_add((atomic_p)(_v), (Int32)(_i))
#define ATOMIC_AND(_v,_i) fetch_and_and((atomic_p)(_v), (UInt32)(_i))
#define ATOMIC_OR(_v,_i) fetch_and_or((atomic_p)(_v), (UInt32)(_i))
#define ATOMIC_SWAP(_v, _p, _i) compare_and_swap((atomic_p)(_v), (Int32 *)(_p), (Int32)(_i))
#ifdef _KERNEL
#define ATOMIC_SET(_v,_i) test_and_set((atomic_p)(_v), (Int32)(_i))
/* Atomic ops on memory known to be in the kernel's address space rather than
   the address space of the user process; includes the shared segment.
   Code that runs in an interrupt handler must must use these routines. */
#define ATOMIC_ADD_KMEM(_v,_i) fetch_and_add_kmem((atomic_p)(_v), (Int32)(_i))
#define ATOMIC_AND_KMEM(_v,_i) fetch_and_and_kmem((atomic_p)(_v), (UInt32)(_i))
#define ATOMIC_OR_KMEM(_v,_i) fetch_and_or_kmem((atomic_p)(_v), (UInt32)(_i))
#endif /* _KERNEL */

/* 32-bit invariant macros with "no addresses" required for args */
#define ATOMIC_ADD_NA(_v, _i) fetch_and_add((atomic_p)&(_v), (Int32)(_i))

/* Variable size atomic operations (32/64-bit) */
/* These should be used with longs and pointers, ie, the natural word width */
#ifdef __64BIT__
#define ATOMIC_ADDLP(_v,_i) fetch_and_addlp((atomic_l)(_v), (IntNative)(_i))
#define ATOMIC_ANDLP(_v,_i) fetch_and_andlp((atomic_l)(_v), (UIntNative)(_i))
#define ATOMIC_ORLP(_v,_i) fetch_and_orlp((atomic_l)(_v), (UIntNative)(_i))
#define ATOMIC_SWAPLP(_v, _p, _i) compare_and_swaplp((atomic_l)(_v), (IntNative *)(_p), (IntNative)(_i))
#ifdef _KERNEL
#  define ATOMIC_SETLP(_v,_i) test_and_setlp((atomic_l)(_v), (IntNative)(_i))
#endif /* _KERNEL */
#else /* _ILP32 */
#define ATOMIC_ADDLP(_v,_i) ATOMIC_ADD(_v, _i)
#define ATOMIC_ANDLP(_v,_i) ATOMIC_AND(_v, _i)
#define ATOMIC_ORLP(_v,_i) ATOMIC_OR(_v, _i)
#define ATOMIC_SWAPLP(_v, _p, _i) ATOMIC_SWAP(_v, _p, _i)
#ifdef _KERNEL
#  define ATOMIC_SETLP(_v,_i) ATOMIC_SET(_v, _i)
#endif
#endif /* __64BIT__ */

/* 64-bit invariant atomic operations */
#ifdef __64BIT__
#define ATOMIC_ADD64(_v,_i) ATOMIC_ADDLP(_v, _i)
#define ATOMIC_AND64(_v,_i) ATOMIC_ANDLP(_v,_i)
#define ATOMIC_OR64(_v,_i) ATOMIC_ORLP(_v,_i)
#define ATOMIC_SWAP64(_v, _p, _i) ATOMIC_SWAPLP(_v, _p, _i)
#ifdef _KERNEL
#define ATOMIC_SET64(_v,_i) ATOMIC_SETLP(_v, _i) 
#endif /* _KERNEL */
#else  /* ! __64BIT__ */
#define ATOMIC_SWAP64(_v, _p, _i) compare_and_swap64_32bit((volatile Int64 *)_v, (Int64 *)_p, (Int64)_i)
#define ATOMIC_OR64(_v,_i) atomic_or64_32bit((volatile Int64 *)_v, (Int64)_i)
#define ATOMIC_ADD64(_v,_i) atomic_add64_32bit((volatile Int64 *)_v, (Int64)_i)
/* This is temparary work-around to avoid compilation error in building 32bit library.
 * On AIX,  32bit is not supported any more, so it doesn't have to work.
 */
#define ATOMIC_AND64(_v,_i) ATOMIC_AND(_v,_i)

#endif /* ! __64BIT__ */

/* Mutex lockword operations */
#ifdef __64BIT__
#define GPFS_CHECK_LOCK(_v, _i1, _i2) _check_locklp((atomic_l)(_v), (IntNative)(_i1), (IntNative)(_i2))
#define LOCKWORD_SWAP  ATOMIC_SWAP64
#define LOCKWORD_OR    ATOMIC_OR64
#define LOCKWORD_AND   ATOMIC_AND64
#else
#define GPFS_CHECK_LOCK(_v, _i1, _i2) _check_lock((atomic_p)(_v), (Int32)(_i1), (Int32)(_i2))
#define LOCKWORD_SWAP  ATOMIC_SWAP
#define LOCKWORD_OR    ATOMIC_OR
#define LOCKWORD_AND   ATOMIC_AND
#endif /* 64b */

#endif /* _h_cxiAtomic */
