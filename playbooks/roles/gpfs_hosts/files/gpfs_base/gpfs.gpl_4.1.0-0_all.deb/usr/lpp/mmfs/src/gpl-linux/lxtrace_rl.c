/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
static char sccsid[] = "@(#)61	1.32  src/avs/fs/mmfs/ts/kernext/gpl-linux/lxtrace_rl.c, mmfs, avs_rfks0, rfks01416c 4/1/14 13:50:27";
/*
 * lxtrace relayfs user code
 */
#include <Shark-gpl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/poll.h>
#include <pthread.h>
#include <string.h>
#include <linux/limits.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <dlfcn.h>
#include <sys/vfs.h>

#define ROUNDUP(_addr, _align) \
   (((long)_addr + (long)_align - 1L) & ~((long)_align - 1L))
#include <lxtrace.h>

int msgQueue = -1;
unsigned int cpuNum = 1;
size_t compLevel = 0;
int useDIO = 0;
size_t subBufSize = 0;
long long percpuOutSize = 256*1024;
int writeMode = LXTRACE_NEITHER;
// base name of per-cpu output files (e.g. ./cpu0, cpu1, ...)
char percpuOutBasename[PATH_MAX];
int RelayFlags = RL_BUF_GLOBAL;
int noWrap = 0; 

// compression buffer
static char* zBufP[LXTRACE_NR_CPUS];
static int zBufSize[LXTRACE_NR_CPUS];
static int (*compress2)(char *dst, unsigned long *dlen, char *src,
            unsigned long slen, int level);
static void *libz_handle;
#include <aio.h>
#define MAXAIOBUFS 10
#ifndef O_DIRECT
#ifdef GPFS_ARCH_PPC64
#define O_DIRECT 0400000
#else
#define O_DIRECT 040000
#endif
#endif
static int aioBufNum = MAXAIOBUFS;
static char *relayAioBufP[LXTRACE_NR_CPUS][MAXAIOBUFS];  /* the daemon 4k aligned
                                                            trace write buffer */
static char *wBufP[LXTRACE_NR_CPUS][MAXAIOBUFS];     /* the daemon orginal
                                                        trace write buffer */
static int relayWrapBytes[LXTRACE_NR_CPUS] = { 0 };  /* bytes leftover after
                                                        last DIO write */

static int relayAioStarted[LXTRACE_NR_CPUS][MAXAIOBUFS];
static int aioCurBuf[LXTRACE_NR_CPUS] = { 0 };
static char relayWrapBuf[LXTRACE_NR_CPUS][LXTRACE_DIO_ALIGN]; /* bytes that did
                                                                 not make the
                                                                 last dio write. */
static struct aiocb relayAioCb[LXTRACE_NR_CPUS][MAXAIOBUFS];
static char *relayBufP[LXTRACE_NR_CPUS];
static int relayPos[LXTRACE_NR_CPUS] = { 0 };
static int relayEnd[LXTRACE_NR_CPUS] = { 0 };
static int outFile[LXTRACE_NR_CPUS];
static int wrapsCount[LXTRACE_NR_CPUS];
static int timeoutCount[LXTRACE_NR_CPUS];
Boolean lxtraceDebug=false;

//wait for cpu aio buffer
inline void relayAioWait(int cpu, int numBuf)
{
  int i, rc;
  const struct aiocb *aioP[] = { &relayAioCb[cpu][numBuf] };
  if (relayAioStarted[cpu][numBuf])
  {
    //#define GETTIME 1
#ifdef GETTIME
    struct timeval before, after;
    static long wait;
    static int wait_num;
    gettimeofday(&before, NULL);
#endif
    rc = aio_suspend(aioP, 1, NULL);
    if (rc == 0)
    {
      size_t lrc = aio_return(&relayAioCb[cpu][numBuf]);
      relayAioStarted[cpu][numBuf] = 0;
    }
    else
      DP("trace daemon: aio_suspend return error %d\n", errno);
#ifdef GETTIME
    gettimeofday(&after, NULL);
    wait += (after.tv_sec*1000*1000 +
             after.tv_usec -
             before.tv_sec*1000*1000 -
             before.tv_usec);
    wait_num++;
#endif
  }
}

//write cpu aio buffer
inline void relayAioWrite(int cpu, int wBytes)
{
  int rc;
  int numBuf = aioCurBuf[cpu];
  memset(&relayAioCb[cpu][numBuf], 0, sizeof(struct aiocb));
  relayAioCb[cpu][numBuf].aio_buf = relayAioBufP[cpu][numBuf];
  relayAioCb[cpu][numBuf].aio_nbytes = wBytes;
  relayAioCb[cpu][numBuf].aio_offset = relayPos[cpu];
  relayAioCb[cpu][numBuf].aio_fildes = outFile[cpu];
  relayAioCb[cpu][numBuf].aio_sigevent.sigev_notify = SIGEV_NONE;
  rc = aio_write(&relayAioCb[cpu][numBuf]);
  if (rc != 0)
    DP("trace daemon: aio_write return error %d\n", errno);
  relayAioStarted[cpu][numBuf] = 1;
  numBuf = (numBuf + 1) % aioBufNum;
  aioCurBuf[cpu] = numBuf;
}

// rename output file for cpu
static int renameOutFile(int cpu, const char *out_basename, int uponWrap)
{
  char old[PATH_MAX];
  char new[PATH_MAX];
  char timeout[PATH_MAX];
  struct stat buf;

  sprintf(old, "%s.cpu%d", out_basename, cpu);
  //for no-wrap case, rename the old file with a sequence number as suffix
  if (uponWrap)
  {
    sprintf(new, "%s.nowrap.%d.cpu%d", out_basename, wrapsCount[cpu], cpu);
  }
  else
    sprintf(new, "%s.recycle.cpu%d", out_basename, cpu);

  //do not overwrite recycle file caused by timeout
  if (stat(new, &buf) == 0)
  {
    sprintf(timeout, "%s.timeout.%d.cpu%d",
            out_basename, timeoutCount[cpu]++, cpu);
    DP("trace daemon: rename recycle file %s to %s\n", new, timeout);
    rename(new, timeout);
  }
  return rename(old, new);
}

// open output file for cpu
int openOutFiles(int cpu, const char *out_basename)
{
  char tmp[PATH_MAX];
  /* Special cases of specifying stdout or stderr to receive the trace output. */
  if (strcmp(out_basename, "stdout") == 0)
    outFile[cpu] = 1; //stdout;
  else if (strcmp(out_basename, "stderr") == 0)
    outFile[cpu] = 2; //stderr;
  else
  {
    sprintf(tmp, "%s.cpu%d", out_basename, cpu);
    if ((outFile[cpu] = open(tmp, O_CREAT | O_RDWR | O_TRUNC, 0644 )) < 0)
    {
      DP("trace daemon: Couldn't open output file %s: errcode = %s\n",
         tmp, strerror(errno));
      return -1;
    }
    DFP("trace daemon: Open file %s succeed\n", tmp);
  }
  if (useDIO)
    fcntl(outFile[cpu], F_SETFL, O_DIRECT);

  return 0;
}

//close output file for cpu
void closeOutFiles(int cpu)
{
  if (outFile[cpu] > 0)
    close(outFile[cpu]);
}

//rename old output files and open new files
int recycleOutFiles(int cpu, int uponWrap)
{

  closeOutFiles(cpu);
  if (renameOutFile(cpu, percpuOutBasename, uponWrap) < 0)
  {
    DP("trace daemon: rename %s for cpu %d failed errno %d\n",
       percpuOutBasename, cpu, errno);
  }

  if (!uponWrap)
  {
    wrapsCount[cpu] = 0;
  }

  openOutFiles(cpu, percpuOutBasename);

  return 0;
}

void flushAioBuffers(int cpu)
{
  //aio buffer cleanup
  int i;
  if (useDIO)
  {
    for (i=0; i < aioBufNum; i++)
    {
      relayAioWait(cpu, i);
    }
    fcntl(outFile[cpu], F_SETFL, 0);
    lseek(outFile[cpu], relayPos[cpu], SEEK_SET);
    write(outFile[cpu], relayWrapBuf[cpu], relayWrapBytes[cpu]);
    lseek(outFile[cpu], 0, SEEK_SET);
    if (relayPos[cpu]+relayWrapBytes[cpu] > relayEnd[cpu])
      ftruncate(outFile[cpu], relayPos[cpu]+relayWrapBytes[cpu]);
    else
      ftruncate(outFile[cpu], relayEnd[cpu]);
    relayWrapBytes[cpu] = relayPos[cpu] = relayEnd[cpu] = 0;
  }
  else
  {
    relayPos[cpu] = 0;
  }

}
// write into aio buffer, also handle file wrap
void writeBuffer(int cpu, char *bufP, int nBytes)
{
  int rc;
  int numBuf;

  if (useDIO)
  {
    numBuf = aioCurBuf[cpu];
    relayAioWait(cpu, numBuf);
  }

  if (nBytes > 0)
  {
    /* Check the output file wrap-size and handle if it has been reached. */
    if ((outFile[cpu] > 2) &&
        (percpuOutSize > 0) &&
        ((relayPos[cpu] + nBytes) > percpuOutSize))
    {
      if (noWrap)
      {
        //rename and store old file upon wrap
        flushAioBuffers(cpu);
        recycleOutFiles(cpu, 1);
      }
      else if (useDIO)
      {
        /* Write any leftover bytes as a full block and setup to truncate on exit
           any data that may have extended past this point from the last
           time we wrapped. */
        memset(relayAioBufP[cpu][numBuf], 0, LXTRACE_DIO_ALIGN);
        memcpy(relayAioBufP[cpu][numBuf], relayWrapBuf[cpu], relayWrapBytes[cpu]);
        relayEnd[cpu] = relayPos[cpu] + relayWrapBytes[cpu];
        relayWrapBytes[cpu] = 0;
        relayAioWrite(cpu, LXTRACE_DIO_ALIGN);
        numBuf = aioCurBuf[cpu];
        relayAioWait(cpu, numBuf);
      }
      else
      {
        lseek(outFile[cpu], 0, SEEK_SET);
        ftruncate(outFile[cpu], relayPos[cpu]);
      }
      relayPos[cpu] = 0;
      wrapsCount[cpu]++;
    }

    if (useDIO)
    {
      /* dio nees 4k aligned buffers */
      int totalBytes = nBytes + relayWrapBytes[cpu];
      int aioBytes = totalBytes & LXTRACE_DIO_MASK;
      int extraBytes = totalBytes - aioBytes;
  
      if (aioBytes > 0)
      {
        /* Write the buffer to the trace output file */
        memcpy(relayAioBufP[cpu][numBuf], relayWrapBuf[cpu],
               relayWrapBytes[cpu]);
        memcpy((relayAioBufP[cpu][numBuf] + relayWrapBytes[cpu]),
               bufP, aioBytes - relayWrapBytes[cpu]);
        relayAioWrite(cpu, aioBytes);
  
        if (extraBytes > 0)
          memcpy(relayWrapBuf[cpu], bufP + aioBytes - relayWrapBytes[cpu],
                 extraBytes);
        relayWrapBytes[cpu] = extraBytes;
      }
      else
      {
        /* Add data to the existing relayWrapBuf.  There must be room, or
         * we wouldn't be here.  */
        memcpy(relayWrapBuf[cpu] + relayWrapBytes[cpu], bufP, nBytes);
        relayWrapBytes[cpu] += nBytes;
      }
  
      relayPos[cpu] += aioBytes;
    }
    else
    {
      rc = write(outFile[cpu], bufP, nBytes);
      if (rc == -1)
        DP("trace daemon: write return error %d\n", errno);
      relayPos[cpu] += nBytes;
    }
  }
}

// write to disk with checking free space
void tryWriteBuffer( int cpu, char *bufP, int nBytes )
{
  struct statfs buf;
  unsigned long long freeBytes;

  //if file wraps, the needed disk space should already be allocated 
  if (wrapsCount[cpu] && !noWrap)
  {
    writeBuffer(cpu, bufP, nBytes);
    return;
  }

  //check free space
  fstatfs(outFile[cpu], &buf);
  freeBytes = buf.f_bsize*buf.f_bavail;

  if (nBytes > freeBytes)
  {
    DP("Not enough free space %llu for %d bytes trace data. Kill myself!\n",
       freeBytes, nBytes);
    //this function may be called in a child thread 
    //so send termination signal to myself and let the main thread do the cleanup
    raise(SIGTERM);
  }
  else
  {
    writeBuffer(cpu, bufP, nBytes);
  } 
}

// compression and write
void compWrite(int cpu, char*subbuf_ptr, int len)
{
  int ret;
  trc_comp_header_t *comp_hdr;

  if (len == 0)
    return;

  /* Every trace record starts with a header (trc_hdrs_t) that includes
   * a magic number.  If we ever get a buffer that doesn't start
   * properly, write some debug information and refuse to write it
   * to the trace file.
   */
  if (((trc_header_t *)subbuf_ptr)->trMagic != LXTRACE_MAGIC &&
      ((trc_header_t *)subbuf_ptr)->trMagic != LXTRACE_SEQ_MAGIC) 
  {
    DP("%s", "lxtrace: bad trace buffer from tracedev!\n");
    DP("lxtrace: bufP 0x%X %d bytes at offset %d data 0x%X\n",
       subbuf_ptr, len, (int)relayPos[cpu], ((trc_header_t *)subbuf_ptr)->trMagic);
    return;
  }

  if (compLevel)
  {
    unsigned long dlen = zBufSize[cpu] - sizeof(trc_comp_header_t);
    comp_hdr = (trc_comp_header_t *)zBufP[cpu];
    comp_hdr->trMagic = LXTRACE_COMP_MAGIC;
    ret = compress2(zBufP[cpu] + sizeof(trc_comp_header_t), &dlen, subbuf_ptr,
                    len, compLevel);
    if (ret != 0)
    {
      DP("trace daemon: compress error %d\n", ret);
      return;
    }
    comp_hdr->dataLength  = subBufSize;
    comp_hdr->compLength = dlen;
    DFP("trace daemon: cpu %d comp %d write %d at %p\n",
        cpu, comp_hdr->dataLength, comp_hdr->compLength, zBufP[cpu]);
    tryWriteBuffer(cpu, zBufP[cpu], sizeof(trc_comp_header_t)+dlen);
  }
  else
    tryWriteBuffer(cpu, subbuf_ptr, len);
}


/* Allocate aio and compression buffer load compression library */
int allocBuffers(void)
{
  int i, cpu;
  char *error;

  if (RelayFlags & RL_BUF_PERCPU)
    aioBufNum = 1;

  if (useDIO)
  {
    for (cpu=0; cpu<cpuNum; cpu++)
    {
      for (i=0; i < aioBufNum; i++)
      {
        // dio needs 4k aligned buffers
        wBufP[cpu][i] = malloc(subBufSize + 4095);
        if (wBufP[cpu][i] == NULL)
        {
          DP("%s", "trace daemon: allocate buffer failed\n");
          return -1;
        }
        relayAioBufP[cpu][i] = (char*)ROUNDUP(wBufP[cpu][i], LXTRACE_DIO_ALIGN);
        /* Force page faults to occur now */
        memset(relayAioBufP[cpu][i], 0, subBufSize);
        relayAioStarted[cpu][i] = 0;
      }
    }
  }
  /* allocate compression buffer */
  if (compLevel)
  {
    for (i=0; i<cpuNum; i++)
    {
      //the compressed buffer size should be safe enough
      //otherwise the memory will be corrupted by zlib and lxtrace daemon might crash 
      zBufSize[i] = sizeof(trc_comp_header_t) + (subBufSize+12)*1.001;
      zBufP[i] = malloc(zBufSize[i]);
      if (zBufP[i] == NULL)
      {
        DP("%s", "trace daemon: allocate buffer failed\n");
        return -1;
      }
    }
    //load libz.so.1
    libz_handle = dlopen("libz.so.1", RTLD_NOW);
    if (libz_handle == NULL)
    {
      DP("lxtrace format: dlopen libz.so.1 error: %s\n", dlerror());
      return -1;
    }
    //clear previous dlerror
    dlerror();
    compress2 = dlsym(libz_handle, "compress2"); 
    if ((error = dlerror()) != NULL) 
    {
      DP("lxtrace format: dlsym compress2 error: %s\n", error);
      return -1;
    } 
  }
  return 0;
}


/* Free aio and compression buffers */
void freeBuffers()
{
  int i, cpu;
  /* release compression buffer memory */
  if (compLevel)
  {
    for (i=0; i<cpuNum; i++)
    {
      if (zBufP[i] != NULL)
        free(zBufP[i]);
    }
    if (libz_handle != NULL)
      dlclose(libz_handle);
  }

  if (useDIO)
  {
    //relase aio buffer memory
    for (cpu=0; cpu<cpuNum; cpu++)
    {
      for (i=0; i < aioBufNum; i++)
      {
        if (wBufP[cpu][i] != NULL)
        {
          free(wBufP[cpu][i]);
        }
      }
    }
  }
}

//setup ipc message queue
int GetMsgQueue(int flags)
{
  key_t key;
  int msgQueue;
  /* get id */
  key = ftok(LXTRACE_CMD_PATH, LXTRACE_PROJID);
  if (key == -1)
  {
    DP("trace daemon: ftok error %d\n", errno);
    return -1;
  }  

  //for recycle and child daemon error message
  msgQueue = msgget(key, flags);
  if (msgQueue == -1)
  {
    return -1;
  }  

  return msgQueue;
}


#ifdef GPFS_LINUX   /* Include the remainder of this file */

// base name of per-cpu relay files (e.g. /debug/cpu0, cpu1, ...)
char *percpuBasename = "cpu";
// relay parameters
static size_t subBufNum = 4;

//sychronize flag and mutex
static int processing;
static pthread_mutex_t processingMutex;

// per-cpu variables
static int relayFile[LXTRACE_NR_CPUS];
static pthread_t readerThread[LXTRACE_NR_CPUS];
static int cpu[LXTRACE_NR_CPUS] = { 0 };

// control files
static int producedFile[LXTRACE_NR_CPUS];
static int consumedFile[LXTRACE_NR_CPUS];


// per-cpu buffer info
static struct buf_status
{
  size_t produced;
  size_t consumed;
  size_t max_backlog; // max sub-buffers ready at one time
  size_t undelivered_subbufs; // undelivered sub-buffers we were forced to drop
} status[LXTRACE_NR_CPUS];


/* ProcessSubbufs - write ready subbufs to disk for blocking mode */
static int processSubbufs(unsigned int cpu)
{
  size_t i, start_subbuf, end_subbuf, subbuf_idx, subbufs_consumed = 0;
  size_t subbufs_ready = status[cpu].produced - status[cpu].consumed;
  char *subbuf_ptr;
  size_t padding, commit;
  unsigned start_reserve = sizeof(commit) + sizeof(padding);
  int undelivered_idx = -1;
  int len;

  start_subbuf = status[cpu].consumed % subBufNum;
  end_subbuf = start_subbuf + subbufs_ready;
  for (i = start_subbuf; i < end_subbuf; i++)
  {
    subbuf_idx = i % subBufNum;
    subbuf_ptr = relayBufP[cpu] + subbuf_idx * subBufSize;
    commit = *((size_t *)subbuf_ptr);
    padding = *((size_t *)(subbuf_ptr + sizeof(size_t)));
    subbuf_ptr += sizeof(commit) + sizeof(padding);
    len = subBufSize - start_reserve - padding;
    if (commit != len)
    {
      undelivered_idx = i;
      DP("trace daemon: buffer %d incomplete, commit %d padding %d len %d\n", i-start_subbuf, commit, padding, len);
      break; /* stop processing sub-buffers for now */
    }
    compWrite(cpu, subbuf_ptr, len);
    subbufs_consumed++;
  }

  /* If we're full and the first sub-buffer is still not completely
     committed, we must drop it */
  if (subbufs_ready == subBufNum && undelivered_idx == start_subbuf)
  {
    status[cpu].undelivered_subbufs++;
    subbufs_consumed++;
  }

  return subbufs_consumed;
}

/* processSubbufs - write ready subbufs to disk for overwrite mode */
static int flushSubbufs(unsigned int cpu)
{
  size_t i, start_subbuf, end_subbuf, subbuf_idx, subbufs_consumed = 0;
  size_t subbufs_ready = status[cpu].produced - status[cpu].consumed;
  char *subbuf_ptr;
  size_t padding, commit;
  unsigned start_reserve = sizeof(commit) + sizeof(padding);
  int undelivered_idx = -1;
  int len;

  DFP("trace daemon:produced %d consumed %d\n",
      status[cpu].produced, status[cpu].consumed);

  /* buffer is not wrapped */
  if (subbufs_ready < subBufNum )
  {
    start_subbuf = status[cpu].consumed % subBufNum;
    end_subbuf = start_subbuf + subbufs_ready;
  }
  else
  {
    /* start from oldest buffer */
    start_subbuf = status[cpu].produced % subBufNum;
    end_subbuf = start_subbuf + subBufNum ; //subbufs_ready;
    subbufs_consumed = subbufs_ready - subBufNum ;
  }
  for (i = start_subbuf; i < end_subbuf; i++)
  {
    subbuf_idx = i % subBufNum;
    subbuf_ptr = relayBufP[cpu] + subbuf_idx * subBufSize;
    commit = *((size_t *)subbuf_ptr);
    padding = *((size_t *)(subbuf_ptr + sizeof(size_t)));
    subbuf_ptr += sizeof(commit) + sizeof(padding);
    len = subBufSize - start_reserve - padding;
    if (commit != len)
    {
      undelivered_idx = i;
      DP("trace daemon: buffer %d incomplete, commit %d padding %d len %d\n",
         i-start_subbuf, commit, padding, len);
      break; /* stop processing sub-buffers for now */
    }
    compWrite(cpu, subbuf_ptr, len);
    subbufs_consumed++;
  }

  /* If we're full and the first sub-buffer is still not completely
     committed, we must drop it */
  if (subbufs_ready >= subBufNum && undelivered_idx == start_subbuf)
  {
    status[cpu].undelivered_subbufs++;
    subbufs_consumed++;
  }

  return subbufs_consumed;
}

/* checkBuffer - check for and read any available sub-buffers in a
   buffer */
static void checkBuffer(unsigned cpu)
{
  size_t subbufs_consumed;

  lseek(producedFile[cpu], 0, SEEK_SET);
  if (read(producedFile[cpu], &status[cpu].produced,
           sizeof(status[cpu].produced)) < 0)
  {
    DP("trace daemon: Couldn't read from consumed file for cpu %d, exiting: errcode = %d: %s\n",
       cpu, errno, strerror(errno));
    return;
  }
  //overwrite mode
  if (writeMode == LXTRACE_OVERWRITE)
  {
    subbufs_consumed = flushSubbufs(cpu);
  }
  //blocking mode
  else
    subbufs_consumed = processSubbufs(cpu);
  if (subbufs_consumed)
  {
    if (subbufs_consumed > status[cpu].max_backlog)
      status[cpu].max_backlog = subbufs_consumed;
    status[cpu].consumed += subbufs_consumed;
    if (write(consumedFile[cpu], &subbufs_consumed,
              sizeof(subbufs_consumed)) < 0)
    {
      DP("trace daemon: Couldn't write to consumed file for cpu %d, exiting: errcode = %d: %s\n",
         cpu, errno, strerror(errno));
      return;
    }
  }

  int prev_produced = status[cpu].produced;
  lseek(producedFile[cpu], 0, SEEK_SET);
  if (read(producedFile[cpu], &status[cpu].produced,
           sizeof(status[cpu].produced)) < 0)
  {
    DP("trace daemon: Couldn't read from consumed file for cpu %d, exiting: errcode = %d: %s\n",
       cpu, errno, strerror(errno));
    return;
  }
  if (prev_produced != status[cpu].produced)
    DFP("trace daemon: produced prev %d now %d\n", prev_produced, status[cpu].produced);
}

/* readerThreadBody - per-cpu channel buffer readerThread */
static void *readerThreadBody(void *data)
{
  int rc;
  int cpu = *(int *)data;
  PollFd pollfd;

  do
  {
    if (writeMode == LXTRACE_BLK)
    {
      pollfd.fd = relayFile[cpu];
      pollfd.events = POLLIN;
      rc = poll(&pollfd, 1, -1);
      if (rc < 0)
      {
        if (errno != EINTR)
        {
          DP("trace daemon: poll error: %s\n", strerror(errno));
          return NULL;
        }
        DFP("trace daemon: poll warning: %s\n", strerror(errno));
        rc = 0;
      }
      
      pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
      pthread_mutex_lock(&processingMutex);
      processing++;
      pthread_mutex_unlock(&processingMutex);
    }

    checkBuffer(cpu);

    if (writeMode == LXTRACE_BLK)
    {
      pthread_mutex_lock(&processingMutex);
      processing--;
      pthread_mutex_unlock(&processingMutex);
      pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    }

  } while (writeMode == LXTRACE_BLK);
  return NULL;
}

/* controlRead - read a control file and return the value read */
static size_t controlRead(const char *dirname,
                          const char *filename)
{
  char tmp[PATH_MAX];
  int fd;

  sprintf(tmp, "%s/%s", dirname, filename);
  fd = open(tmp, O_RDONLY);
  if (fd < 0)
  {
    DP("trace daemon: Couldn't open control file %s\n", tmp);
    return -1;
  }

  if (read(fd, tmp, sizeof(tmp)) < 0)
  {
    DP("trace daemon: Couldn't read control file %s: errcode = %d: %s\n",
       tmp, errno, strerror(errno));
    close(fd);
    return -1;
  }

  close(fd);

  return atoi(tmp);
}

/* controlWrite - write a value to a control file */
static int controlWrite(const char *dirname,
                        const char *filename,
                        size_t val)
{
  char tmp[PATH_MAX];
  int fd;

  sprintf(tmp, "%s/%s", dirname, filename);
  fd = open(tmp, O_RDWR);
  if (fd < 0)
  {
    DP("trace daemon:Couldn't open control file %s\n", tmp);
    return -1;
  }

  sprintf(tmp, "%zu", val);

  if (write(fd, tmp, strlen(tmp)) < 0)
  {
    DP("Couldn't write %s to control file %s/%s: errcode = %d: %s\n",
       tmp, dirname, filename, errno, strerror(errno));
    close(fd);
    return -1;
  }

  close(fd);

  return 0;
}


/* createPercpuThreads - create per-cpu threads */
static int createPercpuThreads(void)
{
  int i;

  for (i = 0; i < cpuNum; i++)
  {
    cpu[i] = i;
    /* create a thread for each per-cpu buffer */
    if (pthread_create(&readerThread[i], NULL, readerThreadBody,
                       (void *)&cpu[i]) < 0)
    {
      DP("trace daemon: Couldn't create thread\n");
      return -1;
    }
  }

  return 0;
}

/* wait for per-cpu threads to exit */
static void waitPercpuThreads(int n)
{
  int i;

  for (i = 0; i < n; i++)
  {
    pthread_join(readerThread[i], NULL); 
  }

}

/* killPercpuThreads - kill per-cpu threads 0->n-1 */
static int killPercpuThreads(int n)
{
  int i, killed = 0, err;

  for (i = 0; i < n; i++)
  {
    if ((err = pthread_cancel(readerThread[i])) == 0)
      killed++;
    else
      DP("trace daemon: couldn't kill per-cpu thread %d, err = %d\n", i, err);
  }

  if (killed != n)
    DP("trace daemon: couldn't kill all per-cpu threads:  %d killed, %d total\n", killed, n);

  waitPercpuThreads(n);
  return killed;
}

/* closeControlFiles - close per-cpu produced/consumed control files */
static void closeControlFiles(void)
{
  int i;

  for (i = 0; i < cpuNum; i++)
  {
    if (producedFile[i] > 0)
      close(producedFile[i]);
    if (consumedFile[i] > 0)
      close(consumedFile[i]);
  }
}

/* openControlFiles - open per-cpu produced/consumed control files */
static int openControlFiles(const char *dirname, const char *basename)
{
  int i;
  char tmp[PATH_MAX];

  for (i = 0; i < cpuNum; i++)
  {
    sprintf(tmp, "%s/%s%d.produced", dirname, basename, i);
    producedFile[i] = open(tmp, O_RDONLY);
    if (producedFile[i] < 0)
    {
      DP("trace daemon: Couldn't open control file %s\n", tmp);
      goto fail;
    }
  }

  for (i = 0; i < cpuNum; i++)
  {
    sprintf(tmp, "%s/%s%d.consumed", dirname, basename, i);
    consumedFile[i] = open(tmp, O_RDWR);
    if (consumedFile[i] < 0)
    {
      DP("trace daemon: Couldn't open control file %s\n", tmp);
      goto fail;
    }
  }

  return 0;
fail:
  closeControlFiles();
  return -1;
}

/* openCpuFile - open and mmap buffer for cpu */
static int openCpuFile(int cpu, const char *dirname, const char *basename)
{
  size_t total_bufsize;
  char tmp[PATH_MAX];

  memset(&status[cpu], 0, sizeof(struct buf_status));

  sprintf(tmp, "%s/%s%d", dirname, basename, cpu);
  relayFile[cpu] = open(tmp, O_RDONLY | O_NONBLOCK);
  if (relayFile[cpu] < 0)
  {
    DP("trace daemon: Couldn't open relay file %s: errcode = %s\n",
       tmp, strerror(errno));
    return -1;
  }

  total_bufsize = subBufSize * subBufNum;
  relayBufP[cpu] = mmap(NULL, total_bufsize, PROT_READ,
                        MAP_PRIVATE | MAP_POPULATE, relayFile[cpu],
                        0);
  if (relayBufP[cpu] == MAP_FAILED)
  {
    DP("trace daemon: Couldn't mmap relay file, total_bufsize (%d) = subBufSize (%d) * subBufNum(%d), error = %s \n",
       total_bufsize, subBufSize, subBufNum, strerror(errno));
    close(relayFile[cpu]);
    return -1;
  }

  return 0;
}

/* closeCpuFile - close and munmap buffer for cpu */
static void closeCpuFile(int cpu)
{
  size_t total_bufsize = subBufSize * subBufNum;

  if (relayFile[cpu] > 0)
  {
    munmap(relayBufP[cpu], total_bufsize);
    close(relayFile[cpu]);
  }
}

/* close cpu files and output files */
static void closeAppFiles(void)
{
  int i;

  for (i = 0; i < cpuNum; i++)
  {
    closeCpuFile(i);
    closeOutFiles(i);
  }

}

/* open cpu files and output files */
static int openAppFiles(void)
{
  int i;

  for (i = 0; i < cpuNum; i++)
  {
    if (openCpuFile(i, DEBUG_DIR, percpuBasename) < 0)
    {
      return -1;
    }
    if (openOutFiles(i, percpuOutBasename) < 0)
      return -1;
  }

  return 0;
}


int RelayDump(void)
{
  int subbuf_size, subbuf_num;
  int dropped;
  int i;
  int create;

  create = controlRead(DEBUG_DIR, "create");
  if (create <= 0)
    return -1;

  if (create & RL_BUF_PERCPU)
    cpuNum = sysconf(_SC_NPROCESSORS_ONLN);

  if (controlRead(DEBUG_DIR, "enabled") <= 0)
    return -1;

  subbuf_size = controlRead(DEBUG_DIR, "subbuf_size");
  if (subbuf_size <= 0)
    return -1;

  subbuf_num = controlRead(DEBUG_DIR, "n_subbufs");
  if (subbuf_size <= 0)
    return -1;

  dropped = controlRead(DEBUG_DIR, "dropped");
  if (subbuf_size <= 0)
    return -1;

  if (openControlFiles(DEBUG_DIR, percpuBasename) < 0)
    return -1;

  for (i = 0; i < cpuNum; i++)
  {
    lseek(producedFile[i], 0, SEEK_SET);
    read(producedFile[i], &status[i].produced, sizeof(status[i].produced));
    lseek(consumedFile[i], 0, SEEK_SET);
    read(consumedFile[i], &status[i].consumed, sizeof(status[i].consumed));
  }
  printf("Cpu number: %d, sub-buffer size %d sub-buffer number %d\n",
         cpuNum, subbuf_size, subbuf_num);
  printf("Dropped records %zu.\n", dropped);

  for (i = 0; i < cpuNum; i++)
  {
    printf("  Cpu %u:\n", i);
    printf("    %zu sub-buffers processed\n",
           status[i].consumed);
  }

  closeControlFiles();
  return 0;
}


/* Relay trace daemon main entry */
int BlockingTraceDaemonBody(long long outSize, int bufSize, int bufNum,
                            int interval, int level)
{
  int i, c, signal;
  sigset_t signals;
  int rc;
  int cpu;
  int traceDeviceFD;
  TraceDaemonMsg_t msg;

  pthread_mutex_init(&processingMutex, NULL);

  //block signals
  sigemptyset(&signals);
  sigaddset(&signals, SIGINT);
  sigaddset(&signals, SIGTERM);
  sigaddset(&signals, SIGIO);
  sigaddset(&signals, SIGALRM);
  pthread_sigmask(SIG_BLOCK, &signals, NULL);

  //set up configurations
  if (RelayFlags & RL_BUF_PERCPU)
    cpuNum = sysconf(_SC_NPROCESSORS_ONLN);

  subBufSize = bufSize/cpuNum/bufNum;
  subBufNum = bufNum;
  compLevel = level;
  percpuOutSize = outSize/cpuNum;
  //sub-buffer size must meet minimum dio alignment
  if (subBufSize < LXTRACE_DIO_ALIGN)
  {
    DP("trace daemon: tracedevbuffersize must be larger than %d\n",
       LXTRACE_DIO_ALIGN*cpuNum*bufNum);
    return ENOMEM;
  }

  /* Initialize the trace device */
  traceDeviceFD = open(TRC_DEVICE, O_RDWR);
  if (traceDeviceFD < 0)
  {
    /* Device does not exist, wrong type, or already open, ... */
    DP("trace daemon: device open failed with errno %d\n", errno);
    rc = ENODEV;
    return rc;
  }
  DFP("Successfully opened trace device %s\n", TRC_DEVICE);

  /* Record the pid of this process in the tracedev kernel module so we
     can signal this process later. */
  ioctl(traceDeviceFD, TrRegisterTraceDaemon);
  if (controlWrite(DEBUG_DIR, "subbuf_size", subBufSize) < 0)
  {
    rc = errno;
    goto ret;
  }
  if (controlWrite(DEBUG_DIR, "n_subbufs", subBufNum) < 0)
  {
    rc = errno;
    goto ret;
  }
  /* disable logging in case we exited badly in a previous run */
  if (controlWrite(DEBUG_DIR, "enabled", 0) < 0)
  {
    rc = errno;
    goto ret;
  }
  if (controlWrite(DEBUG_DIR, "create", RelayFlags) < 0)
  {
    rc = errno;
    goto ret;
  }

  //only use DIO for blocking mode
  if (writeMode == LXTRACE_BLK)
    useDIO = 1;

  //open relay files, output files and control files
  if (openAppFiles() < 0)
  {
    rc = -1;
    goto ret;
  }
  if (openControlFiles(DEBUG_DIR, percpuBasename) < 0)
  {
    rc = -1;
    goto ret;
  }

  if (allocBuffers() < 0)
  {
    rc = ENOMEM;
    goto ret;
  }
  //create cpu threads for blocking mode
  if (writeMode == LXTRACE_BLK)
  {
    if (createPercpuThreads())
    {
      rc = -1;
      goto ret;
    }
  }

  //turn on trace with given write mode
  if (controlWrite(DEBUG_DIR, "enabled", writeMode) < 0)
  {
    rc = errno;
    goto ret;
  }

  // initialization succeed, send message to parent
  msg.mtype = LXTRACE_MTYPE;
  strcpy(msg.mtext, LXTRACE_INIT_OK);
  msgsnd(msgQueue, &msg, strlen(msg.mtext)+1, 0);
  DFP("trace daemon: send message to parent: %s\n", msg.mtext);

  /* Mark as ready for tracing. */
  rc = ioctl(traceDeviceFD, TrStartBlockingTrace, NULL);
  if (rc < 0)
  {
    DP("trace daemon: device begin failed with errno %d\n", errno);
    //avoid sending message since parent already exited
    rc = 0;
    goto ret;
  }

  DFP("Zlib enabled with comp level %d\n", compLevel);
  DFP("Creating channel with %u sub-buffers of size %u.\n",
      subBufNum, subBufSize);
  DFP("Logging... interval %d\n", interval);

  //receive signal
  sigemptyset(&signals);
  sigaddset(&signals, SIGINT);
  sigaddset(&signals, SIGTERM);
  sigaddset(&signals, SIGIO);

  //flush trace data periodically
  if (interval > 0)
  {
    sigaddset(&signals, SIGALRM);
    alarm(interval);
  }

  while (sigwait(&signals, &signal) == 0)
  {
    switch (signal)
    {
      /* recycle output files */
      case SIGIO:
        //for blocking mode, stop cpu thread first
        if (writeMode == LXTRACE_BLK)
        {
          controlWrite(DEBUG_DIR, "enabled", LXTRACE_BLK | RL_FLUSH);
          killPercpuThreads(cpuNum);
        }
        else
          //for overwrite mode, turn to blocking mode during buffers flushing
          controlWrite(DEBUG_DIR, "enabled", LXTRACE_BLK | RL_FLUSH | RL_NB_PAUSE);
        for (i = 0; i < cpuNum; i++)
          checkBuffer(i);
        if (writeMode == LXTRACE_OVERWRITE)
          //turn back to overwrite mode after flushing 
          controlWrite(DEBUG_DIR, "enabled", LXTRACE_OVERWRITE);
        for (i = 0; i < cpuNum; i++)
        {
          flushAioBuffers(i);
          recycleOutFiles(i, 0);
        }

        /* send ack msg to lxtrace recycle */
        msgQueue = GetMsgQueue(0);
        msg.mtype = LXTRACE_MTYPE;
        msgsnd(msgQueue, &msg, 0, IPC_NOWAIT); 
        DFP("trace daemon: send recycle message %ld to %d\n",
            msg.mtype, msgQueue);
        //need to respawn thread for blocking mode
        if (writeMode == LXTRACE_BLK)
        {
          if (createPercpuThreads())
          {
            DP("trace daemon: create thread error, exiting\n");
            goto ret;
          }
        }
        break;

      /* flush trace data */
      case SIGALRM:
        //only for overwrite mode, turn to blocking mode first
        controlWrite(DEBUG_DIR, "enabled", LXTRACE_BLK);
        //crate cpu thread to flush trace data
        if (createPercpuThreads())
        {
          DP("trace daemon: create thread error, exiting\n");
          goto ret;
        }
        //sychronize each cpu thread
        waitPercpuThreads(cpuNum);
        //go back to overwrite mode
        controlWrite(DEBUG_DIR, "enabled", LXTRACE_OVERWRITE);
        alarm(interval);
        break;

      /* exit lxtrace daemon */
      case SIGINT:
      case SIGTERM:
        controlWrite(DEBUG_DIR, "enabled", RL_DISABLE);
        if (writeMode == LXTRACE_BLK)
        {
          killPercpuThreads(cpuNum);
          //sychronize each cpu thread
          while (1)
          {
            pthread_mutex_lock(&processingMutex);
            if (!processing)
            {
              pthread_mutex_unlock(&processingMutex);
              break;
            }
            pthread_mutex_unlock(&processingMutex);
          }
        }
        for (i = 0; i < cpuNum; i++)
        {
          checkBuffer(i);
          flushAioBuffers(i);
        }
        //send msg to lxtrace off 
        msgQueue = GetMsgQueue(0);
        msg.mtype = LXTRACE_MTYPE;
        msgsnd(msgQueue, &msg, 0, IPC_NOWAIT); 
        DFP("trace daemon: send off message %ld to %d\n", msg.mtype, msgQueue);
        goto ret;

      default:
        goto ret;
    }//switch
  }//while

ret:
  freeBuffers();
  //close all files and turn off trace
  closeControlFiles();
  closeAppFiles();
  controlWrite(DEBUG_DIR, "enabled", RL_DISABLE);
  controlWrite(DEBUG_DIR, "create", 0);
  return rc;
}

#endif  /* GPFS_LINUX */
