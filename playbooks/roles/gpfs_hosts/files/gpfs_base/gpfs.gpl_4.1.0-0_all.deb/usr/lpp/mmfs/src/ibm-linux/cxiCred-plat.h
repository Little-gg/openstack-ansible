/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)87       1.8  src/avs/fs/mmfs/ts/kernext/ibm-linux/cxiCred-plat.h, mmfs, avs_rfks0, rfks01416c 10/20/11 12:22:37 */
#ifndef _h_CXICRED_PLAT
#define _h_CXICRED_PLAT

#ifndef _h_CXICRED
#error Platform header (XXX-plat.h) should not be included directly
#endif

/* Special CIFS privileges (winAccessFlags in ext_cred_t below) */
#define GPFS_WINACCFLAG_HAS_TRAVERSE_PRIVILEGE    0x01

/* Internal extended credential. */
struct ext_cred_t
{
  cxiUid_t principal;          /* user id */
  cxiGid_t group;              /* primary group id */
  int      capabilities;       /* effective capabilities */
  int      winAccessFlags;     /* Windows-oriented access privileges */
  int      num_groups_max;     /* number secondary groups allocated */

  UInt16   num_groups;         /* number secondary groups for this user */
  UInt16   pad;
#define ECRED_NGROUPS 32
  gid_t eGroups[ECRED_NGROUPS];/* array of secondary groups */
};

typedef struct ext_cred_t ext_cred_t;

#define MAX_ECRED_SIZE (PAGE_SIZE)
#define MAX_ECRED_NGROUPS ((MAX_ECRED_SIZE - ((size_t)(&((ext_cred_t *)0)->eGroups[0]))) / sizeof (gid_t))

#endif /* _h_CXICRED_PLAT */
