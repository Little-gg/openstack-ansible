/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)02       1.12  src/avs/fs/mmfs/ts/kernext/ibm-kxi/LockNames.h, mmfs, avs_rfks0, rfks01416c 8/8/13 13:50:07 */

/*
 * Lock classes for simple locks.  Many of these are defined in
 * /usr/include/sys/lockname.h on AIX, but are defined here in case the
 * latest version isn't installed.
 */

#ifndef _h_LockNames
#define _h_LockNames

#ifdef GPFS_AIX
#include <sys/lockname.h>
#endif

/* The AIX names for these locks need to be the discontiguous numbers
   assigned in sys/lockname.h.  To keep statistics for each lock class,
   each lock class must have an index that is a small integer from a
   contiguous range.  Thus, there are two defines for each lock class:
   the AIX lock name (GPFS_LOCK_xxx) and the table index
   (GPFS_LOCK_xxx_IDX).  To add a new lock class, add both defines and
   add the string name of the lock to the KernelLockNamePP table below. */

//#ifndef GPFS_LOCK_BRL
//#define GPFS_LOCK_BRL             607     /* GPFS */
//#endif

//#ifndef GPFS_LOCK_LKOBJWAIT
//#define GPFS_LOCK_LKOBJWAIT       608     /* GPFS */
//#endif

#ifndef GPFS_LOCK_PUD
#define GPFS_LOCK_PUD               609     /* GPFS */
#endif
#define GPFS_LOCK_PUD_IDX             0

#ifndef GPFS_LOCK_RL
#define GPFS_LOCK_RL                610     /* GPFS */
#endif
#define GPFS_LOCK_RL_IDX              1

#ifndef GPFS_LOCK_RLSLEEPER
#define GPFS_LOCK_RLSLEEPER         611     /* GPFS */
#endif
#define GPFS_LOCK_RLSLEEPER_IDX       2

#ifndef GPFS_LOCK_PINTABLE
#define GPFS_LOCK_PINTABLE          612     /* GPFS */
#endif
#define GPFS_LOCK_PINTABLE_IDX        3

//#ifndef GPFS_LOCK_MB
//#define GPFS_LOCK_MB              613     /* GPFS */
//#endif

#ifndef GPFS_LOCK_VINFOACC
#define GPFS_LOCK_VINFOACC          614     /* GPFS */
#endif
#define GPFS_LOCK_VINFOACC_IDX        4

//#ifndef GPFS_LOCK_VINFOINT
//#define GPFS_LOCK_VINFOINT        615     /* GPFS */
//#endif

//#ifndef GPFS_LOCK_MMFSNODE
//#define GPFS_LOCK_MMFSNODE        616     /* GPFS */
//#endif

#ifndef GPFS_LOCK_GPFSNODE
#define GPFS_LOCK_GPFSNODE          616     /* GPFS */
#endif
#define GPFS_LOCK_GPFSNODE_IDX        5

//#ifndef GPFS_LOCK_COMMONRL
//#define GPFS_LOCK_COMMONRL        617     /* GPFS */
//#endif

#ifndef GPFS_LOCK_TSBUF
#define GPFS_LOCK_TSBUF             618     /* GPFS */
#endif
#define GPFS_LOCK_TSBUF_IDX           6

//#ifndef GPFS_LOCK_LOOKUP
//#define GPFS_LOCK_LOOKUP          619     /* GPFS */
//#endif

#ifndef GPFS_LOCK_NFS
#define GPFS_LOCK_NFS               620     /* GPFS */
#endif
#define GPFS_LOCK_NFS_IDX             7

#ifndef GPFS_LOCK_MOUNTS
#define GPFS_LOCK_MOUNTS            621     /* GPFS */
#endif
#define GPFS_LOCK_MOUNTS_IDX          8

//#ifndef GPFS_LOCK_NEEDRESV
//#define GPFS_LOCK_NEEDRESV        622     /* GPFS */
//#endif

#ifndef GPFS_LOCK_SHSEG
#define GPFS_LOCK_SHSEG             623     /* GPFS */
#endif
#define GPFS_LOCK_SHSEG_IDX           9

#ifndef GPFS_LOCK_KSYNCH
#define GPFS_LOCK_KSYNCH            624     /* GPFS */
#endif
#define GPFS_LOCK_KSYNCH_IDX         10


/* These haven't yet been added to /usr/include/sys/lockname.h */

#ifndef GPFS_LOCK_PAGER
#define GPFS_LOCK_PAGER            1019    /* GPFS */
#endif
#define GPFS_LOCK_PAGER_IDX          11

#ifndef GPFS_LOCK_SHMEM
#define GPFS_LOCK_SHMEM            1020    /* GPFS */
#endif
#define GPFS_LOCK_SHMEM_IDX          12

#ifndef GPFS_LOCK_GPFSNODEHASH
#define GPFS_LOCK_GPFSNODEHASH     1021    /* GPFS */
#endif
#define GPFS_LOCK_GPFSNODEHASH_IDX   13

#ifndef GPFS_LOCK_MMAP
#define GPFS_LOCK_MMAP             1022    /* GPFS */
#endif
#define GPFS_LOCK_MMAP_IDX           14

#ifndef GPFS_LOCK_IORENDEZVOUS
#define GPFS_LOCK_IORENDEZVOUS     1023    /* GPFS */
#endif
#define GPFS_LOCK_IORENDEZVOUS_IDX   15

#ifndef GPFS_LOCK_STRATIO
#define GPFS_LOCK_STRATIO          1024    /* GPFS */
#endif
#define GPFS_LOCK_STRATIO_IDX        16

#ifndef GPFS_LOCK_KPROC
#define GPFS_LOCK_KPROC            1025    /* GPFS */
#endif
#define GPFS_LOCK_KPROC_IDX          17

#ifndef GPFS_LOCK_MEMPOOL
#define GPFS_LOCK_MEMPOOL          1026    /* GPFS */
#endif
#define GPFS_LOCK_MEMPOOL_IDX        18

//#ifndef GPFS_LOCK_DFS_INTEROP
//#define GPFS_LOCK_DFS_INTEROP    1027    /* GPFS */
//#endif

#ifndef GPFS_LOCK_RL_SLEEP
#define GPFS_LOCK_RL_SLEEP         1028    /* GPFS */
#endif
#define GPFS_LOCK_RL_SLEEP_IDX       19 

#ifndef GPFS_LOCK_VINFO
#define GPFS_LOCK_VINFO            1029    /* GPFS */
#endif
#define GPFS_LOCK_VINFO_IDX          20

#ifndef GPFS_LOCK_MMAP_FLUSH
#define GPFS_LOCK_MMAP_FLUSH       1030    /* GPFS */
#endif
#define GPFS_LOCK_MMAP_FLUSH_IDX     21

//#ifndef GPFS_LOCK_SMBINTEROP
//#define GPFS_LOCK_SMBINTEROP     1031    /* GPFS */
//#endif

#ifndef GPFS_LOCK_NFSKPROC_DONE
#define GPFS_LOCK_NFSKPROC_DONE    1032    /* GPFS */
#endif
#define GPFS_LOCK_NFSKPROC_DONE_IDX  22

#ifndef GPFS_LOCK_SWAPD
#define GPFS_LOCK_SWAPD            1033    /* GPFS */
#endif
#define GPFS_LOCK_SWAPD_IDX          23

#ifndef GPFS_LOCK_MMAP_FREEQ
#define GPFS_LOCK_MMAP_FREEQ       1034    /* GPFS */
#endif
#define GPFS_LOCK_MMAP_FREEQ_IDX     24

#ifndef GPFS_LOCK_FCNTL_OPS
#define GPFS_LOCK_FCNTL_OPS        1035    /* GPFS */
#endif
#define GPFS_LOCK_FCNTL_OPS_IDX      25 

#ifndef GPFS_LOCK_TSBUF_ELMT
#define GPFS_LOCK_TSBUF_ELMT       1036    /* GPFS */
#endif
#define GPFS_LOCK_TSBUF_ELMT_IDX     26

#ifndef GPFS_LOCK_CIFS_TABLE
#define GPFS_LOCK_CIFS_TABLE       1037    /* GPFS */
#endif
#define GPFS_LOCK_CIFS_TABLE_IDX     27

#ifndef GPFS_LOCK_AIO_UNCOMPQ
#define GPFS_LOCK_AIO_UNCOMPQ      1038    /* GPFS */
#endif
#define GPFS_LOCK_AIO_UNCOMP_IDX     28


/* Update MAX_GPFS_LOCK_NAMES if add too many more locks */
#define MAX_GPFS_LOCK_NAMES 48


#ifdef GPFS_AIX
#ifdef _KERNEL
/* Array that maps lock name indeces to AIX lock names */
EXTERNC int LockIndexToAIXName[];

#ifdef DEFINE_LOCK_INDEX_TO_AIX_NAME_TABLE
int LockIndexToAIXName[] =
{
  GPFS_LOCK_PUD,
  GPFS_LOCK_RL,
  GPFS_LOCK_RLSLEEPER,
  GPFS_LOCK_PINTABLE,
  GPFS_LOCK_VINFOACC,
  GPFS_LOCK_GPFSNODE,
  GPFS_LOCK_TSBUF,
  GPFS_LOCK_NFS,
  GPFS_LOCK_MOUNTS,
  GPFS_LOCK_SHSEG,
  GPFS_LOCK_KSYNCH,
  GPFS_LOCK_PAGER,
  GPFS_LOCK_SHMEM,
  GPFS_LOCK_GPFSNODEHASH,
  GPFS_LOCK_MMAP,
  GPFS_LOCK_IORENDEZVOUS,
  GPFS_LOCK_STRATIO,
  GPFS_LOCK_KPROC,
  GPFS_LOCK_MEMPOOL,
  GPFS_LOCK_RL_SLEEP,
  GPFS_LOCK_VINFO,
  GPFS_LOCK_MMAP_FLUSH,
  GPFS_LOCK_NFSKPROC_DONE,
  GPFS_LOCK_SWAPD,
  GPFS_LOCK_MMAP_FREEQ,
  GPFS_LOCK_FCNTL_OPS,
  GPFS_LOCK_TSBUF_ELMT
};
#endif  /* DEFINE_LOCK_INDEX_TO_NAME_TABLE */
#endif  /* _KERNEL */
#endif  /* GPFS_AIX */


#ifdef INSTRUMENT_LOCKS
#ifdef DEFINE_KERNEL_LOCK_NAMES
/* Lock name table.  Must be kept in synch with the lock name indices above. */
const char* KernelLockNamePP[] =
{
  "Page usage decl",                    // GPFS_LOCK_PUD_IDX             0
  "Rec lock",                           // GPFS_LOCK_RL_IDX              1
  "Rec lock sleeper",                   // GPFS_LOCK_RLSLEEPER_IDX       2
  "Pin table",                          // GPFS_LOCK_PINTABLE_IDX        3
  "Vinfo access",                       // GPFS_LOCK_VINFOACC_IDX        4
  "gpfsNode",                           // GPFS_LOCK_GPFSNODE_IDX        5
  "tsBufLock",                          // GPFS_LOCK_TSBUF_IDX           6
  "NFS",                                // GPFS_LOCK_NFS_IDX             7
  "Mount list",                         // GPFS_LOCK_MOUNTS_IDX          8
  "Shared segment",                     // GPFS_LOCK_SHSEG_IDX           9
  "Kernel synch state",                 // GPFS_LOCK_KSYNCH_IDX         10
  "pagerLock",                          // GPFS_LOCK_PAGER_IDX          11
  "Shared Memory Alloc/Delete",         // GPFS_LOCK_SHMEM_IDX          12
  "gpfsNode hash",                      // GPFS_LOCK_GPFSNODEHASH_IDX   13
  "MMAP",                               // GPFS_LOCK_MMAP_IDX           14
  "I/O rendezvous",                     // GPFS_LOCK_IORENDEZVOUS_IDX   15
  "I/O",                                // GPFS_LOCK_STRATIO_IDX        16
  "MMAP kproc",                         // GPFS_LOCK_KPROC_IDX          17
  "MemPool",                            // GPFS_LOCK_MEMPOOL_IDX        18
  "Rec lock sleep",                     // GPFS_LOCK_RL_SLEEP_IDX       19
  "Vinfo list",                         // GPFS_LOCK_VINFO_IDX          20
  "MMAP flush",                         // GPFS_LOCK_MMAP_FLUSH_IDX     21
  "NFS kproc done",                     // GPFS_LOCK_NFSKPROC_DONE_IDX  22
  "Swapd",                              // GPFS_LOCK_SWAPD_IDX          23
  "MMAP free queue",                    // GPFS_LOCK_MMAP_FREEQ_IDX     24
  "fcntl operation",                    // GPFS_LOCK_FCNTL_OPS_IDX      25
  "tsBuf element",                      // GPFS_LOCK_TSBUF_ELMT_IDX     26
  ""
};
#endif  /* DEFINE_KERNEL_LOCK_NAMES */
#endif  /* INSTRUMENT_LOCKS */

#endif  /* h_LockNames */
