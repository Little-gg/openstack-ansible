/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)24       1.316  src/avs/fs/mmfs/ts/kernext/gpl-linux/super.c, mmfs, avs_rfks0, rfks01416c 4/2/14 11:14:18 */
/*
 * Superblock operations
 *
 * Contents:
 *   TraceBKL
 *   gpfs_s_read_inode2
 *   gpfs_s_read_inode
 *   gpfs_s_delete_inode
 *   gpfs_s_notify_change
 *   gpfs_s_put_super
 *   gpfs_s_statfs
 *   gpfs_s_umount_begin
 *   gpfs_s_remount
 *   gpfs_s_write_inode
 *   gpfs_s_clear_inode
 *   gpfs_s_write_super
 *   gpfs_s_fs_locations
 *   gpfs_fill_super
 *   gpfs_reg_fs
 *   gpfs_unreg_fs
 *   kill_mmfsd
 *   get_myinode
 *   exec_mmfs
 *   fork_mount_helper
 *   vfsUserCleanup
 *   cxiSetMountInfo
 *   cxiUnmount
 *   cxiReactivateOSNode
 *   cxiNewOSNode
 *   cxiFreeOSNode
 *   cxiDeleteMmap
 *   cxiReinitOSNode
 *   cxiFindOSNode
 *   cxiDumpOSNode
 *   cxiRefOSNode
 *   cxiInactiveOSNode
 *   cxiPutOSNode
 *   cxiDestroyOSNode
 *   cxiSetOSNodeType
 *   cxiUpdateInode
 *   cxiCanUncacheOSNode
 *   cxiAddOSNode
 *
 */

#include <Shark-gpl.h>

#include <linux/string.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/fs.h>
#ifndef GPFS_ARCH_X86_64
#define __KERNEL_SYSCALLS__
#endif
#include <linux/unistd.h>
#include <asm/uaccess.h>   /* KERNEL_DS */
#ifdef USE_KTHREAD_CREATE
#include <linux/kthread.h>
#endif

#define FOOBAR #error Do not do this

/* GPFS headers */
#include <verdep.h>
#include <linux2gpfs.h>
#include <cxiSystem.h>
#include <cxiTypes.h>
#include <cxiAtomic.h>
#include <cxi2gpfs.h>
#include <cxiIOBuffer.h>
#include <cxiSharedSeg.h>
#include <cxiCred.h>
#include <linux2gpfs.h>
#include <Trace.h>
#include <cxiVFSStats.h>
#include <linux/kmod.h>
#if LINUX_KERNEL_VERSION > 2062200
#include <linux/exportfs.h>
#endif
#include <linux/wait.h>
#include <linux/sunrpc/svc.h>
#include <linux/nfsd/nfsfh.h>
#include <linux/sunrpc/cache.h>
#include <linux/nfsd/export.h>
#ifdef MUST_DEFINE_SYNCFS
#include <linux/blkdev.h>
#include <linux/quota.h>
const struct quotactl_ops gpfs_quotactl_ops = { NULL };
#endif

/* forward declaration */
int vfsUserCleanup(struct super_block *sbP,  
                   struct gpfsVfsData_t *privVfsP, Boolean force);

int gpfs_get_name(struct dentry *dentry, char *name, struct dentry *child);
void printInodeList(struct super_block *sbP);

extern struct file_system_type  gpfs_fs_type;

int mmfsd_module_active = 0;
static int mount_id = -1;
char mountCmd[CXI_MAXPATHLEN+1] = "M ";
char mmfs_path[CXI_MAXPATHLEN+1] = "";
char bin_path[CXI_MAXPATHLEN+1];
static char mount_opt[CXI_MAXPATHLEN+1];

static unsigned int unusedInodeNum = 1;
static struct inode *unusedInodeP = NULL;
static struct super_block *unusedSuperP = NULL;
struct super_block *shutdownSuperP = NULL;

static spinlock_t gpfs_inode_lock;

/* Routine to trace whether kernel lock is held */
#ifdef VERBOSETRACE
void TraceBKL()
{
  TRACE2(TRACE_VNODE, 10, TRCID_VNODE_BKL,
         "BKL %d lock_depth %d\n", KERNEL_LOCKED(), CURRENT_LOCK_DEPTH);
}
#endif

#include <linux/pagemap.h>

static KMEM_CACHE_T* gpfsInodeCacheP;
struct gpfs_bloated_inode 
{
   struct inode inode;
   char cxiNode[CXINODE_SIZE];
};

static atomic_t GpfsInodeCount = ATOMIC_INIT(0);

static void 
#if LINUX_KERNEL_VERSION >= 2062700
gpfs_init_once(void * iP)
{
     inode_init_once((struct inode *)iP);
}
#else
#if LINUX_KERNEL_VERSION >= 2062400
gpfs_init_once(KMEM_CACHE_T * cacheP, void * iP)
#else
gpfs_init_once(void * iP, KMEM_CACHE_T * cacheP, unsigned long flags)
#endif
{
#if LINUX_KERNEL_VERSION < 2062200
  if ((flags & (SLAB_CTOR_VERIFY|SLAB_CTOR_CONSTRUCTOR)) ==
      SLAB_CTOR_CONSTRUCTOR)
#endif
     inode_init_once((struct inode *)iP);
}
#endif

int
gpfs_init_inodecache(void)
{
  gpfsInodeCacheP = kmem_cache_create("gpfsInodeCache",
                                      sizeof(struct gpfs_bloated_inode), 0,
                                      SLAB_HWCACHE_ALIGN|SLAB_RECLAIM_ACCOUNT,
                                      gpfs_init_once
#if LINUX_KERNEL_VERSION < 2062300
                                      , NULL /* dtor */
#endif
                                      );

  if (gpfsInodeCacheP == NULL)
    return -ENOMEM;
  return 0;
}

struct inode *
gpfs_alloc_inode(struct super_block *sbP)
{
  struct inode * iP;

  iP = (struct inode *)kmem_cache_alloc(gpfsInodeCacheP, SLAB_KERNEL);

  if (iP != 0)
    atomic_inc(&GpfsInodeCount);

  /* This trace record serialize linux kernel threads during
     operations on the dcache. */
  TRACE1N(TRACE_VNODE, 5, TRCID_LINUXOPS_GPFS_ALLOC_INODE_EXIT,
         "gpfs_alloc_inode: inode 0x%lX\n", iP);
  return iP;
}

void 
gpfs_destroy_inode(struct inode *iP)
{
  /* NOTE: This trace record serializes linux kernel threads that 
     are freeing slab memory. When the tracelevel is set to generate
     this trace, gpfs is unable to free gpfsInodeCache memory rapidly
     enough to prevent an out-of-memory condition in the kernel. */
  TRACE1N(TRACE_VNODE, 5, TRCID_LINUXOPS_GPFS_DESTROY_INODE,
         "gpfs_destroy_inode: inode 0x%lX\n", (void *)iP);

  if (iP == NULL)
    return;

  atomic_dec(&GpfsInodeCount);
  kmem_cache_free(gpfsInodeCacheP, (void *)iP);
}

void 
gpfs_destroy_inodecache(void)
{
  int count = 0;
  while (kmem_cache_shrink(gpfsInodeCacheP) != 0 && count++ < 1000)
      cxiSleep(40);
#if LINUX_KERNEL_VERSION >= 2061900
  kmem_cache_destroy(gpfsInodeCacheP);
#else
  while (kmem_cache_destroy(gpfsInodeCacheP) != 0 && count++ < 1000)
      cxiSleep(40);
#endif
  /* Under normal circumstances kmem_cache_ calls finish immediately
     or after a few tries.  However, if some inodes have mismanaged ref
     counts (as a result of a bug), GPFS inode cache object won't be
     destroyed, and trying forever would result in a hung rmmod.  Turn
     the hang into an assert instead. */
  LOGASSERT(count < 1000);
}


/* This routine is called from iget() just after allocating a new inode.
   This is a variant of the normal read_inode operation that allows passing an
   opaque parameter through iget4 into read_inode2.  We need the parameter to
   know whether read_inode2 is being called from a normal lookup opration,
   where we are already holding a distributed lock on the file, or from nfs
   calling iget, where we need to get the lock inside of read_inode2.

   Note: In the Linux source the call to read_inode2 is labelled a "reiserfs
   specific hack" with the additional warning "We don't want this to last, and
   are looking for VFS changes that will allow us to get rid of it." If and
   when such a change is made, we will hopefully be able to adapt our code
   accordingly.  Otherwise, if read_inode2 goes away without a suitable
   replacement, we will have to use a more expensive approach, e.g., a global
   table where lookup would leave some state before calling iget. */
void
gpfs_s_read_inode2(struct inode *iP, void *opaque)
{
  struct gpfsVfsData_t *privVfsP;
  ino_t inum = iP->i_ino;
  cxiNode_t *cnP;
  int rc;

  ENTER(0);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_READINODE_ENTER,
         "gpfs_s_read_inode2 enter: inode 0x%lX inode %lld\n",
         iP, inum);
  /* BKL is sometimes held at entry */

  cnP = (cxiNode_t *)&((struct gpfs_bloated_inode *)iP)->cxiNode;
  memset(cnP, 0, CXINODE_SIZE);

  TRACE4(TRACE_VNODE, 2, TRCID_LINUXOPS_NEW_VNODE_1,
         "gpfs_s_read_inode2: iP 0x%lX cnP 0x%lX uSize-void* %d nodeSize %d",
         iP, cnP, sizeof(iP->PRVINODE) - sizeof(void *), CXINODE_SIZE);

  /* connect cxiNode_t to struct inode */
  cnP->osNodeP = iP;
  iP->PRVINODE = cnP;

  /* get inode attributes */
  privVfsP = VP_TO_PVP(iP);
  rc = gpfs_ops.gpfsInodeRead(privVfsP, cnP, inum, opaque);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_READINODE_EXIT,
         "gpfs_s_read_inode2 exit: inode 0x%lX rc %d",
         iP, rc);

  if (rc == 0)
  {
    EXIT(0);
    return;  /* success! */
  }

  /* undo cxiNode_t allocation */
  cnP->osNodeP = NULL;
  iP->PRVINODE = NULL;

exit_bad:
  /* make_bad_inode will initialize iP so that all operations return EIO;
     also set i_nlink to zero so that the bad inode will be thrown out of
     the cache at the next opportunity */
  make_bad_inode(iP);
  set_nlink(iP, 0);
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READINODE_EXIT_BAD,
         "gpfs_s_read_inode2 exit: inode 0x%lX rc BADINODE",
         iP);

  if (rc)
    cxiErrorNFS(rc);

  EXIT(0);
}

/* The following routine should never be called, since we have a read_inode2
   operation.  However, knfsd checks the operation table and refuses to export
   a file system if its read_inode operation ptr is NULL.  Hence, we need to
   have one, even if it never gets called. */
void
gpfs_s_read_inode(struct inode *iP)
{
  /* only iget will use read_inode; this shouldn't happen as long as
     gpfs_nfsd_iget is being invoked via fh_to_dentry/gpfs_fh_to_dentry */
  ENTER(0);
  TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_READINODE_HUH,
         "gpfs_s_read_inode: ? calling make_bad_inode");
  make_bad_inode(iP);
  EXIT(0);
}


/* The following routine is called from iput when the i_count goes to zero and
   the link count in the inode is zero, which presumably means that the file
   was deleted.  If so, we should free the disk space occupied by the file. */
void
gpfs_s_delete_inode(struct inode *iP)
{
  cxiNode_t *cnP;
  Boolean isGPFS = (cxiIsGPFSThread() || cxiIsGpfsSwapdThread());
  struct gpfsVfsData_t *privVfsP;

  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_DELETE_INODE,
        "gpfs_s_delete_inode enter: inode 0x%lX inode %lld gpfsThread %d",
        iP, iP->i_ino, isGPFS);
  TraceBKL();

#if MUST_TRUNCATE_INODE_PAGES
  truncate_inode_pages(&iP->i_data, 0);
#endif

  cnP = VP_TO_CNP(iP);

  if (!cnP) 
  {
    /* The cxiNode_t is allocated in gpfs_s_read_inode2, so if cnP is NULL,
       this means gpfs_s_read_inode2 failed and has marked this as a bad
       inode.  No further actions necessary in this case. */
    goto xerror;
  }

  TRACE3(TRACE_VNODE, 4, TRCID_LINUXOPS_DELETE_INODE1,
        "gpfs_s_delete_inode: inode %lld cnP 0x%08X ctFlags 0x%08X",
        iP->i_ino, cnP, cnP->ctFlags);
  if (TestCtFlag(cnP, destroyIfDelInode))
  {
    privVfsP = VP_TO_PVP(iP);
    DBGASSERT(privVfsP != NULL);

    gpfs_ops.gpfsInodeDelete(privVfsP, cnP, isGPFS);

    iP->PRVINODE = NULL;
    cnP->osNodeP = NULL;
  }

xerror:
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_DELETE_INODE_1,
         "gpfs_s_delete_inode exit: inode 0x%lX cnP 0x%lX",
         iP, cnP);

#ifdef HAS_END_WRITEBACK
  end_writeback(iP);
#else
  clear_inode(iP);
#endif
  EXIT(0);
}

#if (LINUX_KERNEL_VERSION >= 2063600)
void
gpfs_s_evict_inode(struct inode *iP)
{
  gpfs_s_delete_inode(iP);
  gpfs_s_clear_inode(iP);
}
#endif

int 
gpfs_s_notify_change(struct dentry *dentryP, struct iattr *attrP)
{
  int rc;

  ENTER(0);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_NOTIFY_ENTER,
         "gpfs_s_notify_change enter: inode 0x%lX attr 0x%lX\n",
         dentryP->d_inode, attrP);
  TraceBKL();

  rc = gpfs_i_setattr_internal(dentryP->d_inode, attrP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_NOTIFY_EXIT,
         "gpfs_s_notify_change exit: inode 0x%lX rc %d\n",
         dentryP->d_inode, rc);
  EXIT(0);
  if (rc)
    return (-rc);
  return rc;
}

/* put_super is called just before the super_block is freed in do_unmount */
void 
gpfs_s_put_super(struct super_block *sbP)
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP;

  ENTER(0);
  LOGASSERT(sbP != NULL);
  LOGASSERT(sbP->s_magic == GPFS_SUPER_MAGIC);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_PUTSUPER_ENTER,
         "gpfs_s_put_super enter: sbP 0x%lX sbP->s_dev 0x%X\n",
         sbP, sbP->s_dev);
  TraceBKL();

  rc = cxiUnmount(sbP, false, true);

  printInodeList(sbP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_PUTSUPER_EXIT,
         "gpfs_s_put_super exit: rc %d\n", rc);

  EXIT(0);
}

#if defined(STATFS_USES_DENTRY) || LINUX_KERNEL_VERSION > 2061700 || \
      (defined(CONFIG_SLE_VERSION) && CONFIG_SLE_VERSION == 10 && CONFIG_SLE_SP == 2)
int
gpfs_s_statfs(struct dentry *dentryP, struct kstatfs *bufP)
{
  struct super_block *sbP = dentryP->d_sb;
  struct inode *iP = dentryP->d_inode;
#else
int
gpfs_s_statfs(struct super_block *sbP, struct kstatfs *bufP)
{
  struct inode *iP = NULL;
#endif
  int rc;
  int code = 0;
  int len = sizeof(struct kstatfs);
  struct gpfsVfsData_t *privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;
  cxiStatfs_t statfs; 
  cxiNode_t *cnP = NULL;

  VFS_STAT_START(statfsCall);
  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_STATFS_ENTER,
         "gpfs_s_statfs enter: sbP 0x%lX len %d iP 0x%lX\n", sbP, len, iP);
  memset(bufP, 0, len);
  /* BKL is held at entry */

  LOGASSERT(sbP->s_magic == GPFS_SUPER_MAGIC);
  LOGASSERT(privVfsP != NULL);

  if (iP)
    cnP = VP_TO_CNP(iP);

  rc = gpfs_ops.gpfsStatfs(privVfsP, &statfs, cnP, NULL);
  if (rc)
  {
    rc = -rc;
    code = 1;
    goto xerror;
  }

  bufP->f_type = GPFS_SUPER_MAGIC;
  bufP->f_bsize = statfs.f_bsize;
  bufP->f_blocks = statfs.f_blocks;
  bufP->f_bfree = statfs.f_bfree;
  bufP->f_bavail = statfs.f_bavail;
  bufP->f_files = statfs.f_files;
  bufP->f_ffree = statfs.f_ffree; 
  bufP->f_namelen = statfs.f_name_max;
  bufP->f_fsid.val[0] = statfs.f_fsid.val[0];
  bufP->f_fsid.val[1] = statfs.f_fsid.val[1];

  /* If filesystem size cannot be represented by the OS statfs structure,
     increase the "block size" and reduce the numbers */
  if (sizeof(bufP->f_blocks) < sizeof(statfs.f_blocks))
  {
    while (bufP->f_blocks != statfs.f_blocks)
    {
      statfs.f_bsize  <<= 1;  /* double f_bsize */
      statfs.f_blocks >>= 1;  /* halve the rest */
      statfs.f_bfree  >>= 1;
      statfs.f_bavail >>= 1;
      bufP->f_bsize = statfs.f_bsize;
      bufP->f_blocks = statfs.f_blocks;
      bufP->f_bfree = statfs.f_bfree;
      bufP->f_bavail = statfs.f_bavail;
    }
  }

xerror:
  TRACE7(TRACE_VNODE, 1, TRCID_LINUXOPS_STATFS_EXIT,
         "gpfs_s_statfs exit: f_blocks %lld f_bfree %lld f_files %lld "
         "f_free %lld f_bsize %d code %d rc %d\n",
         statfs.f_blocks, statfs.f_bfree, bufP->f_files, bufP->f_ffree,
         bufP->f_bsize, code, rc);

  if (rc)
    cxiErrorNFS(rc);

  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}

void 
#if LINUX_KERNEL_VERSION >= 2061700 && LINUX_KERNEL_VERSION < 2062600
/* umount_begin is called with flags = MNT_FORCE when force option used */
gpfs_s_umount_begin(struct vfsmount *vfs, int flags)
#else
/* umount_begin is called only when the force option is used */
gpfs_s_umount_begin(struct super_block * sbP)
#endif
{
  int dmrc = 0;
  char* sgNameP=NULL;
  struct gpfsVfsData_t *privVfsP;
  Boolean doDMEvents = false;
  struct dentry *dP = NULL;
  struct inode *iP = NULL;
  cxiNode_t *cnP = NULL;
#if LINUX_KERNEL_VERSION >= 2061700  && LINUX_KERNEL_VERSION < 2062600
  struct super_block * sbP;
  LOGASSERT(vfs != NULL);
  LOGASSERT(vfs->mnt_sb != NULL);
  sbP = vfs->mnt_sb;
#else
  int flags = MNT_FORCE;
#endif

  ENTER(0);
  LOGASSERT(sbP != NULL);
  LOGASSERT(sbP->s_magic == GPFS_SUPER_MAGIC);
  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_UMOUNT_ENTER,
         "gpfs_s_umount_begin enter: sbP 0x%lX sbP->s_dev 0x%X "
         "root vfsmount 0x%X pwd vfsmount 0x%X force %d\n", sbP, sbP->s_dev, 
         TASK_ROOTMNT(current), TASK_PWDMNT(current), flags & MNT_FORCE);
  TraceBKL();

  privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;

  /* We may need to generate a preunmount DMAPI event, since this 
   * is a user initiated force unmount and we need to inform any
   * DM application before we start flushing out VFS users.
   */
  if (privVfsP)
  {
#ifdef USER_EXIT_ENTENSIONS
    gpfs_ops.gpfsGenFsUnmountCallback(true, flags & MNT_FORCE, privVfsP, &sgNameP, false);
#endif

    dP = sbP->s_root;
    if (dP != NULL)
      iP = dP->d_inode;
    if (iP != NULL)
      cnP = VP_TO_CNP(iP);

    /* Generate preunmount event.  We have to present this because 
     * vfsUserCleanup() may potentially kill processes on forced unmount.
     * Since the DM application may have an open file in this file system
     * we have to warn him.   The DM application may not however receive
     * the final unmount event if we can't get everything released.  If 
     * VFS users still exist after this, then no mntput() and subsequent 
     * gpfs_s_put_super() will occur.
     */
    dmrc = gpfs_ops.gpfsDmUnmountEvent(true, flags & MNT_FORCE, privVfsP, cnP,
                                       &doDMEvents, NULL, NULL, NULL, 0);

#ifdef GPFS_CACHE
    gpfs_ops.gpfsUnmountPcache(privVfsP, flags & MNT_FORCE);
#endif

    /* Force unmount */
    vfsUserCleanup(sbP, privVfsP, flags & MNT_FORCE);

    if (sbP->s_root)
      printDentryTree(sbP->s_root, 10);
#ifdef USER_EXIT_ENTENSIONS
    /*clean up sgNameP only */
    gpfs_ops.gpfsGenFsUnmountCallback(false, flags & MNT_FORCE, privVfsP, &sgNameP, true);
#endif    
  }
  
exit:
  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_UMOUNT_EXIT,
         "gpfs_s_umount_begin exit: sbP 0x%lX privVfsP 0x%lX dmrc %d "
         "s_active %d s_count 0x%X",
         sbP, privVfsP, dmrc, atomic_read(&sbP->s_active), 
         sbP->s_count);

  /* Module count is decremented later on in do_unmount via gpfs_s_put_super */
  EXIT(0);
}

int 
gpfs_s_remount(struct super_block *sbP, int *flags, char *data)
{
  ENTER(0);
  TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_REMOUNT,
         "gpfs_s_remount: called\n");
  TraceBKL();
  EXIT(0);
  return 0;
}
#if defined(REDHAT_RHEL6) || LINUX_KERNEL_VERSION >= 2063400
int
gpfs_s_write_inode(struct inode *iP, struct writeback_control *wbcP)
#else
int
gpfs_s_write_inode(struct inode *iP, int wait)
#endif
{
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP;
  struct MMFSVInfo *vinfoP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  int rc = 0, NFSflags;

  ENTER(0);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_WRITEINODE,
         "gpfs_s_write_inode enter: iP 0x%lX isDir %d\n",
          iP, S_ISDIR(iP->i_mode));
  TraceBKL();

  if (S_ISDIR(iP->i_mode))
    goto exit;

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    rc = 0;
    goto exit;
  }

  rc = gpfs_ops.gpfsGetOpenNFS((void *)iP, (struct MMFSVInfo **)&vinfoP,
                                                                &NFSflags);
  if (rc || vinfoP == NULL)
  {
    rc = 0;
    goto exit;
  }
  rc = gpfs_ops.gpfsSyncNFS(privVfsP, cnP, 0, eCredP);
  gpfs_ops.gpfsReleaseNFS(iP);

exit:
  putCred(&eCred, &eCredP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_WRITEINODE_EXIT,
         "gpfs_s_write_inode exit: iP 0x%lX\n", iP);

  EXIT_RC(0, rc);
  return -rc;
}


/* This routine is called from iput() just before the storage of the
   Linux inode is freed.  Since this code path is involved during
   inode cache shrinkage, it it critical for the clear_inode operation
   to be as fast as possible, else there is a risk of slowing down the
   overall cache reclaim process to the point where it may lead to 
   memory allocation failures.  We need to avoid doing anything that
   is not strictly necessary in this path, like trace calls enabled at
   the default levels, expensive debugging code, etc. */
void
gpfs_s_clear_inode(struct inode *iP)
{
  int code = 0;
  struct gpfsVfsData_t *privVfsP;
  cxiNode_t *cnP; 

  TRACE3N(TRACE_VNODE, 5, TRCID_LINUXOPS_CLEARINODE,
         "gpfs_s_clear_inode enter: inode 0x%lX inode %lld generic_ip 0x%lX",
         iP, iP->i_ino, iP->PRVINODE);
  TRACE2N(TRACE_VNODE, 5, TRCID_LINUXOPS_CLEARINODE_DETAILS, 
         "gpfs_s_clear_inode: cnP 0x%lX privVfsP 0x%lX",
         VP_TO_CNP(iP), VP_TO_PVP(iP));

  DBGASSERT(atomic_read((atomic_t *)&iP->i_count) == 0);

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);

  if (cnP)
    gpfs_ops.gpfsRele(privVfsP, cnP, (void *)iP);

xerror:
  TRACE3N(TRACE_VNODE, 5, TRCID_LINUXOPS_CLEARINODE_EXIT,
         "gpfs_s_clear_inode exit: inode 0x%lX generic_ip 0x%lX code %d\n",
         iP, iP->PRVINODE, code);
}

#ifdef HAS_WRITE_SUPER
void 
gpfs_s_write_super(struct super_block * sbP)
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP;
  gpfsSyncType_t syncMode = GPFS_SYNC_LEGACY;

  ENTER(0);
  LOGASSERT(sbP != NULL);
  LOGASSERT(sbP->s_magic == GPFS_SUPER_MAGIC);
  privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;
  LOGASSERT(privVfsP != NULL);
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_WRITESUPER,
         "gpfs_s_write_super enter: sbP 0x%lX\n", sbP);

  /* We have to either adhere to the s_dirt semantics or
   * ignore all syncs.  Once a file systems write_super gets 
   * called, sync_supers() restarts the super block scan.  If 
   * we don't turn off s_dirt then sync_supers() will be caught
   * in a loop.  Alternatively if we only ignored kupdated then
   *
   * 1) a person could write to a file (which turns on s_dirt)
   * 2) kupdated could run (and be ignored) but the s_dirt is turned off
   * 3) the user attempts a sync from the command line sync, but that
   *    does nothing since s_dirt was off
   * 4) the user expected the sync to have done something before he 
   *    halts the machine.
   */
  sbP->s_dirt = 0;

   /*
   * jcw: Another way to handle this would be never turn on the s_dirt flag,
   * and not to even have a write_super callback.  Then neither kupdated nor
   * sync would do anything.  The sync watchdog in the GPFS daemon would
   * substitute for kupdated.  To regain the semantics of sync, we would
   * create dummy inodes that would have I_DIRTY set, and link one such inode
   * onto each GPFS superblock.  Then sync would notice the dirty inodes
   * and call back through their write_inode callbacks.  This would be
   * the only use of I_DIRTY by GPFS, so it could be reinterpreted to mean
   * "sync this file system".  For now, s_dirt is still set and reset, but
   * s_dirt gets reset for all file systems before they have all been synced,
   * so the race described above can occur.  The permanently-dirty inode
   * needs to be implemented to fix this.
   */
/*  goto xerror; */

  /* BKL is held at entry */
  TRACE0(TRACE_VNODE, 3, TRCID_LINUXOPS_WRITESUPER_3,
         "gpfs_s_write_super: performing sync");

/* From 2.6.31, kernel splits the explicit sync and periodic sync
   into sync_supers kthread and sync_fs() super block ops. So 
   we always do incomplete sync when comes from write_super(), which
   is always the case for periodic sync. */
#ifdef MUST_DEFINE_SYNCFS
  syncMode = GPFS_SYNC_INCOMPLETE;
#endif
  rc = gpfs_ops.gpfsSyncfs(privVfsP, syncMode);
  if (rc) {
    cxiErrorNFS(rc);
    rc = -rc;
  }
xerror:
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_WRITESUPER_5,
         "gpfs_s_write_super exit: sbP 0x%lX rc %d\n", sbP, rc);
  EXIT(0);
}
#endif 
  
#ifdef MUST_DEFINE_SYNCFS
/* Impementation of sync_fs() super block operation.
 * The content of this function derives from gpfs_s_write_super(). */
int
gpfs_s_sync_fs(struct super_block * sbP, int wait)
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP;

  ENTER(0);
  LOGASSERT(sbP != NULL);
  LOGASSERT(sbP->s_magic == GPFS_SUPER_MAGIC);
  privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;
  LOGASSERT(privVfsP != NULL);
#ifdef HAS_S_DIRT
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_SYNCFS,
         "gpfs_s_sync_fs enter: sbP 0x%lX, sbP->s_dirt %d, wait %d",
          sbP, sbP->s_dirt, wait);
#else
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_SYNCFS_1,
         "gpfs_s_sync_fs enter: sbP 0x%lX, wait %d", sbP, wait);
#endif

  /* We always skip sync when wait is false so that no excessive sync message
     will be sent to daemon. */
  if (!wait) 
    goto exit;

#ifdef HAS_S_DIRT
  /* Don't really sync GPFS when no dirty data. */
  if (sbP->s_dirt == 0)
    goto exit;

  /* We are going to do a complete sync so forbid other sync
     to come in by resetting s_dirt. */
  /* Check gpfs_s_write_super() for more details. */
  sbP->s_dirt = 0;
#endif

  rc = gpfs_ops.gpfsSyncfs(privVfsP, GPFS_SYNC_COMPLETE);

exit:
  if (rc) 
  {
    cxiErrorNFS(rc);
    rc = -rc;
  }
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_SYNCFS_EXIT,
         "gpfs_s_sync_fs exit: sbP 0x%lX rc %d\n", sbP, rc);
  EXIT(0);
  return(rc);
}
#endif

#ifdef FILE_SYSTEM_TYPE_HAS_MOUNT_OP
struct dentry *
gpfs_mount(struct file_system_type *fsTypeP,
            int flags, const char *devNameP, void *dataP)
{
  struct dentry *dP = NULL;
  ENTER(0);

  dP = mount_nodev(fsTypeP, flags, dataP, gpfs_fill_super);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_MOUNT,
         "gpfs_mount: flags 0x%X dataP 0x%X dP 0x%X\n",
         flags, dataP, dP);

  EXIT(0);
  return dP;
}

#elif LINUX_KERNEL_VERSION > 2061700
int
gpfs_get_sb(struct file_system_type *fsTypeP,
            int flags, const char *devNameP, void *dataP, struct vfsmount *vfs)
{
  int err;
  struct super_block *sbP = NULL;

  ENTER(0);

  err = get_sb_nodev(fsTypeP, flags, dataP, gpfs_fill_super, vfs);
  sbP = vfs->mnt_sb;

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_GET_SB2,
         "gpfs_get_sb: flags 0x%X dataP 0x%X sbP 0x%X\n",
         flags, dataP, sbP);
          
  EXIT(0);
  return err;
}
#else
struct super_block *
 gpfs_get_sb(struct file_system_type *fsTypeP,
            int flags, const char *devNameP, void *dataP)
 {
  struct super_block *sbP;

   ENTER(0);
   sbP = get_sb_nodev(fsTypeP, flags, dataP, gpfs_fill_super);

   TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_GET_SB,
          "gpfs_get_sb: flags 0x%X dataP 0x%X sbP 0x%X\n",
          flags, dataP, sbP);

   EXIT(0);
   return sbP;
 }
#endif

int
gpfs_fill_super(struct super_block *sbP, void *dataP, int silent)
{
  int kernel_unlock = 0;
  struct inode *rootIP = NULL;
  struct dentry *rootDP = NULL;
  char *myBufP = NULL;
  char *sgNameP;
  char *strP;
  char *strP2;
  char *mountpointP;
  char *optionsP;
  int rc = 0;
  int mountHelperID = -1;
  int code = 0;
  int namelen;
  struct gpfsVfsData_t *privVfsP;
  cxiNode_t *cnRootP;
  cxiIno_t rootINum;
  char bname[BDEVNAME_SIZE];
  Boolean restricted = false;
#ifdef MUST_USE_BDI
  struct backing_dev_info * bdiP = NULL;
  Boolean bdiRegistered = false;
#endif
  ENTER(0);
  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_1,
         "gpfs_fill_super enter: sbP 0x%lX dev 0x%X silent %d data '%s'\n",
         sbP, sbP->s_dev, silent, ((char *)dataP == NULL) ? "" : dataP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_2,
         "gpfs_fill_super: dev name '%s'\n", 
         (sbP->s_bdev == NULL) ? "" : bdevname(sbP->s_bdev, bname));

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_3,
         "gpfs_fill_super: s_flags 0x%x\n", sbP->s_flags);

  if (dataP == NULL || *(char *)dataP == '\0')
  {
    rc = EINVAL;
    code = 1;
    goto xerror;
  }
   
  if (strlen((char *)dataP) > CXI_MAXPATHLEN)
  {
    rc = ENAMETOOLONG;
    code = 2;
    goto xerror;
  }

  sbP->s_magic = GPFS_SUPER_MAGIC;
  sbP->s_op = &gpfs_sops;
  sbP->s_export_op = &gpfs_export_ops;
  sbP->s_fs_info = NULL;
  sbP->s_root = NULL;
  sbP->s_blocksize = 0;
  sbP->s_blocksize_bits = 0;
  /* maximum filesize (avoid sign bit due to use with loff_t) */
  sbP->s_maxbytes = 0x7FFFFFFFFFFFFFFFULL;
#ifdef MUST_DEFINE_SYNCFS
  /* GPFS implements its own quota mechanism without quotactl_ops.
   * By default, Linux will assign vfs_quotactl_ops to any newly 
   * allocated super block in alloc_super() function.
   * We should reset quotactl_ops to all NULL to avoid Linux kernel invoking
   * improper quota operations to GPFS FS and improper sync_fs() which has
   * been observed from vfs_quota_disable() and sync_quota_sb().*/
  sbP->s_qcop = &gpfs_quotactl_ops;
#endif

  myBufP = (char *)cxiMallocPinned(strlen((char *)dataP) + 1);
  if (myBufP == NULL)
  {
    code = 3;
    rc = ENOMEM;
    goto xerror;
  }
  strcpy(myBufP, (char *)dataP);
  optionsP = myBufP;

  /* This is the syntax parser for the options field.  At
   * least one option must be "dev=<devname>".
   */
  sgNameP = NULL;
  strP = myBufP;

  while(strP)
  {
    if (!strncmp(strP, "dev=", 4))
    {
      strP2 = strP;
      sgNameP = (char *)strchr(strP, '=') + 1;
      strP = (char *)strchr(strP, ','); /* more options */
      if (strP)
        namelen = strP - sgNameP;
      else
        namelen = strlen(sgNameP);

      /* Copy the sgName into the first part of the 
       * buffer, null terminate it, then append the 
       * full option list.
       */
      strncpy(myBufP, sgNameP, namelen);
      sgNameP = myBufP;
      sgNameP[namelen] = '\0';

      optionsP = myBufP + namelen + 1;
      /* Move the options next (if there are any) */
      if (strP2 > (char*)myBufP)
      {
        namelen = strP2 - (char*)myBufP;
        strncpy(optionsP, (char *)dataP, namelen);
        strcpy(optionsP + namelen, strP?(char *)strP:"");
      }
      else
        strcpy(optionsP, strP?(char *)strP:"");
      break;
    }
    else
    {
      strP = (char *)strchr(strP, ',');
      if (strP) strP++;
    }
  }

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_OPTIONS,
         "gpfs_fill_super: optionsP \"%s\"\n", optionsP);

  strP = optionsP;
  while (strP)
  {
    /* look for rs option */
    strP = (char *)strchr(strP, ',');
    if (strP) 
      strP++;
    if (strP)
    {
      if (!strncmp(strP, "rs", 2))
      {
        restricted = true;
        break;
      }
    }
  }

  if (sgNameP == NULL || *sgNameP == '\0')
  {
    code = 4;
    rc = EINVAL;
    goto xerror;
  }
  mountpointP = sgNameP;  /* ??? */

  if (restricted)
  {
    /* restricted mount - make it readonly */
    sbP->s_flags |= MS_RDONLY;
  }
#ifdef REDHAT_RHEL53
  sbP->s_flags |= MS_HAS_SETLEASE;
#endif
#if LINUX_KERNEL_VERSION >= 2060000
  /* GPFS does not consider the umask when the parent directory
   * has a default ACL.  We must also prevent the Linux vfs from
   * merging the umask with the mode when it calls create, and
   * this is done by declaring support for POSIX ACLs (see
   * the IS_POSIXACL check in open_namei).
   */
  sbP->s_flags |= MS_POSIXACL;
#endif

  strcpy(mmfs_path, bin_path);
  strcat(mmfs_path, "/mmfsmount");

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_STARTHELPER,
         "gpfs_fill_super: start mount helper '%s'\n", mmfs_path);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_STARTHELPER1,
         "gpfs_fill_super: s_flags 0x%x (rs %d), mountpointP %s\n", 
          sbP->s_flags, restricted, mountpointP);

  if (strlen(sgNameP) > CXI_MAXPATHLEN)
  {
    rc = ENAMETOOLONG;
    code = 5;
    goto xerror;
  }
  rc = gpfs_ops.gpfsReady();
  if (rc != 0)
  {
    rc = EAGAIN;
    code = 6;
    goto xerror;
  }

  /* Start a new process that will receive and forward all messages during the
   * mount process to the mount invoker. The current process will wait for
   * this new process (in HandleMBUnmount()) and the daemon to be connected with
   * a socket and only than call SFSMountFS() that does the real mount work.
   */
  strcpy(&mountCmd[2], sgNameP);               /* "M /dev/gpfs1" */
  if (cxiHasMountHelper())
    mountHelperID = fork_mount_helper(mountCmd);
  else
  {
    /* Use special pid (-1) when not using mount helper */
    mountHelperID = -1;
  }

#ifdef MUST_USE_BDI
  bdiP = cxiMallocPinned(sizeof(*bdiP));
  if (!bdiP)
  {
    rc = ENOMEM;
    code = 9;
    goto xerror;
  }
  /* Initialize the BDI device for sync_fs() to work. */
  rc = initBDI(bdiP, sbP);
  if (rc)
  {
    code = 10;
    goto xerror;
  }
  /* Remeber that BDI is already registered so that we can destroy it
     when error happens later. */
  bdiRegistered = true;
#endif

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_HELPERRC,
         "gpfs_fill_super: mount helper mountHelperID %d\n", mountHelperID);

  /*
   * In 2.5, a bunch of calls originating from sys_sync will try to down
   * s_umount and block, because it's already downed in get_sb_nodev, and won't
   * be upped until get_sb returns (in do_kern_mount).  During gpfsMount, we'll
   * call mmcommon getEFOption, and that will at some point try to do a sync
   * (e.g. in gpfsClusterInit, two times), and mount will deadlock.  One way
   * to fix this is to take out relevant sync's in the shell scripts, but this
   * is dodgy because we might end up pulling a new sdr from another node, and
   * that's a long and compelex path, I don't think one can guarantee there 
   * won't be any syscalls that desire s_umount along the way.  Need to think
   * how to fix this right.  For now, up the semaphore for the duration of 
   * the gpfsMount (possibly opening up a window for other races e.g. with
   * unmount). 
   */
  up_write(&sbP->s_umount);
  rc = gpfs_ops.gpfsMount((void *)sbP, PAGE_SIZE, sgNameP, mountpointP,
                 optionsP,
                 (struct gpfsVfsData_t **)&(sbP->s_fs_info),
                 &cnRootP,      /* returned root cxiNode_t */
                 &rootINum,     /* returned root inode number */
                 NULL,          /* not a soft mount */
                 mountHelperID  /* mount helper id */,
                 -1U,           /* no unique mount ID specified */
                 (sbP->s_flags & MS_RDONLY), /* is it readonly */
                 true);   /* allocate pinned memory */

  down_write(&sbP->s_umount);

  if (rc)
  {
    code = 7;
    goto xerror;
  }

  privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;
  DBGASSERT(cnRootP != NULL);
  rootIP = (struct inode *)cnRootP->osNodeP;

  DBGASSERT(rootIP != NULL);
  DBGASSERT(rootIP->PRVINODE == cnRootP);
  DBGASSERT(cnRootP->osNodeP == rootIP);

  /* Successful mount in daemon.  Allocate root directory cache entry */
#ifdef NEW_D_MAKE_ROOT
  rootDP = d_make_root(rootIP);
#else
  rootDP = d_alloc_root(rootIP);
#endif
  if (!rootDP)
  {
#ifdef NEW_D_MAKE_ROOT
    /* If fail, d_make_root will iput rootIP inode itself */
    rootIP = NULL;
#endif
    rc = gpfs_ops.gpfsUnmount(privVfsP, true);
    if (rc == 0 || rc == ENOSYS)
      gpfs_ops.gpfsFinishUnmount(privVfsP);

    code = 8;
    goto xerror;
  }

  set_dentry_operations(rootDP, &gpfs_dops_valid, false);
  sbP->s_root = rootDP;
#ifdef HAS_S_DIRT
  sbP->s_dirt = 1;            /* keep it on for sync to work */
#endif

  if (myBufP != NULL)
    cxiFreePinned(myBufP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_SUCCEED,
         "gpfs_fill_super exit: success sbP 0x%lX\n", sbP);
  EXIT(0);
  return 0;

xerror:
  if (rootDP)
    dput(rootDP);
  if (rootIP)
    iput(rootIP);

  if (myBufP != NULL)
    cxiFreePinned(myBufP);
#ifdef MUST_USE_BDI
  if (rc)
  {
    /* Destroy BDI device if something wrong happens and if it is already 
       registered. Note that bdiP will also get freed in destroyBDI(). */
    if (bdiRegistered)
      destroyBDI(bdiP);
    sbP->s_bdi = NULL;
  }
#endif

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_READSUPER_FAILED,
         "gpfs_fill_super: failed code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}

int
gpfs_reg_fs()
{
  int rc;

  ENTER(0);
  spin_lock_init(&gpfs_inode_lock);

  rc = register_filesystem(&gpfs_fs_type);
  if (rc)
    goto xerror;

  /* We create a dummy super block for purposes of instantiating
   * a shutdown file descriptor.  When the daemon dies this file
   * will be closed and its special ops will be called.  
   * See cxiRegisterCleanup()
   */
#ifdef SET_SUPER_USE_SGET
  shutdownSuperP = SGET(&gpfs_fs_type, NULL, set_anon_super, MS_ACTIVE, NULL);
  if (IS_ERR(shutdownSuperP))
  {
    rc = PTR_ERR(shutdownSuperP);
    shutdownSuperP = NULL;
    goto xerror;
  }
  up_write(&shutdownSuperP->s_umount);

  /* Release the extra module count added by sget for compatibility with
     older versions of this code.  The mmfsenv script complains if the use
     count is not one at unload time.  Rather than trying to fix mmfsenv to
     know which kernel versions uses which count, just fudge the count
     here.  The module can't go away without getting rid of the super_block
     since it is owned by us, and we already have a use count.  Still, it
     would be better not to have to do this, so if the old code ever goes
     away, then this should be deleted too, and mmfsenv can be changed to
     check for a use count of two. */
  module_put(gpfs_fs_type.owner);
#else
  shutdownSuperP = cxiMallocPinned(sizeof(struct super_block));
  if (!shutdownSuperP)
  {
    unregister_filesystem(&gpfs_fs_type);
    rc = -ENOMEM;
    goto xerror;
  }
  
  SET_SUPER_BLOCK(shutdownSuperP, &null_sops);
#endif

xerror:
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_REGFS,
         "gpfs_reg_fs shutdownSuperP 0x%lX rc %d\n", 
         shutdownSuperP, rc);
  EXIT(0);
  return rc;
}

void
gpfs_unreg_fs()
{
  int rc;

  ENTER(0);
  rc = unregister_filesystem(&gpfs_fs_type);

  if (shutdownSuperP)
  {
#ifdef SET_SUPER_USE_SGET
    /* Put back the extra module count that we subtracted in gpfs_reg_fs
       (see comment there). */
    if (try_module_get(gpfs_fs_type.owner))
      deactivate_super(shutdownSuperP);
#else
    UNSET_SUPER_BLOCK(shutdownSuperP);
    cxiFreePinned(shutdownSuperP);
#endif
    shutdownSuperP = NULL;
  }

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_UNREGFS,
         "gpfs_unreg_fs rc %d\n", rc);
  EXIT(0);
}

/*
 * Note: since this function is executed as kernel_thread "main" routine,
 * it may not be safe to use stack at all, e.g. call non-inlined functions,
 * at least in the success path.  See comments e.g. in asm-i386/unistd.h
 */
int
exec_mmfs(void *nothing)
{
  static char *argv[] = { mmfs_path, mount_opt, NULL };
  static char *envp[] = { "HOME=/", NULL };
  int rc;

  ENTER(0);
  set_fs(KERNEL_DS);

  rc = call_usermodehelper(mmfs_path, argv, envp, 1 /* wait if possible */);

xerror:
  if(rc)
    TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_EXECMMFS_EXIT,
         "exec_mmfs: exit rc -1 errno %d path %s\n", errno, mmfs_path);
  EXIT(0);
  return rc;
}

int
fork_mount_helper(char *data)
{
  struct task_struct *tP = NULL;

  ENTER(0);
  strcpy(mount_opt, data);

#ifdef USE_KTHREAD_CREATE
  tP = kthread_run(exec_mmfs, NULL, "gpfs_mount_helper");
  if (IS_ERR(tP)) {
    mount_id = PTR_ERR(tP);
  }
  else{
    mount_id = tP -> pid;
  }
#else
  mount_id = kernel_thread(exec_mmfs, 0, 0);
#endif

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_FORK_MOUNTHELPER,
        "fork_mount_helper: new pid %d\n", mount_id);

  EXIT(0);
  return mount_id;
}

/* Set device id and other information for a file system being mounted */
int
cxiSetMountInfo(void *osVfsP, cxiDev_t sgDevID,
                int bsize, void *osRootNodeP, cxiNode_t *cnRootP,
                Boolean *releRootP, void *gnRootP, 
                fsid_t fsid)/* (out) maintain hold on root */
{
  struct super_block *sbP = (struct super_block *)osVfsP;
  struct inode *rootIP = (struct inode *)osRootNodeP; /* root dir inode */
  int i;

  ENTER(0);
  TRACE4(TRACE_VNODE, 1, TRCID_SET_MOUNT_INFO,
         "cxiSetMountInfo: sbP 0x%lX rootIP 0x%lX cnRootP 0x%lX "
         "gnRootP 0x%lX\n", sbP, rootIP, cnRootP, gnRootP);
  DBGASSERT(sbP != NULL);

  /* This is the auto remount case where mmfsd died/killed and restarted. */
  if (gnRootP == cnRootP)
  {
    /* Since the OS independent layer looked up and held the
     * root vnode, we've got too many hold counts for a reconnect.
     * Tell upper layer that we must release.
     */
    *releRootP = true;
  }
  else
  {
    /* Don't attempt to release the root VFS node */
    *releRootP = false;
    sbP->s_blocksize = bsize;
    for (i = sbP->s_blocksize, sbP->s_blocksize_bits = 0; i != 1; i >>= 1)
      sbP->s_blocksize_bits++;
  }
  if (rootIP != NULL)
  {
    DBGASSERT(rootIP->i_ino == INODENUM_ROOTDIR_FILE);
    DBGASSERT(rootIP->PRVINODE == cnRootP);
  }

  EXIT(0);
  return 0;
}

/* Attempt whatever we can to get holders of VFS elements 
 * (dcache entries, etc) to leave.
 */
int
vfsUserCleanup(struct super_block *sbP,  
               struct gpfsVfsData_t *privVfsP, Boolean force)
{
  struct siginfo sinfo;
  struct task_struct *g, *tsP;
  Boolean killit;
  int rc, pid;

  ENTER(0);

  /* Purge cached OS VFS nodes/cxiNodes. */
  rc = gpfs_ops.gpfsUncache(privVfsP);

  EXIT(0);
  return rc;
}

/* Called by gpfs_s_put_super() when the last holder of the superblock
 * is gone.   We should be able to successfully clean up and become
 * unmounted.
 */
int 
cxiUnmount(void *osVfsP, Boolean force, Boolean doDMEvents)
{
  int rc = 0;
  int dmrc = 0;
  struct super_block *sbP = (struct super_block *)osVfsP;
  struct gpfsVfsData_t *privVfsP;
  char* sgNameP = NULL;
  Boolean dmDoUnmountEvent = false;
  void *sgUidP = NULL;
  void *eventlistP = NULL;
  void *sessLocP = NULL;
  struct dentry *dP = NULL;
  struct inode *iP = NULL;
  cxiNode_t *cnP = NULL;

  ENTER(0);
  LOGASSERT(sbP != NULL);
  privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_CXIUNMOUNT_ENTER,
         "cxiUnmount: enter privVfsP 0x%lX sbP 0x%lX force %d doDM %d\n", 
         privVfsP, sbP, force, doDMEvents);

  if (privVfsP == NULL)
    goto exit;

#ifdef USER_EXIT_ENTENSIONS
  gpfs_ops.gpfsGenFsUnmountCallback(true, force, privVfsP, &sgNameP, false);
#endif

  dP = sbP->s_root;
  if (dP != NULL)
    iP = dP->d_inode;
  if (iP != NULL)
    cnP = VP_TO_CNP(iP);

  /* Generate preunmount event */
  if (doDMEvents)
  {
    rc = gpfs_ops.gpfsDmUnmountEvent(true, force, privVfsP, cnP,
                                     &dmDoUnmountEvent, &sgUidP, 
                                     &eventlistP, &sessLocP, 0);
    /* We should continue unmount even if it fails. Otherwise, linux 
       screwup and cannot remount unless we shutdown the daemon */
  }
  
  /* The superblock is unallocated by the kernel after gpfs_s_put_super / 
     cxiUnmount, regardless of any errors here because it doesn't check
     a return code from the filesystem specific put_super call, so we need to
     proceed through these calls even if an error occurs; not cleaning up
     things in gpfsFinishUnmount (ie, the gpfs mount list) after an error
     with unmount causes havoc when the daemon later restarts. */
#ifdef GPFS_CACHE
  gpfs_ops.gpfsUnmountPcache(privVfsP, force);
#endif

  rc = vfsUserCleanup(sbP, privVfsP, force);
  if (rc == ENOSYS)
    rc = 0;

  rc = gpfs_ops.gpfsUnmount(privVfsP, force);
  if (rc == ENOSYS)
    rc = 0; 

  gpfs_ops.gpfsFinishUnmount(privVfsP);
  sbP->s_fs_info = NULL;

  if (dmDoUnmountEvent)
    dmrc = gpfs_ops.gpfsDmUnmountEvent(false, force, NULL, NULL,
                                       &dmDoUnmountEvent, &sgUidP,
                                       &eventlistP, &sessLocP, rc);
#ifdef HAS_S_DIRT
  sbP->s_dirt = 0;
#endif

  printSuperList(sbP);

#ifdef MUST_USE_BDI
  destroyBDI(sbP->s_bdi);
  sbP->s_bdi = NULL;
#endif
  
#ifdef USER_EXIT_ENTENSIONS
  gpfs_ops.gpfsGenFsUnmountCallback(false, force, privVfsP, &sgNameP, (Boolean)(rc!=0));
#endif

exit:
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_CXIUNMOUNT_EXIT,
         "cxiUnmount: exit rc %d dmrc %d\n", rc, dmrc);
  EXIT(0);
  return rc;
}

int
cxiReactivateOSNode(void *osVfsP, cxiNode_t *cnP, void **osNodePP)
{
  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_REACTIVATE_VNODE,
         "cxiReactivateOSNode: sbP 0x%lX cxiNodeP 0x%lX osNodePP 0x%lX\n",
         osVfsP, cnP, osNodePP);
  LOGASSERT(0);   /* not implemented on linux */
  return 0;
}


static int
inodeFindActor(struct inode *iP, void *opaqueP)
{
  /* iget4 can be called on one thread which goes to create a new
   * inode (get_new_inode, gpfs_s_read_inode2, gpfsInodeRead, readOSNode)
   * but before that thread completes initializing the cxiNode_t, another
   * thread calls iget4 and gets here (find_inode, inodeFindActor).
   * Similar races exist when an inode is being deleted.
   *
   * Ideally, we'd like to spin_unlock() on the inode_lock and call
   * wait_on_inode() but we cannot release the inode_lock here (find_inode
   * is depending on it to protect its list_entry() calls).  Fortunately,
   * iget4 does exactly this wait for the inode upon return from
   * find_inode.  Returning zero here would cause get_new_inode to be 
   * called (which would assert when it found the first thread had 
   * already allocated the gnode).  Return 1 and iget4 will do the 
   * necessary wait.
   *
   * ??? In the cases where we return 1 without calling gpfsInodeFindActor,
   *     We should at least verify that we have the correct inode number
   *     (hash collision in the linux inode hash table).
   *
   * We can't call anything here that could sleep because we are holding
   * the inode_lock and sleeping can result in a hang
   * TRACE4N does not block and is ok here.
   */

  cxiIGetArg_t *argsP = (cxiIGetArg_t *)opaqueP;

  TRACE4N(TRACE_VNODE, 2, TRCID_LINUXOPS_INODEFINDACTOR,
          "inodeFindActor: iP 0x%lX i_state 0x%x cxiNodeP 0x%lX isBad %d\n",
          iP, iP->i_state, VP_TO_CNP(iP), is_bad_inode(iP));

  if (iP->i_state & INODE_INIT_INCOMPLETE)
    return 1;

  /* If we find an inode in being released state, return 0 instead of blocking
     if SKIP_BEING_FREED flag is enabled and turn on the INODE_BEING_FREED flag.
     The caller MUST ignore the inode being returned */
  if ((argsP->flags & SKIP_BEING_FREED) && (iP->i_state & INODE_BEING_RELEASED))
  {
    argsP->flags |= INODE_BEING_FREED;
    return 0;
  }

  if (VP_TO_CNP(iP) == NULL)
  {
    if (iP->i_state == 0)
      return 0;
    else
      return 1;
  }

  return gpfs_ops.gpfsInodeFindActor(VP_TO_CNP(iP), iP->i_ino, opaqueP);
}

static int
inodeInitLocked(struct inode *iP, void *opaqueP)
{
  cxiIGetArg_t *argsP = (cxiIGetArg_t *)opaqueP;

  /* If the inode is in being freed state, return an error */
  if (argsP->flags & INODE_BEING_FREED)
    return 1;

  iP->i_ino = argsP->extInodeNum;
  return 0;
}


int
cxiNewOSNode(void *osVfsP, cxiNode_t **cnPP, void **osNodePP,
             cxiIno_t inum, int nodeSize, void *opaqueP)
{
  struct super_block *sbP = (struct super_block *)osVfsP;
  cxiIGetArg_t *argsP = (cxiIGetArg_t *)opaqueP;
  struct inode *iP;
  int rc;
  int loop_count = 0;
  int sleep_count = 0;

  ENTER(0);
  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_NEW_VNODE,
         "cxiNewOSNode: sbP 0x%lX inum %lld size %d",
         sbP, inum, nodeSize);

  /* The requested nodeSize must match CXINODE_SIZE */
  if (nodeSize != CXINODE_SIZE)
    goto bad_node_size;

repeat:
  iP = iget5_locked(sbP, inum, inodeFindActor, inodeInitLocked, opaqueP);
  if (iP == NULL)
  {
    *cnPP = NULL;
    *osNodePP = NULL;
    /* if the inode was being released, return ENOENT instead */
    if (argsP->flags & INODE_BEING_FREED)
      rc = ENOENT;
    else
      rc = ENOMEM;
    goto xerror;
  }

  if (argsP->flags & INODE_BEING_FREED)
  {
    TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_NEW_BEING_FREED,
           "cxiNewOSNode: ignoring inode being freed");
    *cnPP = NULL;
    *osNodePP = NULL;
    rc = ENOENT;
    goto xerror;
  }

  /* We fill in the inode as opposed to a read_inode
   * operation executed with iget()
   */
  if (iP->i_state & I_NEW)
  {
    gpfs_s_read_inode2(iP, opaqueP);
    unlock_new_inode(iP);
  }
  
  if (is_bad_inode(iP))
  {
    TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_NEW_BAD,
           "cxiNewOSNode: BAD INODE 0x%X\n", iP);
    *cnPP = NULL;
    *osNodePP = NULL;
    iput(iP);
    rc = EIO;
    goto xerror;
  }

  /* Did we get the right inode ?
   * When inodeFindActor is called from find_inode() and the inode
   * is in transition it might return found without checking sanpId
   * so go check again.
   */
  if (!inodeFindActor(iP, opaqueP))
  {
    if (sleep_count > 10)
    {
      TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_NEW_VNODE_2,
             "cxiNewOSNode: rc ESTALE inode 0x%lX inode %lld i_state 0x%x "
             "cxiNodeP 0x%lX isBad %d\n", iP, iP->i_ino, iP->i_state, 
             VP_TO_CNP(iP), is_bad_inode(iP));

      *cnPP = NULL;
      *osNodePP = NULL;
      iput(iP);
      rc = EIO;
      goto xerror;
    }

    if (loop_count > 1000)
    {
      cxiSleep(10);
      sleep_count++;
      loop_count = 0;
    }

    loop_count++;
    iput(iP);
    goto repeat;
  }
  
  DBGASSERT(iP->PRVINODE != NULL);
  *cnPP = (cxiNode_t *)iP->PRVINODE;
  *osNodePP = iP;
  rc = 0;

xerror:
  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_NEW_VNODE_EXIT,
         "cxiNewOSNode: exit osNodeP 0x%lX cnP 0x%lX rc %d\n",
         *osNodePP, *cnPP, rc);
  EXIT(0);
  return rc;

bad_node_size:
  /* The requested nodeSize does not match CXINODE_SIZE.
     Whoever called us is an incompitble version of the code or was
     somehow not compiled correctly. */
  TRACE2(TRACE_VNODE, 2, TRCID_LINUXOPS_NEW_VNODE_BAD,
         "cxiNewOSNode: requested nodeSize %d does not match CXINODE_SIZE %d",
         nodeSize, CXINODE_SIZE);
  printk("mmfs: module inconsistency detected in cxiNewOSNode:\n"
         "      requested nodeSize %d does not match CXINODE_SIZE %u\n",
         nodeSize, (unsigned int)CXINODE_SIZE);
  LOGASSERT(!"nodeSize != CXINODE_SIZE");
  EXIT(0);
  return ELIBBAD;
}


/* The linux kernel decrements the inode count and deallocates the
 * inode after gpfs_s_put_inode() is called therefore this routine 
 * doesn't perform a delete.
 */
void
cxiFreeOSNode(void *osVfsP, struct cxiNode_t *cnP, void *osNodeP)
{
  struct super_block *sbP = (struct super_block *)osVfsP;
  struct inode *iP = (struct inode *)osNodeP;

  ENTER(0);
  TRACE5(TRACE_VNODE, 2, TRCID_LINUXOPS_DELETE_VNODE,
         "cxiFreeOSNode enter: sbP 0x%lX cxiNodeP 0x%lX "
         "iP 0x%lX inode %lld i_count %d\n",
         sbP, cnP, iP,
         iP ? iP->i_ino : INVALID_INODE_NUMBER,
         iP ? atomic_read((atomic_t *)&iP->i_count) : 0);

  DBGASSERT(cnP->osNodeP == iP);
  cnP->osNodeP = NULL;

  if (iP)
  {
    DBGASSERT(atomic_read((atomic_t *)&iP->i_count) == 0);
    iP->i_op = NULL;
    iP->i_fop = NULL;
    if (iP->i_mapping)
      iP->i_mapping->a_ops = &gpfs_aops_after_inode_delete;
    iP->i_size = 0;
    set_nlink(iP, 0);
  }
  EXIT(0);
}

void
cxiDeleteMmap(cxiVmid_t segid)
{
  TRACE1(TRACE_VNODE, 2, TRCID_LINUXOPS_DELETE_MMAP,
         "cxiDeleteMmap: segid 0x%X\n", segid);
}

void
cxiReinitOSNode(void *osVfsP, struct cxiNode_t *cnP, void *osNodeP)
{
  struct super_block *sbP = (struct super_block *)osVfsP;
  struct inode *iP = (struct inode *)osNodeP;

  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_REINIT_VNODE,
         "cxiReinitOSNode: sbP 0x%lX cnP 0x%lX iP 0x%lX\n",
         sbP, cnP, iP);
  LOGASSERT(0);   /* not implemented on linux */
}

void
cxiDumpOSNode(cxiNode_t *cnP, int ino)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  struct dentry *dentry;

  ENTER(0);
  TRACE2(TRACE_VNODE, 2, TRCID_LINUXOPS_DUMP_VNODE,
         "cxiDumpOSNode: cxiNodeP 0x%lX iP 0x%lX\n", cnP, iP);
  if (iP)
  {
    printInode(iP);

#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&iP->i_lock);
#else
    spin_lock(&dcache_lock);
#endif
    LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
    {
#ifdef DCACHE_LOCK_IS_GONE
      spin_lock(&dentry->d_lock);
#endif
      printDentry(dentry);
#ifdef DCACHE_LOCK_IS_GONE
      spin_unlock(&dentry->d_lock);
#endif
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&iP->i_lock);
#else
    spin_unlock(&dcache_lock);
#endif
  }
  EXIT(0);
}

static int
igrabInodeFindActor(struct inode *iP, void *opaqueP)
{
  /* igrab can be called while another thread is doing a finial iput
   * so instead we are call ilookup5. ilookup5 processes stuff under
   * the inode_lock so if we are in here and find the inode then
   * ilookup5 will increase i_count
   *
   * We can't call anything here that could sleep because we are holding
   * the inode_lock and sleeping can result in a hang
   * TRACE4N does not block and is ok here.
   */

   TRACE3N(TRACE_VNODE, 2, TRCID_LINUXOPS_IGRABINODEFINDACTOR,
          "igrabInodeFindActor: iP 0x%lX i_state 0x%x inode 0x%lX \n",
          iP, iP->i_state, (struct inode *) opaqueP);

   if (iP->i_state & INODE_BEING_RELEASED)
     return 0;

   if (iP != (struct inode *) opaqueP)
     return 0;

   return 1;
}

/* On linux we can't just decrement the i_count
 * thus this routine will only accept a positive
 * increment.  If you want to put a reference then
 * call cxiPutOSNode() which calls back thru the VFS
 * layer.
 */
static int
cxiRefOSNodeInternal(void *osVfsP, cxiNode_t *cnP, void *osNodeP,
                     Boolean nonBlocking)
{
  struct inode *iP = (struct inode *)osNodeP;
  struct inode *riP = NULL;
  int holdCount;
  int ino;

  ENTER(0);
  DBGASSERT(iP != NULL);

  TRACE5N(TRACE_VNODE, 3, TRCID_REFOS_INTERNAL_0,
        "cxiRefOSNodeInternal: iP 0x%lX i_state 0x%x I_LOCK %d osVfsP %d nonBlocking %d \n",
         iP, iP ? iP->i_state : 0, iP ? (iP->i_state & I_LOCK) : 0,
         osVfsP, nonBlocking);

  /* The igrab() may fail if this inode is actively going
     thru a release.  igrab also will not block if I_LOCK bit
     is set in the inode state, unlike ilookup5, so if 
     non-blocking semantics are desired, we use igrab.
   */
  if (osVfsP || nonBlocking)
  {
    /* we already have a hold, or can tolerate igrab returning NULL */
    riP = igrab(iP);

    TRACE3N(TRACE_VNODE, 3, TRCID_REFOS_INTERNAL,
          "cxiRefOSNodeInternal: iP 0x%lX i_state 0x%x I_LOCK %d\n",
           riP, riP ? riP->i_state : 0, riP ? (riP->i_state & I_LOCK) : 0);
  }
  /* we may not currently have a hold so use ilookup5 */
  else if (GPFS_TYPE(iP))
  {
    riP = ilookup5(iP->i_sb, iP->i_ino, igrabInodeFindActor, (void*)iP);
  }
  if (riP)
  {
    DBGASSERT(!(iP->i_state & INODE_BEING_RELEASED));
    holdCount = atomic_read((atomic_t *)&riP->i_count);
    ino = riP->i_ino;
  }
  else
  {
    holdCount = 0;
    ino = INVALID_INODE_NUMBER;
    if (iP->i_state & INODE_BEING_RELEASED)
      holdCount = -1;
  }

  TRACE6(TRACE_VNODE, 2, TRCID_LINUXOPS_REF_VNODE,
         "cxiRefOSNode exit: sbP 0x%lX cxiNodeP 0x%lX iP 0x%lX inode %lld "
         "nb %d i_count to %d", osVfsP, cnP, iP, ino, nonBlocking, holdCount);

  EXIT(0);
  return holdCount;
}

int
cxiRefOSNode(void *osVfsP, cxiNode_t *cnP, void *osNodeP, int inc)
{
  DBGASSERT(inc == 1);
  return cxiRefOSNodeInternal(osVfsP, cnP, osNodeP, false);
}

int
cxiRefOSNodeNoWait(cxiNode_t *cnP, void *osNodeP)
{
  return cxiRefOSNodeInternal(NULL, cnP, osNodeP, true);
}

  
/* Determines if OS node is inactive */
int 
cxiInactiveOSNode(void *osVfsP, struct cxiNode_t *cnP, void *osNodeP, 
                 Boolean *canCacheP, Boolean *hasReferencesP)
{
  struct inode *iP = (struct inode *)osNodeP;
  struct super_block *sbP = (struct super_block *)osVfsP;
  int holdCount;

  ENTER(0);
  DBGASSERT(cnP->osNodeP == iP);

  *canCacheP = false;
  *hasReferencesP = false;

  holdCount = atomic_read((atomic_t *)&iP->i_count);
  if (holdCount > 0)
    *hasReferencesP = true;

  TRACE6(TRACE_VNODE, 2, TRCID_LINUXOPS_INACTIVE_VNODE,
         "cxiInactiveOSNode: sbP 0x%lX cxiNodeP 0x%lX iP 0x%lX "
         "i_count %d canCache %d hasReferences %d\n", sbP, cnP, iP, 
         holdCount, *canCacheP, *hasReferencesP);

  EXIT(0);
  return holdCount;
}

void
cxiPutOSNode(void *vP)
{
  struct inode *iP = (struct inode *)vP;
  int holdCount;

  ENTER(0);
  DBGASSERT(iP != NULL);
  DBGASSERT(!(iP->i_state & INODE_BEING_RELEASED));
  holdCount = atomic_read((atomic_t *)&iP->i_count);
  DBGASSERT(holdCount > 0);

  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_PUT_OSNODE,
         "cxiPutOSNode enter: iP 0x%lX inode %lld i_count to %d\n",
         iP, iP->i_ino, holdCount-1);

  iput(iP);

  EXIT(0);
  return;
}

void
cxiDestroyOSNode(void *vP)
{
  struct inode *iP = (struct inode *)vP;
  int holdCount;

  ENTER(0);
  DBGASSERT(iP != NULL);
  holdCount = atomic_read((atomic_t *)&iP->i_count);
  DBGASSERT(holdCount > 0);

  TRACE4(TRACE_VNODE, 2, TRCID_LINUXOPS_DESTROY_OSNODE,
         "cxiDestroyOSNode enter: iP 0x%lX inode %lld i_count %d i_nlink %u\n",
         iP, iP->i_ino, holdCount, iP->i_nlink);

  set_nlink(iP, 0);
  EXIT(0);
  return;
}

void
cxiSetOSNodeType(struct cxiNode_t *cnP, cxiMode_t mode, cxiDev_t dev)
{
  ENTER(0);
  if (S_ISDIR(mode))
    cnP->nType = cxiVDIR;
  else if (S_ISREG(mode))
    cnP->nType = cxiVREG;
  else if (S_ISLNK(mode))
    cnP->nType = cxiVLNK;
  else if (S_ISCHR(mode))
    cnP->nType = cxiVCHR;
  else if (S_ISBLK(mode))
    cnP->nType = cxiVBLK;
  else if (S_ISFIFO(mode))
    cnP->nType = cxiVFIFO;
  else if (S_ISSOCK(mode))
    cnP->nType = cxiVSOCK;
  else
    DBGASSERT(0);
  EXIT(0);
}

void
cxiUpdateInode(cxiNode_t *cnP, cxiVattr_t *attrP, int what,
               Boolean doPutOSNode, int flags)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  Boolean xferUseCount = false;

  ENTER(0);

#ifdef GPFS_CACHE
  if (flags & GETATTR_ATIMEXATTR)
  {
    if (attrP->va_xinfo &
        (VA_HASXATTR | VA_XPERM | VA_ISIMMUTABLE | VA_ISAPPENDONLY))
      attrP->va_atime.tv_nsec &= 0xFFFFFFFE; // might have xattr/ACL/Immutablefile/AppendOnly
    else
      attrP->va_atime.tv_nsec |= 0x00000001; // no xattr for this file
  }
#endif

  if (iP != NULL)
  {
    if (what & CXIUP_ATIME)
    {
      CXITIME_TO_INODETIME(attrP->va_atime, iP->i_atime);
      goto exit;
    }
    if (what & CXIUP_MODE)
    {
      iP->i_mode = attrP->va_mode;
      CXITIME_TO_INODETIME(attrP->va_ctime, iP->i_ctime);
    }
    if (what & CXIUP_OWN)
    {
      iP->i_mode = attrP->va_mode;
      iP->i_uid  = MAKE_KUID(attrP->va_uid);
      iP->i_gid  = MAKE_KGID(attrP->va_gid);
      CXITIME_TO_INODETIME(attrP->va_ctime, iP->i_ctime);
    }
    if (what & CXIUP_NLINK)
    {
      set_nlink(iP, attrP->va_nlink);
    }
    if (what & CXI_CLEAR_DESTROY_FLAG)
    {
       /* assert no race between relink and inode deletion */
       LOGASSERT(!(iP->i_state & INODE_BEING_RELEASED));
       ClearCtFlag(cnP, destroyIfDelInode);
    }
    if (what & CXIUP_SIZE)
    {
      iP->i_size = attrP->va_size;
      iP->i_blocks = attrP->va_blocks;
    }
    if (what & CXIUP_SIZE_BIG)
    {
      spin_lock(&gpfs_inode_lock);
      if (attrP->va_size > iP->i_size)
      {
        iP->i_size = attrP->va_size;
        iP->i_blocks = attrP->va_blocks;
      }
      spin_unlock(&gpfs_inode_lock);
    }
    if (what & CXIUP_TIMES)
    {
      CXITIME_TO_INODETIME(attrP->va_atime, iP->i_atime);
      CXITIME_TO_INODETIME(attrP->va_mtime, iP->i_mtime);
      CXITIME_TO_INODETIME(attrP->va_ctime, iP->i_ctime);
    }
    if (what & CXIUP_PERM)
    {
      iP->i_mode = attrP->va_mode;
      iP->i_uid  = MAKE_KUID(attrP->va_uid);
      iP->i_gid  = MAKE_KGID(attrP->va_gid);
      cnP->xinfo = attrP->va_xinfo;
      setIopTable(iP, (attrP->va_xinfo & VA_XPERM) != 0);
      cnP->icValid |= CXI_IC_PERM;
    }
    if (TestCtFlag(cnP, destroyIfDelInode))
    {
      /* If this inode has been marked for deletion, we need to ask Swapd
         to throw out any invalid dcache entries.  We also ask Swapd to
         decrement ref count on the inode, because doing that here is
         dangerous: final iput on a deleted file triggers delete_inode iop
         callback, which will require making a mailbox call, and if the
         current thread is a mailbox handler already, trying to get another
         mailbox could cause a deadlock. */
      if (what & CXIUP_NLINK)
        cxiDropInvalidDCacheEntry(cnP);

      if (doPutOSNode && (what & CXIUP_RENAME))
      {
        xferUseCount = true;
        doPutOSNode = false;
      }

      if (TestCtFlag(cnP, pruneDCacheNeeded) ||
          xferUseCount)
        gpfs_ops.gpfsSwapdEnqueue(cnP, xferUseCount);
    }
  }
  else
  {
    EXIT(0);
    return;
  }
exit:
  TRACE4(TRACE_VNODE, 3, TRCID_CXIUPDATE_INODE_3,
     "cxiUpdateInode: iP 0x%X atime 0x%X mtime 0x%X ctime 0x%X\n",
      iP, iP->i_atime.tv_sec, iP->i_mtime.tv_sec, iP->i_ctime.tv_sec);

  TRACE8(TRACE_VNODE, 3, TRCID_CXIUPDATE_INODE_1,
     "cxiUpdateInode: what 0x%X flags 0x%X mode 0x%X uid %d gid %d nlink %u size %lld"
     " blocks %d\n",
     what, flags, iP->i_mode, FROM_KUID(iP->i_uid), FROM_KGID(iP->i_gid), iP->i_nlink,
     iP->i_size, iP->i_blocks);

  if (doPutOSNode)
    cxiPutOSNode(iP);

  EXIT(0);
}

int
cxiCheckInode(cxiNode_t *cnP, cxiVattr_t *attrP, int what, int flags)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  int what_chaned = 0;

  ENTER(0);

  if (iP != NULL)
  {
    if (what & CXIUP_ATIME)
      goto exit;

    if (what & CXIUP_MODE && (iP->i_mode != attrP->va_mode))
        what_chaned |= CXIUP_MODE;

    if (what & CXIUP_OWN)
    {
      if ((iP->i_mode != attrP->va_mode) ||
          (!UID_EQ(iP->i_uid, MAKE_KUID(attrP->va_uid)))  ||
          (!GID_EQ(iP->i_gid, MAKE_KGID(attrP->va_gid))))
        what_chaned |= CXIUP_OWN;
    }
    if (what & CXIUP_NLINK)
      what_chaned |= CXIUP_NLINK;

    if (what & CXIUP_SIZE)
    {
      if ((iP->i_size != attrP->va_size) ||
          (iP->i_blocks != attrP->va_blocks))
        what_chaned |= CXIUP_SIZE;
    }
    if (what & CXIUP_SIZE_BIG && (attrP->va_size > iP->i_size))
      what_chaned |= CXIUP_SIZE_BIG;

    if (what & CXIUP_TIMES)
      what_chaned |= CXIUP_TIMES;

    if (what & CXIUP_PERM)
    {
      if ((iP->i_mode != attrP->va_mode) ||
          (!UID_EQ(iP->i_uid, MAKE_KUID(attrP->va_uid)))  ||
          (!GID_EQ(iP->i_gid, MAKE_KGID(attrP->va_gid)))  ||
          (cnP->xinfo != attrP->va_xinfo))
        what_chaned |= CXI_IC_PERM;
    }
    TRACE7(TRACE_VNODE, 3, TRCID_CXICHECK_INODE_1,
      "cxiCheckInode: ino %lld what 0x%X changed 0x%X size %lld:%lld blk %d:%d",
       iP->i_ino, what, what_chaned, iP->i_size, attrP->va_size,
       iP->i_blocks, attrP->va_blocks);
  }

exit:

  EXIT(0);
  return what_chaned;
}

Boolean
cxiSameInode(cxiNode_t *cnP, cxiVattr_t *attrP, int what)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  Boolean same = false;

  ENTER(0);
  if (iP == NULL || attrP == NULL)
    return same;

  if (what == CXIUP_SIZE)
  {
    if ((iP->i_size == attrP->va_size) && (iP->i_blocks == attrP->va_blocks))
      same = true;
    goto exit;
  }

exit:
  TRACE5(TRACE_VNODE, 3, TRCID_CXIDIFF_INODE_3,
     "cxiSameInode: iP 0x%X what 0x%X same %d size %lld blocks %d",
      iP, what, same, iP->i_size, iP->i_blocks);

  EXIT(0);
  return same;
}

/* Determine if operating system specific node belongs to a particular VFS and
   can be uncached.  Returns OS node if it exists, the determination of
   whether it can be uncached or not. */
Boolean
cxiCanUncacheOSNode(void *osVfsP, struct cxiNode_t *cnP, void **vPP)
{
  struct inode *iP = (struct inode *)cnP->osNodeP;
  int count = 0;

  ENTER(0);
  if (iP != NULL && iP->i_sb == osVfsP)
  {
    count = atomic_read((atomic_t *)&iP->i_count);
    *vPP = (void *)iP;
  }
  else
    *vPP = NULL;

  TRACE6(TRACE_VNODE, 2, TRCID_LINUXOPS_CANUNCACHE_OSNODE,
         "cxiCanUncacheOSNode: cxiNode 0x%lx vPP 0x%lX osVfsP 0x%lX "
         "i_sb 0x%lX inode %lld i_count %d\n", cnP, vPP, osVfsP,
         (iP ? iP->i_sb : 0), (iP ? iP->i_ino : 0), count);
  EXIT(0);
  return (count == 0);
}


/* Add operating system specific node to the lookup cache.
   This routine is called with the necessary distributed lock held to
   guarantee that the lookup cache entry is valid. */
void * 
cxiAddOSNode(void *dentryP, void *vP, DentryOpTableTypes dopTabType, int lookup)
{
  struct inode *iP = (struct inode *)vP;
  struct dentry *dP = (struct dentry *)dentryP;

  ENTER(0);
  TRACE4(TRACE_VNODE, 2, TRCID_LINUXOPS_ADD_OSNODE,
         "cxiAddOSNode: dentry 0x%lX dopTabType %d vP 0x%lX unhashed %d",
         dentryP, dopTabType, vP, d_unhashed(dP));

  /* mark dentry valid */
  switch(dopTabType)
  {
    /* Positive dcache entry for inexact file name match for Samba user.
       Only valid for other Samba users.
       Not valid for local/NFS users.  Forces lookup for local/NFS users. */
    case DOpOnlyValidIfSamba:
      set_dentry_operations(dP, &gpfs_dops_valid_if_Samba, false);
      break;
    /* Negative dcache entry for exact file name match for local/NFS user.
       Only valid for other local/NFS users.
       Not valid for Samba users.  Forces lookup for Samba users. */
    case DOpInvalidIfSamba:
      set_dentry_operations(dP, &gpfs_dops_invalid_if_Samba, false);
      break;
    case DOpValidate:
      set_dentry_operations(dP, &gpfs_dops_revalidate, false);
      break;
#ifdef GPFS_CACHE
    case DOpPCache:
      set_dentry_operations(dP, &gpfs_dops_pcache, false);
      break;
#endif
    default:
      set_dentry_operations(dP, &gpfs_dops_valid, false);
      break;
  }

  if (d_unhashed(dP))
  {
    if (lookup)
    {  
      dP = d_splice_alias(iP, dP);
      goto exit;
    }
    /* hook up dentry and inode */
    d_instantiate(dP, iP);

    /* if not yet done so, add to hash list */
    d_rehash(dP);

    dP = NULL;
  }
  else
  {
    /* hook up dentry and inode */
    d_instantiate(dP, iP);
    dP = NULL;
  }
exit:

#ifdef GPFS_CACHE
  if (iP)
    ClearCtFlag(VP_TO_CNP(iP), pcacheLookupInProg);
#endif

  EXIT(0);
  return dP;
}


/* Functions for converting between an NFS file handle and a dentry.
   We define our own functions rather than using the generic ones in
   fs/nfsd/nfsfh.c so we can revalidate the file inode, since it could have
   been changed by another node. */

static struct dentry *
gpfs_nfsd_iget_dentry(struct inode *inode, __u32 generation)
{
  struct dentry *result;
  cxiNode_t *cnP = VP_TO_CNP(inode);

  ENTER(0);
  TRACE2(TRACE_VNODE, 3, TRCID_NFSD_IGET_DENTRY_1,
         "gpfs_nfsd_iget_dentry: inode %lld generation %d",
         inode->i_ino,  generation);

#ifdef GPFS_CACHE
  if (cnP != NULL && TestCtFlag(cnP, homeChanged))
  {
    iput(inode);
    EXIT(0);
    return ERR_PTR(-ENOENT);
  }
#endif

  /* Now find a dentry.  If possible, get a well-connected one. */
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&inode->i_lock);
#else
  spin_lock(&dcache_lock);
#endif
  LIST_FOR_I_DENTRY(result, &inode->i_dentry, d_alias)
  {
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&result->d_lock);
#endif

    if (!(result->d_flags & DCACHE_DISCONNECTED))
    {
#ifdef DCACHE_LOCK_IS_GONE
      dget_dlock(result);
      result->d_flags |= DCACHE_REFERENCED;
      spin_unlock(&result->d_lock);
      spin_unlock(&inode->i_lock);
#else
      dget_locked(result);
      result->d_flags |= DCACHE_REFERENCED;
      spin_unlock(&dcache_lock);
#endif

      if (result->d_inode != inode)
      {
        TRACE4(TRACE_VNODE, 11, TRCID_NFSD_IGET_31,
               "gpfs_nfsd_iget_dentry:0 dentry flags 0x%x count %d inode 0x%lX "
               "time %lu", 
               result->d_flags, GET_DENTRY_D_COUNT(result),
               result->d_inode, result->d_time);

        TRACE7(TRACE_VNODE, 11, TRCID_NFSD_IGET_41,
               "gpfs_nfsd_iget_dentry:0 Inode %lld nlink %u i_count %d gen %u %u "
               "state %lu flags 0x%x",
               inode->i_ino, inode->i_nlink, atomic_read(&inode->i_count),
               inode->i_generation, generation, inode->i_state, inode->i_flags);

        dput(result);
        goto build_dentry;
      }
      if (gpfs_i_revalidate(result))
      {
        TRACE4(TRACE_VNODE, 11, TRCID_NFSD_IGET_3,
               "gpfs_nfsd_iget_dentry:1 dentry flags 0x%x count %d inode 0x%lX "
               "time %lu", 
               result->d_flags, GET_DENTRY_D_COUNT(result),
               result->d_inode, result->d_time);

        TRACE7(TRACE_VNODE, 1, TRCID_NFSD_IGET_4,
               "gpfs_nfsd_iget_dentry:1 Inode %lld nlink %u i_count %d gen %u %u "
               "state %lu flags 0x%x",
               inode->i_ino, inode->i_nlink, atomic_read(&inode->i_count),
               inode->i_generation, generation, inode->i_state, inode->i_flags);

        iput(inode);
        dput(result);
        EXIT(0);
        return ERR_PTR(-ESTALE);
      }
      if (generation && 
          generation != 0xffffffff && /* GENNUM_UNKNOWN */
          inode->i_generation != generation)
      {
        /* we didn't find the right inode.. */
        TRACE4(TRACE_VNODE, 11, TRCID_NFSD_IGET_5,
               "gpfs_nfsd_iget_dentry:2 dentry flags 0x%x count %d inode 0x%lX "
               "time %lu", 
               result->d_flags, GET_DENTRY_D_COUNT(result),
               result->d_inode, result->d_time);

        TRACE7(TRACE_VNODE, 11, TRCID_NFSD_IGET_6,
               "gpfs_nfsd_iget_dentry:2 Inode %lld nlink %u i_count %d gen %u %u "
               "state %lu flags 0x%x",
               inode->i_ino, inode->i_nlink, atomic_read(&inode->i_count),
               inode->i_generation, generation, inode->i_state, inode->i_flags);

        iput(inode);
        dput(result);
        EXIT(0);
        return ERR_PTR(-ESTALE);
      }
      iput(inode); 
      EXIT(0);
      return result;
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&result->d_lock);
#endif
  }
#ifdef DCACHE_LOCK_IS_GONE
  spin_unlock(&inode->i_lock);
#else
  spin_unlock(&dcache_lock);
#endif

build_dentry:

  result = d_alloc_anon(inode);
  if (result == NULL)
  {
    iput(inode);
    result = ERR_PTR(-ENOMEM);
  }

  if (IS_ERR(result))
  {
    EXIT(0);
    return result;
  }

  if (gpfs_i_revalidate(result))
  {
    TRACE4(TRACE_VNODE, 11, TRCID_NFSD_IGET_7,
           "gpfs_nfsd_iget_dentry:3 dentry flags 0x%x count %d inode 0x%lX time %lu",
           result->d_flags, GET_DENTRY_D_COUNT(result),
           result->d_inode, result->d_time);

    TRACE7(TRACE_VNODE, 11, TRCID_NFSD_IGET_8,
           "gpfs_nfsd_iget_dentry:3 Inode %lld nlink %u i_count %d gen %u %u "
           "state %lu flags 0x%x",
           inode->i_ino, inode->i_nlink, atomic_read(&inode->i_count),
           inode->i_generation, generation, inode->i_state, inode->i_flags);

    /* The dput call here is releases the dcache entry that was 
     * allocated by to d_alloc_root. It also results in an iput effectively
     * removing the hold we place by our iget call above.
     */
    dput(result);
    EXIT(0);
    return ERR_PTR(-ESTALE);
  }
  if (generation && 
      generation != 0xffffffff && /* GENNUM_UNKNOWN */
      inode->i_generation != generation)
  {
    /* we didn't find the right inode.. */
    TRACE4(TRACE_VNODE, 11, TRCID_NFSD_IGET_9,
           "gpfs_nfsd_iget_dentry:4 dentry flags 0x%x count %d inode 0x%lX time %lu",
           result->d_flags, GET_DENTRY_D_COUNT(result),
           result->d_inode, result->d_time);

    TRACE7(TRACE_VNODE, 11, TRCID_NFSD_IGET_10,
           "gpfs_nfsd_iget_dentry:4 Inode %lld nlink %u i_count %d gen %u %u "
           "state %lu flags 0x%x",
           inode->i_ino, inode->i_nlink, atomic_read(&inode->i_count),
           inode->i_generation, generation, inode->i_state, inode->i_flags);

    /* Release the dcache entry.  This also does an iput. */
    dput(result);
    EXIT(0);
    return ERR_PTR(-ESTALE);
  }
  TRACE1(TRACE_VNODE, 3, TRCID_NFSD_IGET_101,
           "gpfs_nfsd_iget_dentry: build result 0x%lX\n", result);
  EXIT(0);
  return result;
}

static struct dentry *
gpfs_nfsd_iget(struct super_block *sbP, InodeNumber ino,
               cxiIGetArg_t *argP, __u32 generation)
{
  int rc;
  struct inode *inode;
  struct gpfsVfsData_t *privVfsP;

  ENTER(0);
  TRACE6(TRACE_VNODE, 3, TRCID_NFSD_IGET_1,
         "gpfs_nfsd_iget: sbP 0x%lX extinode %lld inode %lld snapid %d "
         "fileset %d generation %d",
         sbP, ino, argP->inodeNum, argP->snapId, argP->filesetId,
         generation);

  /* get the inode */
  if (ino == 0)
  {
    EXIT(0);
    return ERR_PTR(-ESTALE);
  }

  /* Try to find and hold an existing inode and dentry, make sure we have the
     right inode/generation and that the inode found is valid. */
  inode = ilookup5(sbP, ino, inodeFindActor, argP);
  /* @@@ Warning @@@: ilookup5 might not return the inode you are looking for
  (see inodeFindActor) so it must be verified. */
  if (inode != NULL)
  {
    struct dentry *dentry;
    cxiNode_t *cnP;

    cnP = VP_TO_CNP(inode);

    if (cnP &&
        generation &&
        (generation != 0xffffffff) && /* GENNUM_UNKNOWN */
        (cnP->icValid & CXI_IC_ALL) &&
        !(inode->i_state & INODE_INIT_INCOMPLETE) &&
        gpfs_ops.gpfsInodeFindActor(cnP, inode->i_ino, argP))
    {
      dentry = gpfs_nfsd_iget_dentry(inode, generation);
      if (dentry != NULL && !IS_ERR(dentry))
      {
        TRACE5(TRACE_VNODE, 3, TRCID_NFSD_IGET_12,
             "gpfs_nfsd_iget: found ino %lld gen %d inode 0x%lX dentry 0x%lX d_name %s",
              ino, generation, inode, dentry, dentry->d_name.name);
        EXIT(0);
        return dentry;
      }
#ifdef GPFS_CACHE
      if (dentry != NULL && IS_ERR(dentry) && 
          PTR_ERR(dentry) == -ENOENT && TestCtFlag(cnP, homeChanged))
      {
        EXIT(0);
        return dentry;
      }
#endif      
    }
    else
      iput(inode);
  }

  /* Callers have set inodeNum/snapId in argP.  vattrP is NULL and
   * readInodeCalled is false, but these will be set appropriately in 
   * gpfsNFSIget after it obtains the attributes.
   */

  privVfsP = (struct gpfsVfsData_t *)cxiGetPrivVfsP(sbP);
  rc = gpfs_ops.gpfsNFSIget(privVfsP, argP, generation, (void **)&inode);

  if (rc)
  {
    cxiErrorNFS(rc);

    EXIT(0);
    return ERR_PTR(-rc);
  }

  if (inode == NULL)
  {
    EXIT(0);
    return ERR_PTR(-ENOMEM);
  }

  if (is_bad_inode(inode))
  {
    EXIT(0);
    return ERR_PTR(-ESTALE);
  }

  /* gpfsNFSIget will have called findOrCreateLinux/cxiNewOSNode which
   * makes the iget call along with the inodeFindActor validation.
   */

  EXIT(0);
  return(gpfs_nfsd_iget_dentry(inode,generation));

}

struct dentry *get_dentry(struct super_block *sbP, InodeNumber ino, __u32 gen)
{
  struct dentry *dentry;
  cxiIGetArg_t arg;

  arg.inodeNum = ino;
  arg.snapId = 0;
  arg.extInodeNum = INVALID_INODE_NUMBER;
  arg.filesetId = (unsigned)-1;
  arg.flags = 0;
  arg.vattrP = NULL;
  arg.readInodeCalled = false;

  dentry = gpfs_nfsd_iget(sbP, ino, &arg, gen);

  return dentry;
};

/* export_operations for nfsd communication with our file system
 * via gpfs_export_ops 
 */

/* 
 * gpfs_get_dparent: (get_parent) find the parent dentry for a given dentry 
 */
struct dentry *gpfs_get_dparent(struct dentry * child)
{
  int rc = 0;
  struct dentry *result = NULL;
  struct gpfsVfsData_t *privVfsP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiNode_t *dcnP;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  cxiNode_t *cnP = NULL;
  struct inode *newInodeP = NULL;
  struct dentry *retP = NULL;

  ENTER(0);
  VFS_INC(get_parentCall);

  TRACE2(TRACE_VNODE, 3, TRCID_GET_DPARENT_ENTER,
         "gpfs_get_dparent: dentry 0x%lX inode 0x%d",
         child,  child->d_inode->i_ino);

  dcnP = VP_TO_CNP(child->d_inode);
  privVfsP = VP_TO_PVP(child->d_inode);
  DBGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror2;

  if (!dcnP)
  {
    /* This can happen due to a bug in linux/fs/dcache.c (prune_dcache)
       where "count" entries are to be pruned, but the last one is
       found to be recently referenced.  When this happens, count is
       decremented, but the loop is not terminated.  The result is that
       it continues to prune entries past where it should (prunes
       everything).  If our patch for this is not applied, the result
       is a kernel failure as the cxiNode is referenced.  Checking
       here (and revalidate) allows us to reject the call instead. */
    PRINTINODE(child->d_inode);
    result = (struct dentry *)ERR_PTR(-ESTALE);
    goto xerror;
  }

  rc = gpfs_ops.gpfsLookup(privVfsP, (void *)child->d_inode, dcnP,
                           NULL, NULL, (char *)"..", GPFS_LOOKUP_DPARENT,
                           (void **)&newInodeP, &cnP, &iNum, NULL,
                           NULL, eCredP, IS_CASE_SENSITIVE(),
                           (void **)&retP, NULL, NULL, NULL);
  if (rc == 0)
  {
    DBGASSERT(cnP != NULL);
    DBGASSERT(iNum != INVALID_INODE_NUMBER);
    DBGASSERT(newInodeP != NULL);
    DBGASSERT(newInodeP->PRVINODE == cnP);
    DBGASSERT(cnP->osNodeP == (void *)newInodeP);
    result = gpfs_nfsd_iget_dentry(newInodeP, (__u32)newInodeP->i_generation);
  }
  else 
  {
xerror2:
    cxiErrorNFS(rc);
    result  = (struct dentry *)ERR_PTR(-rc);
    iNum = INVALID_INODE_NUMBER;
  }

xerror:
  putCred(&eCred, &eCredP);

  TRACE4(TRACE_VNODE, 3, TRCID_GET_DPARENT_EXIT,
        "gpfs_get_dparent dentry 0x%lX inode %lld result %lX err%d \n",
           child, iNum, result, IS_ERR(result)? PTR_ERR(result): 0);
  EXIT(0);
  return result;
}

/*
 * gpfs_get_dentry: (get_dentry) find dentry for the inode given a file handle
 */
struct dentry *gpfs_get_dentry(struct super_block *sbP, void * vdata)
{
  smallNfsFileHandleCommon_t *snfshP = (smallNfsFileHandleCommon_t *)vdata;
  cxiIGetArg_t arg;
  __u32 generation;
  struct dentry *result;

  ENTER(0);
  VFS_INC(get_dentryCall);

  TRACE4(TRACE_VNODE, 4, TRCID_GET_DENTRY_1,
         "gpfs_get_dentry: %16x %08x %08x %16x",
         snfshP->inode, snfshP->sid, snfshP->gen, snfshP->inode2);

  arg.inodeNum = snfshP->inode;
  arg.snapId = snfshP->sid;
  generation = snfshP->gen;
  arg.extInodeNum = INVALID_INODE_NUMBER;
  arg.filesetId = (unsigned)-1; /* FIXME */
  arg.flags = 0;
  arg.vattrP = NULL;
  arg.readInodeCalled = false;
  result = gpfs_nfsd_iget(sbP, arg.inodeNum, &arg, generation);
  EXIT(0);
  return result;
}

/* It is acceptable to create a disconnected dentry for pNFS since it is used
   only for read/write. The check if it was exported is not required since
   the call to the MDS will verify that the file is open.
*/
static int pnfs_acceptable(void *expv, struct dentry *dentry)
{
  if (dentry && dentry->d_inode) {
    /* INODE64: ! What about the inode number here? */
    TRACE2(TRACE_VNODE, 3, TRCID_PNFS_1,
           "pnfs_acceptable dentry 0x%lX dinode %d\n", 
           dentry, dentry->d_inode);
    return 1;
  }
  return 0;
}

static struct file *dentry_open_s(struct dentry *dentry, int flags)
{
  struct file *f;
  struct inode *inode;
  int error = -ENOTDIR;
  int (*open)(struct inode *, struct file *);
#if defined(USE_ALLOC_FILE)
  struct path path;
#endif

  inode = dentry->d_inode;

#if defined(USE_ALLOC_FILE)
  path.mnt = NULL;
  path.dentry = dentry;
  f = alloc_file(&path, ((flags+1) & O_ACCMODE), fops_get(inode->i_fop));
  if (f == NULL) {
    return ERR_PTR(error);
  }
#else
  f = get_empty_filp();
  if (f == NULL) {
    return ERR_PTR(error);
  }
  f->f_mode = ((flags+1) & O_ACCMODE);

  f->f_mapping = inode->i_mapping;
  f->f_dentry = dentry;
  f->f_vfsmnt = NULL;
  f->f_op = fops_get(inode->i_fop);
#endif

#ifdef HAS_FMODE_NONOTIFY
  //?? Temp fix for kernel bug in fsnotify
  f->f_mode |= FMODE_NONOTIFY;
#endif

  f->f_flags = flags;
  f->f_pos = 0;
  open = f->f_op->open;
  if (open) {
    error = open(inode, f);
    if (error)
      goto cleanup_all;
  }
  f->f_flags &= ~(O_CREAT | O_EXCL | O_NOCTTY | O_TRUNC);

  return f;

cleanup_all:
  /* Open failed so not all fields are set. Don't call back into GPFS
     to do close (release) it might get confused and assert. */
  fops_put(f->f_op);
  f->f_op = NULL;
  fput(f);
  return ERR_PTR(error);
}

struct compat_getdents_callback {
#if !defined(HAS_READDIR)
  struct dir_context ctx;
#endif
  struct getdents_callback_s buffer;
};

/*
 * A rather strange filldir function to capture
 * the name matching the specified inode number.
 */
static int filldir_one_s(void * __buf, const char * name, int len,
                        loff_t pos, u64 ino, unsigned int d_type)
{
  struct compat_getdents_callback *buf = __buf;
  int result = 0;

  buf->buffer.sequence++;
  if (buf->buffer.ino == ino) {
    memcpy(buf->buffer.name, name, len);
    buf->buffer.name[len] = '\0';
    buf->buffer.found = 1;
    result = -1;
  }
  return result;
}

/* no one use slow_get_next_name(), so this function will not be called */
#if 0
static int filldir_next_one_s(void * __buf, const char * name, int len,
                        loff_t pos, u64 ino, unsigned int d_type)
{
  getdents_callback_t *buf = __buf;
  int result = 0;

  TRACE5(TRACE_VNODE, 3, TRCID_SLOW_FILLDIR_21,
         "filldir_next_one_s: ino %lld:%lld seq %d found %d pos %lld",
          buf->ino, ino, buf->sequence, buf->found, pos);
  buf->sequence++;
  if (buf->ino == ino)
  {
    if (buf->found == 0)
    {
      memcpy(buf->name, name, len);
      buf->name[len] = '\0';
      buf->found = 1;
    }
    else
      result = -1;

    TRACE4(TRACE_VNODE, 3, TRCID_SLOW_FILLDIR_23,
           "filldir_next_one_s: seq %d found %d resuld %d name %s",
            buf->sequence, buf->found, result, buf->name);
  }
  return result;
}
#endif

/**
 * @dentry: the directory in which to find a name
 * @name:   a pointer to a %NAME_MAX+1 char buffer to store the name
 * @child:  the dentry for the child directory.
 *
 * calls readdir on the parent until it finds an entry with
 * the same inode number as the child, and returns that.
 */
static int
slow_get_name(Boolean pcache, struct dentry *dentry, char *name,
              struct dentry *child)
{
  struct inode *dir = dentry->d_inode;
  int error;
  struct file *file;
  struct compat_getdents_callback buffer = {
#if !defined(HAS_READDIR)
    .ctx.actor = filldir_one_s
#endif
  };

  ENTER(0);

  error = -ENOTDIR;
  if (!dir || !S_ISDIR(dir->i_mode))
    goto out;
  error = -EINVAL;
  if (!dir->i_fop)
    goto out;

  /*
   * Open the directory ...
   */
  file = dentry_open_s(dget(dentry), O_RDONLY);
  error = PTR_ERR(file);
  if (IS_ERR(file))
    goto out;

  error = -EINVAL;
#ifdef HAS_READDIR
  if (!file->f_op->readdir)
    goto out_close;
#else
  if (!file->f_op->iterate)
    goto out_close;
#endif

#ifdef GPFS_CACHE
  if (pcache)
    file->f_flags |= FWRITE;  // will not call GW
#endif
  buffer.buffer.name = name;
  buffer.buffer.ino = child->d_inode->i_ino;
  buffer.buffer.found = 0;
  buffer.buffer.sequence = 0;
  while (1) {
    int old_seq = buffer.buffer.sequence;

#ifdef HAS_READDIR
    error = file->f_op->readdir(file, &buffer, filldir_one_s);
#else
    error = file->f_op->iterate(file, &buffer.ctx);
#endif

    if (error < 0)
      break;

    error = 0;
    if (buffer.buffer.found)
      break;

    error = -ENOENT;
    if (old_seq == buffer.buffer.sequence)
      break;
  }

out_close:
  fput(file);
out:
  TRACE2(TRACE_VNODE, 3, TRCID_SLOW_GETNAME_2,
         "slow_get_name: error %d name %s",
          error, (error) ? "" : name);
  return error;
}

/* no one use it */
#if 0
/**
 * calls readdir on the parent until it finds an entry with
 * the same inode number as the child, and returns that.
 */
int
slow_get_next_name(struct dentry *dentry, getdents_callback_t *bufP)
{
  struct inode *dir = dentry->d_inode;
  int error;
  struct file *file;
  ENTER(0);

  error = -ENOTDIR;
  if (!dir || !S_ISDIR(dir->i_mode))
    goto out;
  error = -EINVAL;
  if (!dir->i_fop)
    goto out;

  /*
   * Open the directory ...
   */
  file = dentry_open_s(dget(dentry), O_RDONLY);
  error = PTR_ERR(file);
  if (IS_ERR(file))
    goto out;

  if (!file->f_op->readdir)
  {
    error = -EINVAL;
    goto out_close;
  }

  if (bufP->pos == GPFS_DIR_EOF)
  {
    error = -ENOENT;
    goto out_close;
  }
  file->f_flags |= O_WRONLY; /* Don't call remote pcache home */
  file->f_pos = bufP->pos;
  bufP->found = 0;

  error = file->f_op->readdir(file, bufP, filldir_next_one_s);
  bufP->pos = file->f_pos;

  if (error < 0)
    goto out_close;

  error = 0;
  if (bufP->found)
    goto out_close;

  error = -ENOENT;

out_close:
  fput(file);
out:
  TRACE2(TRACE_VNODE, 3, TRCID_SLOW_GETNEXTNAME_21,
         "slow_get_next_name: error %d name %s",
          error, (error) ? "" : bufP->name);
  return error;
}
#endif

/*
 * @dentry: the directory in which to find a name
 * @name:   a pointer to a %NAME_MAX+1 char buffer to store the name
 * @child:  the dentry for the child directory.
 */
int
gpfs_get_name(struct dentry *dentry, char *name, struct dentry *child)
{
  cxiNode_t *dcnP, *cnP;
  struct gpfsVfsData_t *privVfsP;
  struct inode *dir = dentry->d_inode;
  int error;
  ENTER(0);

  TRACE3(TRACE_VNODE, 3, TRCID_GETNAME_1,
         "gpfs_get_name: parent inode %lld child inode %lld hash 0x%08X",
         dentry->d_inode->i_ino, child->d_inode->i_ino, child->d_fsdata);

  error = -ENOTDIR;
  if (!dir || !S_ISDIR(dir->i_mode))
    goto out;

  dcnP = VP_TO_CNP(dentry->d_inode);
  cnP = VP_TO_CNP(child->d_inode);
  privVfsP = VP_TO_PVP(dentry->d_inode);
  error = gpfs_ops.gpfsGetHashName(NULL, privVfsP, dcnP, name, NAME_MAX+1, cnP,
                                   (UInt32)(unsigned long)child->d_fsdata,
                                   NULL);

  TRACE2(TRACE_VNODE, 3, TRCID_GETNAME_2,
         "gpfs_get_name: error %d name %s",
          error, (error) ? "" : name);

  if (error)
    error = slow_get_name(false, dentry, name, child);

out:
  if (error) {
    cxiErrorNFS(error);
    return -ENOENT;
  }
  return error;
}

#if (LINUX_KERNEL_VERSION < 2062400)
/* GPFS is taking over this routine so it can compare the inode number
   instead of the dentry address. When GPFS has snapshots in the path
   it might create different dentry with the same inode number. We use
   the inode number to identify the export point.
*/
static int gpfs_acceptable(void *expv, struct dentry *dentry)
{
  struct svc_export *exp = expv;
  int rv = 1;
  struct dentry *tdentry;
  struct dentry *parent;
  struct dentry *ex_dentry;


  if (exp->ex_flags & NFSEXP_NOSUBTREECHECK)
    return rv;

  ex_dentry = EXP_DENTRY(exp);

  TRACE4(TRACE_VNODE, 3, TRCID_ACC_1,
         "gpfs_acceptable dentry 0x%lX inode %lld %lld ex_flags %X\n",
         dentry, dentry->d_inode->i_ino, ex_dentry->d_inode->i_ino,
         exp->ex_flags);

  tdentry = dget(dentry);
  while (tdentry->d_inode->i_ino != ex_dentry->d_inode->i_ino && ! IS_ROOT(tdentry))
  {
    /* make sure parents give x permission to user */
    int err;
    parent = dget_parent(tdentry);
    err = permission(parent->d_inode, S_IXOTH, NULL);
    if (err < 0) {
      dput(parent);
      break;
    }
    dput(tdentry);
    tdentry = parent;
    TRACE4(TRACE_VNODE, 3, TRCID_ACC_2,
          "gpfs_acceptable comp 0x%lX 0x%lX inode %lld %lld\n",
           tdentry, ex_dentry, tdentry->d_inode->i_ino,
           ex_dentry->d_inode->i_ino);
  }
  if (tdentry->d_inode->i_ino != ex_dentry->d_inode->i_ino)
  {
    TRACE4(TRACE_VNODE, 3, TRCID_ACC_3,
          "gpfs_acceptable failed 0x%lX 0x%lX inode %lld %lld\n",
           tdentry, ex_dentry, tdentry->d_inode->i_ino,
           ex_dentry->d_inode->i_ino);
    rv = 0;
  }
  dput(tdentry);
  return rv;
}
#endif /* (LINUX_KERNEL_VERSION < 2062400) */

/*
 * Generate the small nfs file handle for both file and parent inodes.
 * Also return dentry name hash if a location is specified for it.
 */
void 
generate_smallnfs_fh(__u32 *fh, int len, int fhtype, \
                     smallNfsFileHandleCommon_t *fnfshP, \
                     smallNfsFileHandleCommon_t *pnfshP, __u32 *foldValP)
{
  __u32 foldVal = 0;

  if (len < MAX_FH_INT)
  {
    if (fhtype > 4 && fhtype < 8 && len >= 5)
    {
      if (fnfshP != NULL)
      {
        fnfshP->inode = fh[0];  /* file inode */
        fnfshP->sid   = fh[1]; 	/* file sid */
        fnfshP->gen    = fh[2]; /* generation */
        fnfshP->inode2 = fh[3]; /* parent ino */
      }
      
      if (pnfshP != NULL)
      {
        pnfshP->inode = fh[3]; 	/* parent inode */
        pnfshP->sid   = fh[4]; 	/* p_sid */
        if (len > 5)
        {
          pnfshP->gen    = fh[5]; /* generation */
          pnfshP->inode2 = fh[0]; /* file ino */
        }
      }

      if (len > 6) 
        foldVal = fh[6]; /* see gpfs_fh_to_dentry, might have the hashVal */
    }
  }
  else
  {
    nfsFileHandleCommon_t *nfshP = (nfsFileHandleCommon_t *)fh;

    /* file info plus parent inode */
    if (fnfshP != NULL)
    {
      fnfshP->inode  = nfshP->inode;
      fnfshP->sid    = nfshP->sid;
      fnfshP->gen    = nfshP->gen;
      fnfshP->inode2 = nfshP->pinode;
    }

    /* parent info plus file inode */
    if (pnfshP != NULL)
    {
      pnfshP->inode  = nfshP->pinode;
      pnfshP->sid    = nfshP->psid;
      pnfshP->gen    = nfshP->pgen;
      pnfshP->inode2 = nfshP->inode;
    }
  
    foldVal = nfshP->hash; 
  }

  if (foldValP != NULL)
    *foldValP = foldVal;
}

#if (LINUX_KERNEL_VERSION >= 2062400)
struct dentry *
gpfs_fh_to_dentry(struct super_block *sbP, struct fid *fid,
                  int len, int fhtype)
{
  struct dentry *result;
  smallNfsFileHandleCommon_t fnfsh = {};
  __u32 *fh = fid->raw;

  TRACE11(TRACE_VNODE, 3, TRCID_FH_2_DENTRY_1,
         "gpfs_fh_to_dentry sbP 0x%lX type %d len %d: %08X %08X %08X %08X %08X %08X %08X %08X",
          sbP, fhtype, len, fh[0],fh[1],fh[2],fh[3],fh[4],fh[5],fh[6],fh[7]);

  if (fhtype > 4 && fhtype < 11)
  {
    generate_smallnfs_fh(fh, len, fhtype, &fnfsh, 
                         (smallNfsFileHandleCommon_t  *)NULL, (__u32 *)NULL);

    result = gpfs_get_dentry(sbP, (void *)&fnfsh);

    TRACE4(TRACE_VNODE, 3, TRCID_FH_2_DENTRY_2,
           "gpfs_fh_to_dentry: sbP 0x%lX fh 0x%lX result %lX err %d",
           sbP, fh, result, IS_ERR(result)? PTR_ERR(result): 0);
    if (IS_ERR(result))
    {
      cxiErrorNFS(PTR_ERR(result));
      /* File not found must return estale */
      if (result == ERR_PTR(-ENOENT))
        result = ERR_PTR(-ESTALE);
    }
    else
    {
      if (len < 10)  
        result->d_fsdata = (void *)(unsigned long)fh[6]; /* see gpfs_fh_to_dentry, possible hashVal */
      else
      {
        nfsFileHandleCommon_t * nfsfhP = (nfsFileHandleCommon_t *)fid->raw;
        result->d_fsdata = (void *)(unsigned long)nfsfhP->hash;
      }
    }
    EXIT(0);
    return result;
  }
  
  TRACE2(TRACE_VNODE, 3, TRCID_FH_2_DENTRY_3,
         "gpfs_fh_to_dentry: sbP 0x%lX fh 0x%lX -EINVAL",
         sbP, fh);
  EXIT(0);
  return ERR_PTR(-EINVAL);
}

struct dentry *
gpfs_fh_to_parent(struct super_block *sbP, struct fid *fid,
                  int len, int fhtype)
{
  struct dentry *result;
  __u32 *fh = fid->raw;
  cxiIGetArg_t arg;
  __u32 generation;

  TRACE10(TRACE_VNODE, 3, TRCID_FH_2_PARENT_1,
         "gpfs_fh_to_parent sbP 0x%lX len %d type %d: %08X %08X %08X %08X %08X %08X %08X ",
          sbP, len, fhtype, fh[0],fh[1],fh[2],fh[3],fh[4],fh[5],fh[6]);

  if (len < 10)
  {
    if (fhtype > 4 && fhtype < 8 && len >= 5)
    {
      arg.inodeNum = fh[3];     /* parent inode num */
      arg.snapId = fh[4];       /* parent snap id */
      generation = fh[5];       /* parent gen num */
      arg.extInodeNum = INVALID_INODE_NUMBER;
      arg.filesetId = (unsigned)-1; /* FIXME */
      arg.flags = 0;
      arg.vattrP = NULL;
      arg.readInodeCalled = false;

      result = gpfs_nfsd_iget(sbP, arg.inodeNum, &arg, generation);

      TRACE4(TRACE_VNODE, 3, TRCID_FH_2_PARENT_2,
             "gpfs_fh_to_parent: sbP 0x%lX fh 0x%lX result %lX err %d",
             sbP, fh, result, IS_ERR(result)? PTR_ERR(result): 0);
      if (IS_ERR(result))
        cxiErrorNFS(PTR_ERR(result));

      EXIT(0);
      return result;
    }
  }
  else
  {
    nfsFileHandleCommon_t *nfshP = (nfsFileHandleCommon_t *)fid->raw;

    arg.inodeNum = nfshP->pinode;   /* parent inode num */ 
    arg.snapId = nfshP->psid;       /* parent snap id */
    generation = nfshP->pgen;       /* parent gen num */

    arg.extInodeNum = INVALID_INODE_NUMBER;
    arg.filesetId = (unsigned)-1; /* FIXME */

    arg.vattrP = NULL;
    arg.readInodeCalled = false;

    result = gpfs_nfsd_iget(sbP, arg.inodeNum, &arg, generation);

    TRACE4(TRACE_VNODE, 3, TRCID_FH_2_PARENT_3,
           "gpfs_fh_to_parent: sbP 0x%lX fh 0x%lX result %lX err %d",
           sbP, fh, result, IS_ERR(result)? PTR_ERR(result): 0);
    if (IS_ERR(result))
      cxiErrorNFS(PTR_ERR(result));

    EXIT(0);
    return result;
  }

  TRACE2(TRACE_VNODE, 3, TRCID_FH_2_PARENT_4,
         "gpfs_fh_to_parent: sbP 0x%lX fh 0x%lX -EINVAL",
         sbP, fh);
  EXIT(0);
  return ERR_PTR(-EINVAL);
}
#else  /* (LINUX_KERNEL_VERSION < 2062400) */

static struct dentry *
acceptable_alias(struct dentry *result, void *context)
{
  struct dentry *dentry, *toput = NULL;

  spin_lock(&dcache_lock);
  LIST_FOR_I_DENTRY(dentry, &result->d_inode->i_dentry, d_alias)
  {
    dget_locked(dentry);
    spin_unlock(&dcache_lock);
    if (toput)
      dput(toput);
    if (dentry != result && gpfs_acceptable(context, dentry)) {
      dput(result);
      return dentry;
    }
    spin_lock(&dcache_lock);
    toput = dentry;
  }
  spin_unlock(&dcache_lock);

  if (toput)
    dput(toput);
  return NULL;
}

struct dentry *
new_decode_fh(struct super_block *sbP, __u32 *fh, int len, int fhtype,
              void *context)
{
  struct dentry *result = NULL, *target_dir = NULL, *npd = NULL;
  struct dentry *alias;
  smallNfsFileHandleCommon_t fnfsh = {};
  smallNfsFileHandleCommon_t pnfsh = {};
  __u32 foldVal = 0;
  int err, code = 0;
  char nbuf[NAME_MAX+1];
  int noprogress;
  ENTER(0);

  generate_smallnfs_fh(fh, len, fhtype, &fnfsh, &pnfsh, &foldVal);
  
  TRACE6(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_2,
         "new_decode_fh: len %d %lld:%d:%d:%lld foldVal %d",
         len, pnfsh.inode, pnfsh.sid, pnfsh.gen, pnfsh.inode2, foldVal);
  result = gpfs_get_dentry(sbP, (void *)&fnfsh);
  err = -ESTALE;
  if (result == NULL)
    goto err_out;
  if (IS_ERR(result)) {
    err = PTR_ERR(result);
    goto err_out;
  }
  if (S_ISDIR(result->d_inode->i_mode) &&
      (result->d_flags & DCACHE_DISCONNECTED))
  {
    ;  /* unconnected directory */
  }
  else
  {
    if (gpfs_acceptable(context, result))
    {
      code = 3;
      return result;
    }
    if (S_ISDIR(result->d_inode->i_mode))
    {
      code = 5;
      err = -EACCES;
      goto err_result;
    }

    alias = acceptable_alias(result, context);
    if (alias)
      return alias;
  }			
  if (S_ISDIR(result->d_inode->i_mode))
    target_dir = dget(result);
  else
  {
    target_dir = gpfs_get_dentry(sbP, (void *)&pnfsh);
    if (IS_ERR(target_dir))
      err = PTR_ERR(target_dir);
    if (target_dir == NULL || IS_ERR(target_dir))
      goto err_result;
  }
  noprogress = 0;
  while (target_dir->d_flags & DCACHE_DISCONNECTED && noprogress++ < 10)
  {
    struct dentry *pd = target_dir;

    dget(pd);
    spin_lock(&pd->d_lock);
    while (!IS_ROOT(pd) &&
           (pd->d_parent->d_flags & DCACHE_DISCONNECTED))
    {
      struct dentry *parent = pd->d_parent;

      dget(parent);
      spin_unlock(&pd->d_lock);
      dput(pd);
      pd = parent;
      spin_lock(&pd->d_lock);
    }
    spin_unlock(&pd->d_lock);

    if (!IS_ROOT(pd))
    {
      spin_lock(&pd->d_lock);
      pd->d_flags &= ~DCACHE_DISCONNECTED;
      spin_unlock(&pd->d_lock);
      noprogress = 0;
    }
    else if (pd == sbP->s_root)
    {
      TRACE0(TRACE_VNODE, 0, TRCID_NEW_DECODE_FH_4,
             "new_decode_fh: ERROR: filesystem root is not connected");
      spin_lock(&pd->d_lock);
      pd->d_flags &= ~DCACHE_DISCONNECTED;
      spin_unlock(&pd->d_lock);
      noprogress = 0;
    }
    else
    {
      struct dentry *ppd;
      struct dentry *npd;

      INODE_LOCK(pd->d_inode);
      ppd = gpfs_get_dparent(pd);
      INODE_UNLOCK(pd->d_inode);

      if (IS_ERR(ppd))
      {
        err = PTR_ERR(ppd);
        TRACE2(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_6,
               "new_decode_fh: get_parent of %ld failed, err %d",
                pd->d_inode->i_ino, err);
        dput(pd);
        break;
      }
      TRACE2(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_8,
             "new_decode_fh: find name of %lu in %lu",
              pd->d_inode->i_ino, ppd->d_inode->i_ino);
      pd->d_fsdata = (void *)(unsigned long)foldVal;
      foldVal = 0; /* it is there only for first dentry */
      err = gpfs_get_name(ppd, nbuf, pd);
      if (err)
      {
        dput(ppd);
        dput(pd);
        if (err == -ENOENT)
          continue;
        break;
      }
      TRACE1(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_10,
             "new_decode_fh: found name: %s", nbuf);
      INODE_LOCK(ppd->d_inode);
      npd = lookup_one_len(nbuf, ppd, strlen(nbuf));
      INODE_UNLOCK(ppd->d_inode);
      if (IS_ERR(npd))
      {
        err = PTR_ERR(npd);
        TRACE1(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_12,
               "new_decode_fh: lookup failed: %d", err);
        dput(ppd);
        dput(pd);
        break;
      }
      if (npd == pd)
        noprogress = 0;
      else
        TRACE0(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_14,
               "new_decode_fh: npd != pd");
      dput(npd);
      dput(ppd);
      if (IS_ROOT(pd))
      {
        dput(pd);
        break;
      }
    }
    dput(pd);
  }

  if (target_dir->d_flags & DCACHE_DISCONNECTED)
  {
    if (!err)
      err = -ESTALE;
    goto err_target;
  }
  if (result != target_dir)
  {
    struct dentry *nresult;
    result->d_fsdata = (void *)(unsigned long)foldVal;
    err = gpfs_get_name(target_dir, nbuf, result);
    if (!err)
    {
      INODE_LOCK(target_dir->d_inode);
      nresult = lookup_one_len(nbuf, target_dir, strlen(nbuf));
      INODE_UNLOCK(target_dir->d_inode);
      if (!IS_ERR(nresult))
      {
        if (nresult->d_inode)
        {
          dput(result);
          result = nresult;
        }
        else
          dput(nresult);
      }
    }
  }
  dput(target_dir);
  if (gpfs_acceptable(context, result))
    return result;

  alias = acceptable_alias(result, context);
  if (alias)
    return alias;

  dput(result);
  code = 15;
  TRACE2(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_261,
         "new_decode_fh: err %d code %d", err, code);
  return ERR_PTR(-EACCES);

err_target:
  dput(target_dir);
err_result:
  dput(result);
err_out:

  TRACE2(TRACE_VNODE, 3, TRCID_NEW_DECODE_FH_16,
         "new_decode_fh: err %d code %d", err, code);
  return ERR_PTR(err);
}

/*
 * gpfs_decode_fh: (decode_fh) decode a file handle returning ptr to it's dentry
 */
struct dentry *
gpfs_decode_fh(struct super_block *sbP, __u32 *fh,
               int len, int fhtype,
               int (*acceptable)(void *context, struct dentry *de),
               void *context)
{
  struct dentry *result;
  smallNfsFileHandleCommon_t fnfsh = {};
  smallNfsFileHandleCommon_t pnfsh = {};

  ENTER(0);
  VFS_INC(decode_fhCall);

  TRACE4(TRACE_VNODE, 3, TRCID_DECODE_FH_0,
         "gpfs_decode_fh: sbP 0x%lX fh 0x%lX, len %d type %d",
         sbP, fh, len, fhtype);

  TRACE8(TRACE_VNODE, 3, TRCID_DECODE_FH_1,
             "gpfs_decode_fh len %d: %08x %08x %08x %08x %08x %08x %08x\n",
              len, fh[0],fh[1],fh[2],fh[3],fh[4],fh[5],fh[6]);


  generate_smallnfs_fh(fh, len, fhtype, &fnfsh, &pnfsh, (__u32 *)NULL);

  if (fhtype > 4 && fhtype < 11  && len >= 5)
  {
    if (cxiIsLockdThread())  /* check for lockd thread */
      result = sbP->s_export_op->find_exported_dentry(sbP, &fnfsh, &pnfsh,
                                                      pnfs_acceptable, 
                                                      context);
    else
    {
#if (LINUX_KERNEL_VERSION > 2061000) && !defined(SKIP_NEW_DECODE_FH)
      result =  new_decode_fh(sbP, fh, len, fhtype, context);
      TRACE3(TRACE_VNODE, 3, TRCID_DECODE_FH_2,
             "gpfs_decode_fh: try_decode_fh fh 0x%lX result %lX err %d",
             fh, result, IS_ERR(result)? PTR_ERR(result): 0);

#else
      result = sbP->s_export_op->find_exported_dentry(sbP, &fnfsh, &pnfsh,
                                                      gpfs_acceptable, 
                                                      context);
#endif
    }
    TRACE4(TRACE_VNODE, 3, TRCID_DECODE_FH_3,
           "gpfs_decode_fh: sbP 0x%lX fh 0x%lX result %lX err %d",
           sbP, fh, result, IS_ERR(result)? PTR_ERR(result): 0);

    if (IS_ERR(result))
    {
      cxiErrorNFS(PTR_ERR(result));
      /* File not found must return estale */
      if (result == ERR_PTR(-ENOENT))
        result = ERR_PTR(-ESTALE);
    }
    EXIT(0);
    return result;
  }
  
  TRACE2(TRACE_VNODE, 3, TRCID_DECODE_FH_4,
         "gpfs_decode_fh: sbP 0x%lX fh 0x%lX -EINVAL",
         sbP, fh);
  EXIT(0);
  return ERR_PTR(-EINVAL);
}
#endif /* (LINUX_KERNEL_VERSION < 2062400) */

/* 
 * gpfs_encode_fh: (encode_fh) encode a file handle from the given dentry
 */
#ifdef NEW_ENCODE_FH
int 
gpfs_encode_fh(struct inode *inode, __u32 *fh, int *lenp,
               struct inode *parent)
{
  struct gpfsVfsData_t *privVfsP;
  unsigned int hashValue = 0;
  struct dentry *dentryP = NULL;

  ENTER(0);
  VFS_INC(encode_fhCall);

  if (inode == NULL || *lenp < 5)
  {
    TRACE1(TRACE_VNODE, 3, TRCID_FH_ENCODE_2_1,
           "gpfs_encode_fh: len %d rc 255", *lenp);
    EXIT(0);
    return 255;
  }

  if (VP_TO_CNP(inode) == NULL)
  {
    EXIT(0);
    return 255;
  }

  dentryP = d_find_alias(inode);
  if (dentryP != NULL)
  {
    privVfsP  = VP_TO_PVP(inode);
    hashValue = gpfs_ops.gpfsGetHashValue(privVfsP, (caddr_t)dentryP->d_name.name);
    dput(dentryP);
  }

  if (gpfs_ops.gpfsEncodeFileHandle(VP_TO_CNP(inode),
                                    parent ? VP_TO_CNP(parent) : NULL,
                                    lenp, hashValue, fh) != 0)
  {
    EXIT(0);
    return 255;
  }

  EXIT(0);
  return *lenp;
}

#else
int 
gpfs_encode_fh(struct dentry *dentry, __u32 *fh, int *lenp,
               int need_parent)
{
  struct gpfsVfsData_t *privVfsP;
  unsigned int hashValue = 0;

  ENTER(0);
  VFS_INC(encode_fhCall);

  if (dentry == NULL || dentry->d_inode == NULL || *lenp < 5)
  {
    TRACE1(TRACE_VNODE, 3, TRCID_FH_ENCODE_2,
           "gpfs_encode_fh: len %d rc 255", *lenp);
    EXIT(0);
    return 255;
  }
 
  privVfsP  = VP_TO_PVP(dentry->d_inode);
  hashValue = gpfs_ops.gpfsGetHashValue(privVfsP, (caddr_t)dentry->d_name.name);
  if (VP_TO_CNP(dentry->d_inode) == NULL)
  {
    EXIT(0);
    return 255;
  }
  if (gpfs_ops.gpfsEncodeFileHandle(VP_TO_CNP(dentry->d_inode),
                                    VP_TO_CNP(dentry->d_parent->d_inode),
                                    lenp, hashValue, fh) != 0)
  {
    EXIT(0);
    return 255;
  }

  EXIT(0);
  return *lenp;
}
#endif

void
printSuper(struct super_block *sbP)
{
  if (!_TRACE_IS_ON(TRACE_VNODE, 3))
    return;

  /* private field won't make much sense for non-GPFS file systems */
  TRACE4N(TRACE_VNODE, 3, TRCID_PRINTSUPER_1,
         "printSuper: sbP 0x%lX magic 0x%lX type 0x%lX private 0x%lX\n",
         sbP, sbP->s_magic, sbP->s_type, sbP->s_fs_info);

  TRACE3N(TRACE_VNODE, 3, TRCID_PRINTSUPER_3,
         "printSuper: s_dev 0x%X count 0x%X active %d\n",
         sbP->s_dev, sbP->s_count, atomic_read(&sbP->s_active));
}

void
printSuperList(struct super_block *sbP)
{
  struct list_head *lP;
  struct super_block *sP;

  if (!_TRACE_IS_ON(TRACE_VNODE, 5))
    return;

  /* Run through all super blocks starting from provided GPFS super block. */
  /* Ideally we would lock sb_lock, but we can't access it,
     so small probability of this breaking, which is why it is at
     a higher trace level (vnode 5). */
  TRACE0N(TRACE_VNODE, 5, TRCID_PRINTALLSUPER_1,
           "printSuperList:\n");
  printSuper(sbP);
  list_for_each(lP, &sbP->s_list)
  {
    sP = sb_entry(lP);
    printSuper(sP);
  }
}

void printInodeList(struct super_block * sbP)
{
  struct inode *iP, *nextP;

  if (!_TRACE_IS_ON(TRACE_VNODE, 2))
    return;

#if LINUX_KERNEL_VERSION >= 2061100 || \
   (LINUX_KERNEL_VERSION == 2060507 && defined(SUSE_LINUX))

  TRACE1N(TRACE_VNODE, 2, TRCID_PRINTINODELIST_ENTER,
          "printInodeList: sbP 0x%lX", sbP);

  spin_lock(&gpfs_inode_lock);
  list_for_each_entry_safe(iP, nextP, &sbP->s_inodes, i_sb_list)
  {
    TRACE2N(TRACE_VNODE, 2, TRCID_PRINTINODELIST_1,
            "iP 0x%lX i_count %d", iP, atomic_read(&iP->i_count));
  }
  spin_unlock(&gpfs_inode_lock);
#endif
}

/* The drop_inode sop.  It is called when the inode ref count drops to zero.
   To avoid an unbounded growth of the GPFS inode cache, we force cache
   eviction for those inodes that have already been invalidated by GPFS.
   Note: this routine is called with inode_lock held, so it must
   not do any blocking trace calls (and thus can't use the ENTER
   macro. */
#if LINUX_KERNEL_VERSION >= 2063600
#define RETURN_TYPE int
#define RETURN return
#elif LINUX_KERNEL_VERSION >= 2061300
#define RETURN_TYPE void
#define RETURN
#endif
#if (LINUX_KERNEL_VERSION >= 2061300)
RETURN_TYPE gpfs_s_drop_inode(struct inode *iP)
{
  cxiNode_t *cnP;

  cnP = VP_TO_CNP(iP);
  TRACE5N(TRACE_VNODE, 4, TRCID_DROPINODE_ENTER,
          "gpfs_drop_inode: iP 0x%lX GpfsInodeCount %d cnP 0x%lX icValid 0x%X i_state 0x%X",
          iP, atomic_read(&GpfsInodeCount), cnP,
          (cnP == NULL) ? 0 : cnP->icValid, iP->i_state);

  if (cnP == NULL ||
      ((cnP->icValid & CXI_IC_STAT) == 0))
    RETURN generic_delete_inode(iP);
  else
    RETURN generic_drop_inode(iP);
}
#endif

#ifdef MUST_USE_BDI
/* Initialize and register pseudo BDI for GPFS to implement sync_fs ops
 * in super block. */
int initBDI(struct backing_dev_info *bdi, struct super_block *sbP)
{
  int rc;

  cxiMemset(bdi, 0, sizeof(struct backing_dev_info));
  bdi->name = "gpfs";
  bdi->ra_pages = (VM_MAX_READAHEAD * 1024) / PAGE_CACHE_SIZE;
#ifdef PER_QUEUE_PLUGGING
  bdi->unplug_io_fn = default_unplug_io_fn;
#endif
  bdi->capabilities = BDI_CAP_NO_ACCT_WB;

  rc = bdi_init(bdi);
  if (rc)
    goto xerror;

  /* we don't have backing block device assigned to GPFS */
  DBGASSERT(!sbP->s_bdev);
  rc = bdi_register_dev(bdi, sbP->s_dev);
  if (rc)
  {
    bdi_destroy(bdi);
    goto xerror;
  }
  sbP->s_bdi = bdi;

xerror:
  return(rc);
}

/* Destroy the BDI structure associated with super block. */
inline void destroyBDI(struct backing_dev_info *bdi)
{
  if (bdi)
  {
    bdi_destroy(bdi);
    cxiFreePinned(bdi);
  }
}
#endif

