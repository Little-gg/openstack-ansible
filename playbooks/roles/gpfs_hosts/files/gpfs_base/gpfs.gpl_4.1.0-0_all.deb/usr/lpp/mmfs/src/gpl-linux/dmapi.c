/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)11       1.8  src/avs/fs/mmfs/ts/kernext/gpl-linux/dmapi.c, mmfs, avs_rfks0, rfks01416c 1/28/08 16:02:40 */

#include <Shark-gpl.h>
#include <linux/fs.h>
#include <linux/string.h>
#include <linux/file.h>
#include <linux/namei.h>
#include <cxiSystem.h>
#include <cxiCred.h>

/*
#ifndef _KERNEL
#define _KERNEL
#include <cxi2gpfs.h>
#undef _KERNEL
#else
#include <cxi2gpfs.h>
#endif
*/
#include <linux2gpfs.h>
#include <Trace.h>

Boolean
cxiIsReadOnlyMnt( void *vfsP)
{
  struct super_block *sbP = (struct super_block *)vfsP;
  Boolean rc = (sbP->s_flags & MS_RDONLY);
  return rc;  
}

int
cxiGetFileAndVp(int fd, void **fileP, void **iPP)
{
  struct file *fP = NULL;
  struct inode *iP = NULL;
  *fileP = NULL;
  *iPP = NULL;
  fP = fget(fd);
  if (fP == NULL)
    return EBADF;

  *fileP = (void *)fP;
  iP = fP->f_dentry->d_inode;
  *iPP = (void *)iP;
  return 0;
}

void
cxiReleaseFile(int fd, void *fP)
{
  struct file *fileP = (struct file *)fP;
  fput(fileP);
}

Boolean
cxiMountedOverVfsType(void *vfsP)
{
   struct super_block *sbP = (struct super_block *)vfsP;
   if (strcmp(sbP->s_type->name, "gpfs") == 0)
     return true;
   else
     return false;
} 
  
void
cxiGetMountedOverOSNode(void *vfsP, void **mntdovervfsP, 
                        cxiNode_t **cnP)
{ 
   struct super_block *sbP = (struct super_block *)vfsP;
   struct list_head *p;
   struct vfsmount *tmp, *parent;
   struct inode *mntdvverrootIP = NULL;
   struct super_block *parentsbP; 
   *mntdovervfsP = NULL;
   *cnP = NULL;
#if 0
   spin_lock(&dcache_lock);
   list_for_each(p, &sbP->s_mounts) 
   {
     tmp = list_entry(p, struct vfsmount, mnt_instances);
     parent = tmp->mnt_parent;
     parentsbP = parent->mnt_sb; 
     if (parentsbP == sbP && cxiMountedOverVfsType((void *)parentsbP))
     {
       *mntdovervfsP = (void *)parentsbP->u.generic_sbp;
       LOGASSERT(*mntdovervfsP != NULL);
       mntdvverrootIP = (struct inode *)parentsbP->s_root->d_inode;
       LOGASSERT(mntdvverrootIP != NULL);
       *cnP = VP_TO_CNP(mntdvverrootIP); 
       break;
     }
   }
   spin_unlock(&dcache_lock);
#endif
}  
   
void
cxiGetRootInode(void *vfsP, cxiNode_t **cnP)
{
  struct super_block *sbP = (struct super_block *)vfsP;
  struct inode *rootIP; 
  if ( sbP->s_root )
  {
    rootIP = (struct inode *)sbP->s_root->d_inode;
    LOGASSERT(rootIP != NULL);
    *cnP = VP_TO_CNP(rootIP);
  }
}
    
