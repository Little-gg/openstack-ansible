/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)13       1.79  src/avs/fs/mmfs/ts/kernext/ibm-linux/cxiIOBuffer-plat.h, mmfs, avs_rfks1, rfks1s007a_addw 8/1/14 15:50:04 */
/*
 * Abstraction of an I/O buffer, Linux implementation
 *
 * Contents:
 *   struct cxiIOBufferAttachment_t
 *   InitBufferAttachment
 *   struct cxiContiguousBuffer_t
 *   InitContiguousBuffer
 *   EXTERNC int kxMapAndRecordPages
 *   Methods for manipulating cxiIOBuffer_t's
 *   #define __CXI_BUFFERS_ARE_CONTIGUOUS
 *   GetDiskInfoX
 */

#ifndef _h_cxiIOBuffer_plat
#define _h_cxiIOBuffer_plat

#ifndef _h_cxiIOBuffer
#error Platform header (XXX-plat.h) should not be included directly
#endif

/* Address of the first byte past the end of memory addressible by
   processes (PAGE_OFFSET), and routine to get this value from the kernel.
   Stacks are below this address. */
EXTERNC UIntPtr KernelBoundary;
EXTERNC int kxGetKernelBoundary(UIntPtr* kBoundP);

EXTERNC unsigned long KernelPageSize;
EXTERNC int kxGetKernelPageSize(unsigned long* kPageSizeP);
EXTERNC int kxGetFixedAddrs(char**, char**, char**, Int64*);

/* forward declarations */
struct page;

/* User address space range used for page pool. */
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE) || defined(GPFS_ARCH_X86_64)
  #define LINUX_PAGE_POOL_BASE (0x0000004000000000) /* offset 256G */
#endif
#ifdef GPFS_ARCH_S390X
/* The page pool is below the shared segment with a size of max 256GB.
   The pool boundaries are fixed because of early initialization of the
   upper limit.  Note that shared segment changes through
   GPL_GET_SHARED_SEG_ADDRS() must not below the SSEG_USER_MIN_DEF offset.
  
   To increase the page pool size, lower the pool base address accordingly. */
#define LINUX_PAGE_POOL_BASE            (0x07C000000000UL)
#define LINUX_PAGE_POOL_UPPER_BOUNDARY  (SSEG_USER_MIN_DEF - PAGE_SIZE)
#endif


#define POOL_MMAP_CHUNK_SIZE  0x04000000

/* Address where token manager malloc pool begins */
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE) || defined(GPFS_ARCH_X86_64) || defined(GPFS_ARCH_S390X)
    /* TM Pool follows the shared segment reserved address range */
#   define TM_POOL_START (SSEG_USER_MAX+1)
#endif

/* Buffers in user address space must be aligned to a boundary of this size
   in order to perform an I/O request. */
#define IOBUF_ALIGN_SIZE 512

/* Kernel data structure that describes the pages associated with a
   piece of the page pool or a user buffer pinned for direct I/O.  The
   cxiXmem_t type is really a pointer to one of these cxiPageList_t
   objects.  The pointers to the Linux struct page objects obtained with
   map_user_pages are stored in a sparse radix tree whose depth depends
   on the maximum number of pages to be recorded.  The special case of a
   single page is represented by setting plNLevel to 0 and storing the
   page pointer in plRootP. */
struct cxiPageList_t
{
  /* Number of pages in the tree.  Will never exceed the number of pages
     that can be described by a two-level radix tree with nodes of size
     PAGE_SIZE. */
  int plNPages;

  /* Number of levels in the radix tree.  Possible values are 0..2. */
  int plNLevel;

  /* Virtual address in the owner's address space of the zero'th page
     in this page list */
  UIntPtr plBaseAddr;

  /* Pointer to root node of radix tree, or to a single page if plNLevel
     is zero */
  void* plRootP;
};

typedef struct cxiPageList_t cxiPageList_t;

#ifdef DATA_IN_INODE
/* Special value for plNPages that means that the buffer being mapped
   is allocated in the shared segment. */
#define PL_BUFFER_IN_MALLOC 0x7ffffffd

/* Mark this PageList to show that the buffer is allocated in the
   shared segment. */
static inline void plSetMALLOC(struct cxiPageList_t *plP)
{ plP->plNPages = PL_BUFFER_IN_MALLOC; }

/* Return true if the buffer being mapped is in the shared segment */
static inline Boolean plIsInMALLOC(struct cxiPageList_t *plP)
{ return plP->plNPages == PL_BUFFER_IN_MALLOC; }
#endif

EXTERNC struct cxiPageList_t* cxiAllocPageList(int maxPages,
                                               UIntPtr baseAddr);
EXTERNC int cxiMapAndRecordPages(struct cxiPageList_t* plP,
                                 UIntPtr uaddr,
                                 int nPages);
EXTERNC int cxiReleaseAndForgetPages(struct cxiPageList_t* plP,
                                     UIntPtr uaddr,
                                     int nPages);
EXTERNC int cxiMapUserBuffer(const struct cxiIovec_t* iovP, size_t len,
                             struct cxiPageList_t** plPP);
EXTERNC void cxiGetPagePtrs(struct cxiPageList_t* plP,
                            UIntPtr uaddr,
                            int nPages,
                            struct page ** pagePP);
EXTERNC void cxiDeallocPageList(struct cxiPageList_t* plP);


static inline void
InitMemoryMapping(struct cxiMemoryMapping_t *mmP)
{
  mmP->vaddr = NULL;
  mmP->kBytes = 0;
  mmP->vindex = -1;
  mmP->kvaddr = NULL;
  mmP->xmemDesc.pageListP = NULL;
}

static inline Boolean
IsMemoryMappingFree(struct cxiMemoryMapping_t *mmP)
{
  if (mmP->kBytes == 0)
    return true;

  return false;
}

typedef struct cxiMemoryMapping_t cxiMemoryMapping_t;

/* Initialization and termination routines.  Called at module load
   and unload, respectively. */
EXTERNC void IOBufferModuleInit();
EXTERNC void IOBufferModuleTerm();


/* Create a cross-memory descriptor object for a page in user address
   space that is already pinned.  The page will be mapped into kernel
   address space.  This is used by mmap routines that want to do
   direct I/O from user page to disk.  The cxiXmem_t that this routine
   creates can be passed through the GPFS I/O stack just like the ones
   describing buffers in the GPFS page pool. */
EXTERNC int cxiPinMM(struct page *pageP,
                     cxiXmem_t* xmemDescP);

/* Free a cross-memory descriptor that was created by cxiPinMM. */
EXTERNC void cxiUnpinMM(struct page *pageP,
                        cxiXmem_t* xmemDescP);


/* Handle that describes a particular cxiIOBuffer_t that has been attached.
   On Linux, this is a pointer to a page list. */
struct cxiIOBufferAttachment_t
{
  struct cxiPageList_t* pageListP;
};


/* Initialize a cxiIOBufferAttachment_t */
static inline void InitBufferAttachment(struct cxiIOBufferAttachment_t* baP)
{
  baP->pageListP = NULL;
};



/* Result of making a read-only copy of a portion of an I/O buffer.  On
   Linux, this must record the base address of the copy buffer, if one was
   required.  If data was mapped in place, the cxiContiguousBuffer_t records
   which page was kmapped. */
struct cxiContiguousBuffer_t
{
  /* Base of storage allocated with vmalloc / kmalloc, or NULL if data is
     referenced in place. */
  char* mallocedBaseP;

  /* True if storage pointed to be mallocedBaseP was allocated using
     kmalloc.  If false, then vmalloc was used. */
  Boolean usedKmalloc;

  /* Pointer used to remember which page to unmap, or NULL if data was copied
     to mallocedBaseP by mapContiguousRO. */
  void* pageP;
};


/* Initialize a cxiContiguousBuffer_t */
static inline void InitContiguousBuffer(struct cxiContiguousBuffer_t* cbP)
{
  cbP->mallocedBaseP = NULL;
  cbP->usedKmalloc = false;
  cbP->pageP = NULL;
}


/* Kernel calls used to manipulate page lists */
EXTERNC int kxMapAndRecordPages(int vindex, char* dataP, int nBytes,
                                int maxPages);
EXTERNC int kxReleaseAndForgetPages(int vindex, char* dataP, int nBytes);


/* On Linux, I/O buffers can be accessed at contiguous virtual addresses
   from the daemon process, but not from kernel code */
#ifndef _KERNEL
#define __CXI_BUFFERS_ARE_CONTIGUOUS
#endif

/* Routine to set up the disk block size and get disk parameters */
EXTERNC int GetDiskInfoX(cxiDev_t devId, struct cxiDiskInfo_t* diskInfoP);

/* Start an asynchronous I/O.  When the I/O is finished, the callback
   routine will be invoked with the parameter given at I/O start time.
   This callback occurs at interrupt level, so the callback routine must
   be careful about what it does.  Completed I/Os notify the given
   rendezvous. */
EXTERNC int cxiStartIO(int ioVecSize, cxiIOVecEntry* iovP,
                       Boolean isWrite, cxiDev_t dev,
                       UInt64 startSector, int sectorSize,
                       struct cxiIORendezvous_t* renP,
                       cxiIODoneIntCallback_t intCallbackRtn,
                       void* callbackParmP,
                       void** chunkHeadPP
#ifdef VDISK_LOOP_DEVICES
                       , int vdiskLoopDeviceMajor,
                       int vdiskLoopAdjustor
#endif
                       );

/* Clean up after or prepare for I/O completion.  If the I/O has
   completed, walk the list of cxiBioChunk_ts, summarizing the return
   codes and freeing storage.  If a pointer to an I/O rendezvous was
   provided, increment its count of the number of completed I/Os.  *rcP
   in this case will be the most severe return code seen.

   If the I/O has not yet completed, record the pointer to the I/O
   rendezvous.  This pointer may be NULL if the I/O rendezvous is about
   to be destroyed because kxLocalIO is about to return. */
EXTERNC void cxiCleanIO(void* chunkHeadP, struct cxiIORendezvous_t* renP,
                        UInt32* ioStateP, Boolean* isCompleteP, int* rcP);

/* Set up an I/O so its completion will be handled by the async I/O
   completion handler thread or a kernel work queue.  The I/O may have
   already been submitted and may even already be complete.  Depending
   on the state of the I/O, this routine will either move the completed
   I/O to the correct completion queue and wake up the waiting thread or
   set up the I/O so that chunkListDone will do this when the I/O
   completes later.  The last parameter is the address of the
   MBDoDiskIOParms object, needed by the callback routine that adds it
   to a completion queue. */
EXTERNC void cxiAssignAsyncIO(void* chunkHeadP, struct cxiIORendezvous_t* renP,
                              UInt32* ioStateP,
                              void (*completionCallbackP)(void*), void* p);

/* Increment ioqNComplete in the Rendezvous structure.  If doWakeUp is
   true and ioqNComplete >= ioqNDesired, then wake up the waiting thread. */
EXTERNC void cxiSignalCompletion(struct cxiIORendezvous_t* renP,
                                 Boolean doWakeUp);
#ifdef GPFS_ENC
/* Kernel crypto is available on Linux, in most cases (see gpl-layer) */
#include <cxiGcryptoDefs.h>
#ifdef __cplusplus
extern "C"
{
#endif
int cxiKEncryptDecrypt(gcryptoCtx_t *ctxP, void *srcP,
    void *dstP,
    UInt32 len,
    UInt64 blockNum,
    Int32 isEncrypt);
int cxiInitKernelCrypto(void);
#ifdef __cplusplus
}
#endif
#endif /* GPFS_ENC */

#endif  /* _h_cxiIOBuffer_plat */

