/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
#ifndef _h_qosio_k
#define _h_qosio_k
/* qosio-k.h
   Some qosio definitions -
    separated from qosio.h so they can be included where all
    the other qosio.h complexities are not required and/or may
    be detrimental to portable kernel code.
 */


/* magic and daemon thread qosid values */

/*
   QosId - revised numbering scheme

   High order byte is used to group similar activities and represents
   the class of work - which along with disk being accessed  will get mapped to a throttle/token bucket.

   Lower order bits may be used to track/analyze/breakout/tag more specific origin or type of work,
   The QosCmd/SgetStatParms API includes a mask parameter to control the level of statistics tracking - which
   has some costs in extra storage, communication, computation

   2014.03 - revised some again. As we go into production, and as we would like to do fast simple indexed
   lookups, particularly in the kernel, where we can not use the same C++ library datastructure allocated
   and built in user space (even if we finessed the allocator to put it in shared segment, we would have
   to fix all internal pointers to be XPTRs) And then we'd still be slower than we like...
   For most uses, the map<,> is overkill anyway - although useful for some kinds of tracing and analysis.

 */

/* All daemon iops not explicitly tied to a user process,  nor explicitly assigned to a work class are in the
   0D work class
 */

/* class 0DFF - uninitialized qosid - might bear investigation */
#define QOSID_U_WORKER   0x0DFF0002  /* uninit .. in WorkerParms */
#define QOSID_U_MAILBOX  0x0DFF0003  /* .. in Mailbox */
#define QOSID_U_DISKIO   0x0DFF0004  /* .. in iop Mailbox */
#define QOSID_U_OPENINST 0x0DFF0005  /* .. in OpenInstance */
#define QOSID_U_INODEPRE 0x0DFF0006  /* .. in InodePrefetchInstance */
#define QOSID_U_BUFDESC  0x0DFF0011  /* uninitialized qosid in BufferDesc */
#define QOSID_U_BUFDCLN  0x0DFF0012  /* similar .. but buffer was cleaned */

#define QOSID_U_ANON     0x0DFD0000  /* QosIoMon | anonymous qosid counter from daemon */
#define QOSID_U_ANONK    0x0CFC0000  /* QosIoMon | anonymous assignment from kernel */

/* class 0DFB - flush, but application to charge has gone */
#define QOSID_U_FLUSH    0x0DCC0007  /* flushFile with NULL OpenFile* or OpenInstance* */
#define QOSID_U_RELNQABR 0x0DCC0013  /* anonymous ReliquishAttrByteRange */

/* class 0DD0 - pit stuff */
#define QOSID_PITBASE    0x0DD00000  /* qosid = QOSID_PITBASE + (PitForWhat value) */
#define QOSID_MULTI      0x0D800000  /* qosid = QOSID_MULTI | ThreadName enumerator - see ThreadNames.h */

/* class 0DEE - various Daemon  overhead stuff */
#define QOSID_STRPG_BASE 0x0DE00000  /* StripeGroupCfg::exceptionHandlerBody + whichException */
#define QOSID_SYNC_WDOG  0x0DEE0002  /* SFSSyncWatchdogMain */
#define QOSID_DISK_INIT  0x0DEE0003  /* StripeGroup::DoDiskInit */
#define QOSID_LOGWRAP    0x0DEE0004  /* LogFile::wraparoundHelperThreadBody */
#define QOSID_RECOVERY   0x0DEE0005  /* InodeManagerRecovery */
#define QOSID_COMMAND    0x0DEE0006  /* HandleCmdMsg */
#define QOSID_DEALLOC    0x0DEE0007  /* DeallocHelperThreadBody */

/* class 0A - default work class for a user process */
#define QOSID_A_PROCESS  0x0A000000  /* qosid = user process w/o ionice value */
#define QOSID_K_DIO      0x0B000000  /* qosid = kernel directio w/o ionice value */

/* explicitly assigned classes via _setqos() shoud be 01..0F (assuming 15 or less are supported) */

#define QOSID_LOWMASK    0x00FFffFF  /* for nonDaemon, low bits of qosid are the process id */
#define QOSID_HIMASK     0x0F000000  /* notice we are dropping highest nibble */
#define QOSID_SHIFT      24          /* so after shift the range is 0..F can use small table */
#define QOSID_SNUM       16          /* = (QOSID_HIMASK>>QOSID_SHIFT)+1 number of distinct statistics per pool in histf array */
/* the HIMASK and SHIFT govern the map avoiding fastpath for statistics keeping and throttle
   selection, if necessary we could go bigger 16, 32, ... 256 */

#define MAX_QOS_CLASSES 7
#define QOS_MAX_CLASSNAME 18

#  ifndef _KERNEL
#  ifndef  STANDALONE_UTILITY
/* Daemon methods to manipulate thread qosid class */

uint qos_lkupName(const char* classname); /* lookup/validate QOS classname
                                             if not found or not valid return 0.
                                             Otherwise return the small value (1-255).
                                             Note: An alternative to alpha names is just the decimal numerals 1..255 */

int qos_lkupName(uint v, char classname[QOS_MAX_CLASSNAME]); /* from number
               set preferred name of QOS class */

uint qos_setqos(const char* classname, uint lowid =0, bool set =true); /* e.g. qos_setqos("GOLD"),
                 when lowid==0 keep low 24 bits from above QOSID_ ... 0Dxxxxxx defines
         If set==true AND classname is found then invoke qos_setqos(qosid value) and return qosid value.
         Otherwise just return the check the classname for validity and return its qosid value
         Return 0 if classname is invalid.     */

inline
uint qos_setqos(uint idqos) /* use with the QOSID_ constants or however you get the full 32 bit id */
{
  Thread::setGbl(THGBL_QOSID, (void*)idqos);
  return idqos;
}

inline uint qos_getqos()
{
  return (uint)(long)Thread::getGbl(THGBL_QOSID);
}
uint qos_stat_tracking(uint mask =0); /* Use (QOSID_HIMASK | mask) bits to distinguish iops
                                         iow if two iops have the same tracking bits they are summed into the same statistic */
#  endif
#  endif
#endif /* _h_qosio_k */
