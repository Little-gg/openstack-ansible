/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)01       1.214.1.4  src/avs/fs/mmfs/ts/kernext/gpl-linux/inode.c, mmfs, avs_rfks1, rfks1s008a 4/16/15 12:04:36 */
/*
 * Inode operations
 *
 * Contents:
 *   printInode
 *   printDentry
 *   cxiSetOSNode
 *   cxiInvalidatePerm
 *   getIattr
 *   get_umask
 *   gpfs_i_create
 *   gpfs_i_lookup
 *   gpfs_i_link
 *   gpfs_i_unlink
 *   gpfs_i_symlink
 *   gpfs_i_mkdir
 *   gpfs_i_rmdir
 *   gpfs_i_mknod
 *   gpfs_i_rename
 *   gpfs_i_readlink
 *   gpfs_i_follow_link
 *   gpfs_i_readpage        (in mmap.c)
 *   gpfs_i_writepage       (in mmap.c)
 *   gpfs_i_bmap
 *   gpfs_i_truncate
 *   gpfs_i_permission
 *   gpfs_i_smap
 *   gpfs_i_updatepage
 *   gpfs_i_revalidate
 *   gpfs_i_setattr
 *   gpfs_i_setattr_internal
 *   gpfs_i_getattr
 *   gpfs_i_getattr_internal
 *   gpfs_i_lock
 *   gpfs_i_getxattr
 *   gpfs_i_setxattr
 *   gpfs_i_listxattr
 *   gpfs_i_removexattr
 */

#include <Shark-gpl.h>

#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/highmem.h>
#include <linux/kdev_t.h>
#include <linux/sched.h>
#include <linux/xattr.h>

#include <verdep.h>
#include <cxiMode.h>
#include <cxiSystem.h>
#include <cxi2gpfs.h>
#include <cxiVFSStats.h>
#include <cxiCred.h>
#include <cxiAclUser.h>

#include <linux2gpfs.h>
#include <Trace.h>

#include <cxiTSFattr.h>

#define MAX_NLINK16 65535

#ifdef MODULE
#include <linux/module.h>
#endif /* MODULE */

/* assumes size > 256 */
static inline unsigned int myblksize_bits(unsigned int size)
{
  unsigned int bits = 8;
  do {
    bits++;
    size >>= 1;
  } while (size > 256);
  return bits;
}

void
printInode(struct inode *iP)
{
  TRACE7(TRACE_VNODE, 3, TRCID_PRINTINODE_1,
         "printInode: iP 0x%lX inode %lld (0x%X) i_count %d dev 0x%X "
         "mode 0x%X nlink %u\n",
         iP, iP->i_ino, iP->i_ino, atomic_read((atomic_t *)&iP->i_count),
         (unsigned int)iP->i_rdev, iP->i_mode, iP->i_nlink);

  TRACE6(TRACE_VNODE, 3, TRCID_PRINTINODE_2,
         "printInode: uid %d gid %d rdev 0x%X atime 0x%X mtime 0x%X "
         "ctime 0x%X\n", FROM_KUID(iP->i_uid), FROM_KGID(iP->i_gid), (unsigned int)iP->i_rdev,
         iP->i_atime.tv_sec, iP->i_mtime.tv_sec, iP->i_ctime.tv_sec);

  TRACE5(TRACE_VNODE, 3, TRCID_PRINTINODE_4,
         "printInode: size %lld blksize 0x%X blocks %d ver 0x%X op 0x%lX\n",
         iP->i_size, GET_INODE_BLOCKSIZE(iP), iP->i_blocks, iP->i_version,
         iP->i_op);

  TRACE6(TRACE_VNODE, 3, TRCID_PRINTINODE_5,
         "printInode: fop 0x%lX sb 0x%lX flags 0x%X state 0x%X gen 0x%X "
         "generic 0x%lX\n", iP->i_fop, iP->i_sb, iP->i_flags, iP->i_state,
         iP->i_generation, iP->PRVINODE);

#ifdef INODE_HAS_I_LIST_FIELD
  TRACE3(TRACE_VNODE, 3, TRCID_PRINTINODE_6,
         "printInode: list 0x%lX next 0x%lX prev 0x%lX\n",
         &(iP->i_list), iP->i_list.next, iP->i_list.prev);
#endif

  TRACE1(TRACE_VNODE, 3, TRCID_PRINTINODE_7_1,
         "printInode: dentry 0x%lX\n",
         &(iP->i_dentry));

#ifdef HLIST_I_DENTRY
  if (!hlist_empty(&iP->i_dentry))
    TRACE1(TRACE_VNODE, 3, TRCID_PRINTINODE_7_2,
         "printInode: dentry next 0x%lX\n",
         iP->i_dentry.first->next);
#else
  if (!list_empty(&iP->i_dentry))
    TRACE2(TRACE_VNODE, 3, TRCID_PRINTINODE_7,
         "printInode: dentry next 0x%lX prev 0x%lX\n",
         iP->i_dentry.next, iP->i_dentry.prev);
#endif

#ifdef INODE_HAS_I_LRU_FIELD 
  TRACE6(TRACE_VNODE, 3, TRCID_PRINTINODE_8,
         "printInode: wb_list 0x%lX next 0x%lX prev 0x%lX, lru 0x%lX next 0x%lX prev 0x%lX\n",
         &(iP->i_wb_list), iP->i_wb_list.next, iP->i_wb_list.prev,
         &(iP->i_lru), iP->i_lru.next, iP->i_lru.prev);
#endif

  TRACE3(TRACE_VNODE, 3, TRCID_PRINTINODE_9,
         "printInode: hash 0x%lX next 0x%lX prev 0x%lX\n",
         &(iP->i_hash), iP->i_hash.next,
         iP->i_hash.pprev != NULL ? *iP->i_hash.pprev : (void *)(-1L));
}

void
printDentry(struct dentry *dP)
{
  struct inode *iP = NULL;

  if (!_TRACE_IS_ON(TRACE_VNODE, 3))
    return;

  if (dP == NULL || IS_ERR(dP)) {
    TRACE2(TRACE_VNODE, 3, TRCID_PRINTDENTRY_0,
          "printDentry: dentry 0x%lX err %d\n",
          dP, PTR_ERR(dP));
    return;
  }
  iP = dP->d_inode;

  TRACE3N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_1,
          "printDentry: dentry 0x%lX count %d name '%s'\n",
          dP, GET_DENTRY_D_COUNT(dP), dP->d_name.name);

  TRACE5N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_2,
          "printDentry: time 0x%X op 0x%lX flags 0x%X parent 0x%lX "
          "inode 0x%X\n", dP->d_time, dP->d_op, dP->d_flags, 
          dP->d_parent, iP);

  if (iP)    
  {
#ifdef HLIST_I_DENTRY
    if (!hlist_empty(&iP->i_dentry))
      TRACE3N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_3A_1,
              "printDentry: i_ino %lld i_count %d "
              "i_dentry next 0x%lX\n",
              iP->i_ino, atomic_read((atomic_t *)&iP->i_count),
              hlist_entry(iP->i_dentry.first, struct dentry, d_alias));
#else
    if (!list_empty(&iP->i_dentry))
      TRACE4N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_3A,
              "printDentry: i_ino %lld i_count %d "
              "i_dentry next 0x%lX i_dentry prev 0x%lX\n",
              iP->i_ino, atomic_read((atomic_t *)&iP->i_count),
              list_entry(iP->i_dentry.next, struct dentry, d_alias),
              list_entry(iP->i_dentry.prev, struct dentry, d_alias));
#endif
    else
      TRACE2N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_3B,
              "printDentry: i_ino %lld i_count %d\n", 
              iP->i_ino, atomic_read((atomic_t *)&iP->i_count));
  }
  TRACE3N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_3D,
          "printDentry: &d_hash 0x%lX d_hash.next 0x%lX d_hash.pprev 0x%lX\n",
          &dP->d_hash, dP->d_hash.next, dP->d_hash.pprev);
  TRACE3N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_4,
          "printDentry: &child 0x%lX child.next 0x%lX child.prev 0x%lX\n", 
          &dP->d_child, dP->d_child.next, dP->d_child.prev);

  if (!list_empty(&dP->d_subdirs))
    TRACE3N(TRACE_VNODE, 3, TRCID_PRINTDENTRY_5,
            "printDentry: &subdirs 0x%lX subdir next 0x%lX "
            "subdir prev 0x%lX\n", &dP->d_subdirs,
            list_entry(dP->d_subdirs.next, struct dentry, d_child),
            list_entry(dP->d_subdirs.prev, struct dentry, d_child));
}

/* Print directory entry tree up to maxPrint elements.
 * If maxPrint is 0 then there is no upper limit.
 */
void
printDentryTree(struct dentry *entryDP, int maxPrint)
{
  int count = 0;
  struct list_head *lhP;
  struct dentry *siblingDP = NULL;
  struct dentry *parentDP;

  /* Check trace level required by printDentry() */
  if (!_TRACE_IS_ON(TRACE_VNODE, 3))
    return;

  /* should acquire rename_lock and siblingDP->dlock? */
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&entryDP->d_inode->i_lock);
  spin_lock(&entryDP->d_lock);
#else
  spin_lock(&dcache_lock);
#endif

  parentDP = entryDP;
  lhP = parentDP->d_subdirs.next;

  printDentry(parentDP);
  if (maxPrint > 0 && ++count >= maxPrint)
    goto xerror;

  if (list_empty(&parentDP->d_subdirs))
    goto xerror;

  do
  {
    while (lhP != &parentDP->d_subdirs)
    {
      siblingDP = list_entry(lhP, struct dentry, d_child);

      printDentry(siblingDP);
      if (maxPrint > 0 && ++count >= maxPrint)
        goto xerror;

      if (!list_empty(&siblingDP->d_subdirs))
      {
        parentDP = siblingDP;
        lhP = siblingDP->d_subdirs.next;
        continue;
      }

      lhP = siblingDP->d_child.next;
      parentDP = siblingDP->d_parent;
    }
  
    siblingDP = siblingDP->d_parent;
    parentDP = siblingDP->d_parent;
    lhP = siblingDP->d_child.next;
  } 
  while (lhP != entryDP->d_child.next);

xerror:
#ifdef DCACHE_LOCK_IS_GONE
  spin_unlock(&entryDP->d_lock);
  spin_unlock(&entryDP->d_inode->i_lock);
#else
  spin_unlock(&dcache_lock);
#endif

  return;
}



/* Set the inode operations table for a regular file, special file, or directory.
   Call with xperm set to true if the file has extended permission attributes
   (i.e. an ACL).

   If the file does not have extended attributes, the table that is used
   will have a null value for the permission routine pointer.  This will
   cause Linux to perform access checks directly instead of acquiring the
   kernel lock and calling GPFS, giving better performance. */
void setIopTable(struct inode *iP, Boolean xperm)
{
  struct inode_operations *xopP = NULL;

  /* Choose the correct inode operations table based on whether this is a
     directory, regular file, or special file.  Assume that the file has
     extended attributes so that GPFS permission checking will be required. */
  ENTER(0);
  if (S_ISDIR(iP->i_mode))
    xopP = &gpfs_dir_iops_xperm;
  else if (S_ISREG(iP->i_mode))
    xopP = &gpfs_iops_xperm;
  else if (S_ISLNK(iP->i_mode))
  {
    EXIT(0);
    return;
  }
  else
  {
    xopP = &gpfs_special_iops_xperm;
  }

  /* If the file really does have extended attributes (or if the token has
     been lost so that we do not know the status), set extended permission
     table and exit. */
  if (xperm)
  {
    iP->i_op = xopP;
    EXIT(0);
    return;
  }

  /* Get address of an inode operations table that has a generic permission
     routine pointer. */
  if (S_ISDIR(iP->i_mode))
    iP->i_op = &gpfs_dir_iops_stdperm;
  else if (S_ISREG(iP->i_mode))
    iP->i_op = &gpfs_iops_stdperm;
  else
    iP->i_op = &gpfs_special_iops_stdperm;
  EXIT(0);
}


void
cxiPrintInode(void *iP)
{
  struct inode *inodeP = iP;
  printInode(iP);
}


void
cxiSetOSNode(void *osVfsP, cxiNode_t *cnP, cxiVattr_t *attrP, int flags)
{
  struct super_block *sbP = (struct super_block *)osVfsP;
  struct inode *inodeP = (struct inode *)cnP->osNodeP;

  ENTER(0);
  DBGASSERT(inodeP != NULL);
  DBGASSERT(inodeP->PRVINODE == cnP);
  DBGASSERT(inodeP->i_sb == sbP);

  inodeP->i_mode = attrP->va_mode;
  /* Make sure we do a best effort to convert nlink to fit the field */
  set_nlink(inodeP, attrP->va_nlink);
  if (sizeof(inodeP->i_nlink) == 2)
    set_nlink(inodeP, MIN(attrP->va_nlink, MAX_NLINK16));
  inodeP->i_uid  = MAKE_KUID(attrP->va_uid);
  inodeP->i_gid  = MAKE_KGID(attrP->va_gid);
  inodeP->i_rdev = cxiDevToKernelDev(cxiDev32ToDev(attrP->va_rdev));
#ifdef GPFS_CACHE
  if (flags & GETATTR_ATIMEXATTR)
  {
    if (attrP->va_xinfo & 
        (VA_HASXATTR | VA_XPERM | VA_ISIMMUTABLE | VA_ISAPPENDONLY))
      attrP->va_atime.tv_nsec &= 0xFFFFFFFE; // might have xattr/ACL/Immutablefile/AppendOnly
    else
      attrP->va_atime.tv_nsec |= 0x00000001; // no xattr for this file
  }
#endif
  CXITIME_TO_INODETIME(attrP->va_atime, inodeP->i_atime);
  CXITIME_TO_INODETIME(attrP->va_mtime, inodeP->i_mtime);
  CXITIME_TO_INODETIME(attrP->va_ctime, inodeP->i_ctime);

  inodeP->i_size = attrP->va_size;
  SET_INODE_BLOCKSIZE(inodeP,attrP->va_blocksize);
  inodeP->i_blocks = attrP->va_blocks;
  inodeP->i_generation = attrP->va_gen;
  inodeP->i_flags = 0;

  cnP->xinfo = attrP->va_xinfo;

  switch (inodeP->i_mode & S_IFMT)
  {
    case S_IFREG:
      setIopTable(inodeP, (attrP->va_xinfo & VA_XPERM) != 0);
#ifdef REDHAT_RHEL53
      inodeP->i_fop = (struct file_operations *)&gpfs_fops_ext;
#else
      inodeP->i_fop = &gpfs_fops;
#endif
      break;

    case S_IFDIR:
      setIopTable(inodeP, (attrP->va_xinfo & VA_XPERM) != 0);
      inodeP->i_fop = &gpfs_dir_fops;
      break;

    case S_IFLNK:
      inodeP->i_op = &gpfs_link_iops;
#ifdef REDHAT_RHEL53
      inodeP->i_fop = (struct file_operations *)&gpfs_fops_ext;
#else
      inodeP->i_fop = &gpfs_fops;
#endif
      break;

    case S_IFBLK:
    case S_IFCHR:
    case S_IFIFO:
    case S_IFSOCK:
      setIopTable(inodeP, (attrP->va_xinfo & VA_XPERM) != 0);
      /* Set vector table for special files, gpfs will not get 
       * these operations. 
       */
      init_special_inode(inodeP, inodeP->i_mode, inodeP->i_rdev);
      break;
  }
  if (inodeP->i_mapping)
    inodeP->i_mapping->a_ops = &gpfs_aops;

  cnP->icValid = CXI_IC_ALL;
#ifdef GPFS_CACHE
  if (flags & GETATTR_REVALIDATE)
    SetCtFlag(cnP, revalidateNeeded);
  else
    ClearCtFlag(cnP, revalidateNeeded);
#endif

  TRACE7(TRACE_VNODE, 2, TRCID_LINUXOPS_SETINODE,
         "cxiSetOSNode: inodeP 0x%lX inode %lld i_count %d i_mode 0x%X "
         "i_xinfo 0x%X i_nlink %u i_size %lld\n",
         inodeP, inodeP->i_ino, atomic_read((atomic_t *)&inodeP->i_count),
         inodeP->i_mode, attrP->va_xinfo, inodeP->i_nlink, inodeP->i_size);
  EXIT(0);
  return;
}


/* The following function is called from cxiInvalidateAttr when the
   CXI_IC_PERM option was specified, which indicates that permission related
   attributes cached in the struct inode (owner, mode, etc.) are no longer
   known to be valid. */
void
cxiInvalidatePerm(cxiNode_t *cnP)
{
  struct inode *inodeP = (struct inode *)cnP->osNodeP;

  ENTER(0);
  TRACE3(TRACE_VNODE, 2, TRCID_CXIINVA_PERM,
         "cxiInvalidatePerm: cnP 0x%lX std %d dir std %d",
         cnP, inodeP->i_op == &gpfs_iops_stdperm,
         inodeP->i_op == &gpfs_dir_iops_stdperm);

  /* Set the inode operation table to gpfs_..._xperm; the next permission
     check will then go through our gpfs_i_permission function, which will
     revalidate permission attributes and set the inode operation table
     back to gpfs_..._stdperm, if appropriate. Note: since symlinks always
     have permission iop set, setIopTable is a noop for symlinks. */
  setIopTable(inodeP, true);
  EXIT(0);
}

static void
getIattr(struct inode *inodeP, struct iattr *attrP)
{
  ENTER(0);
  // attrP->ia_valid = ??? ;
  attrP->ia_mode = inodeP->i_mode;
  attrP->ia_uid = inodeP->i_uid;
  attrP->ia_gid = inodeP->i_gid;
  attrP->ia_size = inodeP->i_size;
  attrP->ia_atime = inodeP->i_atime;
  attrP->ia_mtime = inodeP->i_mtime;
  attrP->ia_ctime = inodeP->i_ctime;
  EXIT(0);
  return;
}

static inline int
get_umask()
{
  return (current->fs->umask);
}


/* inode_operations */

/* Called with a negative (no inode) dir cache entry.
 * If this call succeeds, we fill in with d_instantiate(). 
 */

#ifdef NAMEIDATA_REPLACED
int
gpfs_i_create(struct inode *diP, struct dentry *dentryP, umode_t mode,
              bool excl)
#elif defined(NEW_MODE_TYPE)
int
gpfs_i_create(struct inode *diP, struct dentry *dentryP, umode_t mode,
              struct nameidata *ni)
#else
int
gpfs_i_create(struct inode *diP, struct dentry *dentryP, int mode,
              struct nameidata *ni)
#endif
{
  int rc;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *dcnP = NULL;
  cxiNode_t *cnP = NULL;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  struct inode *newInodeP = NULL;
  int flags = FWRITE | FCREAT | FEXCL;
  cxiMode_t umask = get_umask();
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct dentry *retP = NULL;
  UInt32 intent;

  VFS_STAT_START(createCall);
  ENTER(0);
  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_CREATE_ENTER,
         "gpfs_i_create enter: iP 0x%lX dentryP 0x%lX mode 0x%X name '%s'\n",
         diP, dentryP, mode, dentryP->d_name.name);
  /* BKL is held at entry */

  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

retry:

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  rc = gpfs_ops.gpfsCreate(privVfsP, NULL, dcnP, (void **)&newInodeP, &cnP, &iNum, 0,
                           flags, dentryP, (char *)dentryP->d_name.name, 
                           IS_CASE_SENSITIVE(), mode, umask, NULL, eCredP, NULL);
  if (rc == 0)
  {
    DBGASSERT(cnP != NULL);
    DBGASSERT(iNum != INVALID_INODE_NUMBER);
    DBGASSERT(newInodeP != NULL);
    DBGASSERT(newInodeP->PRVINODE == cnP);
    DBGASSERT(cnP->osNodeP == (void *)newInodeP);
    cnP->createRaceLoserThreadId = 0;
  }

  /* linux would normally serialize the creates on a directory (via the 
   * parent directory semaphore) to ensure that a create didn't fail with 
   * EEXIST.  However in a multinode environment we may perform a lookup 
   * on one node (thinking the file doesn't exist) yet a create is 
   * performed on a different node before linux can call the physical
   * file systems create.  We attempt to reconcile this case by marking
   * the fact that this happened and checking the FEXCL flag at gpfs_f_open()
   * to see if we should have failed this with EEXIST.
   */
  if (rc == EEXIST)
  {
    /* Make sure that this create call is part of the linux open call.  NFS
       and mknod calls create without an open, so check that this is not one
       of those calls. On the open call the open flags are available and if
       the FEXCL was on fail it with EEXIST. */
    unsigned int mode1 = mode;

    /* Skip if NFS create call. */
    if (cxiIsNFSThread()
#ifdef GANESHA
       || cxiIsGaneshaThread()
#endif
       )
      goto retExist;

    /* ??? if (sys_mknod call) goto xerror; */

    /* Do it only if trying to create a regular file. */
    if (((mode & S_IFMT) != 0) && !(mode & S_IFREG))
      goto retExist;

    rc = getCred(&eCred, &eCredP); // rebuild since gpfsCreate may remap ids
    if (rc)
      goto retExist;

#ifdef NAMEIDATA_REPLACED
    intent = GPFS_LOOKUP_CREATE;
#else
    intent = (ni != NULL) ? LOOKUP_FLAGS_TO_INTENT(ni->flags) : 0;
#endif
    rc = gpfs_ops.gpfsLookup(privVfsP, (void *)diP, dcnP, dentryP, NULL,
                             (char *)dentryP->d_name.name, intent,
                             (void **)&newInodeP, &cnP, &iNum, NULL, &mode1,
                             eCredP, IS_CASE_SENSITIVE(), (void **)&retP, NULL, 
                             NULL, NULL);
    if (rc == ENOENT)
      goto retry;
    if (!rc)
    {
      /* If the file that was found was a directory than return the
         return code that linux would have returned. */
      if (S_ISDIR(newInodeP->i_mode))
      {
        rc = EISDIR;
        goto retExist;
      }
      cnP->createRaceLoserThreadId = cxiGetThreadId();
    }
  }

retExist:
  if (rc)
  {
    d_drop(dentryP);
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  diP->i_sb->s_dirt = 1;
#endif

xerror:
  putCred(&eCred, &eCredP);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_CREATE_EXIT,
         "gpfs_i_create exit: new inode 0x%lX iNum %lld (0x%llX) rc %d\n",
         newInodeP, iNum, iNum, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

/* If this routine successfully finds the file, it should
 * add the dentry to the hash list with d_add() and return
 * null.  If a failure occurs then return non null and the
 * dentry will be dput() by the linux lfs layer
 */
#ifdef NAMEIDATA_REPLACED
struct dentry *
gpfs_i_lookup(struct inode *diP, struct dentry *dentryP, unsigned int flags)
#else
struct dentry *
gpfs_i_lookup(struct inode *diP, struct dentry *dentryP, struct nameidata *ni)
#endif
{
  int code = 0;
  int rc = 0;
  struct dentry *retP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiNode_t *dcnP;
  cxiMode_t mode = 0;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  cxiNode_t *cnP = NULL;
  struct inode *newInodeP = NULL;
  UInt32 intent;

  VFS_STAT_START(lookupCall);
  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_LOOKUP_ENTER,
         "gpfs_i_lookup enter: diP 0x%lX dentryP 0x%lX name '%s'\n",
         diP, dentryP, dentryP->d_name.name);
  /* BKL is held at entry */

  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 4;
    retP = (struct dentry *)ERR_PTR(-rc);
    goto xerror;
  }

  if (!dcnP)
  {
    /* This can happen due to a bug in linux/fs/dcache.c (prune_dcache)
       where "count" entries are to be pruned, but the last one is
       found to be recently referenced.  When this happens, count is
       decremented, but the loop is not terminated.  The result is that
       it continues to prune entries past where it should (prunes
       everything).  If our patch for this is not applied, the result
       is a kernel failure as the cxiNode is referenced.  Checking
       here (and revalidate) allows us to reject the call instead. */

    TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_LOOKUP_STALE,
           "cxiNode for inode 0x%lX (ino 0x%X) was FREED!\n",
           diP, diP->i_ino);

    /* Although we may like to know more about this inode, it is not
     * ok to call PRINTINODE(iP) here.
     */
    rc = ESTALE;
    code = 1;
    retP = (struct dentry *)ERR_PTR(-rc);
    goto xerror;
  }
#ifdef NAMEIDATA_REPLACED
  intent = LOOKUP_FLAGS_TO_INTENT(flags);
  rc = gpfs_ops.gpfsLookup(privVfsP, (void *)diP, dcnP,
                           dentryP, NULL, (char *)dentryP->d_name.name,
                           intent, (void **)&newInodeP, &cnP, &iNum,
                           NULL, &mode, eCredP, IS_CASE_SENSITIVE(),
                           (void **)&retP, NULL, NULL, NULL);
#else
  intent = (ni != NULL) ? LOOKUP_FLAGS_TO_INTENT(ni->flags) : 0;
  rc = gpfs_ops.gpfsLookup(privVfsP, (void *)diP, dcnP,
                           dentryP, ni, (char *)dentryP->d_name.name,
                           intent, (void **)&newInodeP, &cnP, &iNum,
                           NULL, &mode, eCredP, IS_CASE_SENSITIVE(),
                           (void **)&retP, NULL, NULL, NULL);
#endif

  if (rc == 0)
  {
    DBGASSERT(cnP != NULL);
    DBGASSERT(iNum != INVALID_INODE_NUMBER);
    DBGASSERT(newInodeP != NULL);
    DBGASSERT(newInodeP->PRVINODE == cnP);
    DBGASSERT(cnP->osNodeP == (void *)newInodeP);
  }
  else if (rc != ENOENT) // internal failure
  {
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);
    code = 2;
    retP = (struct dentry *)ERR_PTR(-rc);
    goto xerror;
  }
  else if (diP->i_nlink == 0) // ENOENT but unlinked parent
  {
    /* This odd code is here because this function would normally 
     * exit with a negative dcache entry on ENOENT.  However if 
     * we allow a negative dcache entry in a directory thats been
     * deleted (but we're still sitting in it) then the d_count
     * will never go to zero and we'll strand any open file that
     * is associated with the parent directory.  If we drop the 
     * dentry and return the ENOENT then the VFS will dput the
     * dentry.  The scenario that gave us trouble was:
     *
     * NODE 1                               NODE 2
     * `rm -rf dirA`                        `rm -rf dirA`
     * ==========================================================
     * gpfs_f_open("dirA", ...)
     * gpfs_f_readdir(...)
     * [read "fileA", "fileB"]              gpfs_f_open("dirA", ...)
     *                                      gpfs_f_readdir(...)
     *                                      [read "fileA", "fileB"]
     *
     *                                      gpfs_i_lookup("fileA")
     *                                      gpfs_i_unlink("fileA")
     *                                      gpfs_s_delete_inode(fileA's inode)
     *                                      gpfs_i_lookup("fileB")
     *                                      gpfs_i_unlink("fileB")
     *                                      gpfs_s_delete_inode(fileB's inode)
     *                                      ...
     *                                      gpfs_i_rmdir("dirA", ...)
     *                                      gpfs_s_delete_inode(dirA's inode)
     * destroyOnLastClose=1 for dirA        <======
     * 
     * gpfs_i_lookup("fileA")
     *  [creates a negative dentry for fileA,
     *   increments dirA's reference count]
     * gpfs_i_lookup("fileB")
     *  [creates a negative dentry for fileB,
     *   increments dirA's reference count]
     */
    DBGASSERT(dentryP->d_inode == NULL);
    dentryP->d_op = NULL;
    d_drop(dentryP);

    code = 3;
    retP = (struct dentry *)ERR_PTR(-rc);
    goto xerror;
  }

  PRINTDENTRY(dentryP);

xerror:
  putCred(&eCred, &eCredP);

  TRACE7(TRACE_VNODE, 1, TRCID_LINUXOPS_LOOKUP_EXIT,
         "gpfs_i_lookup exit: new inode 0x%lX iNum %lld (0x%llX) cnP 0x%lX retP 0x%lX "
         "code %d rc %d\n", newInodeP, iNum, iNum, cnP, retP, code, rc);

  VFS_STAT_STOP;
  EXIT(0);
  return retP;
}

/* Added a parameter 'isRelink'. This flag is passed down to mainline code,
   make it known we're executing a relink vs regular link.
   Notice: at this point, the VFS always calls relink iop if a file system
   implements it, even at the place which should call link iop! In another
   word, currently, HPC kernel expects relink iop is a superset of link iop,
   so GPFS must comply this semantic too. */

int
gpfs_i_link(struct dentry *oldDentryP, struct inode *diP,
            struct dentry *dentryP)
{
  return gpfs_i_link_common(oldDentryP, diP, dentryP, false);
}

int
gpfs_i_relink(struct dentry *oldDentryP, struct inode *diP,
            struct dentry *dentryP)
{
  return gpfs_i_link_common(oldDentryP, diP, dentryP, true);
}

int
gpfs_i_link_common(struct dentry *oldDentryP, struct inode *diP,
            struct dentry *dentryP, Boolean isRelink)
{
  int rc = 0;
  struct inode *iP = oldDentryP->d_inode;
  cxiNode_t *dcnP;
  cxiNode_t *cnP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;
  char *tnameP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;

  VFS_STAT_START(linkCall);
  ENTER(0);
  TRACE6(TRACE_VNODE, 1, TRCID_LINUXOPS_LINK_ENTER,
         "gpfs_i_link enter: diP 0x%lX dentryP 0x%lX dentryP 0x%lX "
         "isRelink %d i_nlink %u name '%s'\n", diP, oldDentryP, dentryP,
         isRelink, iP->i_nlink, dentryP->d_name.name);
  /* BKL is held at entry */

  cnP = VP_TO_CNP(iP);
  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  rc = gpfs_ops.gpfsLink(privVfsP, cnP, dcnP,
                         dentryP, (char *)dentryP->d_name.name,
                         IS_CASE_SENSITIVE(), isRelink, eCredP);
  if (rc)
  {
    d_drop(dentryP);
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  iP->i_sb->s_dirt = 1;
#endif

xerror:
  putCred(&eCred, &eCredP);

  PRINTINODE(iP);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_LINK_EXIT,
         "gpfs_i_link exit: diP 0x%lX iP 0x%lX rc %d\n", diP, iP, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_unlink(struct inode *diP, struct dentry *dentryP)
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct inode *iP = dentryP->d_inode;
  cxiNode_t *dcnP;
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
#if LINUX_KERNEL_VERSION >= 2063000
  const struct dentry_operations *orig_d_opP;
#else
  struct dentry_operations *orig_d_opP;
#endif
#if LINUX_KERNEL_VERSION > 2060000
  struct dentry *dentry;
  Boolean disconnectedDentries = false;
#endif

  VFS_STAT_START(removeCall);
  ENTER(0);
  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_UNLINK_ENTER,
         "gpfs_i_unlink enter: diP 0x%lX iP 0x%lX dentryP 0x%lX name '%s'\n",
         diP, iP, dentryP, dentryP->d_name.name);
  /* BKL is held at entry */

  cnP = VP_TO_CNP(iP);

  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

#ifdef P_NFS4
  cxiRecallLayout(iP->i_sb, iP, NULL);
#endif

  /* Regarding dcache entry update: upon returning from gpfs_i_unlink, the VFS
     layer will turn the dentry into a valid, negative dcache entry by calling
     d_delete().  If another node then creates a new file with the same name,
     the BR token revoke for the directory block will invalidate the negative
     dcache entry.  However, there is a window between the gpfsRemove() and
     the d_delete(), where a BR token revoke would not recognize that it
     should invalidate the dcache entry, because d_delete() has not yet turned
     it into a negative dcache entry.  To fix this, we mark the dentry as
     "valid with d_delete pending"; the meaning of this state is "the dentry
     is still valid, but a BR token revoke should mark it as 'needing 
     revalidation', even if it does not (yet) look like a negative dcache 
     entry".  Note that we don't want to mark "valid with d_delete pending"
     entries as invalid in the BR revoke handler, because we don't know for 
     sure that the file is in fact going to be deleted.  The unlink operation
     may fail, for any number of reasons, and the dentry should not be marked
     as invalid prematurely.  It's safe to mark a dentry as 'needing 
     revalidation', however.  Ideally, we should swap d_op inside gpfsRemove 
     while we are holding the BR lock on the directory.  However, (1) there is
     local synchronization in the VFS (our caller is holding the i_sem 
     semaphore on the directory) that will prevent other threads from doing a 
     lookup or create that might change the state back to just plain "valid" 
     before the gpfsRemove has happened, and (2) a BR revoke that happens 
     before the gpfsRemove might unnecessarily mark the dentry as 'needing 
     revalidation'; this is sub-optimal, but it doesn't hurt.  Also see 
     comment in gpfs_i_rmdir. */

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    d_drop(dentryP);
    goto xerror;
  }

  orig_d_opP = (struct dentry_operations *)dentryP->d_op;
  set_dentry_operations(dentryP, &gpfs_dops_ddeletepending, false);

  rc = gpfs_ops.gpfsRemove(privVfsP, cnP, dcnP, (char *)dentryP->d_name.name,
                           true, NULL, eCredP);
  if (rc)
  {
    d_drop(dentryP);
    if (dentryP->d_op == &gpfs_dops_ddeletepending)
      set_dentry_operations(dentryP, orig_d_opP, false);
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  diP->i_sb->s_dirt = 1;
#endif

  /* d_delete will be called at VFS layer if rc == 0 */

  /* Drop case-insensitive matches */
  cxiDropSambaDCacheEntry(cnP);

xerror:
  putCred(&eCred, &eCredP);

  PRINTINODE(iP);
  PRINTDENTRY(dentryP);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_UNLINK_EXIT,
         "gpfs_i_unlink exit: diP 0x%lX iP 0x%lX rc %d\n", diP, iP, rc);

#if LINUX_KERNEL_VERSION > 2060000
  /* Prune disconnected dentries:
     When gpfs_nfsd_iget_dentry cannot find an existing dentry on the 
     inode->i_dentry list, it allocates a new entry using d_alloc_anon, 
     and the new dentry then remains in a disconnected state (subsequent
     gpfs_i_revalidate calls cannot splice it in on the right lists, since 
     the code doesn't know what the object name or the parent dir).
     The problem is that when a file is deleted, any anon dentry created by 
     gpfs_nfsd_iget_dentry remains intact.  If there are any of these
     disconnected dentries after this unlink, prune the dentries for
     this inode. */

  /* Traverse the list looking for disconnected dentries. */
#ifdef DCACHE_LOCK_IS_GONE
  spin_lock(&iP->i_lock);
#else
  spin_lock(&dcache_lock);
#endif
  LIST_FOR_I_DENTRY(dentry, &iP->i_dentry, d_alias)
  {
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&dentry->d_lock);
#endif

    TRACE3N(TRACE_VNODE, 3, TRCID_LINUXOPS_UNLINK_DENTRY,
           "gpfs_i_unlink: dentry 0x%lX d_flags 0x%lX d_count %d", dentry, dentry->d_flags, 
            GET_DENTRY_D_COUNT(dentry));

    if (dentry->d_flags & DCACHE_DISCONNECTED)
    {
      disconnectedDentries = true;
      DENTRY_DROP(dentry);
#ifdef DCACHE_LOCK_IS_GONE
      spin_unlock(&dentry->d_lock);
#endif
      break;
    }
#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&dentry->d_lock);
#endif
  }

#ifdef DCACHE_LOCK_IS_GONE
  spin_unlock(&iP->i_lock);
#else
  spin_unlock(&dcache_lock);
#endif

  /* prune any unheld dentries pointing at the inode */
  if (disconnectedDentries)
    d_prune_aliases(iP);
#endif

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_symlink(struct inode *diP, struct dentry *dentryP,
               const char *symlinkTargetP)
{
  int rc = 0;
  cxiNode_t *dcnP;
  cxiNode_t *cnP;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  struct inode *newInodeP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;

  VFS_STAT_START(symlinkCall);
  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_SYMLINK1,
         "gpfs_i_symlink enter: iP 0x%lX dentryP 0x%lX symlinkTargetP '%s'\n",
         diP, dentryP, symlinkTargetP);
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_SYMLINK2,
         "gpfs_i_symlink: newLinkName '%s'\n", dentryP->d_name.name);
  /* BKL is held at entry */

  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    d_drop(dentryP);
    goto xerror;
  }

  rc = gpfs_ops.gpfsSymlink(privVfsP, NULL, dcnP, (void **)&newInodeP, &cnP,
                            &iNum, dentryP, (char *)dentryP->d_name.name, 
                            IS_CASE_SENSITIVE(), (char *)symlinkTargetP, eCredP);
  if (rc == 0)
  {
    DBGASSERT(cnP != NULL);
    DBGASSERT(iNum != INVALID_INODE_NUMBER);
    DBGASSERT(newInodeP != NULL);
    DBGASSERT(newInodeP->PRVINODE == cnP);
    DBGASSERT(cnP->osNodeP == (void *)newInodeP);
  }
  else
  {
    d_drop(dentryP);
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  diP->i_sb->s_dirt = 1;
#endif

xerror:
  putCred(&eCred, &eCredP);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_SYMLINK_EXIT,
         "gpfs_i_symlink exit: new inode 0x%lX iNum %lld (0x%llX) rc %d\n",
         newInodeP, iNum, iNum, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

#ifdef NEW_MODE_TYPE
int
gpfs_i_mkdir(struct inode *diP, struct dentry *dentryP, umode_t mode)
#else
int
gpfs_i_mkdir(struct inode *diP, struct dentry *dentryP, int mode)
#endif
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *dcnP;
  cxiNode_t *cnP;
  cxiMode_t umask;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  struct inode *newInodeP = NULL;
  
  VFS_STAT_START(mkdirCall);
  ENTER(0);
  umask = get_umask();  /* LFS should not apply umask and we may not */

  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_MKDIR_ENTER,
         "gpfs_i_mkdir enter: diP 0x%lX mode 0x%X name '%s'\n",
         diP, mode, dentryP->d_name.name);
  /* BKL is held at entry */

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    d_drop(dentryP);
    goto xerror;
  }

  rc = gpfs_ops.gpfsMkdir(privVfsP, NULL, dcnP, (void **)&newInodeP, &cnP, &iNum,
                          dentryP, (char *)dentryP->d_name.name, 
                          IS_CASE_SENSITIVE(), mode, umask, eCredP);

  if (rc == 0)
  {
    DBGASSERT(cnP != NULL);
    DBGASSERT(iNum != INVALID_INODE_NUMBER);
    DBGASSERT(newInodeP != NULL);
    DBGASSERT(newInodeP->PRVINODE == cnP);
    DBGASSERT(cnP->osNodeP == (void *)newInodeP);
  }
  else
  {
    d_drop(dentryP);
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  diP->i_sb->s_dirt = 1;
#endif

xerror:
  putCred(&eCred, &eCredP);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_MKDIR_EXIT,
         "gpfs_i_mkdir exit: new inode 0x%lX iNum %lld (0x%llX) rc %d\n",
         newInodeP, iNum, iNum, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_rmdir(struct inode *diP, struct dentry *dentryP)
{
  int rc;
  struct inode *iP = dentryP->d_inode;
  cxiNode_t *dcnP;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
#if LINUX_KERNEL_VERSION >= 2063000
  const struct dentry_operations *orig_d_opP;
#else
  struct dentry_operations *orig_d_opP;
#endif

  VFS_STAT_START(rmdirCall);
  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_RMDIR_ENTER,
         "gpfs_i_rmdir enter: diP 0x%lX iP 0x%lX name '%s'\n",
         diP, iP, dentryP->d_name.name);
  /* BKL is held at entry */

  cnP = VP_TO_CNP(iP);
  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

  /* See comment in gpfs_i_unlink.  Note that Linux kernel processes 
     directory dentries a little differently from regular file
     dentries.  In particular, it doesn't appear that a successful
     rmdir call results in the removed directory dentry being turned
     into a valid negative dentry; the dentry just gets unhashed and
     recycled if it had no references at the time of rmdir.  If the
     dentry did have extra references, e.g. due to a process using the
     directory in question as cwd, the dentry is unhashed, but it
     remains a positive dentry pointing to the deleted inode, and will
     remain as such until the dentry ref count goes to zero, at which
     point the dentry is recycled.  So there's no apparent need to 
     mark directory dentries as 'needing revalidation' during BR token
     revoke (we do know that we need to do this for regular files).
     However, this particular aspect of Linux kernel operation is not
     guaranteed to always work in this fashion, so we might as well 
     try to stay on the safe side of things, and treat directories the
     same way as regular files.  It doesn't appear that marking a
     dentry as 'needing revalidation' has any ill effects besides extra
     cycles required for revalidation, and BR token revoke handler 
     racing with an unsuccessful gpfsRmdir is a rare enough event to
     tolerate this extra performance hit. */

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    /* d_drop(dentryP); */
    goto xerror;
  }

  orig_d_opP = (struct dentry_operations *)dentryP->d_op;
  set_dentry_operations(dentryP, &gpfs_dops_ddeletepending, false);

  rc = gpfs_ops.gpfsRmdir(privVfsP, cnP, dcnP, (char *)dentryP->d_name.name,
                          true, eCredP);
  if (rc)
  {
    if (rc == EEXIST)
      rc = ENOTEMPTY;
    if (dentryP->d_op == &gpfs_dops_ddeletepending)
      set_dentry_operations(dentryP, orig_d_opP, false);
    /* d_drop(dentryP); */
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  diP->i_sb->s_dirt = 1;
#endif

  /* d_delete will be called at VFS layer if rc == 0 */

  /* Drop case-insensitive matches */
  cxiDropSambaDCacheEntry(cnP);

xerror:
  putCred(&eCred, &eCredP);

  PRINTINODE(iP);
  PRINTDENTRY(dentryP);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_RMDIR_EXIT,
         "gpfs_i_rmdir exit: diP 0x%lX iP 0x%lX rc %d\n", diP, iP, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

#ifdef NEW_MODE_TYPE
int
gpfs_i_mknod(struct inode *diP, struct dentry *dentryP, umode_t mode, dev_t rdev)
#else
int
gpfs_i_mknod(struct inode *diP, struct dentry *dentryP, int mode, dev_t rdev)
#endif
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *dcnP;
  cxiNode_t *cnP;
  cxiIno_t iNum = (cxiIno_t)INVALID_INODE_NUMBER;
  struct inode *newInodeP = NULL;
  cxiMode_t umask = get_umask();
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiDev32_t rdev32;

  VFS_STAT_START(mknodCall);
  ENTER(0);
  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_MKNOD_ENTER,
         "gpfs_i_mknod enter: diP 0x%lX mode 0x%X rdev 0x%X name '%s'\n",
         diP, mode, (int)rdev, dentryP->d_name.name);
  /* BKL is held at entry */

  dcnP = VP_TO_CNP(diP);
  privVfsP = VP_TO_PVP(diP);
  LOGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    d_drop(dentryP);
    goto xerror;
  }

  rdev32 = cxiDevToDev32(rdev);
  rc = gpfs_ops.gpfsMknod(privVfsP, NULL, dcnP, (void **)&newInodeP, &cnP,
                          &iNum, dentryP, (char *)dentryP->d_name.name,
                          IS_CASE_SENSITIVE(), mode, umask, (cxiDev_t)rdev32, 
                          eCredP);
  if (rc == 0)
  {
    DBGASSERT(cnP != NULL);
    DBGASSERT(iNum != INVALID_INODE_NUMBER);
    DBGASSERT(newInodeP != NULL);
    DBGASSERT(newInodeP->PRVINODE == cnP);
    DBGASSERT(cnP->osNodeP == (void *)newInodeP);
  }
  else
  {
    d_drop(dentryP);
    goto xerror;
  }
#ifdef  HAS_S_DIRT
  diP->i_sb->s_dirt = 1;
#endif

  /* Device inodes should be new and not show any residual dev fields */

  if (S_ISFIFO(newInodeP->i_mode))
    LOGASSERTRC(newInodeP->i_pipe == NULL, PTR_TO_INT32(newInodeP),
                PTR_TO_INT32(newInodeP->i_pipe), 0);
  else if (S_ISBLK(newInodeP->i_mode))
    LOGASSERTRC(newInodeP->i_bdev == NULL, PTR_TO_INT32(newInodeP),
                PTR_TO_INT32(newInodeP->i_bdev), 0);
  else if (S_ISCHR(newInodeP->i_mode))
    LOGASSERTRC(newInodeP->i_cdev == NULL, PTR_TO_INT32(newInodeP),
                PTR_TO_INT32(newInodeP->i_cdev), 0);

  /* Set vector table for special files, gpfs will not get these operations.*/
  init_special_inode(newInodeP, newInodeP->i_mode, newInodeP->i_rdev);

xerror:
  putCred(&eCred, &eCredP);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_MKNOD_EXIT,
         "gpfs_i_mknod exit: new inode 0x%lX iNum %lld (0x%llX) rc %d\n",
         newInodeP, iNum, iNum, rc);
  
  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_rename(struct inode *diP, struct dentry *dentryP,
              struct inode *tdiP, struct dentry *tDentryP)
{
  int rc = 0;
  struct inode *iP = dentryP->d_inode;
  struct inode *tiP = tDentryP->d_inode;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *sourceCNP, *sourceDirCNP, *targetCNP, *targetDirCNP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
#if LINUX_KERNEL_VERSION > 2060000
  struct dentry *dentry;
  Boolean disconnectedDentries = false;
#endif

  
  VFS_STAT_START(renameCall);
  ENTER(0);
  TRACE6(TRACE_VNODE, 1, TRCID_LINUXOPS_RENAME_1,
         "gpfs_i_rename enter: iP 0x%lX dvP 0x%lX name '%s'"
         " tiP 0x%lX tdiP 0x%lX new name '%s'\n",
         iP, diP, dentryP->d_name.name, tiP, tdiP, tDentryP->d_name.name);
  /* BKL is held at entry */

  /* Do not allow simple rename across mount points */
  if (diP->i_sb != tdiP->i_sb)
  {
    rc = EXDEV;
    goto xerror;
  }

  sourceCNP = VP_TO_CNP(iP);
  sourceDirCNP = VP_TO_CNP(diP);

  targetCNP = (tiP != NULL) ? VP_TO_CNP(tiP) : NULL;
  targetDirCNP = VP_TO_CNP(tdiP);

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  rc = gpfs_ops.gpfsRename(privVfsP, sourceCNP, sourceDirCNP,
                           (char *)dentryP->d_name.name, targetCNP,
                           targetDirCNP, (char *)tDentryP->d_name.name,
                           IS_CASE_SENSITIVE(), true, eCredP);
  if (rc == 0)
  {
    gpfs_i_getattr_internal(iP);
    gpfs_i_getattr_internal(diP);

    if (tiP)
      gpfs_i_getattr_internal(tiP);

    if (tdiP != diP)
      gpfs_i_getattr_internal(tdiP);

#ifdef  HAS_S_DIRT
    diP->i_sb->s_dirt = 1;
#endif
  }

xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_RENAME_EXIT,
         "gpfs_i_rename exit: iP 0x%lX rc %d\n", iP, rc);

#if LINUX_KERNEL_VERSION > 2060000
  /* Prune dcache if needed (see explanations in gpfs_i_unlink).
     Note that renaming a file on top of an existing file results
     in a delete of the target file/inode...just as if it had
     been unlinked. */

  if (tiP)
  {
    /* Traverse the list looking for disconnected dentries. */
#ifdef DCACHE_LOCK_IS_GONE
    spin_lock(&tiP->i_lock);
#else
    spin_lock(&dcache_lock);
#endif
    LIST_FOR_I_DENTRY(dentry, &tiP->i_dentry, d_alias)
    {
#ifdef DCACHE_LOCK_IS_GONE
      spin_lock(&dentry->d_lock);
#endif

      TRACE4N(TRACE_VNODE, 3, TRCID_LINUXOPS_RENAME_DENTRY,
             "gpfs_i_rename: tiP 0x%lX dentry 0x%lX d_flags 0x%lX d_count %d",
              tiP, dentry, dentry->d_flags, GET_DENTRY_D_COUNT(dentry));

      if (dentry->d_flags & DCACHE_DISCONNECTED)
      {
        disconnectedDentries = true;
        DENTRY_DROP(dentry);
#ifdef DCACHE_LOCK_IS_GONE
        spin_unlock(&dentry->d_lock);
#endif
        break;
      }
#ifdef DCACHE_LOCK_IS_GONE
      spin_unlock(&dentry->d_lock);
#endif
    }

#ifdef DCACHE_LOCK_IS_GONE
    spin_unlock(&tiP->i_lock);
#else
    spin_unlock(&dcache_lock);
#endif

    /* prune any unheld dentries pointing at the inode */
    if (disconnectedDentries)
      d_prune_aliases(tiP);
  }
#endif

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_readlink(struct dentry *dentryP, char *bufP, int buflen)
{
  int rc = 0;
  Boolean gotBKL = false;
  struct cxiUio_t tmpUio;
  cxiIovec_t tmpIovec;
  struct inode *iP = dentryP->d_inode;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  
  VFS_STAT_START(readlinkCall);
  ENTER(0);
  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_READLINK_ENTER,
         "gpfs_i_readlink enter: dentryP 0x%lX bufP 0x%lX len %d "
           "iP 0x%lX name '%s'\n",
         dentryP, bufP, buflen, iP, dentryP->d_name.name);

  /* BKL is not held at entry, except for NFS calls */
  TraceBKL();
  if (CURRENT_LOCK_DEPTH >= 0)  /* kernel lock is held by me */
  {
    gotBKL = true;
    UNLOCK_KERNEL();
  }

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);

  tmpIovec.iov_base = bufP;          /* base memory address                   */
  tmpIovec.iov_len = buflen;         /* length of transfer for this area      */

  tmpUio.uio_iov = &tmpIovec;        /* ptr to array of iovec structs         */
  tmpUio.uio_iovcnt = 1;             /* #iovec elements left to be processed  */
  tmpUio.uio_iovdcnt = 0;            /* #iovec elements already processed     */
  tmpUio.uio_offset = 0;             /* byte offset in file/dev to read/write */
  tmpUio.uio_resid = buflen;         /* #bytes left in data area              */
  tmpUio.uio_segflg = UIO_USERSPACE; /* copy to user space buffer             */
  tmpUio.uio_fmode = 0;              /* file modes from open file struct      */

  rc = gpfs_ops.gpfsReadlink(privVfsP, cnP, &tmpUio, vnOp, NULL);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_READLINK_EXIT,
        "gpfs_i_readlink exit: iP 0x%lX uio_resid %ld offset %d rc %d\n",
         iP, tmpUio.uio_resid, tmpUio.uio_offset, rc);

  VFS_STAT_STOP;

  if (gotBKL)        /* If held kernel lock on entry then reacquire it */
    LOCK_KERNEL();

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  EXIT(0);
  if (rc)
    return (-rc);

  return (buflen - tmpUio.uio_resid);
}

#if LINUX_KERNEL_VERSION >= 2061600
void* gpfs_i_follow_link(struct dentry *dentry, struct nameidata *nd)
#else
int gpfs_i_follow_link(struct dentry *dentry, struct nameidata *nd)
#endif
{
  int rc;
  Boolean gotBKL = false;
  struct cxiUio_t tmpUio;
  cxiIovec_t tmpIovec;
  struct inode *iP = dentry->d_inode;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  char *buf = NULL;
  int bufLen = CXI_PATH_MAX + 1;

  ENTER(0);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_FOLLOW_LINK_ENTER,
         "gpfs_i_follow_link enter: inode 0x%lX name '%s'\n",
         dentry->d_inode, dentry->d_name.name);

  /* BKL is not held at entry, except for NFS calls */
  TraceBKL();
  if (CURRENT_LOCK_DEPTH >= 0)  /* kernel lock is held by me */
  {
    gotBKL = true;
    UNLOCK_KERNEL();
  }

  /* Allocate a temporary buffer to hold the symlink contents */
  buf = cxiMallocPinned(bufLen);
  if (buf == NULL)
  {
    rc = -ENOMEM;
    goto xerror;
  }

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);

  tmpIovec.iov_base = buf;          /* base memory address                   */
  tmpIovec.iov_len = bufLen;        /* length of transfer for this area      */

  tmpUio.uio_iov = &tmpIovec;       /* ptr to array of iovec structs         */
  tmpUio.uio_iovcnt = 1;            /* #iovec elements left to be processed  */
  tmpUio.uio_iovdcnt = 0;           /* #iovec elements already processed     */
  tmpUio.uio_offset = 0;            /* byte offset in file/dev to read/write */
  tmpUio.uio_resid = bufLen;        /* #bytes left in data area              */
  tmpUio.uio_segflg = UIO_SYSSPACE; /* copy to kernel space buffer           */
  tmpUio.uio_fmode = 0;             /* file modes from open file struct      */

  /* Read symlink contents */
  rc = gpfs_ops.gpfsReadlink(privVfsP, cnP, &tmpUio, vnOp, NULL);
  if (rc)
  {
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);
    rc = -rc;
    if (!IS_ERR((void *)(long)rc)) /* just for sure rc not exceeding Linux err range */
      rc = -ESTALE;
    goto xerror;
  }
  
  /* set end of string */
  buf[bufLen - MAX(tmpUio.uio_resid, 1)] = 0;

  TRACE2(TRACE_VNODE, 2, TRCID_LINUXOPS_FOLLOW_LINK_1,
         "gpfs_i_follow_link readlink rc %d data '%s'\n", rc, buf);

  VFS_FOLLOW_LINK(rc, nd, buf);

xerror:
  if (buf)
    cxiFreePinned(buf);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_FOLLOW_LINK_2,
         "gpfs_i_follow_link exit: inode 0x%lX rc %d\n",
         dentry->d_inode, rc);

  if (gotBKL)        /* If held kernel lock on entry then reacquire it */
    LOCK_KERNEL();

  EXIT(0);

#if LINUX_KERNEL_VERSION >= 2061600
  return ERR_PTR(rc); /* return proper err code (D.909232) */
#else
  return rc;
#endif
}

#ifdef HAS_IOP_PUT_LINK

#if LINUX_KERNEL_VERSION >= 2061600
void gpfs_i_put_link(struct dentry *dentry, struct nameidata *nd, void* cookie)
#else
void gpfs_i_put_link(struct dentry *dentry, struct nameidata *nd)
#endif
{
  char *buf = nd_get_link(nd);
  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_PUTLINK,
        "gpfs_i_put_link dentry 0x%lX nd 0x%lX buf 0x%lX\n", dentry, nd, 
        !IS_ERR(buf)? buf : NULL);
  if (!IS_ERR(buf))
     cxiFreePinned(buf);
}

#endif /* HAS_IOP_PUT_LINK */

int
gpfs_i_bmap(struct inode *iP, int fragment)
{
  ENTER(0);
  TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_BMAP,
         "gpfs_i_bmap: rc ENOSYS\n");
  TraceBKL();
  EXIT(0);
  return -ENOSYS;
}

void
gpfs_i_truncate(struct inode *iP)
{
  ENTER(0);
  /* Nothing to do since the file size was updated on the notify_change
   * call which preceeded this call
   */
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_TRUNCATE,
         "gpfs_i_truncate: inode 0x%lX\n", iP);
  TraceBKL();
  EXIT(0);
}

#ifdef ENABLE_IMMUTABLE_FILES
int gpfs_check_immutable_nfs(struct inode *iP, int mode, Boolean isACL)
{
  int rc = 0;
  int possibleWrite = false;
  cxiNode_t *cnP;
  cnP = VP_TO_CNP(iP);

  /* disallow write for immutable and appendOnly files from NFS */
  TRACE3(TRACE_VNODE, 4, TRCID_LINUXOPS_PERMISSION_IMMUTABLE,
         "gpfs_permission_checkimmutable:, flags 0x%lx, xinfo 0x%lx, isACL %d",
	  mode, cnP->xinfo, isACL);
  if (!isACL)
    possibleWrite = (mode & MAY_WRITE) || (mode & MAY_APPEND);
  else
    possibleWrite = mode & ACL_PERM_WRITE;

  if (possibleWrite &&
      ((cnP->xinfo & VA_ISIMMUTABLE) || (cnP->xinfo & VA_ISAPPENDONLY)))
    rc = EROFS;
  return rc;
}
#endif /*ENABLE_IMMUTABLE_FILES*/

#if LINUX_KERNEL_VERSION >= 2061000

int
/* struct inode *iP, int reqMode, unsigned int flags, struct nameidata *ni */
gpfs_i_permission_noacl(INODE_OPS_PERMISSION_PARAMETERS)
{
  int rc = 0;

#ifdef RCU_WALK_FOR_PATH_LOOKUP
#if LINUX_KERNEL_VERSION >= 3010000
  if (reqMode & MAY_NOT_BLOCK)
#else
  if (flags & IPERM_FLAG_RCU)
#endif
    return -ECHILD;
#endif

  ENTER(0);

#ifdef ENABLE_IMMUTABLE_FILES
  if (cxiIsNFSThread())
    rc = gpfs_check_immutable_nfs(iP, reqMode, false);
#endif  
  /* Linux generic_permission can resolve with the mode.
     No check_acl callback is required since this operation is never
     used for files that have ACLs. */
   
  EXIT(0);
  if (rc == 0)
  {
    /* The "cifsBypassTraversalChecking" configuration parameter allows 
       anything that appears to be a Samba thread to have universal
       search permission. */

    if ((reqMode & ACL_PERM_EXECUTE) && S_ISDIR(iP->i_mode) &&
        gpfs_ops.gpfsIsCifsBypassTraversalChecking() && cxiIsSambaThread())
    {
      TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_ACCESS_NOACL_CIFS_BYPASS,
             "gpfs_i_permission_noacl: cifsBypassTraversalChecking allows search permission (iP 0x%X ino %d i_mode 0x%X mode 0x%X)", 
              iP, iP->i_ino, iP->i_mode, reqMode);

      reqMode &= ~ACL_PERM_EXECUTE;

      if (reqMode == 0)
        return 0;
    }

    return LINUX_GENERIC_PERMISSION(iP, reqMode, flags, NULL);
  }
  else
    return -rc;
}
#endif

int
/* struct inode *iP, int reqMode, unsigned int flags, struct nameidata *ni */
gpfs_i_permission(INODE_OPS_PERMISSION_PARAMETERS)
{
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  int mode;
  int rc = 0;
  VFS_STAT_DECL;

#ifdef RCU_WALK_FOR_PATH_LOOKUP
#if LINUX_KERNEL_VERSION >= 3010000
  if (reqMode & MAY_NOT_BLOCK)
#else
  if (flags & IPERM_FLAG_RCU)
#endif
    return -ECHILD;
#endif

  VFS_STAT_START_NODECL(accessCall);
  ENTER(0);

  /* BKL is held at entry */

  cnP = VP_TO_CNP(iP);

  TRACE6(TRACE_VNODE, 1, TRCID_LINUXOPS_ACCESS_ENTER,
         "gpfs_i_permission enter: iP 0x%lX mode 0x%X uid %d gid %d "
         "i_mode 0x%X i_xinfo 0x%X", iP, reqMode, FROM_KUID(CRED(current, fsuid)),
         FROM_KGID(CRED(current, fsgid)), iP->i_mode, cnP->xinfo);

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);

  /* SLES11 defines mode flags  beyond the read/write/execute that
     we support.  Masking these out here since our ACL will never
     grant these extended permissions causing even read/write/execute
     attempts to fail as they are combined with the other unexpected
     bits. */

  mode = reqMode & (ACL_PERM_EXECUTE|ACL_PERM_WRITE|ACL_PERM_READ);
#ifdef ENABLE_IMMUTABLE_FILES
  if (mode && cxiIsNFSThread())
    rc = gpfs_check_immutable_nfs(iP, mode, true);
  if (rc)
    goto xerror1;
#endif  
 
  if (mode)        /* call permission check only if got access mode */
  {
    /* The "cifsBypassTraversalChecking" configuration parameter allows 
       anything that appears to us to be a Samba thread to have universal
       search permission.  If that is the only access requested, short-cut
       the normal ACL checking right here. */

    if (((mode & ACL_PERM_EXECUTE) == mode) && S_ISDIR(iP->i_mode) &&
        gpfs_ops.gpfsIsCifsBypassTraversalChecking() && cxiIsSambaThread())
    {
      TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_ACCESS_CIFS_BYPASS,
             "gpfs_i_permission: cifsBypassTraversalChecking allows search permission\n");
      goto xerror;
    }

    rc = getCred(&eCred, &eCredP);
    if (rc)
      goto xerror;

    rc = gpfs_ops.gpfsAccess(privVfsP, cnP, mode, ACC_SELF, 
                             NULL, NULL, eCredP);
  }

xerror:
  putCred(&eCred, &eCredP);

xerror1:
  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_ACCESS_EXIT,
         "gpfs_i_permission exit: iP 0x%lX std %d dir std %d rc %d",
         iP, iP->i_op == &gpfs_iops_stdperm, iP->i_op == &gpfs_dir_iops_stdperm,
         rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_smap(struct inode *iP, int sector)
{
  ENTER(0);
  TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_SMAP,
         "gpfs_i_smap: rc ENOSYS\n");
  TraceBKL();
  EXIT(0);
  return -ENOSYS;
}

int
gpfs_i_updatepage(struct file *fP, struct page *pageP, const char *bufP,
                  unsigned long offset, uint count, int sync)
{
  ENTER(0);
  TRACE0(TRACE_VNODE, 1, TRCID_LINUXOPS_UPDATEPAGE,
         "gpfs_i_updatepage: rc ENOSYS\n");
  TraceBKL();
  EXIT(0);
  return -ENOSYS;
}

int
gpfs_i_revalidate(struct dentry *dentryP)
{
  int rc;
  int code = 0;
  struct inode *iP = dentryP->d_inode;
  cxiNode_t *cnP;
  cxiVattr_t vattr;
  struct gpfsVfsData_t *privVfsP = NULL;

  ENTER(0);
  VFS_INC(revalidateCount);
  TRACE4(TRACE_VNODE, 2, TRCID_LINUXOPS_REVALIDATE_ENTER,
         "gpfs_i_revalidate enter: dentryP 0x%lX iP 0x%lX ino 0x%X name '%s'\n",
         dentryP, dentryP->d_inode, 
         (iP) ? iP->i_ino : INVALID_INODE_NUMBER,  dentryP->d_name.name);
  /* BKL is usually not held, but seems to be held when coming here as
     part of setting an ACL */

  if (iP == NULL)
  {
    code = 1;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  if (!cnP)
  {
    /* This can happen due to a bug in linux/fs/dcache.c (prune_dcache)
       where "count" entries are to be pruned, but the last one is
       found to be recently referenced.  When this happens, count is
       decremented, but the loop is not terminated.  The result is that
       it continues to prune entries past where it should (prunes
       everything).  If our patch for this is not applied, the result
       is a kernel failure as the cxiNode is referenced.  Checking
       here (and lookup) allows us to reject the call instead. */
      
    TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_REVALIDATE_STALE,
           "gpfs_i_revalidate: cxiNode for iP 0x%lX (ino %lld) was FREED!\n",
           iP, iP->i_ino);

    /* Although we may like to know more about this inode, it is not
     * ok to call PRINTINODE(iP) here.
     */

    rc = ESTALE;
    code = 2;
    goto xerror;
  }

#ifdef GPFS_CACHE
  /* Must revalidate periodically for pcache files */
  if ((cnP->icValid & CXI_IC_STAT) == CXI_IC_STAT &&
      !TestCtFlag(cnP, revalidateNeeded))
#else
  if ((cnP->icValid & CXI_IC_STAT) == CXI_IC_STAT)
#endif
  {
    rc = 0;
    code = 3;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);

  /* This has the effect of calling us back under a lock and 
   * setting the inode attributes at the OS level (since this 
   * operating system caches this info in the vfs layer)
   */
  rc = gpfs_ops.gpfsGetattr(privVfsP, cnP, &vattr, GETATTR_PERM_OK);
  PRINTINODE(iP);

#if 0
  /* Delay briefly to give token revoke races a chance to happen, if there
     are any.  Time delay is in jiffies (10ms). */
#  define howLong 5
  TRACE1(TRACE_VNODE, 4, TRCID_REVAL_DELAY,
         "gpfs_i_revalidate: begin delay %d\n", howLong);
  current->state = TASK_INTERRUPTIBLE;
  schedule_timeout(howLong);
  TRACE1(TRACE_VNODE, 14, TRCID_REVAL_DELAY_END,
         "gpfs_i_revalidate: end delay %d\n", howLong);
#endif

xerror:
  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_REVALIDATE_EXIT,
         "gpfs_i_revalidate exit: dentry 0x%lX code %d rc %d\n",
         dentryP, code, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  EXIT(0);
  return -rc;
}

int
gpfs_i_setattr(struct dentry *dentryP, struct iattr *iattrP)
{
  int rc;

  VFS_STAT_START(setattrCall);
  ENTER(0);
  rc = gpfs_i_setattr_internal(dentryP->d_inode, iattrP);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
gpfs_i_setattr_internal(struct inode *iP, struct iattr *aP)
{
  int rc = 0;
  int code = 0;
  long arg1;      /* must be large enough on 64bit to contain */
  long arg2;      /*   either a pointer or integer            */
  long arg3;
  cxiTimeStruc_t atime, mtime, ctime, ttime;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  unsigned int ia_valid;
  Boolean sync_it = false;

  ENTER(0);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_SETATTR_ENTER,
         "gpfs_i_setattr enter: iP 0x%lX ia_valid 0x%X\n", iP, aP->ia_valid);
  /* ?? Callers of this are inconsistent about whether the BKL is held */

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);

  ia_valid = aP->ia_valid;

  /* Change file size */
  if (ia_valid & ATTR_SIZE)
  {
    arg1 = (long)&aP->ia_size;
    arg2 = 0;
    arg3 = 0;

    /* call gpfsSetattr, unless we know that new size is the same */
    if (!(cnP->icValid & CXI_IC_ATTR) ||
        ((struct inode *)cnP->osNodeP)->i_size != aP->ia_size)
    {
      rc = getCred(&eCred, &eCredP);
      if (rc)
      {
        code = 6;
        goto xerror;
      }

      rc = gpfs_ops.gpfsSetattr(privVfsP, NULL, cnP, V_SIZE, arg1, arg2, arg3,
                                eCredP);
      if (rc != 0)
      {
        code = 1;
        goto xerror;
      }
      sync_it = true;

      /* gpfsSetattr(... V_SIZE ...) will have updated ctime and mtime.
         No need to do this again. */
      ia_valid &= ~(ATTR_MTIME | ATTR_CTIME);
    }
  }

  /* Change file mode */
  if (ia_valid & ATTR_MODE)
  {
    arg1 = (long)aP->ia_mode;
    arg2 = 0; /* do not force setid changes */
    arg3 = 0;

    if (iP->i_mode == aP->ia_mode && cnP &&            /* same mode */
        ((cnP->icValid & CXI_IC_STAT) == CXI_IC_STAT)) /* attr are vaild */
    {
      /* no need to update */
    }
    else 
    {
#if defined(REDHAT_RHEL55) || (LINUX_KERNEL_VERSION >= 2063200)

      /* ATTR_FORCE flag is defined as of 2.6.32, but also ported to RHEL55 (2.6.18-194.el5) */ 
      if (aP->ia_valid & ATTR_FORCE)
      {
        int forceCode = 0;

        /* Verify our understanding of the rules associated with the Linux VFS
           use of the ATTR_FORCE flag.  In any case where it appears to be used
           in a way that we do not anticipate, it is just ignored (defaulting
           to the semantics that existed prior to its coming into existence). */

        if (!(aP->ia_valid & ATTR_MODE))
          forceCode &= 0x1;  /* ATTR_FORCE specified without ATTR_MODE! */

        if (!(aP->ia_valid & ATTR_FILE))
          forceCode &= 0x2;  /* ATTR_FORCE specified without ATTR_FILE! */

        if (!(aP->ia_valid & ATTR_SIZE))
          forceCode &= 0x4;  /* ATTR_FORCE specified without ATTR_SIZE! */

        if ((!(aP->ia_valid & ATTR_KILL_SUID)) && 
            (!(aP->ia_valid & ATTR_KILL_SGID)))
          forceCode &= 0x8;  /* ATTR_FORCE without either ATTR_KILL_SUID or ATTR_KILL_SGID! */

        if ((cnP->icValid & CXI_IC_STAT) == CXI_IC_STAT)
        {
          if (!(iP->i_mode & S_ISUID) && !(iP->i_mode & S_ISGID))
            forceCode &= 0x10;  /* attempt to clear non-existent SETID/SETGID bit! */

          if ((iP->i_mode & ~(S_ISUID|S_ISGID)) != aP->ia_mode)
            forceCode &= 0x20;  /* non-setid changes are included! */
        }

        TRACE6(TRACE_VNODE, 2, TRCID_LINUXOPS_SETATTR_FORCE,
               "gpfs_i_setattr_internal: ATTR_FORCE code 0x%X uid %d gid %d ia_valid 0x%X ia_mode 0x%X i_mode 0x%X\n", 
               forceCode, FROM_KUID(CRED(current, fsuid)), FROM_KGID(CRED(current, fsgid)), aP->ia_valid, aP->ia_mode, iP->i_mode);

        /* If anything is not copasetic, ignore the ATTR_FORCE flag (revert to previous behavior) */
        arg2 = (Boolean)!forceCode;
      }
#endif /* ATTR_FORCE flag is defined */

      rc = getCred(&eCred, &eCredP); // rebuild since gpfsSetattr may remap ids
      if (rc)
      {
        code = 7;
        goto xerror;
      }

      rc = gpfs_ops.gpfsSetattr(privVfsP, NULL, cnP, V_MODE, arg1, arg2, arg3, eCredP);
      if (rc != 0)
      {
        code = 2;
        goto xerror;
      }
      sync_it = true;
    }
  }

  /* Change uid or gid */
  if (ia_valid & (ATTR_UID | ATTR_GID))
  {
    arg1 = 0;
    arg2 = 0;
    arg3 = 0;

    if (ia_valid & ATTR_UID)
      arg2 = (long)FROM_KUID(aP->ia_uid);
    else
      arg1 |= T_OWNER_AS_IS;

    if (ia_valid & ATTR_GID)
      arg3 = (long)FROM_KGID(aP->ia_gid);
    else
      arg1 |= T_GROUP_AS_IS;

    rc = getCred(&eCred, &eCredP); // rebuild since gpfsSetattr may remap ids
    if (rc)
    {
      code = 8;
      goto xerror;
    }

    rc = gpfs_ops.gpfsSetattr(privVfsP, NULL, cnP, V_OWN, arg1, arg2, arg3, eCredP);
    if (rc != 0)
    {
      code = 3;
      goto xerror;
    }
    sync_it = true;
  }

  /* Change access, modification, or change time */
  if (ia_valid & (ATTR_ATIME | ATTR_MTIME | ATTR_CTIME))
  {
    Boolean diff_time = false;
    arg1 = 0;
    arg2 = 0;
    arg3 = 0;

    if (cnP && ((cnP->icValid & CXI_IC_STAT) == CXI_IC_STAT)) /* attr vaild */
      diff_time = false;
    else
      diff_time = true;

    if (ia_valid & ATTR_CTIME)
    {
      CXITIME_FROM_INODETIME(ctime, aP->ia_ctime);
      arg3 = (long)&ctime;

      if (!diff_time)
      {
        CXITIME_FROM_INODETIME(ttime, iP->i_ctime);
        if (ctime.tv_sec != ttime.tv_sec)
          diff_time = true;
        TRACE5(TRACE_VNODE, 3, TRCID_LINUXOPS_SETATTR_1,
           "gpfs_i_setattr: iP 0x%lX new ctime %lx-%lx ctime %lx-%lx\n",
            iP, ctime.tv_sec, ctime.tv_nsec, ttime.tv_sec, ttime.tv_nsec);
      }
    }
    if (ia_valid & ATTR_ATIME)
    {
      CXITIME_FROM_INODETIME(atime, aP->ia_atime);
      arg1 = (long)&atime;

      if (!diff_time)
      {
        CXITIME_FROM_INODETIME(ttime, iP->i_atime);
        if (atime.tv_sec != ttime.tv_sec)
          diff_time = true;
        TRACE5(TRACE_VNODE, 3, TRCID_LINUXOPS_SETATTR_3,
           "gpfs_i_setattr: iP 0x%lX new atime %lx-%lx atime %lx-%lx\n",
            iP, atime.tv_sec, atime.tv_nsec, ttime.tv_sec, ttime.tv_nsec);
      }
    }
    if (ia_valid & ATTR_MTIME)
    {
      CXITIME_FROM_INODETIME(mtime, aP->ia_mtime);
      arg2 = (long)&mtime;

      if (!diff_time)
      {
        CXITIME_FROM_INODETIME(ttime, iP->i_mtime);
        if (mtime.tv_sec != ttime.tv_sec)
          diff_time = true;
        TRACE5(TRACE_VNODE, 3, TRCID_LINUXOPS_SETATTR_2,
           "gpfs_i_setattr: iP 0x%lX new mtime %lx-%lx mtime %lx-%lx\n",
            iP, mtime.tv_sec, mtime.tv_nsec, ttime.tv_sec, ttime.tv_nsec);
      }
    }
    if (diff_time)
    {
      rc = getCred(&eCred, &eCredP); // rebuild since gpfsSetattr may remap ids
      if (rc)
      {
        code = 9;
        goto xerror;
      }

      if (ia_valid & (ATTR_ATIME_SET|ATTR_MTIME_SET))
      {
        arg3 = 0;
        rc = gpfs_ops.gpfsSetattr(privVfsP, NULL, cnP, V_UTIME, arg1, arg2, arg3, eCredP);
                                                         /* ignore the ctime */
      }
      else
      {
        rc = gpfs_ops.gpfsSetattr(privVfsP, NULL, cnP, V_STIME, arg1, arg2, arg3, eCredP);
      }

      if (rc != 0)
      {
        code = 4;
        goto xerror;
      }
      sync_it = true;
    }
  }

xerror:
  putCred(&eCred, &eCredP);

  if (rc == 0)
  {
    /* For NFS we might need to write the inode but the check will be done 
     * in gpfsSyncNFS(). 
     */
    if (cxiAllowNFSFsync() && sync_it)
    {
      rc = getCred(&eCred, &eCredP); // rebuild since gpfsSetattr may remap ids
      if (rc)
        code = 10;
      else
      {
        rc = gpfs_ops.gpfsSyncNFS(privVfsP, cnP, 0, eCredP);
        putCred(&eCred, &eCredP);
      }
    }

#ifdef  HAS_S_DIRT
    iP->i_sb->s_dirt = 1;
#endif
  }
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_SETATTR_EXIT,
         "gpfs_i_setattr exit: iP 0x%lX code %d rc %d\n", iP, code, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  EXIT(0);
  return rc;
}

int
gpfs_i_getattr(struct vfsmount *mntP, struct dentry *dentryP, 
               struct kstat *kstatP)
{
  int rc;
  struct inode *iP = dentryP->d_inode;
  cxiNode_t *cnP;

  VFS_STAT_START(getattrCall);
  ENTER(0);

  cnP = VP_TO_CNP(iP);

  if (cnP && ((cnP->icValid & CXI_IC_STAT) == CXI_IC_STAT)) /* attr are vaild */
    rc = 0;
  else
    rc = gpfs_i_getattr_internal(iP);

  if (!rc)
  {
    generic_fillattr(iP, kstatP);
    kstatP->blksize = GET_INODE_BLOCKSIZE(iP);
  }
  else
    rc = -rc;

  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}

int
gpfs_i_getattr_internal(struct inode *iP)
{
  int rc = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiVattr_t vattr;

  ENTER(0);
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_GETATTR_ENTER,
         "gpfs_i_getattr enter: iP 0x%lX\n", iP);
  /* BKL is held at entry */

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  /* This has the effect of calling us back under a lock and 
   * setting the inode attributes at the OS level (since this 
   * operating system caches this info in the vfs layer)
   */
  rc = gpfs_ops.gpfsGetattr(privVfsP, cnP, &vattr, 0);
  PRINTINODE(iP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_GETATTR_EXIT,
         "gpfs_i_getattr exit: iP 0x%lX rc %d\n", iP, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  EXIT(0);
  return rc;
}

/* Define extended attribute namespaces that are allowed on linux.
   Note: These are a subset of all gpfs EA namespaces
   Changes must also be made in the GPFS namespace superset */
#define LINUX_XATTR_SECURITY_PREFIX "security."
#define LINUX_XATTR_TRUSTED_PREFIX "trusted."
#define LINUX_XATTR_USER_PREFIX "user."
#define LINUX_XATTR_SYSTEM_PREFIX "system."
#define LINUX_XATTR_NAME_ACL_ACCESS	"system.posix_acl_access"
#define LINUX_XATTR_NAME_ACL_DEFAULT	"system.posix_acl_default"
#define LINUX_XATTR_NAME_ACL_NFS4 "system.nfs4_acl"
#ifdef FASTEA
#define LINUX_XATTR_ARCHIVE_PREFIX "archive."
#endif


static const char *
test_prefix(const char *name, const char *prefix)
{
  while (*prefix && *name == *prefix) {
    name++;
    prefix++;
  }
  return *prefix ? NULL : name;
}

/*
 * Inode operation getxattr()
 *
 */
ssize_t
gpfs_i_getxattr(struct dentry *dentry, const char *name, void *buf,
                size_t buf_size)
{
  int rc;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct tsxattr xattr;
  struct tsxattrs xattrs;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  void *argP = &xattrs;
  int flags = 0;
  struct inode *iP = dentry->d_inode;
  mm_segment_t oldfs;
  const char *n;
  Boolean nonBlocking = false;
  Boolean forLSM = false;

  VFS_STAT_DECL;
  ENTER(0);
  VFS_STAT_START_NODECL(getxattrCall);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_GETEXTATTR_ENTER,
         "gpfs_i_getxattr enter: iP 0x%lX name %s buf 0x%lX size %d\n",
         iP, (name) ? name : "NULL", buf, buf_size);

  if (iP == NULL)
  {
    rc = ENOENT;
    goto xerror;
  }

  /* Handle POSIX access ACL */
  if (strcmp(name, LINUX_XATTR_NAME_ACL_ACCESS) == 0)
  {
#ifndef CONFIG_FS_POSIX_ACL
    rc = EOPNOTSUPP;
    goto xerror;
#else
    rc = gpfs_get_posix_acl(dentry, ACL_TYPE_ACCESS, buf, buf_size);

    /* GPFS uses ENOSPC when the caller's buffer is too small, but
       getxattr callers expect ERANGE, so translate here.  When received,
       Linux will then make a call with buf==NULL and buf_size==0 to
       obtain the required size (positive rc here will be the size).  */
    if (rc == -ENOSPC)
      rc = -ERANGE;

    goto xerror2;
#endif
  }

  /* Handle POSIX default ACL */
  if (strcmp(name, LINUX_XATTR_NAME_ACL_DEFAULT) == 0) 
  {
#ifndef CONFIG_FS_POSIX_ACL
    rc = EOPNOTSUPP;
    goto xerror;
#else
    if (S_ISDIR(iP->i_mode))
    {
      rc = gpfs_get_posix_acl(dentry, ACL_TYPE_DEFAULT, buf, buf_size);

      /* GPFS uses ENOSPC when the caller's buffer is too small, but
         getxattr callers expect ERANGE, so translate here.  When received,
         Linux will then make a call with buf==NULL and buf_size==0 to
         obtain the required size (positive rc here will be the size).  */
      if (rc == -ENOSPC)
        rc = -ERANGE;
    }
    else
      rc = -ENODATA;

    goto xerror2;
#endif
  }

  /* Deny NFSv4 ACL that is called from nfs4_getfacl */
  if (strcmp(name, LINUX_XATTR_NAME_ACL_NFS4) == 0) 
  {
    rc = EOPNOTSUPP;
    goto xerror;
  }

  if (n = test_prefix(name, LINUX_XATTR_SECURITY_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    nonBlocking = true;
    forLSM = true;
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_TRUSTED_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_SYSTEM_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_USER_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    goto xattr;
  }
#ifdef FASTEA
  /* Archive namespace must have admin capability */
  if (n = test_prefix(name, LINUX_XATTR_ARCHIVE_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
#endif

  rc = EOPNOTSUPP;
  goto xerror;

xattr:

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

#ifdef DISKEA
  /* External attributes should not have been stored in the
     GPFS internal application space. Uniquely identify them
     to account for their space correctly. */
  xattrs.appId = 4;       // application id GPFS_ATTR_EXT_NAMESPACE_ID
#else
  xattrs.appId = 3;       // application id GPFS_ATTR_INTERNAL_APPL_ID
#endif
  xattrs.nattrs = 1;      // no of attributes to get or set
  xattrs.attrs = &xattr;  // attributes to get or set

  xattr.keyP = (char*) name;        // attribute key
  xattr.keyLen = strlen(name) + 1;  // key length
  xattr.valueP = buf;               // attribute value
  xattr.valueLen = buf_size;        // length of attribute value

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  oldfs = get_fs();
  set_fs(get_ds());

  rc = gpfs_ops.gpfsGetOrListXattr(privVfsP, cnP, GET_XATTR, argP, eCredP,
                                   nonBlocking);

  set_fs(oldfs);
  if (!rc)
  {
    TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_GETEXTATTR_EXIT0,
           "gpfs_i_getxattr exit: iP 0x%lX len %d\n", iP, xattr.valueLen);
    VFS_STAT_STOP;
    EXIT(0);
    if (xattr.valueLen < 0)
      rc = ENODATA;
    else
    {
      putCred(&eCred, &eCredP);
      return (xattr.valueLen);
    }
  }

xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_GETEXTATTR_EXIT,
         "gpfs_i_getxattr exit: iP 0x%lX rc %d\n", iP, rc);

  /* D829674: if getxattr was called for a security EA, we should return
     -ENODATA instead of -ESTALE. Otherwise, it will print annoying 
     message in dmesg */
  if (forLSM && rc == ESTALE)
    rc = ENODATA;

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENODATA);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);

xerror2:
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_GETEXTATTR_EXIT2,
         "gpfs_i_getxattr exit2: iP 0x%lX rc %d\n", iP, rc);

  /* xerror2 is given a positive rc to indicate a length, and a negative
     errno on failures.  Only make the cxiErrorNFS call for the errors,
     and in those cases pass it the positive errno it expects. */
  if (rc<0) {
    int rc2;
    rc2 = cxiErrorNFS(rc, privVfsP, rc);
    if (rc2 == -EUNATCH || rc2 == EUNATCH)
      rc = -EUNATCH;
  }
  VFS_STAT_STOP;
  EXIT(0);
  return (rc);
}

/*
 * Inode operation setxattr()
 *
 */
int
gpfs_i_setxattr(struct dentry *dentry, const char *name, const void *buf,
                size_t buf_size, int ext_flags)
{
  int rc;
  int op_flag = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct tsxattr xattr;
  struct tsxattrs xattrs;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  void *argP = &xattrs;
  struct inode *iP = dentry->d_inode;
  mm_segment_t oldfs;
  const char *n;

  VFS_STAT_DECL;
  ENTER(0);
  VFS_STAT_START_NODECL(setxattrCall);

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_SETEXTATTR_ENTER,
         "gpfs_i_setxattr enter: iP 0x%lX name %s buf 0x%lX size %d flags 0x%X\n",
         iP, (name) ? name : "NULL", buf, buf_size, ext_flags);

  if (iP == NULL)
  {
    rc = ENOENT;
    goto xerror;
  }

  /* Handle POSIX access ACL */
  if (strcmp(name, LINUX_XATTR_NAME_ACL_ACCESS) == 0)
  {
#ifndef CONFIG_FS_POSIX_ACL
    rc = EOPNOTSUPP;
#else
    if ((!UID_EQ(CRED(current, fsuid), iP->i_uid)) && !capable(CAP_FOWNER))
      return -EPERM;
    rc = gpfs_set_posix_acl(dentry, ACL_TYPE_ACCESS, buf, buf_size);
#endif
    goto xerror;
  }

  /* Handle POSIX default ACL */
  if (strcmp(name, LINUX_XATTR_NAME_ACL_DEFAULT) == 0)
  {
#ifndef CONFIG_FS_POSIX_ACL
    rc = EOPNOTSUPP;
#else
    if (S_ISDIR(iP->i_mode))
    {
      if ((!UID_EQ(CRED(current, fsuid), iP->i_uid)) && !capable(CAP_FOWNER))
        return -EPERM;
      rc = gpfs_set_posix_acl(dentry, ACL_TYPE_DEFAULT, buf, buf_size);
    }
    else
      rc = EPERM;

#endif
    goto xerror;
  }

  /* Deny setting NFSv4 ACL through nfs4_setfacl */
  if (strcmp(name, LINUX_XATTR_NAME_ACL_NFS4) == 0)
  {
    rc = EOPNOTSUPP;
    goto xerror;
  }

  if (n = test_prefix(name, LINUX_XATTR_SECURITY_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_TRUSTED_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_SYSTEM_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_USER_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    goto xattr;
  }
#ifdef FASTEA
  /* Archive namespace must have admin capability */
  if (n = test_prefix(name, LINUX_XATTR_ARCHIVE_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
#endif

  rc = EOPNOTSUPP;
  goto xerror;

xattr:

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

#ifdef DISKEA
  /* External attributes should not have been stored in the
     GPFS internal application space. Uniquely identify them
     to account for their space correctly. */
  xattrs.appId = 4;       // application id GPFS_ATTR_EXT_NAMESPACE_ID
#else
  xattrs.appId = 3;       // application id GPFS_ATTR_INTERNAL_APPL_ID
#endif
  xattrs.nattrs = 1;      // no of attributes to get or set
  xattrs.attrs = &xattr;  // attributes to get or set

  xattr.keyP = (char*) name;            // attribute key
  xattr.keyLen = strlen(name) + 1;      // key length (stores '\0' with key)
  xattr.valueP = (char *)buf;           // attribute value
  xattr.valueLen = buf_size;            // length of attribute value

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  oldfs = get_fs();
  set_fs(get_ds());

  if (ext_flags == XATTR_CREATE)
    op_flag = GPFS_XATTR_CREATE;
  else if (ext_flags == XATTR_REPLACE)
    op_flag = GPFS_XATTR_REPLACE;

  rc = gpfs_ops.gpfsSetXattr(privVfsP, cnP, op_flag, argP, eCredP);
  set_fs(oldfs);
xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_SETEXTATTR_EXIT,
         "gpfs_i_setxattr exit: iP 0x%lX rc %d\n", iP, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}


static Boolean
listAttr(const char *nameP, Boolean isDir)
{
  /* Only return the attribute names if the caller can obtain the value */
#ifdef CONFIG_FS_POSIX_ACL
  if (strcmp(nameP, LINUX_XATTR_NAME_ACL_ACCESS) == 0)
    return true;
  if ((strcmp(nameP, LINUX_XATTR_NAME_ACL_DEFAULT) == 0) &&
      isDir)
    return true;
#endif
  if (test_prefix(nameP, LINUX_XATTR_SECURITY_PREFIX))
    return true;
  if ((test_prefix(nameP, LINUX_XATTR_TRUSTED_PREFIX)) &&
      (capable(CAP_SYS_ADMIN)))
    return true;
  if ((test_prefix(nameP, LINUX_XATTR_SYSTEM_PREFIX)) &&
      (capable(CAP_SYS_ADMIN)))
    return true;
  if (test_prefix(nameP, LINUX_XATTR_USER_PREFIX))
    return true;
#ifdef FASTEA
  /* Archive namespace must have admin capability */
  if ((test_prefix(nameP, LINUX_XATTR_ARCHIVE_PREFIX)) &&
      (capable(CAP_SYS_ADMIN)))
    return true;
#endif
  return false;
}

/*
 * Inode operation listxattr()
 *
 * Copy a list of attribute names into the buffer
 * provided, or compute the buffer size required.
 * Buffer is NULL to compute the size of the buffer required.
 *
 * Returns a negative error number on failure, or the number of bytes
 * used / required on success.
 */
ssize_t
gpfs_i_listxattr(struct dentry *dentry, char *buf, size_t buf_size)
{
  int rc;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct tsxattr xattr;
  struct tsxattrs xattrs;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  void *argP = &xattrs;
  struct inode *iP = dentry->d_inode;
  mm_segment_t oldfs;
  char *bufP = NULL;
  char *scanP, *nameP, *nextP, *endP;
  Boolean isDir;
  int bufLen = 0;
  char *ubuf;
  size_t ubif_size;
 
  VFS_STAT_DECL;
  ENTER(0);
  VFS_STAT_START_NODECL(listxattrCall);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_LIST_XATTR_IN,
         "gpfs_i_listxattr enter: iP 0x%lX buf 0x%lX buf_size %d\n",
          iP, buf, buf_size);

  if (iP == NULL)
  {
    rc = ENOENT;
    goto xerror;
  }
  isDir = S_ISDIR(iP->i_mode);

  if (buf_size > CXI_ATTR_MAX)
  {
    rc = EINVAL;
    goto xerror;
  }

  bufLen = CXI_ATTR_MAX;
  bufP = cxiMallocPinned(CXI_ATTR_MAX);
  if (bufP == NULL)
  {
    rc = ENOMEM;
    goto xerror;
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

#ifdef DISKEA
  /* External attributes should not have been stored in the
     GPFS internal application space. Uniquely identify them
     to account for their space correctly. */
  xattrs.appId = 4;       // application id GPFS_ATTR_EXT_NAMESPACE_ID
#else
  xattrs.appId = 3;       // application id GPFS_ATTR_INTERNAL_APPL_ID
#endif
  xattrs.nattrs = 0;      // get all attribute name
  xattrs.attrs = &xattr;  // attributes to get or set

  xattr.keyP = NULL;            // attribute key
  xattr.keyLen = 0;             // key length
  xattr.valueP = bufP;          // attribute value
  xattr.valueLen = bufLen;      // length of attribute value

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  oldfs = get_fs();
  set_fs(get_ds());

  /* Collect all attribute names */
  rc = gpfs_ops.gpfsGetOrListXattr(privVfsP, cnP, LIST_XATTR, argP, eCredP,
                                   false);

  set_fs(oldfs);
  if (rc != 0)
    goto xerror;

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_LISTXTATTR_FILTER,
        "gpfs_i_listxattr orig len %d", xattr.valueLen);
  
  /* Only return names that the caller can read via getxattr */
  nameP = bufP;
  endP = bufP + xattr.valueLen;
  bufLen = 0;
  
  while (nameP < endP)
  {
    nextP = cxiStrchr(nameP, '\0');
    if (nextP == NULL)
      break;
    nextP += 1;
    if (nextP > endP)
      break;
    
    /* Check if the caller can obtain the value */
    if (listAttr(nameP, isDir))
    {
      TRACE2(TRACE_VNODE, 5, TRCID_LINUXOPS_LISTXTATTR_RETURN,
            "gpfs_i_listxattr return nameP %s at offset %d", nameP, bufLen);
      
      /* repack buffer to only contain valid names */
      if (nameP != &bufP[bufLen])
        cxiStrcpy(&bufP[bufLen], nameP);
      bufLen += (nextP - nameP);
    } 
    else
    {
      TRACE2(TRACE_VNODE, 7, TRCID_LINUXOPS_LISTXTATTR_SKIP,
            "gpfs_i_listxattr skip nameP %s at offset %d", nameP, bufLen);
    }
    
    /* Advance to next name in original buffer */
    nameP = nextP;
  }
  
  /* Check if caller provided a large enough buffer */
  if (bufLen > buf_size)
  {
    if (buf_size != 0)          /* no error if buf_size == 0 */
    {
        rc = ERANGE;
        goto xerror;
    }
  }
  else if (bufLen > 0)
  {
    /* Return buffer to caller */
    cxiMemcpy(buf, bufP, bufLen);
  }

xerror:
  putCred(&eCred, &eCredP);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_LISTXTATTR_EXIT,
        "gpfs_i_listxattr exit: iP 0x%lX bufLen %d rc %d",
        iP, bufLen, rc);

  /* On success, return length of buffer
     Return negative number on failure */
  if (rc == 0)
    rc = bufLen;
  else
  {
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);
    rc = -rc;
  }

  if (bufP)
    cxiFreePinned(bufP);

  VFS_STAT_STOP;
  EXIT(0);
  return (rc);
}

/*
 * Inode operation removexattr()
 *
 */
int
gpfs_i_removexattr(struct dentry *dentry, const char *name)
{
  int rc;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct tsxattr xattr;
  struct tsxattrs xattrs;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  void *argP = &xattrs;
  int flags = 0;
  struct inode *iP = dentry->d_inode;
  mm_segment_t oldfs;
  const char *n;

  VFS_STAT_DECL;
  ENTER(0);
  VFS_STAT_START_NODECL(removexattrCall);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_REMOVEXATTR_IN,
         "gpfs_i_removexattr enter: iP 0x%lX name %s\n", iP, (name) ? name : "NULL");

  if (iP == NULL)
  {
    rc = ENOENT;
    goto xerror;
  }
#ifdef CONFIG_FS_POSIX_ACL
  if (strcmp(name, LINUX_XATTR_NAME_ACL_ACCESS) == 0) {
    if ((!UID_EQ(CRED(current, fsuid), iP->i_uid)) && !capable(CAP_FOWNER))
      return -EPERM;
    rc = gpfs_set_posix_acl(dentry, ACL_TYPE_ACCESS, NULL, -1);
    goto xerror;
  }
  if (S_ISDIR(iP->i_mode))
  {
    if (strcmp(name, LINUX_XATTR_NAME_ACL_DEFAULT) == 0) {
      if ((!UID_EQ(CRED(current, fsuid), iP->i_uid)) && !capable(CAP_FOWNER))
        return -EPERM;
      rc = gpfs_set_posix_acl(dentry, ACL_TYPE_DEFAULT, NULL, -1);
      goto xerror;
    }
  }
#endif
  if (n = test_prefix(name, LINUX_XATTR_SECURITY_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_TRUSTED_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_SYSTEM_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
  if (n = test_prefix(name, LINUX_XATTR_USER_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    goto xattr;
  }
#ifdef FASTEA
  /* Archive namespace must have admin capability */
  if (n = test_prefix(name, LINUX_XATTR_ARCHIVE_PREFIX)) {
    if (n && (strcmp(n, "") == 0)) {
      rc = EINVAL;
      goto xerror;
    }
    if (!capable(CAP_SYS_ADMIN)) {
      rc = EPERM;
      goto xerror;
    }
    goto xattr;
  }
#endif

  rc = EOPNOTSUPP;
  goto xerror;

xattr:

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

#ifdef DISKEA
  /* External attributes should not have been stored in the
     GPFS internal application space. Uniquely identify them
     to account for their space correctly. */
  xattrs.appId = 4;       // application id GPFS_ATTR_EXT_NAMESPACE_ID
#else
  xattrs.appId = 3;       // application id GPFS_ATTR_INTERNAL_APPL_ID
#endif
  xattrs.nattrs = 1;      // no of attributes to get or set
  xattrs.attrs = &xattr;  // attributes to delete

  xattr.keyP = (char*) name;            // attribute key
  xattr.keyLen = strlen(name) + 1;      // key length
  xattr.valueP = NULL;                  // attribute value
  xattr.valueLen = -1;                  // length < zero means delete

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  oldfs = get_fs();
  set_fs(get_ds());

  rc = gpfs_ops.gpfsSetXattr(privVfsP, cnP, flags, argP, eCredP);
  set_fs(oldfs);

xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_REMOVEXATTR_EXIT,
         "gpfs_i_removexattr exit: iP 0x%lX rc %d\n", iP, rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, ENOENT);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}

int cxiInitInodeSecurity(void *dP, void *vP,
                         char **secattrPrefixPP, char **secattrSuffixPP,
                         void **secattrValuePP, size_t *secattrValueLenP)
{
  int rc = EOPNOTSUPP;
#ifdef CONFIG_SECURITY
  struct dentry *dentryP = (struct dentry *)dP;
  struct inode *iP = (struct inode *)vP, *parentP;

  ENTER(0);
  /* We need a valid parent inode to compute the new security context */
  if (dentryP->d_parent == NULL)
  {
    rc = EINVAL;
    goto exit;
  }

  parentP = dentryP->d_parent->d_inode;

  if (parentP == NULL)
  {
    rc = EINVAL;
    goto exit;
  }

  /* This computes and sets an inode's i_security field */
  rc = SECURITY_INODE_INIT_SECURITY(iP, parentP, &dentryP->d_name,
                                    secattrSuffixPP, secattrValuePP,
                                    secattrValueLenP);
  if (rc != 0)
    goto exit;

  *secattrPrefixPP = LINUX_XATTR_SECURITY_PREFIX;

exit:
  TRACE3(TRACE_VNODE, 4, TRCID_CXIINITINODESEC_EXIT,
         "cxiInitInodeSecurity: dP 0x%lX iP 0x%lX rc %d",
         dP, iP, rc);
  EXIT(0);
#endif
  if (rc < 0)
    rc = -rc;

  return rc;
}

void cxiInitInodeSecurityCleanup(char* secattrSuffix, void *secattrValue)
{
#ifndef CONSTANT_NAME_OF_INODE_INIT_SECURITY
  kfree(secattrSuffix);
#endif
  kfree(secattrValue);
}

Boolean cxiIsLSMEnabled(void)
{
  u32 secid = 0;

#ifdef CONFIG_SECURITY
#ifndef SUSE_LINUX
  security_task_getsecid(current, &secid);
#endif
#endif

  return (secid != 0);
}

/* Function to allocate and deallocate file space. */
long gpfs_i_fallocate(struct inode *iP, int mode, loff_t offset, loff_t len)
{
  int rc = 0;
  int code = 0, flags;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;

  ENTER(0);
  TRACE4(TRACE_VNODE, 3, TRCID_LINUXOPS_FALLOC_ENTER,
         "gpfs_i_fallocate enter: iP 0x%lX mode %d offset %ld len %ld",
          iP, mode, offset, len);

  if (mode & FALLOC_FL_KEEP_SIZE)
  {
    code = 1;
    rc = -EOPNOTSUPP;
    goto xerror;
  }
  flags = FWRITE;

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 3;
    goto xerror;
  }
  if (mode & FALLOC_FL_PUNCH_HOLE)
  {
    rc = gpfs_ops.gpfsFclear(privVfsP, cnP, flags, offset, len, NULL,
                             eCredP);
  }
  else if (mode == 0)
  {
     rc = gpfs_ops.gpfsFalloc(privVfsP, cnP, flags, offset, len, mode, NULL,
                              eCredP);
  }
  else {
    code = 5;
    rc = -EOPNOTSUPP;
  }
  putCred(&eCred, &eCredP);

xerror:
  TRACE3(TRACE_VNODE, 3, TRCID_LINUXOPS_FALLOC_EXIT,
         "gpfs_i_fallocate exit: iP 0x%lX rc %d code %d",
          iP, rc, code);

  if (rc > 0)
    rc = -rc;
  EXIT(0);
  return rc;
}

