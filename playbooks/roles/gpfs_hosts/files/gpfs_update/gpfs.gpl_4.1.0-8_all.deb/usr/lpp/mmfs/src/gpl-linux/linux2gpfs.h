/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)02       1.144.1.1  src/avs/fs/mmfs/ts/kernext/gpl-linux/linux2gpfs.h, mmfs, avs_rfks1, rfks1s007a_addw 12/16/14 14:23:44 */
#ifndef _h_linux2gpfs
#define _h_linux2gpfs

#include <cxiTypes.h>
#include <Logger-gpl.h>

#ifdef __cplusplus
#include <prelinux.h>
#endif

#include <linux/kdev_t.h>
#include <linux/fs.h>
#if (LINUX_KERNEL_VERSION >= 2062400)
#include <linux/exportfs.h>
#endif

#ifdef __cplusplus
#include <postlinux.h>
#endif
#include <cxiSystem.h>
#include <verdep.h>
#ifdef GANESHA
#include <gpfs_fcntl.h>
#include <gpfs_nfs.h>
#endif

#ifdef NTRACE
#define PRINTINODE(i)  ((void)0)
#define PRINTDENTRY(d) ((void)0)
#define PRINTSBLOCK(s) ((void)0)
#define PRINTFILE(f)   ((void)0)
#else
#define PRINTINODE(i)  printInode(i)
#define PRINTDENTRY(d) printDentry(d)
#define PRINTSBLOCK(s) printSblock(s)
#define PRINTFILE(f)   printFile(f)
#endif

/* check if inode belongs to GPFS */
#define GPFS_TYPE(IP) (!(IP) ? false : \
                        (!(IP->i_sb) ? false : \
                          (!(IP->i_sb->s_type) ? false : \
                            !strcmp(IP->i_sb->s_type->name, "gpfs"))))


/* forward declarations */
struct ext_cred_t;
struct dentry;
struct super_block;
struct file;
struct nameidata;
struct page;
struct iattr;
struct inode;
struct vm_area_struct;

#ifdef GANESHA
int gpfs_layout_type(struct super_block *sbP);
int gpfs_get_deviceinfo(struct super_block *sbP,
                        struct gpfs_exp_xdr_stream *xdr,
                        u32 layout_type,
                        const struct nfsd4_pnfs_deviceid *devid);
int gpfs_get_deviceiter(struct super_block *sbP, u32 layout_type,
                        struct nfsd4_pnfs_dev_iter_res *iterP);
int gpfs_layout_get(struct inode *iP, struct gpfs_exp_xdr_stream *xdr,
                    const struct nfsd4_pnfs_layoutget_arg *args,
                    struct nfsd4_pnfs_layoutget_res *res);
int gpfs_layout_return(struct inode *iP,
                       const struct nfsd4_pnfs_layoutreturn_arg *lrp);

int gpfs_inode_update(struct gpfsVfsData_t *privVfsP);
#endif // GANESHA

/* inode.C */
#ifdef __cplusplus
extern "C"
{
#endif
  int getCred(struct ext_cred_t *, struct ext_cred_t **);
  void putCred(struct ext_cred_t *, struct ext_cred_t **);

#ifdef NAMEIDATA_REPLACED
  int gpfs_i_create(struct inode *, struct dentry *, umode_t, bool);
#elif defined(NEW_MODE_TYPE)
  int gpfs_i_create(struct inode *, struct dentry *, umode_t, struct nameidata *);
#else
  int gpfs_i_create(struct inode *, struct dentry *, int, struct nameidata *);
#endif

#ifdef NAMEIDATA_REPLACED
  struct dentry *gpfs_i_lookup(struct inode *, struct dentry *, unsigned int);
#else
  struct dentry *gpfs_i_lookup(struct inode *, struct dentry *, struct nameidata *);
#endif
  int gpfs_i_link(struct dentry *, struct inode *, struct dentry *);
  int gpfs_i_relink(struct dentry *, struct inode *, struct dentry *);
  int gpfs_i_link_common(struct dentry *, struct inode *, struct dentry *, Boolean);
  int gpfs_i_unlink(struct inode *, struct dentry *);
  int gpfs_i_symlink(struct inode *, struct dentry *, const char *);
#ifdef NEW_MODE_TYPE
  int gpfs_i_mkdir(struct inode *, struct dentry *, umode_t);
#else
  int gpfs_i_mkdir(struct inode *, struct dentry *, int);
#endif
  int gpfs_i_rmdir(struct inode *, struct dentry *);
#ifdef NEW_MODE_TYPE
  int gpfs_i_mknod(struct inode *, struct dentry *, umode_t, dev_t);
#else
  int gpfs_i_mknod(struct inode *, struct dentry *, int, dev_t);
#endif
  int gpfs_i_rename(struct inode *, struct dentry *, struct inode *,
                    struct dentry *);
  int gpfs_i_readlink(struct dentry *, char *, int);
#if LINUX_KERNEL_VERSION >= 2061600
  void* gpfs_i_follow_link(struct dentry *dentry, struct nameidata *nd);
#else
  int gpfs_i_follow_link(struct dentry *dentry, struct nameidata *nd);
#endif
  int gpfs_i_readpage(struct file *, struct page *);
  int gpfs_i_writepage(struct page *pageP, struct writeback_control *wbcP);
  int gpfs_i_bmap(struct inode *, int);
  void gpfs_i_truncate(struct inode *);
  int gpfs_i_permission(INODE_OPS_PERMISSION_PARAMETERS);
  int gpfs_i_smap(struct inode *, int);
  int gpfs_i_updatepage(struct file *, struct page *, const char *,
                        unsigned long, uint, int);
  int gpfs_i_revalidate(struct dentry *);
  int gpfs_i_setattr(struct dentry *, struct iattr *);
  int gpfs_i_getattr(struct vfsmount *mnt, struct dentry *, struct kstat *);
  long gpfs_i_fallocate(struct inode *iP, int mode, loff_t offset, loff_t len);

  int gpfs_i_setxattr(struct dentry *, const char *, const void *, size_t, int);
  ssize_t gpfs_i_getxattr(struct dentry *, const char *, void *, size_t);
  ssize_t gpfs_i_listxattr(struct dentry *, char *, size_t);
  int gpfs_i_removexattr(struct dentry *, const char *);
  int gpfs_set_posix_acl(struct dentry *, int, const void *, size_t);
  int gpfs_get_posix_acl(struct dentry *, int, const void *, size_t);

  int gpfs_i_getattr_internal(struct inode *iP);
  int gpfs_i_setattr_internal(struct inode *iP, struct iattr *aP);
  void printInode(struct inode *);
  void printDentry(struct dentry *);
  void printDentryTree(struct dentry *, int maxPrint);
  void setIopTable(struct inode *iP, Boolean xperm);
  void printSuper(struct super_block *sbP);
  void printSuperList(struct super_block *sbP);

#ifdef HAS_IOP_PUT_LINK
#if LINUX_KERNEL_VERSION >= 2061600
void gpfs_i_put_link(struct dentry *dentry, struct nameidata *nd, void* cookie);
#else
void gpfs_i_put_link(struct dentry *dentry, struct nameidata *nd);
#endif
#endif

#ifdef __cplusplus
}
#endif

/* file.C */
#ifdef __cplusplus
extern "C"
{
#endif
  loff_t gpfs_f_llseek(struct file *, loff_t, int);
  ssize_t gpfs_f_read(struct file *, char *, size_t, loff_t *);
  ssize_t gpfs_f_dir_read(struct file *, char *, size_t, loff_t *);
  ssize_t gpfs_f_write(struct file *, const char *, size_t, loff_t *);
#if LINUX_KERNEL_VERSION < 2061900
  ssize_t gpfs_f_aio_read(struct kiocb *, char *, size_t, loff_t);
  ssize_t gpfs_f_aio_write(struct kiocb *, const char *, size_t, loff_t);
#else
  ssize_t gpfs_f_aio_read(struct kiocb *, const struct iovec *, unsigned long, loff_t);
  ssize_t gpfs_f_aio_write(struct kiocb *, const struct iovec *, unsigned long, loff_t);
#endif
#ifdef HAS_READDIR
  int gpfs_f_readdir(struct file *, void *, filldir_t);
#else
  int gpfs_f_readdir(struct file *fP, struct dir_context *ctx);
#endif
  uint gpfs_f_poll(struct file *, struct poll_table_struct *);
#ifdef HAVE_UNLOCKED_IOCTL
  long gpfs_f_unlocked_ioctl(struct file *, uint, unsigned long);
#endif
  int gpfs_f_ioctl(struct inode *, struct file *, uint, unsigned long);
  int gpfs_f_mmap(struct file *, struct vm_area_struct *);
  int gpfs_f_open(struct inode *, struct file *);
  int gpfs_f_release(struct inode *, struct file *);
  int gpfs_f_fsync(FILE_OPS_FSYNC_PARAMETERS);
  int gpfs_f_fasync(int, struct file *, int);
  int gpfs_f_lock(struct file *, int, struct file_lock *);
  int gpfs_f_set_lease(struct file *, long, struct file_lock **);
  int __gpfs_f_set_lease(struct file *, long, struct file_lock **);
  int gpfs_f_flock(struct file *, int, struct file_lock *);
  ssize_t gpfs_f_readv(struct file *, const struct iovec *, unsigned long,
                   loff_t *);
  ssize_t gpfs_f_writev(struct file *, const struct iovec *, unsigned long,
                    loff_t *);
  int gpfs_f_cleanup(struct inode *iP, struct file *fP);
#if LINUX_KERNEL_VERSION >= 2062600
  int gpfs_filemap_fault(struct vm_area_struct *area, struct vm_fault *vmf);
#else
#if LINUX_KERNEL_VERSION > 2060300
  struct page *gpfs_filemap_nopage(struct vm_area_struct * area,
                                 unsigned long address, int *no_share);
#else
  struct page *gpfs_filemap_nopage(struct vm_area_struct * area,
                                 unsigned long address, int no_share);
#endif
#endif
  void gpfs_filemap_close(struct vm_area_struct * area);
  void gpfs_filemap_open(struct vm_area_struct * area);
  int gpfs_f_share(struct file *, unsigned int, unsigned int);
  long gpfs_f_fallocate(struct file *, int, loff_t, loff_t);
#ifdef DIRECT_IO_HAS_IOV_ITER
  ssize_t gpfs_f_direct_IO(int rw, struct kiocb *iocb, struct iov_iter *iterP,
                           loff_t in_offset);
#else
  ssize_t gpfs_f_direct_IO(int rw, struct kiocb *iocb, const struct iovec *iovecP,
                           loff_t offset, unsigned long count);
#endif

  int aioComplete(struct cxiUioAio_t *uioaioP, size_t bytesProcessed,
                  int mbAioErr, Boolean mbAioCallback);

#ifdef __cplusplus
}
#endif

/* super.C */
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef VERBOSETRACE
  void TraceBKL();
#else
#define TraceBKL() ((void)0)
#endif
  void gpfs_s_read_inode(struct inode *);
  void gpfs_s_read_inode2(struct inode *, void *);
  void gpfs_s_delete_inode(struct inode *);
#if (LINUX_KERNEL_VERSION >= 2063600)
  void gpfs_s_evict_inode(struct inode *);
#endif
  int gpfs_s_notify_change(struct dentry *, struct iattr *);
  void gpfs_s_put_super(struct super_block *);
#if defined(STATFS_USES_DENTRY) || LINUX_KERNEL_VERSION > 2061700 || \
      (defined(CONFIG_SLE_VERSION) && CONFIG_SLE_VERSION == 10 && CONFIG_SLE_SP == 2)
  int gpfs_s_statfs(struct dentry *, struct kstatfs *);
#else
  int gpfs_s_statfs(struct super_block *, struct kstatfs *);
#endif
  void gpfs_destory_inodecache(void);
  int gpfs_init_inodecache(void);
  struct inode *gpfs_alloc_inode(struct super_block *);
  void gpfs_destroy_inode(struct inode *);
#if LINUX_KERNEL_VERSION >= 2063600
  int gpfs_s_drop_inode(struct inode *);
#else
  void gpfs_s_drop_inode(struct inode *);
#endif
#if LINUX_KERNEL_VERSION >= 2061700 && LINUX_KERNEL_VERSION < 2062600
  void gpfs_s_umount_begin(struct vfsmount *, int);
#else
  void gpfs_s_umount_begin(struct super_block *);
#endif
  int gpfs_s_remount(struct super_block *, int *, char *);
#if (LINUX_KERNEL_VERSION >= 2062400)
  struct dentry * (*fh_to_dentry)(struct super_block *sb, struct fid *fid,
                                  int fh_len, int fh_type);
  struct dentry * (*fh_to_parent)(struct super_block *sb, struct fid *fid,
                                  int fh_len, int fh_type);
#endif
  struct dentry *gpfs_decode_fh(struct super_block *sbP, __u32 *fh,
                                int len, int fhtype, 
                                int (*acceptable)(void *context, struct dentry *dentry),
                                void *context);

#ifdef NEW_ENCODE_FH
  int gpfs_encode_fh(struct inode *inode, __u32 *fh, int *lenp, struct inode *parent);
#else
  int gpfs_encode_fh(struct dentry *dentry, __u32 *fh, int *lenp, int need_parent);
#endif

  struct dentry *gpfs_get_dentry(struct super_block *sb, void *data);
  struct dentry *gpfs_get_dparent(struct dentry * dentry);
#if defined(REDHAT_RHEL6) || LINUX_KERNEL_VERSION >= 2063400
  int gpfs_s_write_inode(struct inode *, struct writeback_control *);
#else
  int gpfs_s_write_inode(struct inode *, int);
#endif
  void gpfs_s_clear_inode(struct inode *);
#ifdef HAS_WRITE_SUPER
  void gpfs_s_write_super(struct super_block *);
#endif
#if LINUX_KERNEL_VERSION >= 2063900
  struct dentry *gpfs_mount(struct file_system_type *fsTypeP,
                            int flags, const char *devNameP, void *dataP);
#elif LINUX_KERNEL_VERSION > 2061700
  int gpfs_get_sb(struct file_system_type *fsTypeP,
                                  int flags, const char *devNameP, void *dataP,
                                  struct vfsmount *vfs);
#else
  struct super_block *gpfs_get_sb(struct file_system_type *fsTypeP,
                                  int flags, const char *devNameP, void *dataP);
#endif
  int gpfs_fill_super(struct super_block *, void *, int);
  int mmfsd_release(struct inode *, struct file *);
  int exec_mmfs(void *);
  void kill_mmfsd(void);
  void gpfs_unreg_fs();
  int gpfs_reg_fs();
  int fork_mmfsd();
  int fork_mount_helper(char *data);
#ifdef MUST_DEFINE_SYNCFS
  int gpfs_s_sync_fs(struct super_block *, int);
#endif
#ifdef MUST_USE_BDI
  int initBDI(struct backing_dev_info *, struct super_block *);
  inline void destroyBDI(struct backing_dev_info *bdi);
#endif
#ifdef __cplusplus
}
#endif

/* Find gpfs info from a linux inode. */
#define VP_TO_CNP(VP)  ((struct cxiNode_t *)((VP)->PRVINODE))
#define VP_TO_GNP(VP)  ((gpfsNode_t *)((VP)->PRVINODE))
#define VP_TO_NFSP(VP) ((VP_TO_CNP((struct inode *)(VP))->nfsP))

#define VP_TO_PVP(VP)  ((struct gpfsVfsData_t *)((VP)->i_sb)->s_fs_info)

/* block.C */
#ifdef __cplusplus
extern "C"
{
#endif
  int gpfs_b_open(struct inode *inode, struct file *file);
  int gpfs_b_release(struct inode *inode, struct file *file);
  int gpfs_b_ioctl(struct inode *inode, struct file *file, unsigned p1,
                   unsigned long p2);
  int gpfs_block_init();
  void gpfs_block_clean();

  int gpfs_fb_open(struct inode *inode, struct file *file);
  int gpfs_fb_release(struct inode *inode, struct file *file);
  int gpfs_fb_ioctl(struct inode *inode, struct file *file, unsigned p1,
                    unsigned long p2);
  ssize_t gpfs_fb_read(struct file *file, char *buf, size_t nbytes, 
                       loff_t *ppos);
  ssize_t gpfs_fb_write(struct file *file, const char *buf, size_t nbytes,
                        loff_t *ppos);
#ifdef __cplusplus
}
#endif

/* dir.C */
#ifdef __cplusplus
extern "C"
{
#endif
#ifdef NAMEIDATA_REPLACED
  int gpfs_d_invalid(struct dentry *dentry, unsigned int);
  int gpfs_d_revalidate(struct dentry *dentry, unsigned int);
  int gpfs_d_valid(struct dentry *dentry, unsigned int);
  int gpfs_d_valid_if_Samba(struct dentry *dentry, unsigned int);
  int gpfs_d_invalid_if_Samba(struct dentry *dentry, unsigned int);
#ifdef GPFS_CACHE
  int gpfs_d_pcache(struct dentry *dentry, unsigned int);
#endif
#else /* nameidata still used where LINUX_KERNEL_VERSION < 3060000 */
  int gpfs_d_invalid(struct dentry *dentry, struct nameidata *);
  int gpfs_d_revalidate(struct dentry *dentry, struct nameidata *);
  int gpfs_d_valid(struct dentry *dentry, struct nameidata *);
  int gpfs_d_valid_if_Samba(struct dentry *dentry, struct nameidata *);
  int gpfs_d_invalid_if_Samba(struct dentry *dentry, struct nameidata *);
#ifdef GPFS_CACHE
  int gpfs_d_pcache(struct dentry *dentry, struct nameidata *);
#endif
#endif  /* End of NAMEIDATA_REPLACED */
#ifdef __cplusplus
}
#endif

/* gplInit.C */
#ifdef __cplusplus
extern "C"
{
#endif
  void reset_gpfs_operations();
  void gpfs_clean();
  int  gpfs_init();


#ifdef __cplusplus
}
#endif

/* gpfs operations tables */
extern struct gpfs_operations   gpfs_ops;
extern struct super_operations  gpfs_sops;
extern struct super_operations  null_sops;
extern struct export_operations gpfs_export_ops;

#define gpfs_dops_valid (*(struct dentry_operations*)0)  /* no ops defined */
#if LINUX_KERNEL_VERSION >= 2063000
extern const struct dentry_operations gpfs_dops_ddeletepending;
#else
extern struct dentry_operations gpfs_dops_ddeletepending;
#endif
extern struct dentry_operations gpfs_dops_invalid;
extern struct dentry_operations gpfs_dops_revalidate;
extern struct dentry_operations gpfs_dops_valid_with_reval;
extern struct dentry_operations gpfs_dops_valid_if_Samba;
extern struct dentry_operations gpfs_dops_invalid_if_Samba;
#ifdef GPFS_CACHE
extern struct dentry_operations gpfs_dops_pcache;
#endif
extern struct file_operations gpfs_fops;
extern struct file_operations gpfs_fops_no_sendfile;
#ifdef REDHAT_RHEL53
extern struct file_operations_ext gpfs_fops_ext;
extern struct file_operations_ext gpfs_fops_ext_no_sendfile;
#endif
extern struct file_operations gpfs_dir_fops;
extern struct file_operations gpfs_cleanup_fops;
extern struct inode_operations  gpfs_iops_stdperm;
extern struct inode_operations  gpfs_iops_xperm;
extern struct inode_operations  gpfs_dir_iops_stdperm;
extern struct inode_operations  gpfs_dir_iops_xperm;
extern struct inode_operations  gpfs_link_iops;
extern struct inode_operations  gpfs_special_iops_stdperm;
extern struct inode_operations  gpfs_special_iops_xperm;
extern struct address_space_operations gpfs_aops;
extern struct address_space_operations gpfs_aops_after_inode_delete;
extern struct vm_operations_struct gpfs_vmop;
extern struct file_operations gpfs_cleanup_cifs_fops;
extern struct file_operations gpfs_null_fops;

#endif /* _h_linux2gpfs */
