/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)62       1.80  src/avs/fs/mmfs/ts/kernext/gpl-linux/kdump-kern.c, mmfs, avs_rfks1, rfks1s007a_addw 8/1/14 15:49:31 */
/* Code for program to dump kernel memory that needs to include kernel
   header files. */

/*
 * Contents:
 *   KernInit
 *   GenericGet
 *   GetDentry
 *   FreeDentry
 *   GetInode
 *   GetVFSMount
 *   GetSuperBlock
 *   GetRootSuperBlock
 *   GetPage
 *   GetAddressSpace
 *   GetVMAreaStruct
 *   GetMMStruct
 *   GetTaskStruct
 *   GetTaskStructByPID
 *   P_HEADER
 *   PrintDentry
 *   PrintDentryTree
 *   PrintInode
 *   PrintSuperBlock
 *   PrintPage
 *   PrintAddressSpace
 *   PrintVMAreaStruct
 *   PrintMMStruct
 *   PrintTaskStruct
 *
 */


#include <Shark-gpl.h>
#include <linux/vfs.h>
#include <cxiSystem.h>
#include <verdep.h>
#include <lxtrace.h>

#if LINUX_KERNEL_VERSION < 2061500
#include <linux/config.h>
#else
#if LINUX_KERNEL_VERSION < 2063600
#include <linux/autoconf.h>
#endif
#endif

/* We have to define __SMALL_STACK for s390x kernels with 8K stacks, otherwise
   THREAD_SIZE will be set wrong. Since we use our own build environment we
   have to do this by ourself. */
#if defined(GPFS_ARCH_S390X) && defined(CONFIG_SMALL_STACK)
#  define __SMALL_STACK
#endif

#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/spinlock.h>
#include <linux/dcache.h>
#include <linux/mount.h>
#if LINUX_KERNEL_VERSION >= 2063000
#include <linux/fs_struct.h>
#endif
#include <linux/fs.h>
#include <linux/mm.h>

#include <linux/elf.h>
#include <linux/elfcore.h>
#include <asm/atomic.h>

#include <kdump-kern.h>
#include <kdump.h>



#ifdef NODWARFS
/* Address of header of the list of all super_blocks */
unsigned long super_blocks_addr = 0x103;

/* Address of a task_struct on the list of all tasks */
unsigned long TaskAddress = 0x104;

/* Address of the struct page of the first page in memory */
unsigned long MemMapAddr;

extern unsigned long HighSymbolAddr;

/* Maco for printing some number of spaces */
static char *blanksP =
"                                                                            ";
#define BLANKS(n) (blanksP + strlen(blanksP) - (n))

/* A structure to keep track of listed process or kernel stack addr */
struct pidStackSymbol
{
  unsigned long id;
  int count;
  struct pidStackSymbol *hashNextP;
};

/* A array to keep track of listed process or kernel stack addr,
   to avoid infinite loop in some case of kernel corrupted */
#define PID_STACKADDR_HASH_BUCKETS 1023
struct pidStackSymbol* pidSymbolAnchor[PID_STACKADDR_HASH_BUCKETS];
struct pidStackSymbol* stackSymbolAnchor[PID_STACKADDR_HASH_BUCKETS];

static void InitPidStackAddrAnchor(struct pidStackSymbol* anchor[])
{
  int i = 0;

  for (i = 0; i < PID_STACKADDR_HASH_BUCKETS; i ++)
    anchor[i] = NULL;
}

static void CleanupPidStackAddrAnchor(struct pidStackSymbol* anchor[])
{
  struct pidStackSymbol* p = NULL;
  struct pidStackSymbol* tmp = NULL;
  int i = 0;

  for (i = 0; i < PID_STACKADDR_HASH_BUCKETS; i ++)
  {
    p = anchor[i];
    while (p != NULL)
    {
      tmp = p;
      p = p->hashNextP;
      kFree(tmp);
    }
    anchor[i] = NULL;
  }
}

/* search the array list to get the specified(pid) item */
static struct pidStackSymbol*
GetPidStackAddr(unsigned long pid, struct pidStackSymbol* anchor[])
{
  struct pidStackSymbol* p = NULL;
  int index = pid % PID_STACKADDR_HASH_BUCKETS;

  p = anchor[index];
  while (p != NULL)
  {
    if (p->id == pid)
      break;
    p = p->hashNextP;
  }

  return p;
}

/* add a pidStackAddr item into the array list */
static void AddPidStackAddr(unsigned long pid, struct pidStackSymbol* anchor[])
{
  struct pidStackSymbol* p = NULL;
  int index = pid % PID_STACKADDR_HASH_BUCKETS;

  p = GetPidStackAddr(pid, anchor);
  if (p != NULL)
  {
    p->count ++;
  }
  else
  {
    p = (struct pidStackSymbol*)kMalloc(sizeof(struct pidStackSymbol));
    p->id = pid;
    p->count = 1;
    p->hashNextP = anchor[index];
    anchor[index] = p;
  }
}

/* A structure to keep track of current position when stepping through
   all threads. */
struct threadIter
{
  unsigned long taskAddr, threadAddr;
  struct task_struct *taskP, *threadP;
};


/* initialize thread iterator */
static void tiInit(struct threadIter *ti)
{
  ti->taskAddr = ti->threadAddr = TaskAddress;
  ti->taskP = ti->threadP = GetTaskStruct(ti->taskAddr);
}

unsigned long RESET_KDUMP_REGPARMS GetOffset(int fMap)
{
#if (defined(GPFS_ARCH_X86_64) && LINUX_KERNEL_VERSION >= 2061600 \
    && (defined(SUSE_LINUX) || defined(REDHAT_AS_LINUX) \
        || defined(FEDORA_LINUX) || defined(DEBIAN_LINUX) || defined(UBUNTU_LINUX))) \
    || ((defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)) && LINUX_KERNEL_VERSION >= 2061100)
  /* rw_verify_area does not allow kernel addr range,
     so a read() will fail with EINVAL.  We subtract the base
     base kernel addr here and add it back in the read file op in
     tracelin.c */
  return(GPFS_KERNEL_OFFSET);
#else
  return(0);
#endif
}

/* Free threadIter memory.  If tiNext returns false, then it isn't necessary
   to call this. */
static void tiDone(struct threadIter *ti)
{
  kFree(ti->taskP);
  if (ti->threadP != ti->taskP)
    kFree(ti->threadP);
  ti->taskP = ti->threadP = NULL;  
}


/* Step to next thread in current task.  If no more threads, step to
   next task.  If no more tasks, return false. */
static Boolean tiNext(struct threadIter *ti)
{

#if LINUX_KERNEL_VERSION < 2060900
  unsigned long pidAddr, headAddr, nextAddr;
  struct pid_link *linkP;

  kAssert(ti->taskP != NULL, "ti->taskP is NULL, invalid\n");
  linkP = &ti->threadP->pids[PIDTYPE_TGID];

  pidAddr = (unsigned long) linkP->pidptr;
  headAddr = pidAddr + offsetof(struct pid, task_list);

  nextAddr = (unsigned long) linkP->pid_chain.next;

  if (nextAddr == headAddr)
  {
    struct pid *pidP = GenericGet(pidAddr, sizeof(struct pid), 0);
    nextAddr = (unsigned long) pidP->task_list.next;
    kFree(pidP);
  }
#else
  unsigned long nextAddr;
#if defined(HAS_PIDTYPE_TGID)
  nextAddr = (unsigned long) ti->threadP->pids[PIDTYPE_TGID].pid_list.next;
#else
  nextAddr = (unsigned long) ti->threadP->thread_group.next;
  if (nextAddr)
      ti->threadAddr = nextAddr - offsetof(struct task_struct, thread_group);
#endif
#endif

#if defined(HAS_PIDTYPE_TGID)
  ti->threadAddr = (unsigned long) pid_task((struct list_head *) nextAddr,
                                            PIDTYPE_TGID);
  if (ti->threadAddr != ti->taskAddr)
  {
    if (ti->threadP != ti->taskP)
      kFree(ti->threadP);
    ti->threadP = GetTaskStruct(ti->threadAddr);
  }
  else
  {
    ti->taskAddr = ti->threadAddr = (unsigned long)
      list_entry(ti->taskP->tasks.next, struct task_struct, tasks);
    kFree(ti->taskP);
    if (ti->threadP != ti->taskP)
      kFree(ti->threadP);
    ti->taskP = ti->threadP = (ti->taskAddr == TaskAddress) ?
      NULL : GetTaskStruct(ti->taskAddr);
  }

  return ti->threadP != NULL;
#else
  kAssert(ti->taskP != NULL, "ti->taskP is NULL, invalid\n");
  /* check there're sub-threads in the process */
  if (ti->taskAddr != ti->threadAddr)
  {
    if (ti->threadP != ti->taskP)
      kFree(ti->threadP);
    ti->threadP = GetTaskStruct(ti->threadAddr);
  }
  else
  {
    ti->taskAddr = ti->threadAddr = (unsigned long)
      list_entry(ti->taskP->tasks.next, struct task_struct, tasks);
    kFree(ti->taskP);
    ti->taskP = ti->threadP = (ti->taskAddr == TaskAddress) ?
      NULL : GetTaskStruct(ti->taskAddr);
  }

  return ti->threadP != NULL;
#endif
}

/* Routine to initialize stuff needing access to kernel declarations */
void RESET_KDUMP_REGPARMS KernInit()
{
  struct Symbol* sP;
  int rc;
#ifdef HAS_VMLIST
  struct vm_struct * vmlist;
  struct vm_struct v;
#else
  /* store kernel address of kernel symbol vmap_area_list
     in vmap_area_list_kaddr and store its contents in
     variable vmap_area_list;

     read the vmap_area from vmap_area_list, and store its
     kernel address in va_kaddr, and contents in va */
  struct list_head vmap_area_list;
  struct list_head* vmap_area_list_kaddr;
  struct vmap_area* va_kaddr;
  struct vmap_area va;
#endif
  struct vmStruct* aListP;
  struct vmStruct** prevPP;
  unsigned long highMem;
  unsigned long endAddr = 0;

  /* Set bounds of valid kernel memory */
  sP = LookupSymbolByName("_stext");
  kAssert(sP != 0, "didn't find _stext symbol in file complete.map.latest\n");
  LowKernelAddr = sP->addr;
#if defined(GPFS_ARCH_X86_64)
  LowKernelAddr = PAGE_OFFSET;
#endif

  rc = GetSymbolValue("high_memory", &highMem, sizeof(HighKernelAddr));
  kAssert(rc == 0, "didn't find high_memory symbol in complete.map.latest\n");

  sP = LookupSymbolByName("_end");
#if ((! defined(GPFS_ARCH_X86_64)) || (LINUX_KERNEL_VERSION < 2063100))
  kAssert(sP != 0, "didn't find _end symbol in complete.map.latest\n");
  endAddr = sP->addr;
#endif
#ifdef HAS_VMLIST
  sP = LookupSymbolByName("vmlist");
  kAssert(sP != 0, "didn't find vmlist symbol in complete.map.latest\n");
#else
  sP = LookupSymbolByName("vmap_area_list");
  vmap_area_list_kaddr = (struct list_head *)sP -> addr;
  kAssert(sP != 0, "didn't find vmap_area_list symbol in complete.map.latest\n");
#endif
  if (sP->addr > endAddr)
    endAddr = sP->addr;

  if (endAddr > highMem)
    HighKernelAddr = endAddr;
  else
    HighKernelAddr = highMem;

  if (!isCore)
  {
#ifdef HAS_VMLIST
    /* Traverse vm_struct list in kernel starting at vmlist and build
       corresponding list of vmStructs describing valid kernel addresses */
    rc = GetSymbolValue("vmlist", &vmlist, sizeof(vmlist));
    kAssert(rc == 0, "didn't find vmlist symbol in file complete.map.latest\n");

    vmListHeadP = NULL;
    prevPP = &vmListHeadP;
    while (vmlist != NULL)
    {
      endAddr = (unsigned long)vmlist;
      if (endAddr > HighKernelAddr)
        HighKernelAddr = endAddr;
      rc = ReadKernel((unsigned long)vmlist, &v, sizeof(v), 0);
      kAssert(rc == 0, "failed to read vm area from kernel with vmaddr: 0x%lX\n",
              (unsigned long)vmlist);
      aListP = (struct vmStruct*) kMalloc(sizeof(struct vmStruct));
      kAssert(aListP != NULL, "failed to alloc memory\n");
      DBG(kPrintf("vm_struct addr 0x%lX size %d\n", v.addr, v.size));
      aListP->startAddr = (unsigned long) v.addr;
      aListP->areaLen = (unsigned long) v.size - PAGE_SIZE;
      aListP->nextAreaP = NULL;
      *prevPP = aListP;
      prevPP = &aListP->nextAreaP;
      vmlist = v.next;
    }
#else
    /* Traverse vmap_area list in kernel starting at vmap_area_list and build
       corresponding list of vmStructs describing valid kernel addresses */
    rc = GetSymbolValue("vmap_area_list", &vmap_area_list, sizeof(vmap_area_list));
    kAssert(rc == 0, "didn't find vmap_area_list symbol in file complete.map.latest\n");

    vmListHeadP = NULL;
    prevPP = &vmListHeadP;

    /* make sure vmap_area_list is not empty */
    if (vmap_area_list.next != vmap_area_list_kaddr)
    {
      va_kaddr = list_entry(vmap_area_list.next, typeof(struct vmap_area), list);
      DBG(kPrintf("vmap_area_list_kaddr %llx\n", vmap_area_list_kaddr));
      do
      {
        endAddr = (unsigned long)va_kaddr;
        if (endAddr > HighKernelAddr)
          HighKernelAddr = endAddr;

        rc = ReadKernel((unsigned long)va_kaddr, &va, sizeof(va), 0);
        kAssert(rc == 0, "failed to read vm area from kernel with vmaddr: 0x%lX\n",
               (unsigned long)va_kaddr);

        aListP = (struct vmStruct*) kMalloc(sizeof(struct vmStruct));
        kAssert(aListP != NULL, "failed to alloc memory\n");
        DBG(kPrintf("vm_struct addr 0x%lX size %d\n", va.va_start, va.va_end - va.va_start));
        aListP->startAddr = (unsigned long) va.va_start;
        aListP->areaLen = (unsigned long) va.va_end - va.va_start - PAGE_SIZE;
        aListP->nextAreaP = NULL;
        *prevPP = aListP;
        prevPP = &aListP->nextAreaP;

        /* get kernel address of next vmap_area in the list */
        va_kaddr = list_entry(va.list.next, typeof(struct vmap_area), list);
        DBG(kPrintf("&va.list %llx va.list.next %llx va.list.prev %llx\n", &va.list, va.list.next, va.list.prev));
      } while (va.list.next != vmap_area_list_kaddr);
    }
#endif
  }

  /* Get address of super_blocks, the head of the list of super_blocks
     threaded through the s_list field */
  sP = LookupSymbolByName("super_blocks");
  if (sP != NULL)
    super_blocks_addr = sP->addr;

  /* Get address of a task_struct on the list of all tasks */
  sP = LookupSymbolByName("init_task_union");
  if (sP == NULL)
    sP = LookupSymbolByName("init_task");
  kAssert(sP != NULL,
          "didn't find init_task and init_task_union symbols in file complete.map.latest\n");
  TaskAddress = sP->addr;

  /* Get address of the base of the array of struct pages */
#if !defined(CONFIG_DISCONTIGMEM) && LINUX_KERNEL_VERSION < 2061300 || \
    !defined(CONFIG_NEED_MULTIPLE_NODES) && LINUX_KERNEL_VERSION >= 2061300
  rc = GetSymbolValue("mem_map", &MemMapAddr, sizeof(MemMapAddr));
  kAssert(rc == 0, "didn't find mem_map symbol in complete.map.lastest\n");
#else
  MemMapAddr = 0;
#endif
}


/* Generic get routine for kernel objects.  Mallocs storage of the
   given size, then reads into the malloc'ed storage from the
   kernel address.  Frees the object and returns NULL if the address
   was invalid. */
void* RESET_KDUMP_REGPARMS GenericGet(unsigned long addr, int len, int fMap)
{
  int rc;
  void* p = NULL;

  DBG(kPrintf("GenericGet: addr 0x%lX len %d\n", addr, len));
  if (len == 0)
    return p;

  p = kMalloc(len);
  kAssert(p != NULL, "failed to malloc memory\n");
  rc = ReadKernel(addr, p, len, fMap);
  if (rc != 0)
  {
    kFree(p);
    return NULL;
  }
  return p;
}


/* Read a dentry from the kernel.  Space may need to be allocated for the
   name string. */
void* RESET_KDUMP_REGPARMS GetDentry(unsigned long addr)
{
  struct dentry* dP;
  char* nameP;
  int rc;

  dP = (struct dentry*) GenericGet(addr, sizeof(struct dentry), 0);
  if (dP != NULL)
  {
    if ((dP->d_name.len > 1024) || (dP->d_name.len < 0))
    {
      kFree(dP);
      return NULL;
    }
    else if (dname_external(dP))
      dP->d_name.name = dP->d_iname;
    else
    {
      nameP = (char*) kMalloc(dP->d_name.len+1);
      kAssert(nameP != NULL, "failed to malloc memory\n");
      rc = ReadKernel((unsigned long)dP->d_name.name, nameP, dP->d_name.len+1, 0);
      if (rc != 0)
      {
        kFree(nameP);
        kFree(dP);
        return NULL;
      }
      dP->d_name.name = nameP;
    }
  }
  return dP;
}


/* Free a dentry, including the name string */
void RESET_KDUMP_REGPARMS FreeDentry(void* p)
{
  struct dentry* dP = (struct dentry*) p;

  if (dP == NULL)
    return;
  if (dname_external(dP))
    kFree((void*)dP->d_name.name);
  kFree(dP);
}


/* Read an inode from the kernel */
void* RESET_KDUMP_REGPARMS GetInode(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct inode), 0);
}

/* Read an vfsmount from the kernel */
void* RESET_KDUMP_REGPARMS GetVFSMount(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct vfsmount), 0);
}

/* Read an fs_struct from the kernel */
void* RESET_KDUMP_REGPARMS GetFSStruct(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct fs_struct), 0);
}

/* Read a superblock from the kernel */
void* RESET_KDUMP_REGPARMS GetSuperBlock(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct super_block), 0);
}


/* Read first superblock on the superblock list */
void * 
RESET_KDUMP_REGPARMS GetRootSuperBlock(unsigned long * addrP)
{
  struct list_head *listP;

  listP = (struct list_head *)GenericGet(super_blocks_addr, 
                                         sizeof(struct list_head), 1);
  if (listP == NULL)
  {
    *addrP = 0;
    return NULL;
  }

  if ((unsigned long)listP->next == super_blocks_addr)
  {
    /* super block list is empty */
    *addrP = 0;
    return NULL;
  }

  *addrP = (unsigned long)list_entry(listP->next, struct super_block, s_list);

  return GetSuperBlock(*addrP);
}


/* Read a struct page from the kernel */
void* RESET_KDUMP_REGPARMS GetPage(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct page), 0);
}


/* Read an address_space from the kernel */
void* RESET_KDUMP_REGPARMS GetAddressSpace(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct address_space), 0);
}


/* Read a vm_area_struct from the kernel */
void* RESET_KDUMP_REGPARMS GetVMAreaStruct(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct vm_area_struct), 0);
}


/* Read an mm_struct from the kernel */
void* RESET_KDUMP_REGPARMS GetMMStruct(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct mm_struct), 0);
}


/* Read a task_struct from the kernel */
void* RESET_KDUMP_REGPARMS GetTaskStruct(unsigned long addr)
{
  return GenericGet(addr, sizeof(struct task_struct), addr == TaskAddress?1:0);
}

/* Read a task_struct from the kernel given its pid */
void* RESET_KDUMP_REGPARMS GetTaskStructByPID(unsigned long pid, unsigned long * addrP)
{
  struct threadIter ti;
  struct task_struct *taskP;
  tiInit(&ti);

  do
  {
    if (ti.threadP->pid == pid)
    {
      *addrP = ti.threadAddr;
      taskP = ti.threadP;
      ti.threadP = NULL;
      if (ti.taskP == taskP)
        ti.taskP = NULL;
      tiDone(&ti);
      return taskP;
    }
  } while (tiNext(&ti));

  kErrPrintf("PID %ld not found\n", pid);
  return NULL;
}


/* Print a dentry.  Parameter may be NULL. */
void 
RESET_KDUMP_REGPARMS PrintDentry(void* parm, unsigned long addr)
{
  struct dentry* dP = (struct dentry*) parm;

  if (dP == NULL)
  {
    kErrPrintf("NULL dentry\n");
    return;
  }

  kPrintf("dentry 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "dentry"))
    DumpMemory((char*)dP, sizeof(struct dentry), addr, DUMPMEM_I4);
}


#define FIELD_ADDR(_ptr, _addr, _field) \
  (_addr + (unsigned long)((char *)&(_ptr)->_field - (char *)(_ptr)))

/* Recursively show given dentry and all its descendants */
static void RESET_KDUMP_REGPARMS PrintDentryTreeRecur(struct dentry* dP, unsigned long addr,
                                 unsigned long parentAddr, int level)
{
  char *indent = BLANKS(2*level);
  unsigned long h;
  unsigned long childAddr;
  unsigned long ipAddr;
  struct list_head *listP;
  struct inode *iP = NULL;
  int nMax = 50;

  ipAddr = (unsigned long)dP->d_inode;
  if (ipAddr)
    iP = (struct inode *)GetInode(ipAddr);

  kPrintf("%sdentry 0x%lX: d_inode %lld i_count %d "
         "d_count %d h_next 0x%lX h_pprev 0x%lX d_name \"%s\"\n",
         indent, addr, (iP ? iP->i_ino : 0),
         (iP ? atomic_read(&iP->i_count) : 0), GET_DENTRY_D_COUNT(dP),
         dP->d_hash.next, dP->d_hash.pprev, dP->d_name.name);

  if ((unsigned long)dP->d_parent != parentAddr)
    kErrPrintf("%sbad d_parent dentry 0x%lX !!!\n",
           indent, dP->d_parent);

  /* prevent infinite recursion */
  if (level > 100)
  {
    kErrPrintf("%srecursion too deep !!!\n");
    return;
  }

  h = FIELD_ADDR(dP, addr, d_subdirs);
  listP = dP->d_subdirs.next;
  while ((unsigned long)listP != h)
  {
    childAddr = (unsigned long)list_entry(listP, struct dentry, d_child);
    dP = (struct dentry*)GetDentry(childAddr);
    if (dP == NULL)
    {
      kErrPrintf("%s  could not get dentry 0x%lX !!!\n", indent, 
              childAddr);
      break;
    }
    PrintDentryTreeRecur(dP, childAddr, addr, level + 1);
    listP = dP->d_child.next;

    /* prevent infinite loop */
    nMax--;
    if (nMax == 0)
    {
      kErrPrintf("%s  too many children !!!\n", indent);
      break;
    }
  }
}

/* Show given dentry and all its descendants */
void RESET_KDUMP_REGPARMS PrintDentryTree(void* parm, unsigned long addr)
{
  if (parm == 0)
  {
    kErrPrintf("NULL dentry\n");
    return;
  }
  PrintDentryTreeRecur((struct dentry*)parm, addr, 
                       (unsigned long)(((struct dentry*)parm)->d_parent), 0);
}

void RESET_KDUMP_REGPARMS PrintFSStruct(void *parm, unsigned long addr)
{
  if (parm == NULL)
  {
    kErrPrintf("NULL fs_struct\n");
    return;
  }
  if (DumpMemoryCast(addr, "fs_struct"))
    DumpMemory((char*)parm, sizeof(struct fs_struct), addr, DUMPMEM_I4);
}

void RESET_KDUMP_REGPARMS PrintVFSMount(void *parm, unsigned long addr)
{
  if (parm == NULL)
  {
    kErrPrintf("NULL vfsmount\n");
    return;
  }
  if (DumpMemoryCast(addr, "vfsmount"))
    DumpMemory((char*)parm, sizeof(struct vfsmount), addr, DUMPMEM_I4);
}

#if (LINUX_KERNEL_VERSION < 3030000)
void 
RESET_KDUMP_REGPARMS PrintVFSMountList(void *parm, unsigned long addr)
{
  struct vfsmount *vfsP = (struct vfsmount *)parm;
  struct list_head *listP;
  char *devnameP;
  unsigned long h;
  unsigned long next;
  
  if (vfsP == NULL)
  {
    kErrPrintf("NULL vfsmount\n");
    return;
  }

  devnameP = (char *)GenericGet((unsigned long)vfsP->mnt_devname, 20, 0);
  kPrintf("vfsmount 0x%lX: mnt_devname %20s\n",
         addr, devnameP);

  h = FIELD_ADDR(vfsP, addr, mnt_list);
  listP = vfsP->mnt_list.next;
  while ((unsigned long)listP != h)
  {
    next = (unsigned long)list_entry(listP, struct vfsmount, mnt_list);
    vfsP = (struct vfsmount *)GetVFSMount(next);
    if (vfsP == NULL)
    {
      kErrPrintf("Could not get vfsmount 0x%lX !!!\n", next);
      return;
    }

    devnameP = (char *)GenericGet((unsigned long)vfsP->mnt_devname, 20, 0);
    kPrintf("vfsmount 0x%lX: mnt_devname %20s\n",
           next, devnameP);

    listP = vfsP->mnt_list.next;
  }
}
#endif

/* Print an inode.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintInode(void* parm, unsigned long addr)
{
  struct inode* iP = (struct inode*) parm;

  if (iP == NULL)
  {
    kErrPrintf("NULL inode\n");
    return;
  }

  kPrintf("inode 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "inode"))
    DumpMemory((char*)iP, sizeof(struct inode), addr, DUMPMEM_I4);
}


/* Print a super_block.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintSuperBlock(void* parm, unsigned long addr)
{
  struct super_block* sP = (struct super_block*) parm;
  if (sP == NULL)
  {
    kErrPrintf("NULL super_block\n");
    return;
  }

  kPrintf("super_block 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "super_block"))
    DumpMemory((char*)sP, sizeof(struct super_block), addr, DUMPMEM_I4);
}


/* Print a page struct.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintPage(void* parm, unsigned long addr)
{
  struct page* pageP = (struct page*) parm;

  if (pageP == NULL)
  {
    kErrPrintf("NULL page\n");
    return;
  }
  kPrintf("page 0x%lX (frame number 0x%lX):\n",
         addr, (addr-MemMapAddr)/sizeof(struct page));

  if (DumpMemoryCast(addr, "page"))
    DumpMemory((char*)pageP, sizeof(struct page), addr, DUMPMEM_I4);
}


/* Print an address_space struct.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintAddressSpace(void* parm, unsigned long addr)
{
  struct address_space* asP = (struct address_space*) parm;

  if (asP == NULL)
  {
    kErrPrintf("NULL address_space\n");
    return;
  }

  kPrintf("address_space 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "address_space"))
    DumpMemory((char*)asP, sizeof(struct address_space), addr, DUMPMEM_I4);
}


/* Print a vm_area_struct struct.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintVMAreaStruct(void* parm, unsigned long addr)
{
  struct vm_area_struct* vmP = (struct vm_area_struct*) parm;

  if (vmP == NULL)
  {
    kErrPrintf("NULL vm_area_struct\n");
    return;
  }

  kPrintf("vm_area_struct 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "vm_area_struct"))
    DumpMemory((char*)vmP, sizeof(struct vm_area_struct), addr, DUMPMEM_I4);
}


/* Print an mm_struct struct.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintMMStruct(void* parm, unsigned long addr)
{
  struct mm_struct* mmP = (struct mm_struct*) parm;

  if (mmP == NULL)
  {
    kErrPrintf("NULL mm_struct\n");
    return;
  }

  kPrintf("mm_struct 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "mm_struct"))
    DumpMemory((char*)mmP, sizeof(struct mm_struct), addr, DUMPMEM_I4);
}


/* Print an task_struct struct.  Parameter may be NULL. */
void RESET_KDUMP_REGPARMS PrintTaskStruct(void* parm, unsigned long addr)
{
  struct task_struct* taskP = (struct task_struct*) parm;

  if (taskP == NULL)
  {
    kErrPrintf("NULL task_struct\n");
    return;
  }

  kPrintf("task_struct 0x%lX:\n", addr);

  if (DumpMemoryCast(addr, "task_struct"))
    DumpMemory((char*)taskP, sizeof(struct task_struct), addr, DUMPMEM_I4);
}

void RESET_KDUMP_REGPARMS DoPs(void)
{
  struct threadIter ti;
  tiInit(&ti);

  kPrintf("task addr      PID        state    name\n");
  do
  {
    kPrintf("0x%08lX    %8d    %0lX   %s%s\n",
           ti.threadAddr, ti.threadP->pid, ti.threadP->state,
           (ti.threadAddr == ti.taskAddr) ? "" : "    ", ti.threadP->comm);
  } while (tiNext(&ti));
}

void PrintTraceback(struct task_struct* taskP, unsigned long threadAddr)
{
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
  struct bt_stack_frame
  {
    struct bt_stack_frame* next;
    long cr;
    void *ret_addr;
  };
  struct bt_stack_frame* frameP = NULL;
  struct pt_regs *regs;
  unsigned long ip, offset, frameAddr;
  struct Symbol* sP;
  struct pidStackSymbol* p;
  int rc, frameNum;

  frameAddr = taskP->thread.ksp;

  kPrintf("\nStack for process %d (%s):\n", taskP->pid, taskP->comm);
  frameNum = 0;
  InitPidStackAddrAnchor(stackSymbolAnchor);
  while ( frameAddr > PAGE_OFFSET )
  {
    frameP = (struct bt_stack_frame*)GenericGet(frameAddr,
                                       sizeof(struct bt_stack_frame), 0);
    if (frameP == NULL)
    {
      kPrintf(" NULL stack frame pointer\n");
      break;
    }
    /* check the total trace number */
    if (frameNum ++ > THREAD_SIZE)
    {
      kPrintf(" frame total num over the THREAD_SIZE,"
              " break the backtrace to avoid infinite loop\n");
      kFree((unsigned long*)frameP);
      break;
    }
    /* check the same symbol called number */
    p = GetPidStackAddr(frameAddr, stackSymbolAnchor);
    if (p == NULL)
    {
      AddPidStackAddr(frameAddr, stackSymbolAnchor);
    }
    else if (p->count > 1024)
    {
      kPrintf(" the same frame %0p occured over 1024 times,"
              " break the backtrace to avoid infinite loop\n", frameAddr);
      kFree((unsigned long*)frameP);
      break;
    }
    else
      p->count ++;
         
    ip = (unsigned long)frameP->ret_addr;
    if (ip != 0)
    {
      sP = LookupSymbolByAddr(ip);
      if ( (sP->flags & FL_TEXT) )
      {
        offset = ip - sP->addr;
        kPrintf("%0p 0x%016lX  %s + 0x%X\n", frameAddr, ip, sP->nameP, offset);
      }
    }
    frameAddr = (unsigned long)(frameP->next);
    kFree((unsigned long*)frameP);
  }
  CleanupPidStackAddrAnchor(stackSymbolAnchor);
#elif defined(GPFS_ARCH_X86_64)
  unsigned long rsp, stackWord, *p, offset, count;
  struct Symbol* sP;

#if (LINUX_KERNEL_VERSION >= 2062500)
  rsp = taskP->thread.sp;
#else
  rsp = taskP->thread.rsp;
#endif

  kPrintf("\nStack for process %d (%s):\n", taskP->pid, taskP->comm);
  while ((rsp & (THREAD_SIZE-1)))
  {
    p = (unsigned long*)GenericGet(rsp++, sizeof(rsp), 0);
    if (p == NULL)
    {
      kPrintf(" NULL stackWord pointer\n");
      break;
    }
    stackWord = *p;
    if (stackWord >= LowKernelAddr && stackWord <= HighSymbolAddr)
    {
      sP = LookupSymbolByAddr(stackWord);
      kAssert(sP != NULL, "failed to lookupSymbolByAddr 0x%0lX\n", stackWord);
      if (sP->flags & FL_TEXT)
      {
        offset = stackWord - sP->addr;
        kPrintf(" 0x%0lX  %s + 0x%X\n", stackWord, sP->nameP, offset);
      }
    }
/*
    else 
      kPrintf(" [%08lX]", stackWord);
*/
    kFree(p);
  }
  kPrintf("\n");
#elif defined(GPFS_ARCH_S390X)
  unsigned long frameAddr, sp, offset;
  struct Symbol* sP;
  struct {
    unsigned long empty1[5];
    unsigned int  empty2[8];
    unsigned long gprs[10];
    unsigned long back_chain;
  } *sfP;

  frameAddr = taskP->thread.ksp;

  kPrintf("\nStack for process %d (%s):\n", taskP->pid, taskP->comm);
  while ((frameAddr & (THREAD_SIZE-1)))
  {
    sfP = GenericGet(frameAddr, sizeof(struct stack_frame), 0);
    if (sfP == NULL)
    {
      kPrintf(" NULL stack frame pointer\n");
      break;
    }
    sp = sfP->gprs[8];

    if (sp >= LowKernelAddr && sp <= HighSymbolAddr)
    {
      sP = LookupSymbolByAddr(sp);
      kAssert(sP != NULL, "failed to lookupSymbolByAddr 0x%0lX\n", sp);
      if (sP->flags & FL_TEXT)
      {
        offset = sp - sP->addr;
        kPrintf(" 0x%0lX  %s + 0x%X\n", sp, sP->nameP, offset);
      }
    }
    frameAddr =  sfP->back_chain;
    kFree(sfP);
  }
  kPrintf("\n");
#endif
}

/* Print kernel traceback for a particular process.  pid == -1
 * means all processes
 */
void RESET_KDUMP_REGPARMS BacktracePid(unsigned long pid)
{
  int i = 0;
  struct threadIter ti;
  struct pidStackSymbol* p = NULL;
  tiInit(&ti);

  InitPidStackAddrAnchor(pidSymbolAnchor); 
  do
  {
    if (pid == -1 || ti.threadP->pid == pid)
    {
      PrintTraceback(ti.threadP, ti.threadAddr);
      if (pid != -1)
      {
        tiDone(&ti);
        return;
      }
    }
    
    p = GetPidStackAddr(ti.threadP->pid, pidSymbolAnchor);
    if (p == NULL)
      /* add into pidStackAddrAnchor list */
      AddPidStackAddr(ti.threadP->pid, pidSymbolAnchor);
    else if (p->count > 4096)
      continue;
    else
      p->count ++;
  } while (tiNext(&ti));
  CleanupPidStackAddrAnchor(pidSymbolAnchor);

  if (pid != -1)
    kErrPrintf("PID %ld not found\n", pid);
}

void RESET_KDUMP_REGPARMS BacktraceAll(void)
{
  BacktracePid(-1);
}

static struct elf_prstatus prstatus;
static struct elf_prpsinfo prpsinfo;

struct memelfnote
{
  char *name;
  int type;
  unsigned int datasize;
  void *data;
};

#define ROUNDUP(_addr, _align) ( (_addr + (_align - 1))/_align * _align)

void ReadElfNote(struct memelfnote* memnote)
{
  struct elf_note note;
  int len;

  readCore(&note, sizeof(note));

  memnote->type = note.n_type;
  len = ROUNDUP(note.n_namesz, 4);
  memnote->name = (char*)kMalloc(len);
  kAssert(memnote->name != NULL, "memnote->name is NULL\n");
  readCore(memnote->name, len);
  memnote->name[note.n_namesz] = '\0';

  len = ROUNDUP(note.n_descsz, 4);
  memnote->datasize = note.n_descsz;
  memnote->data = kMalloc(len);
  kAssert(memnote->data != NULL, "failed to malloc memory\n");
  memset(memnote->data, 0, len);
  readCore(memnote->data, len);
}


/* core file generated by kernel kdump will use 64bit sometime,
   doesn't matter the platform is 32bit or 64bit */
void RESET_KDUMP_REGPARMS ReadKernelCore(char* corefile, int coreType)
{
  int i = 0;
  struct memelfnote status_note, psinfo_note, taskstruct_note;
  struct vmStruct* aListP;
  struct vmStruct** prevPP;
  unsigned char *tmpHdr, *tmpNotePhdr, *tmpLoadPhdr;
  int tmpSize = 0;
  int phdrNum = 0;


  /* init tmpHdr and tmpPhdr */
  if (coreType == 0)
     tmpSize = sizeof(struct elf32_hdr);
  else
     tmpSize = sizeof(struct elf64_hdr);

  tmpHdr = (unsigned char*)kMalloc(tmpSize);
  kAssert(tmpHdr != NULL, "failed to malloc memory\n");


  kPrintf("Reading ELF core file %s...\n", corefile);
  isCore = 1;
  openCore(corefile);
  readCore(tmpHdr, tmpSize);
  if (coreType == 0)
  {
    kAssert(((struct elf32_hdr*)tmpHdr)->e_type == ET_CORE, 
            "e_type isn't ET_CORE, e_type: %d\n", ((struct elf32_hdr*)tmpHdr)->e_type);
    kAssert(((struct elf32_hdr*)tmpHdr)->e_version == EV_CURRENT,
            "e_version isn't EV_CURRENT, e_version: %d\n", ((struct elf32_hdr*)tmpHdr)->e_version);
    kAssert(((struct elf32_hdr*)tmpHdr)->e_ehsize == sizeof(struct elf32_hdr),
            "e_ehsize isn't right, e_ehsize: %d\n", ((struct elf32_hdr*)tmpHdr)->e_ehsize);
    kAssert(((struct elf32_hdr*)tmpHdr)->e_phentsize == sizeof(struct elf32_phdr),
            "e_phentsize isn't right, e_phentsize: %d\n", ((struct elf32_hdr*)tmpHdr)->e_phentsize);
    phdrNum = ((struct elf32_hdr*)tmpHdr)->e_phnum;
  } else {
    kAssert(((struct elf64_hdr*)tmpHdr)->e_type == ET_CORE,
            "e_type isn't ET_CORE, e_type: %d\n", ((struct elf64_hdr*)tmpHdr)->e_type);
    kAssert(((struct elf64_hdr*)tmpHdr)->e_version == EV_CURRENT,
            "e_version isn't EV_CURRENT, e_version: %d\n", ((struct elf64_hdr*)tmpHdr)->e_version);
    kAssert(((struct elf64_hdr*)tmpHdr)->e_ehsize == sizeof(struct elf64_hdr),
            "e_ehsize isn't right, e_ehsize: %d\n", ((struct elf64_hdr*)tmpHdr)->e_ehsize);
    kAssert(((struct elf64_hdr*)tmpHdr)->e_phentsize == sizeof(struct elf64_phdr),
            "e_phentsize isn't right, e_phentsize: %d\n", ((struct elf64_hdr*)tmpHdr)->e_phentsize);
    phdrNum = ((struct elf64_hdr*)tmpHdr)->e_phnum;
  }
  kFree(tmpHdr);

  tmpSize = sizeof(struct elf32_phdr);
  if (coreType == 1)
    tmpSize = sizeof(struct elf64_phdr);
  tmpNotePhdr = (unsigned char*)kMalloc(tmpSize);
  tmpLoadPhdr = (unsigned char*)kMalloc(tmpSize);
  kAssert(tmpNotePhdr != NULL, "failed to malloc memory\n");
  kAssert(tmpLoadPhdr != NULL, "failed to malloc memory\n");
  readCore(tmpNotePhdr, tmpSize);

  vmListHeadP = NULL;
  prevPP = &vmListHeadP;
  for (i = 0; i < phdrNum - 1; i++)
  {
    readCore(tmpLoadPhdr, tmpSize);
    aListP = (struct vmStruct*) kMalloc(sizeof(struct vmStruct));
    kAssert(aListP != NULL, "failed to malloc memory\n");
    if ((coreType == 0) && (((struct elf32_phdr*)tmpLoadPhdr)->p_type & PT_LOAD))
    {
      aListP->startAddr = ((struct elf32_phdr*)tmpLoadPhdr)->p_vaddr;
      aListP->areaLen = ((struct elf32_phdr*)tmpLoadPhdr)->p_memsz;
      aListP->file_offset = ((struct elf32_phdr*)tmpLoadPhdr)->p_offset;
    }
    else
    {
      aListP->startAddr = ((struct elf64_phdr*)tmpLoadPhdr)->p_vaddr;
      aListP->areaLen = ((struct elf64_phdr*)tmpLoadPhdr)->p_memsz;
      aListP->file_offset = ((struct elf64_phdr*)tmpLoadPhdr)->p_offset;
    }
    aListP->nextAreaP = NULL;
    *prevPP = aListP;
    prevPP = &aListP->nextAreaP;
  }
  kFree(tmpLoadPhdr);

  if (coreType == 0)
    seekCore(((struct elf32_phdr*)tmpNotePhdr)->p_offset);
  else
    seekCore(((struct elf64_phdr*)tmpNotePhdr)->p_offset);
  ReadElfNote(&status_note);
  kAssert(status_note.type == NT_PRSTATUS, 
          "wrong status type: %d\n", status_note.type);
  cxiMemcpy(&prstatus, status_note.data, sizeof(prstatus));
  kFree(tmpNotePhdr);
}
#endif
