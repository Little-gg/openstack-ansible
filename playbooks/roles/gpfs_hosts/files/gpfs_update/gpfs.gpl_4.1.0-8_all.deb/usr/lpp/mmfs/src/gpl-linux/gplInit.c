/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)68       1.112.8.7  src/avs/fs/mmfs/ts/kernext/gpl-linux/gplInit.c, mmfs, avs_rfks1, rfks1s008a 3/20/15 19:17:08 */
/*
 * Initialize the linux module
 *
 */

#include <Shark-gpl.h>

#include <linux/types.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>

#if LINUX_KERNEL_VERSION < 2061800
#include <linux/config.h>
#else
#if LINUX_KERNEL_VERSION < 2063600
#include <linux/autoconf.h>
#endif
#endif

#include <verdep.h>
#include <cxiSystem.h>
#include <cxi2gpfs.h>
#include <linux2gpfs.h>
#include <cxiIOBuffer.h>
#include <cxiSharedSeg.h>
#include <Trace.h>
#include <Dynassert.h>

extern char *prog_path;

struct gpfs_operations gpfs_ops;

/* This string must match (in the strcmp sense) PRODUCT_VERSION defined
   in prodname.h.  It is used to make sure that mmfslinux module matches
   the rest of the code. */
#define PRODUCT_VERSION "4.1.0.8 "

#ifdef MODULE

MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION ("GPFS portability layer");
MODULE_AUTHOR ("IBM <gpfs@us.ibm.com>");
#if (LINUX_KERNEL_VERSION >= 2060500)
MODULE_INFO(supported, "external");
#endif

/* The module pointer for the mmfs module.  Exported
 * to the mmfs portability layer module.  Its reference
 * counts are updated via cxiIncModuleCounter().
 */
static struct module *ibmModule = 0;
static struct module *ibmModuleLoaded = 0;

void 
cxiExportModuleStruct(void *modAddr)
{
  ibmModule = (struct module *)modAddr;
}

void 
cxiIncModuleCounter(int up)
{
  #define MAX_MODULE_GET_TIMES 3
  int ret = 0;
  int try_count = 0;
  TRACE3(TRACE_VNODE, 1, TRCID_CXIINC_COUNTER,
         "cxiIncModuleCounter: ibmModule 0x%X up %d, mod name=%s\n",
         ibmModule, up, module_name(ibmModule));


  if (ibmModule)
  {
    if (up)
    {
      /* if try_module_get fails, retry maximum MAX_MODULE_GET_TIMES times*/
      while (try_count++ < MAX_MODULE_GET_TIMES && ret == 0)
      {
          ret = try_module_get(ibmModule);  
          if (ret == 0) 
              TRACE1(TRACE_VNODE, 1, TRCID_CXIINC_COUNTER2,
                   "cxiIncModuleCounter: can't get module reference, %d times tried\n", try_count);
      }
      /* only when the module is finally got referenced, shall we think the module is loaded */
      if (ret != 0) ibmModuleLoaded = ibmModule;
      else 
      {
          TRACE0(TRACE_VNODE, 1, TRCID_CXIINC_COUNTER3, 
                 "cxiIncModuleCounter: try_module_get failed\n");
      }
      DBGASSERT( ret != 0 );
    }
    else if (ibmModuleLoaded)
      module_put(ibmModule);

    #ifdef CONFIG_MODULE_UNLOAD 
    TRACE1(TRACE_VNODE, 1, TRCID_CXIINC_COUNTER4, 
           "cxiIncModuleCounter: ibmModule current ref count %u\n",
           module_refcount(ibmModule));
    #endif
  }
}

#else /* ! MODULE */

static void *ibmModule = 0;
void cxiExportModuleStruct(void *modAddr) {};
void cxiIncModuleCounter(int up) {};

#endif /* MODULE */

extern char bin_path[CXI_MAXPATHLEN+1];
extern char mmfs_path[CXI_MAXPATHLEN+1];
extern int mmfsd_module_active;


/* Dummy operations for initializing gpfs_operations table.
   Using this dummy operation instead of storing a NULL function pointer
   avoids having to check for NULL before each call. */
void 
gpfs_void_op()
{
}

int 
gpfs_enosys_op()
{
  return ENOSYS;
}

int 
gpfs_zero_op()
{
  return 0;
}

void *
gpfs_nullptr_op()
{
  return NULL;
}

typedef void   (*VoidFnP)();
typedef int    (*IntFnP)();
typedef void * (*PtrFnP)();

/* initialize gpfs_operations table */
void
reset_gpfs_operations()
{
  gpfs_ops.mmfs = 0;
  * (IntFnP *) & gpfs_ops.gpfsMount = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsStatfs = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSyncfs = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFsync = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSyncNFS = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsMkdir = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsLink = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsOpen = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsInodeRead = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsInodeDelete = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsInodeFindActor = (IntFnP)gpfs_zero_op;
  * (IntFnP *) & gpfs_ops.gpfsEncodeFileHandle = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetHashValue = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsRemove = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsRename = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsRmdir = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSetattr = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSymlink = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFsyncRange = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsClose = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsUnmap = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFattr = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFsAttr = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFclear = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFalloc = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFtrunc = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsRead = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsWrite = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetattr = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsAccess = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsReaddir = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsReadlink = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetHashName = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsCreate = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsMknod = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsRele = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsLookup = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsFcntl = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsUncache = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsCleanupCifs = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsIsCifs = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsIsCifsBypassTraversalChecking = (IntFnP)gpfs_enosys_op;

#ifdef GPFS_CACHE
  * (IntFnP *) & gpfs_ops.gpfsUnmountPcache = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsEncodePcacheFH = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsDecodePcacheFH = (IntFnP)gpfs_enosys_op;
#endif
  * (IntFnP *) & gpfs_ops.gpfsUnmount = (IntFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsFinishUnmount = (VoidFnP)gpfs_void_op;
  * (IntFnP *) & gpfs_ops.gpfsFcntlReset = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetAcl = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsPutAcl = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetNFS = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetOpenNFS = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsReleaseNFS = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsReady = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsMmap = (IntFnP)gpfs_enosys_op;
#ifdef SMB_LOCKS
  * (IntFnP *) & gpfs_ops.SMBOpenLockControl = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.SMBGetOplockState = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.SMBGetOplockStateV = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSetSMBOplock = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsReserveShare = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsReserveDelegation = (IntFnP)gpfs_enosys_op;
#endif
  * (IntFnP *) & gpfs_ops.gpfsDaemonToDie = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsCleanup = (IntFnP)gpfs_enosys_op;
#ifdef UIDREMAP
  * (IntFnP *) & gpfs_ops.UIDremapOn = (IntFnP)gpfs_enosys_op;
#endif
  * (VoidFnP*) & gpfs_ops.gpfsSwapdEnqueue = (VoidFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsQueueBufs = (VoidFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsMmapFlushLock = (VoidFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsMmapFlushUnlock = (VoidFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsDmUnmountEvent = (IntFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsNFSIget = (VoidFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsOpenNFS = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSeek = (IntFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsGrace = (VoidFnP)gpfs_enosys_op;
#ifdef P_NFS4
  * (IntFnP *) & gpfs_ops.gpfsGetDeviceList = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetLayout = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGotIOnodes = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetOpenState = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsLayoutReturn = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetDeviceInfo = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetMyDevID = (IntFnP)gpfs_enosys_op;
#endif
  * (VoidFnP *) & gpfs_ops.gpfsGetVerifier = (VoidFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetNodeID = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsCheckStatus = (IntFnP)gpfs_enosys_op;
  * (VoidFnP*) & gpfs_ops.gpfsGetFSID = (VoidFnP)gpfs_enosys_op;
 * (IntFnP *) & gpfs_ops.gpfsQuotactl = (IntFnP)gpfs_enosys_op;
#ifdef FILESETMAPPING_API
  * (IntFnP *) & gpfs_ops.gpfsGetFilesetId = (IntFnP)gpfs_enosys_op;
#endif

#ifdef LOCK_TRACING
  * (IntFnP *) & gpfs_ops.gpfsInsertTraceInfo = (IntFnP)gpfs_enosys_op;
#endif
  * (IntFnP *) & gpfs_ops.gpfsLookupFileWithFileId = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsLookupRealName = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsLinuxAIOComplete = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsAioDaemonCallback = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSupportSambaLookup = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetWinBasicInfo = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSetWinBasicInfo = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsWinOps = (IntFnP)gpfs_enosys_op;
#ifdef USER_EXIT_ENTENSIONS
  * (IntFnP *) & gpfs_ops.gpfsGenFsUnmountCallback = (IntFnP)gpfs_enosys_op ; 
#endif    
#ifdef CLONE_FILE
  * (IntFnP *) & gpfs_ops.gpfsCloneFile = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsDeclone = (IntFnP)gpfs_enosys_op;
#endif
  * (IntFnP *) & gpfs_ops.gpfsSetTimes = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsSetXattr = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGetOrListXattr = (IntFnP)gpfs_enosys_op;
  * (VoidFnP *) & gpfs_ops.gpfsGetTime = (VoidFnP)gpfs_enosys_op;
#ifdef GANESHA
  * (IntFnP *) & gpfs_ops.gpfsGaneshaUpdate = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGaneshaLock = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGaneshaRecall = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGaneshaThread = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGaneshaNotify = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsGaneshaGrace = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsRevalidateInterval = (IntFnP)gpfs_enosys_op;
#endif
#ifdef LIGHT_WEIGHT_EVENT 
  * (IntFnP *) & gpfs_ops.gpfslweCreateSession = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfslweDestroySession = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfslweGetAllSessions = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfslweQuerySession = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfslweGetEvents = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfslweRespondEvent = (IntFnP)gpfs_enosys_op;
#endif  
  * (IntFnP *) & gpfs_ops.gpfsGetMemMap = (IntFnP)gpfs_enosys_op;
  * (IntFnP *) & gpfs_ops.gpfsParseDirEntry = (IntFnP)gpfs_enosys_op;
};

void 
gpfs_clean()
{
  if (gpfs_ops.mmfs)
  {
    gpfs_ops.mmfs(CFG_TERM);
  }
  gpfs_unreg_fs();

}

int 
gpfs_init()
{
  if (strlen(prog_path) > CXI_MAXPATHLEN)
  {
    TRACE2(TRACE_SHARED, 0, TRCID_GPFSINIT_000,
         "gpfs_init: prog_path %s length %d too long\n",
         prog_path, strlen(prog_path));
    return -1;
  }

  if (gpfs_reg_fs())
    return -1;

  if (gpfs_ops.mmfs)
  {
    if (gpfs_ops.mmfs(CFG_INIT))
    {
      gpfs_clean();
      return -1;
    }
  }
  else
    return -1;

  strcpy(bin_path, prog_path);
  return 0;
}

int cxiCheckProductVersion(const char* mmfsProductVersion)
{
  if (cxiStrcmp(mmfsProductVersion, PRODUCT_VERSION) != 0)
  {
    TRACE2(TRACE_VNODE, 0, TRCID_PRODVER_MISMATCH,
           "mmfslinux product version %s does not match mmfs version %s",
           PRODUCT_VERSION, mmfsProductVersion);

    /* Since getting a trace of an early startup failure is awkward,
       we should make the issue more obvious. */
    printk("GPFS mmfslinux product version %s does not match mmfs version %s",
           PRODUCT_VERSION, mmfsProductVersion);

    return EINVAL;
  }

  return 0;
}

/* Module initialization */
static int __init myModuleInit(void)
{
  int i;

#ifdef GPFS_ARCH_S390X
  int err = cxiCheckS390x();
  if (err)
    return err;
#endif

#ifdef KSTACK_CHECK
  shInit();
#endif

#ifdef MALLOC_DEBUG
  MallocDebugStart();
#endif

  for (i=0 ; i<MAX_TRACE_CLASSES ; i++)
     TraceFlagsP[i] = 9;

#ifdef DYNASSERTS_FULL
  for (i=0 ; i<MAX_DYN_CLASSES ; i++)
     AssertFlagsP[i] = 9;
#endif  

#ifdef INSTRUMENT_LOCKS
  InitBlockingMutexStats();
#endif

  InitSharedMemory();

  reset_gpfs_operations();

  TRACE1(TRACE_SHARED, 0, TRCID_PORTINIT_001,
         "init_module: prog_path %s\n",
         prog_path == NULL ? "NULL" : prog_path);

  /* Ensure types are the correct size */
  if (cxiCheckTypes())
  {
    CleanUpSharedMemory();
    return -1;
  }

  if (ss_init())
  {
    CleanUpSharedMemory();
    return -1;
  }

  gpfs_proc_export_init();

  IOBufferModuleInit();
   
#ifdef API_32BIT
  gpfs_reg_ioctl32();
#endif 

  return 0;
}

/* Module unload */
static void __exit myModuleExit(void)
{
#ifdef API_32BIT
  gpfs_unreg_ioctl32();
#endif

  gpfs_proc_export_term();

  IOBufferModuleTerm();

  TermSharedMemory();

#ifdef MALLOC_DEBUG
  MallocDebugEnd();
#endif

#ifdef KSTACK_CHECK
  shTerm();
#endif
}

module_init(myModuleInit);
module_exit(myModuleExit);

