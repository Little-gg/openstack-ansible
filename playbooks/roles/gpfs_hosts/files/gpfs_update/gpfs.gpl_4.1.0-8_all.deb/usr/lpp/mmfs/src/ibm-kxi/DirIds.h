/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)69       1.102  src/avs/fs/mmfs/ts/DirIds.h, mmfs, avs_rfks1, rfks1s007a_addw 7/24/14 06:34:18 */
#ifndef _h_DirIds
#define _h_DirIds

/*
 * Define unique numeric IDs for each source directory in Shark that contains
 * code.  These directory IDs are used for several purposes:
 *   1. Generating unique labels ("hookids") for kernel trace points
 *   2. Identifying message set numbers for the message catalog code
 * The symbols defined in this file are formed by appending the relative
 * directory name to the string "DIR_ID_", then translating slashes to
 * underscores.
 *   The values of the directory IDs must be in the range 1...63:
 * zero is not allowed because 0 is not valid as a message set number;
 * values larger than 63 cannot be used because only 6 bits of the ID are
 * used in generating kernel trace hookids.
 * Numbers larger than 63 can be used for directories that have message
 * catalogs, but no traces.
 *
 * ==========================================================================
 *
 * DO NOT renumber these IDs, or reuse an ID for a directory that
 * has been deleted, as numbers derived from these IDs appear in the
 * message catalog and trace format file.
 *
 * The message files are listed here with their message number ranges.
 * The range of numbers of MMFS messages 3-digit codes
 * reserved for each existing message catalog file (.msg file)
 *
 * The messages displayed have the format "GPFS: 6027-xxx <message text>"
 * where xxx is the unique 3-digit or 4-digit code for the particular error.
 *
 *
 * SUBDIRECTORY            CATALOG FILE NAME                RANGE OF CODES
 * ------------            -----------------                --------------
 *                                                    unused    000-299
 *  mmfsd                     mmfsd.msg                         300-309
 *  tasking (1)                task.msg                         310-339
 *  classes/tscomm           tscomm.msg                         340-359
 *  disk (1)                   disk.msg                         360-379
 *  classes/basic (1)          base.msg                         380-399
 *  stripe                   stripe.msg                         400-499
 *  vfs                         vfs.msg                         500-529
 *  fs (1)                       fs.msg                         530-599
 *  cfgmgr (1)                 cfgm.msg                         600-649
 *  logger                   logger.msg                         650-659
 *  cfgmgr (2)                 cfgm.msg                         660-799
 *                                                    unused    800-849
 *  util                       util.msg                         850-999
 *  admin (1)                 admin.msg                        1000-1399
 *  log                         log.msg                        1400-1449
 *  defrag                   defrag.msg                        1450-1499
 *  disk (2)                   disk.msg                        1500-1506
 *  admin (2)                 admin.msg                        1507-1529
 *  tasking (2)                task.msg                        1530-1550
 *  admin (3)                 admin.msg                        1551-1699
 *  classes/tscomm (2)       tscomm.msg                        1700-1799
 *  nsd                         nsd.msg                        1800-1849
 *  vdisk (1)                 vdisk.msg                        1850-1899
 *  admin (4)                 admin.msg                        1900-2049
 *  bufmgr                   bufmgr.msg                        2049-2099
 *  admin (4)                 admin.msg                        2100-2499
 *  sanergy                 sanergy.msg                        2500-2549
 *  bufmgr/linux            bufmgr_linux.msg                   2550-2575
 *  tasking/linux           tasking_linux.msg                  2576-2584
 *  tasking/solaris       tasking_solaris.msg                  2585-2599
 *  fs (2)                       fs.msg                        2600-2699
 *  cfgmgr (3)                 cfgm.msg                        2700-2799
 *  pc                           pc.msg                        2800-2899
 *  dm                           dm.msg                        2900-2949
 *  debug                     debug.msg                        (none)
 *  pfsck                     pfsck.msg                        (none)
 *  rs_t3_d11                    (none)                        (none)
 *  rs_t2_d10                    (none)                        (none)
 *  tasking (3)                task.msg                        2950-2999
 *  vdisk (2)                 vdisk.msg                        3000-3099
 *  classes/basic (2)          base.msg                        3100-3119
 *  pcache                   pcache.msg                        3200-3299
 *  fs (3)                       fs.msg                        3300-3399
 *  flea                       flea.msg                        (none)
 *  stripe (2)               stripe.msg                        3400-3449
 *  crypto                   crypto.msg                        3450-3499
 *  crypto (2)               crypto.msg                        3500-3549
 *  util (2)                   util.msg                        3550-3699
 *  crypto (3)               crypto.msg                        3700-3749
 *  appadmin               appadmin.msg                        3750-3799
 *
 * ==========================================================================
 */

/*
 * IMPORTANT (see also comments at the top of this file):
 *  - names must be of the form DIR_ID_XXX, where XXX = relative dir name
 *  - values must be in the range 1 ... 63
 * Subdirs for different architectures can reuse the same number since they
 * are never combined in the same build.
 * If a *.msg file is mentioned, then there is a "$set nn" line in that file
 * and the numbers MUST match.
 *
 * Do not renumber any existing DIR_ID if there are *.msg files that use
 * that number. These must be backward compatible for releases 3.1 or later.
 * This applies to any messages the GPFS daemon may look up from a client node.
 * Utilities that only do message lookup locally do not have this restriction.
 *
 */
#define DIR_ID_CFGMGR                   1    /* cfgmgr/trcid.h cfgm.msg */
#define DIR_ID_CLASSES_BASIC            2    /* classes/basic/trcid.h base.msg */
/* unused                               3 */
#define DIR_ID_LOCKMGR                  4    /* lockmgr/trcid.h */
#define DIR_ID_CLASSES_TSCOMM           5    /* classes/tscomm/trcid.h tscomm.msg */
#define DIR_ID_DEBUG                    6    /* debug.msg */
#define DIR_ID_DISK                     7    /* disk/trcid.h disk.msg */

#define DIR_ID_FS                       8    /* fs/trcid.h fs.msg */
/* DIR_ID_FS overflow. do not reuse.    9 */ /* (fs/trcid.h) */
/* DIR_ID_FS overflow. do not reuse.    10 *//* (fs/trcid.h) */
/* DIR_ID_FS overflow. do not reuse.    11 *//* (fs/trcid.h) */

#define DIR_ID_LOGGER                   12   /* logger/trcid.h logger.msg */
#define DIR_ID_MMFSD                    13   /* mmfsd/trcid.h mmfsd.msg */
#define DIR_ID_ADMIN                    14   /* admin.msg */
#define DIR_ID_PAGEMGR                  15   /* pagemgr/trcid.h */
#define DIR_ID_KERNEXT_GPL_LINUX        16   /* kernext/gpl-linux/trcid.h */

#define DIR_ID_KERNEXT_GPL_LINUX_I386   17

#define DIR_ID_TASKING                  18   /* tasking/trcid.h task.msg */
#define DIR_ID_VFS                      19   /* vfs.msg */
#define DIR_ID_KERNEXT                  20   /* kernext/trcid.h */
/* DIR_ID_KERNEXT overflow. do not use. 21 */ /* kernext/trcid.h */
#define DIR_ID_DM                       22   /* dm/trcid.h dm.msg */
#define DIR_ID_DM_KX                    23   /* dm/kx/trcid.h */

#define DIR_ID_DM_KX_AIX                24   /* dm/kx/aix/trcid.h */
#define DIR_ID_DM_KX_LINUX              24   /* dm/kx/linux/trcid.h */
#define DIR_ID_DM_KX_WINDOWS            24   /* dm/kx/windows/trcid.h */
#define DIR_ID_DM_KX_SOLARIS            24   /* dm/kx/solaris/trcid.h */

#define DIR_ID_LOG                      25   /* log/trcid.h log.msg */
#define DIR_ID_CLASSES_PERFMON          26   /* classes/perfmon/trcid.h */
#define DIR_ID_UTIL                     27   /* util.msg */
#define DIR_ID_STRIPE                   28   /* stripe/trcid.h stripe.msg */

#define DIR_ID_KERNEXT_AIX              29   /* kernext/aix/trcid.h */
#define DIR_ID_KERNEXT_LINUX            29   /* kernext/linux/trcid.h */
#define DIR_ID_KERNEXT_WINDOWS          29   /* kernext/windows/trcid.h */
#define DIR_ID_KERNEXT_SOLARIS          29

#define DIR_ID_FS_AIX                   30   /* fs/aix/trcid.h */
#define DIR_ID_FS_LINUX                 30   /* fs/linux/trcid.h */
#define DIR_ID_FS_WINDOWS               30   /* fs/windows/trcid.h */
#define DIR_ID_FS_SOLARIS               30

/* unused                               31 */
#define DIR_ID_ADMIN_SCRIPT             32   /* admin.msg */
#define DIR_ID_TM                       33   /* tm/trcid.h */
/* unused                               34 */
#define DIR_ID_DEFRAG                   36   /* defrag/trcid.h defrag.msg */
#define DIR_ID_CLASSES_MBPERFMON        37   /* classes/mbperfmon/trcid.h */
#define DIR_ID_PFSCK                    38   /* pfsck/trcid.h pfsck.msg */
#define DIR_ID_VDISK                    39   /* vdisk/trcid.h vdisk.msg */
/* DIR_ID_VDISK overflow. do not reuse. 40 *//* (vdisk/trcid.h) */
/* unused - try to reserve for DIR_ID_VDISK overflow if possible.  41 */
/* unused                               42 */
/* unused                               43 */
#define DIR_ID_CRYPTO_SKMIP             44   /* crypto/SKMIP/trcid.h */
#define DIR_ID_CRYPTO                   45   /* crypto/trcid.h crypto.msg */
#define DIR_ID_NSD                      46   /* nsd/trcid.h nsd.msg */

#define DIR_ID_LOGGER_AIX               47   /* logger/aix/trcid.h */
#define DIR_ID_LOGGER_LINUX             47   /* logger/linux/trcid.h */
#define DIR_ID_LOGGER_WINDOWS           47   /* logger/windows/trcid.h */
#define DIR_ID_LOGGER_SOLARIS           47

#define DIR_ID_PCACHE                   48   /* pcache/trcid.h */
/* unused                               49 */
#define DIR_ID_CCR                      49   /* ccr/trcid.h */

#define DIR_ID_TASKING_AIX              51   /* tasking/aix/trcid.h */
#define DIR_ID_TASKING_LINUX            51   /* tasking/linux/trcid.h tasking_linux.msg */
#define DIR_ID_TASKING_WINDOWS          51   /* tasking/windows/trcid.h */
#define DIR_ID_TASKING_SOLARIS          51   /* tasking_solaris.msg */

#define DIR_ID_PC                       52   /* pc/trcid.h pc.msg */
#define DIR_ID_SANERGY                  53   /* sanergy/trcid.h sanergy.msg */
#define DIR_ID_SANERGY_KX               54   /* sanergy/kx/trcid.h */
#define DIR_ID_BUFMGR                   55   /* bufmgr/trcid.h bufmgr.msg */

#define DIR_ID_BUFMGR_AIX               56   /* bufmgr/aix/trcid.h */
#define DIR_ID_BUFMGR_LINUX             56   /* bufmgr/linux/trcid.h bufmgr_linux.msg */
#define DIR_ID_BUFMGR_WINDOWS           56   /* bufmgr/windows/trcid.h */
#define DIR_ID_BUFMGR_SOLARIS           56   /* bufmgr/solaris/trcid.h */

#define DIR_ID_RDMA_UDAPL               57   /* rdma/udapl/trcid.h */
#define DIR_ID_RDMA_VERBS               58   /* rdma/verbs/trcid.h */
#define DIR_ID_RDMA                     59   /* rdma/trcid.h */

#define DIR_ID_ADMIN_MORE               60   /* admin.msg */
#define DIR_ID_FLEA                     61   /* flea/flea.msg */
#define DIR_ID_WINDOWS                  62   /* windows/trcid.h */
/* unused                               63 */
/* END OF VALID ID RANGE for Ids that may be used in kernel Tracing */

#define DIR_ID_QOSIO                    65  /* qosio messages */
#define DIR_ID_APPADMIN                 66  /* appadmin.msg */


/* Add new directory IDs above here */

/* Dummy DIR_IDs for directories that do not contain any message catalogs or
   traces, but have id2name definitions that must be extracted my mktrace */
#define DIR_ID_KERNEXT_IBM_KXI           0

/* overrides for default hookid (307) in certain directories */
/* To set a new one, you just add a SHARKHOOKID_DIRNAME */
#define SHARKHOOKID_TM      0x30600000
#define SHARKHOOKID_FS      0x30900000
#define SHARKHOOKID_CFGMGR  0x30800000
#define SHARKHOOKID_TASKING 0x30800000
#define SHARKHOOKID_KERNEXT 0x30900000
#define SHARKHOOKID \
  (LOCAL_BASE == DIR_ID_TM ? SHARKHOOKID_TM : \
   LOCAL_BASE == DIR_ID_TASKING ? SHARKHOOKID_TASKING : \
   LOCAL_BASE == DIR_ID_FS ? SHARKHOOKID_FS : \
   LOCAL_BASE == DIR_ID_KERNEXT ? SHARKHOOKID_KERNEXT : \
   LOCAL_BASE == DIR_ID_CFGMGR ? SHARKHOOKID_CFGMGR : \
   0x30700000)


#endif  /* _h_DirIds */
