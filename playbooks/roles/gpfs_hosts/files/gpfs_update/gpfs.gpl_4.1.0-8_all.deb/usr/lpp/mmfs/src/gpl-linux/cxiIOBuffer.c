/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)37       1.144.1.2  src/avs/fs/mmfs/ts/kernext/gpl-linux/cxiIOBuffer.c, mmfs, avs_rfks1, rfks1s008a 4/13/15 17:12:09 */
/*
 * Linux implementation of I/O buffers
 *
 * Contents:
 *   struct cxiBioChunk_t
 *   struct cxiIORendezvous_t
 *
 *   IOBufferModuleInit
 *   IOBufferModuleTerm
 *   cxiPinMM
 *   cxiUnpinMM
 *
 *   cxiAllocPageList
 *   cxiMapAndRecordPages
 *   cxiReleaseAndForgetPages
 *   cxiGetPagePtrs
 *   cxiDeallocPageList
 *
 *   cxiAttachIOBuffer
 *   cxiDetachIOBuffer
 *   cxiUXfer
 *   cxiKXfer
 *   cxiKZero
 *   cxiMapDiscontiguousRW
 *   cxiUnmapDiscontiguousRW
 *   cxiMapContiguousRO
 *   cxiUnmapContiguousRO
 *
 *   chunkListDone
 *
 *  2.6 kernel:
 *   bioDone
 *   cxiStartIO
 *   GetDiskInfoX
 *
 *   cxiWaitIO
 *   cxiCleanIO
 *   cxiAssignAsyncIO
 *
 *   cxiInitIORendezvous
 *   cxiAllocIORendezvous
 *   cxiFreeIORendezvous
 *   cxiResetIORendezvous
 *   cxiAwakenIORendezvous
 */

#include <Shark-gpl.h>

#include <linux/module.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/mm.h>
#include <linux/blkdev.h>
#include <linux/fs.h>
#include <linux/bio.h>
#if LINUX_KERNEL_VERSION > 2063200
#define GPFS_AIO_PER_CPU
#endif
#ifdef GPFS_AIO_PER_CPU
#include <linux/cpu.h>
#endif

#ifdef ZIP
#include <linux/zlib.h>
#endif

#include <Logger-gpl.h>
#include <Trace.h>
#include <cxiSystem.h>
#include <linux2gpfs.h>
#include <verdep.h>
#include <cxiIOBuffer.h>
#include <cxiAtomic.h>
#include <cxiTypes.h>
#include <linux/mman.h>

//#define PAGE_ALIGN_DEBUG

#ifdef CONFIG_BGL
/* BG/L version of Linux doesn't define get_user_pages, so define it here */
#define get_user_pages(tsk, mm, start, len, write, force, pages, vmas) \
        __get_user_pages(tsk, mm, start, len, write, force, pages, vmas, 0)
#endif


/* Static pointer to slab allocator for cxiBioChunk_t's */
KMEM_CACHE_T* BioChunkCacheP = NULL;


/* Macro to round integer X up to the next integral multiple of integer Y */
#define ROUNDUP(X,Y) ( (Y) * ( ((X)+(Y)-1) / (Y) ) )

/* Group of Linux bios allocated together for a multi-page I/O.  A chunk
   is just less than 1/8 page. */
#define BIOS_PER_CHUNK \
  ( (512 -      \
    (8+ROUNDUP(sizeof(spinlock_t)+4*sizeof(void*)+sizeof(atomic_t), sizeof(void*)) \
     +ROUNDUP(sizeof(void*)+sizeof(int), sizeof(void*)))) / sizeof(void*) )

/* A chunk of bio pointers used by a single I/O.  Allocated from the
   BioChunkCacheP slab cache. */
struct cxiBioChunk_t
{
  /* Fields used only in the first chunk */

  /* Lock serializing uses of and changes to the bcRendezvousP pointer
     between interrupt handlers and threads that assign a
     cxiBioChunk_t to a rendezvous object */
  spinlock_t bioElementLock;

  /* Pointer to block device -- holds a reference on the inode. */
  struct block_device* bdevP;

  /* Pointer to I/O rendezvous to be signalled once all I/O for this
     chunk list has completed.  May be NULL, and will be set back to
     NULL after signalling the I/O rendezvous.  Can only be changed from
     non-NULL to NULL while holding bioElementLock. */
  struct cxiIORendezvous_t* bcRendezvousP;

  /* Callback routine and data pointer for when I/O completes.  The
     ...Int... routine is called at interrupt level as soon as I/O
     completes on every bio associated with a MBDoDiskIOParms. */
  cxiIODoneIntCallback_t bcIntCallbackRtn;
  void* bcCallbackDataP;

  /* Total number of bioDone calls remaining before all I/O is complete
     for this list of chunks.  Always updated with atomic operations,
     since this field is accessed asynchronously from interrupt level.
   */
  atomic_t nBioDonesLeft;

  /* Fields used in every chunk */

  /* Next chunk of bio pointers used for a single I/O.  The list is
     circular. */
  struct cxiBioChunk_t* bcNextP;

  /* Number of bios used in this chunk */
  int nSlotsUsed;

  /* Array of pointers to bios */
  struct bio *biop[BIOS_PER_CHUNK];
};


/* Low-level object to synchronize between asynchronously started disk
   I/Os and a thread that is waiting for them to complete */
struct cxiIORendezvous_t
{
  /* Wait queue used to wait for some number of I/Os to complete */
  wait_queue_head_t ioqWaitQ;

  /* Number of completed I/Os.  Updated from iodone callbacks and from
     process context, always using atomic operations. */
  atomic_t ioqNCompleted;

  /* Number of completed I/Os before awakening a waiting thread.  Only
     accessed or modified using atomic operations. */
  atomic_t ioqNDesired;
#define MAX_IO_NDESIRED MAX_INT32

  /* Set if the I/O timeout handler has fired. */
  atomic_t ioqTimedOut;

  /* I/O Timer */
  struct timer_list ioqTimer;

  /* A NULL ptr indicates this is not an AIO so wake the thread waiting on the
     IO (if there is a thread waiting). If this ptr in non-NULL, then the IO
     completion is queued to the AIO completion thread. */
  struct cxiUioAio_t *uioaioP;
};

spinlock_t aioQueueSpinlock;
#ifdef GPFS_AIO_PER_CPU
struct aioWork_s
{
  struct cxiUioAio_t *aioQueueHeadP;
  struct cxiUioAio_t *aioQueueTailP;
  spinlock_t aioQueueSpinlock;
  struct work_struct aio_work;
};

struct gpfsPerCpuData_s
{
  struct aioWork_s aioWork;
};

struct workqueue_struct *aioWorkQueueP = NULL;
void *perCpuDataP = NULL;

void aioCompletionThread(struct work_struct *workP)
{
  struct aioWork_s *aioP = container_of(workP, struct aioWork_s, aio_work);
  struct cxiUioAio_t *aioQueueHeadP;
  struct cxiUioAio_t *uioaioP;
  unsigned long flags;
  int rc;

  do
  {
    spin_lock_irqsave(&aioP->aioQueueSpinlock, flags);

    if (aioP->aioQueueHeadP)
    {
      aioQueueHeadP = aioP->aioQueueHeadP;
      aioP->aioQueueHeadP = NULL;
      aioP->aioQueueTailP = NULL;
      spin_unlock_irqrestore(&aioP->aioQueueSpinlock, flags);
    }
    else
    {
      spin_unlock_irqrestore(&aioP->aioQueueSpinlock, flags);
      break;
    }
    do
    {
      uioaioP = aioQueueHeadP;
      aioQueueHeadP = uioaioP->aioNextP;
      rc = aioComplete(uioaioP, 0, 0, false);
    } while (aioQueueHeadP != NULL);
  } while (1);
}

void allocPerCpu()
{
  struct gpfsPerCpuData_s *cpuDataP;
  unsigned long cpu;
  perCpuDataP = alloc_percpu(struct gpfsPerCpuData_s);

  if (perCpuDataP == NULL)
    cxiPanic("Cannot allocate per cpu data\n");

#ifdef HAS_ALLOC_WORKQUEUE
  aioWorkQueueP = alloc_workqueue("gpfs_aio", WQ_MEM_RECLAIM, 1);
#else
  aioWorkQueueP = create_workqueue("gpfs_aio");
#endif
  if (aioWorkQueueP == NULL)
    cxiPanic("Cannot create aio work queue\n");

  get_online_cpus();
  for_each_possible_cpu(cpu)
  {
    cpuDataP = per_cpu_ptr(perCpuDataP, cpu);
#if 0
    printk(KERN_WARNING "GPFS: cpu %lu cpuDataP %p\n", cpu, cpuDataP);
#endif
    cpuDataP->aioWork.aioQueueHeadP = NULL;
    cpuDataP->aioWork.aioQueueTailP = NULL;
    spin_lock_init(&cpuDataP->aioWork.aioQueueSpinlock);
    INIT_WORK(&cpuDataP->aioWork.aio_work, aioCompletionThread);
  }
  put_online_cpus();
}

void freePerCpu()
{
  if (aioWorkQueueP != NULL)
  {
    destroy_workqueue(aioWorkQueueP);
    aioWorkQueueP = NULL;
  }
  if (perCpuDataP != NULL)
  {
#if 0
    printk(KERN_WARNING "GPFS: Free perCpuDataP %p \n", perCpuDataP);
#endif
    free_percpu(perCpuDataP);
    perCpuDataP = NULL;
  }
}

#else
int aioCompletionRunning = 0;
struct cxiUioAio_t *aioQueueHeadP = NULL;
struct cxiUioAio_t *aioQueueTailP = NULL;

void aioCompletionThread(void *workP)
{
  struct cxiUioAio_t *uioaioP;
  unsigned long flags;
  Boolean fRunning = false;
  int rc;

  do
  {
    uioaioP = NULL;
    spin_lock_irqsave(&aioQueueSpinlock, flags);
    if (aioQueueHeadP)
    {
      uioaioP = aioQueueHeadP;
      aioQueueHeadP = uioaioP->aioNextP;
      if (!aioQueueHeadP)
        aioQueueTailP = NULL;
      if (!fRunning)
      {
        aioCompletionRunning++;
        fRunning = true;
      }
    }
    else
    {
      if (fRunning)
      {
        aioCompletionRunning--;
        fRunning = false;
      }
    }
    spin_unlock_irqrestore(&aioQueueSpinlock, flags);

    if (fRunning)
    {
      rc = aioComplete(uioaioP, 0, 0, false);
    }

  } while (fRunning);
}

GPFS_DECLARE_WORK(aioCompletionQueue, aioCompletionThread);

#endif

/* Initialization routine - called when module is loaded */
void
IOBufferModuleInit()
{
  int rc;

  ENTER(0);
  TRACE0(TRACE_KSVFS, 1, TRCID_KIBD_INIT,
         "IOBufferModuleInit called\n");

  spin_lock_init(&aioQueueSpinlock);

#ifdef GPFS_AIO_PER_CPU
  allocPerCpu();
#endif

  /* Create a slab allocator for cxiBioChunk_t objects */
  BioChunkCacheP = kmem_cache_create("gpfsBioChunk",
                                     sizeof(struct cxiBioChunk_t),
                                     0 /* offset */,
                                     0 /* flags */,
                                     NULL /* ctor */
#if LINUX_KERNEL_VERSION < 2062300
                                   , NULL /* dtor */
#endif
                                 );
  if (BioChunkCacheP == NULL)
    cxiPanic("Cannot create cxiBioChunk_t cache\n");

  if (gpfs_init_inodecache()!=0)
    cxiPanic("Cannot create gpfsInodeCache cache\n");

  EXIT(0);
}

/* Termination routine - called just before module is unloaded */
void
IOBufferModuleTerm()
{
  int rc;

  ENTER(0);
  TRACE0(TRACE_KSVFS, 1, TRCID_KIBD_TERM,
         "IOBufferModuleTerm called\n");

#ifdef GPFS_AIO_PER_CPU
  freePerCpu();
#endif

  /* Destroy slab allocator for cxiBioChunk_t objects */
#if LINUX_KERNEL_VERSION < 2061800
  rc = kmem_cache_destroy(BioChunkCacheP);
  if (rc)
    TRACE1(TRACE_KSVFS, 1, TRCID_BHC_CACHE_DESTROY,
           "IOBufferModuleTerm: ERROR! BioChunk cache destroy rc %d", rc);
#else
  kmem_cache_destroy(BioChunkCacheP);
#endif

  gpfs_destroy_inodecache();
  EXIT(0);
}


/* Create a cross-memory descriptor object for a page in user address
   space that is already pinned.  The page will be mapped into kernel
   address space.  This is used by mmap routines that want to do
   direct I/O from user page to disk.  The cxiXmem_t that this routine
   creates can be passed through the GPFS I/O stack just like the ones
   describing buffers in the GPFS page pool. */
int cxiPinMM(struct page *pageP, cxiXmem_t* xmemDescP)
{
  struct cxiPageList_t* plP;
  int rc = 0;
  char* kaddrP;

  ENTER(0);

  /* Create a page list object and point it at the given page struct */
  kaddrP = kmap(pageP);
  plP = cxiAllocPageList(1, (unsigned long)kaddrP);
  if (plP == NULL)
  {
    kunmap(pageP);
    rc = ENOMEM;
    goto exit;
  }
  plP->plRootP = (void*)pageP;

  xmemDescP->pageListP = (void*)plP;

exit:
  EXIT(0);
  return rc;
}


/* Free a cross-memory descriptor that was created by cxiPinMM. */
void cxiUnpinMM(struct page *pageP, cxiXmem_t* xmemDescP)
{
  struct cxiPageList_t* plP;

  ENTER(0);
  kunmap(pageP);

  /* Clear pointer to page so cleanup will not decrement the page reference
     count, then free the page list object */
  plP = (struct cxiPageList_t*) xmemDescP->pageListP;
  plP->plRootP = NULL;
  cxiDeallocPageList(plP);
  EXIT(0);
}


/* Fanout of a radix tree page */
#define RADIX_PAGE_FANOUT (PAGE_SIZE/sizeof(void*))

/* Allocate a cxiPageList_t and prepare it to record the addresses
   of up to maxPages pages.  The lowest user address in the set of
   pages to be recorded is baseAddr.  Returns NULL on any error. */
struct cxiPageList_t* cxiAllocPageList(int maxPages, UIntPtr baseAddr)
{
  struct cxiPageList_t* plP;
  int nMidPtrs;

  /* Allocate space for the page list */
  ENTER(0);
  plP = (struct cxiPageList_t*)kmalloc(sizeof(struct cxiPageList_t), GFP_KERNEL);
  if (plP == NULL)
    return NULL;

  /* Verify base address is on a page boundary */
  if ((baseAddr & (PAGE_SIZE-1)) != 0)
    goto errorExit;

  /* Validate max number of pages and compute number of levels in radix
     tree.  Allocate top level pointers if level >= 1. */
  if (maxPages <= 0)
    goto errorExit;
  else if (maxPages == 1)
  {
    plP->plNLevel = 0;
    plP->plRootP = NULL;
  }
  else if (maxPages <= RADIX_PAGE_FANOUT)
  {
    plP->plNLevel = 1;
    nMidPtrs = maxPages;
    plP->plRootP = (void*)kmalloc(nMidPtrs * sizeof(void*), GFP_KERNEL);
    if (plP->plRootP == NULL)
      goto errorExit;
    memset(plP->plRootP, 0, nMidPtrs * sizeof(void*));
  }
  else if (maxPages <= RADIX_PAGE_FANOUT*RADIX_PAGE_FANOUT)
  {
    plP->plNLevel = 2;
    nMidPtrs = (maxPages+RADIX_PAGE_FANOUT-1) / RADIX_PAGE_FANOUT;
    plP->plRootP = (void*)kmalloc(nMidPtrs * sizeof(void*), GFP_KERNEL);
    if (plP->plRootP == NULL)
      goto errorExit;
    memset(plP->plRootP, 0, nMidPtrs * sizeof(void*));
  }
  else
    goto errorExit;

  /* Initialize other fields and return */
  plP->plNPages = maxPages;
  plP->plBaseAddr = baseAddr;
  TRACE3(TRACE_SHARED, 4, TRCID_ALLOC_PAGE_LIST,
         "cxiAllocPageList: maxPages %d baseAddr 0x%lX plP 0x%lX\n",
         maxPages, baseAddr, plP);
  return plP;

errorExit:
  TRACE3(TRACE_SHARED, 1, TRCID_ALLOC_PAGE_LIST_ERR,
         "cxiAllocPageList: maxPages %d baseAddr 0x%lX plP 0x%lX\n",
         maxPages, baseAddr, plP);
#ifdef PAGE_ALIGN_DEBUG
  DBGASSERT(!(baseAddr & (PAGE_SIZE-1)));
#endif
  kfree(plP);
  EXIT(0);
  return NULL;
}


/* Map pages in the caller's address space at the given address and
   record the addresses of the struct page objects */
int cxiMapAndRecordPages(struct cxiPageList_t* plP, UIntPtr uaddr,
                         int nPages)
{
  unsigned long inUaddr = 0;
  struct page ** pagePP = NULL;
  void ** midPP;
  int rc;
  int pageIndex;
  int nPagesLeft;
  int nPagesThisChunk = 0;
  int midIndex;
  int leafIndex;

  /* Verify buffer address is on a page boundary */
  ENTER(0);
  if ((uaddr & (PAGE_SIZE-1)) != 0)
  {
    rc = EINVAL;
    goto exit;
  }

  /* Compute index of start page */
  pageIndex = (uaddr - plP->plBaseAddr) / PAGE_SIZE;
  if (pageIndex < 0  ||
      pageIndex+nPages > plP->plNPages)
  {
    rc = EINVAL;
    goto exit;
  }

  /* While there are more pages to record, get a pointer to where
     the next page pointer should be stored and map a range of pages
     starting at that point */
  inUaddr = uaddr;
  nPagesLeft = nPages;
  while (nPagesLeft > 0)
  {
    /* Compute where to store the pointers to struct page, and insure
       that all required pointer arrays have been allocated */
    switch (plP->plNLevel)
    {
      case 0:
        nPagesThisChunk = 1;
        pagePP = (struct page **)&plP->plRootP;
        break;

      case 1:
        DBGASSERT(plP->plRootP != NULL);
        nPagesThisChunk = nPagesLeft;
        pagePP = &(((struct page **)plP->plRootP)[pageIndex]);
        break;

      case 2:
        DBGASSERT(plP->plRootP != NULL);
        midIndex = pageIndex / RADIX_PAGE_FANOUT;
        leafIndex = pageIndex % RADIX_PAGE_FANOUT;
        midPP = &(((void**)plP->plRootP)[midIndex]);
        if (*midPP == NULL)
        {
          *midPP = (void*)kmalloc(RADIX_PAGE_FANOUT * sizeof(void*), GFP_KERNEL);
          if (*midPP == NULL)
          {
            if (nPages - nPagesLeft)
              (void)cxiReleaseAndForgetPages(plP, inUaddr, nPages - nPagesLeft);
            rc = ENOMEM;
            goto exit;
          }
          memset(*midPP, 0, RADIX_PAGE_FANOUT * sizeof(void*));
          TRACE2(TRACE_SHARED, 4, TRCID_RECORD_DETAIL_2,
                 "cxiMapAndRecordPages: allocated midPP 0x%lX for uaddr 0x%lX\n",
                 midPP, uaddr);
        }
        nPagesThisChunk = MIN(nPagesLeft, RADIX_PAGE_FANOUT-leafIndex);
        pagePP = &(((struct page **)*midPP)[leafIndex]);
        break;
    }

    /* Pin pages and record pointers to their struct page objects for use
       in submitting I/O requests */
    TRACE3(TRACE_SHARED, 4, TRCID_RECORD_DETAIL,
           "cxiMapAndRecordPages: mapping %d pages into 0x%lX uaddr 0x%lX\n",
           nPagesThisChunk, pagePP, uaddr);
    down_read(&current->mm->mmap_sem);
    rc = get_user_pages(current, current->mm, uaddr,
                        nPagesThisChunk, VM_WRITE, 0 /* force */,
                        pagePP, NULL);
    up_read(&current->mm->mmap_sem);
    if (rc != nPagesThisChunk)
    {
      if (nPages - nPagesLeft)
        (void)cxiReleaseAndForgetPages(plP, inUaddr, nPages - nPagesLeft);
      rc = ENOMEM;
      goto exit;
    }

    /* Update for next loop iteration */
    pageIndex += nPagesThisChunk;
    nPagesLeft -= nPagesThisChunk;
    uaddr += nPagesThisChunk * PAGE_SIZE;
  }
  rc = 0;

exit:
  TRACE4(TRACE_SHARED, 2, TRCID_CXIMAP_RECORD,
         "cxiMapAndRecordPages: plP 0x%lX uaddr 0x%lX nPages %d rc %d\n",
         plP, inUaddr, nPages, rc);
#ifdef PAGE_ALIGN_DEBUG
  DBGASSERT(!(inUaddr & (PAGE_SIZE-1)));
#endif
  EXIT(0);
  return rc;
}


/* Release pages mapped by cxiMapAndRecordPages.  Does not free any of
   the nodes of the radix tree.  Not an error to attempt to free pages
   that are not mapped. */
int cxiReleaseAndForgetPages(struct cxiPageList_t* plP, UIntPtr uaddr,
                             int nPages)
{
  struct page ** pagePP;
  struct page * pageP = NULL;
  void * midP;
  int rc;
  int pageIndex;
  int nPagesLeft;
  int midIndex;
  int leafIndex;

  ENTER(0);
  TRACE3(TRACE_SHARED, 2, TRCID_CXIFORGET_PAGES,
         "cxiReleaseAndForgetPages: plP 0x%lX uaddr 0x%lX nPages %d\n",
         plP, uaddr, nPages);

  /* Verify buffer address is on a page boundary */
  if ((uaddr & (PAGE_SIZE-1)) != 0)
  {
    rc = EINVAL;
    goto exit;
  }

  /* Compute index of start page */
  pageIndex = (uaddr - plP->plBaseAddr) / PAGE_SIZE;
  if (pageIndex < 0  ||
      pageIndex+nPages > plP->plNPages)
  {
    rc = EINVAL;
    goto exit;
  }

  /* For each page to unmap, decrement its reference count and clear the
     pointer to it */
  nPagesLeft = nPages;
  while (nPagesLeft > 0)
  {
    /* Walk page list according to its structure */
    switch (plP->plNLevel)
    {
      case 0:
        pagePP = (struct page **)&plP->plRootP;
        pageP = *pagePP;
        *pagePP = NULL;
        break;

      case 1:
        DBGASSERT(plP->plRootP != NULL);
        pagePP = &(((struct page **)plP->plRootP)[pageIndex]);
        pageP = *pagePP;
        *pagePP = NULL;
        break;

      case 2:
        DBGASSERT(plP->plRootP != NULL);
        midIndex = pageIndex / RADIX_PAGE_FANOUT;
        leafIndex = pageIndex % RADIX_PAGE_FANOUT;
        midP = ((void**)plP->plRootP)[midIndex];
        if (midP == NULL)
          pageP = NULL;
        else
        {
          pagePP = &(((struct page **)midP)[leafIndex]);
          pageP = *pagePP;
          *pagePP = NULL;
        }
        break;
    }

    /* Release the page */
    if (pageP != NULL)
    {
      TRACE3(TRACE_SHARED, 12, TRCID_FORGET_DETAIL,
             "cxiReleaseAndForgetPages: release page 0x%lX index %d uaddr 0x%lX\n",
             pageP, pageIndex, uaddr);
      page_cache_release(pageP);
    }

    /* Update for next loop iteration */
    pageIndex += 1;
    nPagesLeft -= 1;
    uaddr += PAGE_SIZE;
  }
  rc = 0;

exit:
#ifdef PAGE_ALIGN_DEBUG
  DBGASSERT(!(uaddr & (PAGE_SIZE-1)));
#endif
  EXIT(0);
  return rc;
}

/* Map a buffer described by iovP in memory, in preparation for
   doing an IO.  This is needed in the DIO path, when the
   buffer passed to us by the user application is used directly
   for submitting an IO request. */
int cxiMapUserBuffer(const struct cxiIovec_t* iovP, size_t len,
                     struct cxiPageList_t** plPP)
{
  int rc = 0;
  struct cxiPageList_t* plP;
  int pinPages;
  char *pinBase;

  ENTER(0);

  /* Make sure we have a pointer to mm_struct */
  if (current->mm == NULL)
  {
     plP = NULL;
     rc = ENOMEM;
     goto exit;
  }

  /* We can only map in multiples of a page, so round up the
     length that we actually mapn to a page boundary.  The I/O
     length could be shorter. */
  pinBase = (char *)((UIntPtr)iovP->iov_base & ~(PAGE_SIZE-1));
  pinPages = ROUNDUP(len + iovP->iov_base - pinBase, PAGE_SIZE) / PAGE_SIZE;
  plP = cxiAllocPageList(pinPages, (UIntPtr)pinBase);
  if (plP == NULL)
  {
     rc = ENOMEM;
     goto exit;
  }
  rc = cxiMapAndRecordPages(plP, (UIntPtr)pinBase, pinPages);
  if (rc != 0)
  {
    cxiDeallocPageList(plP);
    plP = NULL;
    goto exit;
  }

exit:
  *plPP = plP;
  EXIT(0);
  return rc;
}

/* Given a page list object and a user buffer address that is contained
   within the area described by the page list, copy the addresses of
   the struct page objects describing the buffer into the given array
   pagePP.  It is a fatal error if the user buffer is not completely
   contained within the area described by the page list. */
void cxiGetPagePtrs(struct cxiPageList_t* plP, UIntPtr uaddr,
                    int nPages, struct page ** pagePP)
{
  struct page ** srcPagePP = NULL;
  void * midP;
  struct page * pageP;
  int pageIndex;
  int nPagesLeft;
  int nPagesThisChunk = 0;
  int midIndex;
  int leafIndex;
  int i;

  ENTER(0);
  TRACE4(TRACE_SHARED, 5, TRCID_GET_PAGEPTRS,
         "cxiGetPagePtrs: plP 0x%lX uaddr 0x%lX nPages %d pagePP 0x%lX\n",
         plP, uaddr, nPages, pagePP);

  /* Validate parameters */
  LOGASSERT(uaddr >= plP->plBaseAddr);
  pageIndex = (uaddr - plP->plBaseAddr) / PAGE_SIZE;
  LOGASSERT(pageIndex+nPages <= plP->plNPages);
  nPagesLeft = nPages;
  while (nPagesLeft > 0)
  {
    /* Compute address of next saved struct page pointer */
    switch (plP->plNLevel)
    {
      case 0:
        nPagesThisChunk = 1;
        srcPagePP = (struct page **)&plP->plRootP;
        break;

      case 1:
        LOGASSERT(plP->plRootP != NULL);
        nPagesThisChunk = nPagesLeft;
        srcPagePP = &(((struct page **)plP->plRootP)[pageIndex]);
        break;

      case 2:
        LOGASSERT(plP->plRootP != NULL);
        midIndex = pageIndex / RADIX_PAGE_FANOUT;
        leafIndex = pageIndex % RADIX_PAGE_FANOUT;
        midP = ((void**)plP->plRootP)[midIndex];
        LOGASSERT(midP != NULL);
        nPagesThisChunk = MIN(nPagesLeft, RADIX_PAGE_FANOUT-leafIndex);
        srcPagePP = &(((struct page **)midP)[leafIndex]);
        break;
    }

    /* Copy page pointers to target array */
    for (i=0; i<nPagesThisChunk; i++)
    {
      pageP = srcPagePP[i];
      TRACE4(TRACE_SHARED, 12, TRCID_GET_PAGEPTRS_DETAILS,
             "cxiGetPagePtrs: plP 0x%lX i %d/%d pageP 0x%lX\n",
             plP, i, nPagesThisChunk, pageP);
      pagePP[i] = pageP;
    }

    /* Update for next loop iteration */
    pagePP += nPagesThisChunk;
    pageIndex += nPagesThisChunk;
    nPagesLeft -= nPagesThisChunk;
  }
  EXIT(0);
}


/* Release all pages covered by the given page list, then free all kernel
   storage associated with managing the list */
void cxiDeallocPageList(struct cxiPageList_t* plP)
{
  int nMidPtrs;
  int i;
  void * midP;

  TRACE1(TRACE_SHARED, 2, TRCID_DEALLOC_PAGE_LIST,
         "cxiDeallocPageList: plP 0x%lX\n", plP);

  /* Release all pages on this page list */
  ENTER(0);
  (void)cxiReleaseAndForgetPages(plP, plP->plBaseAddr, plP->plNPages);

  /* Free all levels of the radix tree */
  switch (plP->plNLevel)
  {
    case 0:
      break;

    case 1:
      DBGASSERT(plP->plRootP != NULL);
      kfree(plP->plRootP);
      plP->plRootP = NULL;
      break;

    case 2:
      nMidPtrs = (plP->plNPages+RADIX_PAGE_FANOUT-1) / RADIX_PAGE_FANOUT;
      for (i=0; i<nMidPtrs; i++)
      {
        midP = ((void**)plP->plRootP)[i];
        if (midP != NULL)
          kfree(midP);
      }
      kfree(plP->plRootP);
      plP->plRootP = NULL;
      break;
  }

  /* Free the cxiPageList_t itself */
  plP->plNPages = -1;
  kfree(plP);
  EXIT(0);
}


/* Attach an I/O buffer to the kernel's virtual address space.  The
   cxiIOBufferAttachment_t returned in *attachP must be used as a parameter of
   most of the other operations on cxiIOBuffer_t's. */

/* BUFMGR_SCATTER: if the IO buffer (iobP) has more than one memory
   descriptor, we'll handle the additional memory descriptors later
   when we actually use the cxiIOBufferAttachment_t. */
void 
cxiAttachIOBuffer(struct cxiIOBuffer_t* iobP,
                  cxiXmem_t* xmemDescP,
                  struct cxiIOBufferAttachment_t* attachP)
{
  int rc;

  /* Use the cxiPageList_t as the attachment data. */
  attachP->pageListP = (struct cxiPageList_t*)xmemDescP->pageListP;
  DBGASSERT(attachP->pageListP != NULL);
#ifndef BUFMGR_SCATTER
  DBGASSERT(iobP->nDesc == 1);
#endif
  TRACE2(TRACE_KSVFS, 11, TRCID_ATTACH_KIBD,
         "cxiAttachIOBuffer: nDesc %d plP 0x%lX\n",
         iobP->nDesc, attachP->pageListP);
  EXIT(0);
}


/* Detach a buffer from the kernel's virtual address space. */
void 
cxiDetachIOBuffer(struct cxiIOBuffer_t* iobP,
                  struct cxiIOBufferAttachment_t* attachP)
{
  /* Validate attachment data */
  ENTER(0);
  TRACE2(TRACE_KSVFS, 5, TRCID_DETACH_KIBD,
         "cxiDetachIOBuffer: dataPtr 0x%lX plP 0x%lX\n",
         iobP->daemonBufP, attachP->pageListP);
  if (attachP->pageListP == NULL)
  {
    EXIT(0);
    return;
  }

  /* Invalidate attachment data */
  attachP->pageListP = NULL;
  EXIT(0);
}


/* Map an I/O buffer page into the kernel's address space */
static char *kmapPage(struct cxiPageList_t* plP, char *dataAddrP,
                      struct page **pagePP)
{
#ifdef DATA_IN_INODE
  /* If the buffer is in the shared segment, then we don't have to kmap it,
     but we must swizzle the address since the pointer in the cxiIOBuffer_t
     object is a daemon address.  They necessary offset is kept in the
     plBaseAddr of the special page list for the shared segment
     (ssegPageList). */
  if (plIsInMALLOC(plP))
  {
    TRACE3(TRACE_KSVFS, 12, TRCID_KMAP_PAGE,
           "kmapPage: map sseg plP 0x%lX dataAddrP 0x%lX baseAddr 0x%lX",
           plP, dataAddrP, plP->plBaseAddr);
    *pagePP = NULL;
    return (char *)(UINTPTR(dataAddrP - plP->plBaseAddr) & PAGE_MASK);
  }
#endif
  cxiGetPagePtrs(plP, (unsigned long)dataAddrP, 1, pagePP);
  return (*pagePP == NULL) ? NULL : kmap(*pagePP);
}


/* Unmap a buffer page that was previously mapped using kmapPage */
static void kunmapPage(struct page *pageP)
{
  if (pageP != NULL)
    kunmap(pageP);
}


/* Transfer len bytes beginning at offset bufOffset within I/O buffer *iobP
   to or from a user buffer.  The direction of the transfer is given with
   respect to the I/O buffer.  Returns EOK if successful, other error
   codes if unsuccessful. */
IntRC 
cxiUXfer(struct cxiIOBuffer_t* iobP, Boolean toIOBuffer,
         const struct cxiIOBufferAttachment_t* attachP,
         void* vkopP, int bufOffset, int len, struct cxiUio_t* uioP)
{
  char* dataAddrP;
  struct cxiPageList_t* plP = attachP->pageListP;
  unsigned long pageOffset;
  struct page * pageP;
  int pageLen;
  char *kaddrP;
  unsigned long kaddr;
  int rc = 0;
  int currOffset, currLen, tmpLen, nDesc;
  struct cxiMemoryDesc_t* descP;
  struct cxiMemoryMapping_t* memMapP;

  ENTER(0);
  /* Validate parameters */
  TRACE6(TRACE_KSVFS, 5, TRCID_UXFER_LINUX,
         "cxiUXfer: nDesc %d 1st dataPtr 0x%lX plP 0x%lX toIOBuf %d "
         "offset %d len %d\n",
         iobP->nDesc, iobP->daemonBufP, plP, toIOBuffer, bufOffset, len);

  DBGASSERT(bufOffset >= 0);
  DBGASSERT(bufOffset+len <= iobP->ioBufLen);

  dataAddrP = iobP->daemonBufP + bufOffset;
  pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
  pageLen = PAGE_SIZE - pageOffset;

  /* Transfer data in or out of as many pages as necessary to satisfy
     the data move request */
  if (iobP->nDesc <= 1)
  {
    /* Fast path for non-scatter buffers */
    DBGASSERT(iobP->ioBufLen/PAGE_SIZE <= plP->plNPages);

    for (;;)
    {
      /* Calculate how many bytes to move in or out of the current page of the
         I/O buffer */
      if (len < pageLen)
        pageLen = len;

      /* Map current I/O buffer page into the kernel's address space
         temporarily, then copy data in or out of the page */
      kaddrP = kmapPage(plP, dataAddrP, &pageP);
      TRACE4(TRACE_KSVFS, 12, TRCID_UXFER_UIOMOVE,
             "cxiUXfer: uiomove kaddr 0x%lX pageOffset %d pageLen %d pageP 0x%lX\n",
             kaddrP, pageOffset, pageLen, pageP);

      rc = cxiUiomove(kaddrP + pageOffset, pageLen, toIOBuffer, uioP);
      kunmapPage(pageP);

      /* Leave loop if an error occurred on the move */
      if (rc != 0)
        break;

      /* Update length left to copy and test for loop termination */
      len -= pageLen;
      if (len <= 0)
        break;

      /* Set up for next iteration */
      pageOffset = 0;
      dataAddrP += pageLen;
      pageLen = PAGE_SIZE;
    }  /* end of do forever */
  }
  else
  {
    DBGASSERT(iobP->hDescP != NULL);

    descP = iobP->hDescP;
    DBGASSERT(IN_DIO_USER_BUFFER(descP) == false);

    rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
    if (rc != 0)
      goto exit;

    /* The daemon address of the 1st memory descriptor should be cached in
       the IO buffer and the page list ptr for the 1st memory descriptor should
       be cached in teh IO attachment data */
    DBGASSERT(iobP->daemonBufP == memMapP->vaddr + descP->offset);
    DBGASSERT(attachP->pageListP == memMapP->xmemDesc.pageListP);

    currOffset = 0;
    nDesc = 0;
    for (;;)
    {
      DBGASSERT(descP != NULL);
      DBGASSERT(memMapP != NULL);

      dataAddrP = memMapP->vaddr + descP->offset;
      tmpLen = currLen = GETLEN_BYTES(descP);

      /* if starting buffer offset is not in this scatter entry,
         then move to the next one */
      if (bufOffset >= currOffset + currLen)
      {
        TRACE5(TRACE_KSVFS, 6, TRCID_UXFER_SKIP_SCATTER,
               "cxiUXfer: ndesc %d skip dataAddrP 0x%lX currOffset %d "
               "currLen %d bufOffset %d\n",
               nDesc, dataAddrP, currOffset,
               currLen, bufOffset);
      }
      else
      {
        plP = memMapP->xmemDesc.pageListP;

        DBGASSERT(plP != NULL);
        DBGASSERT(currLen/PAGE_SIZE <= plP->plNPages);

        if (bufOffset > currOffset)
        {
          dataAddrP = dataAddrP + bufOffset - currOffset;
          currLen = currLen + currOffset - bufOffset;
        }

        pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
        pageLen = PAGE_SIZE - pageOffset;

        TRACE8(TRACE_KSVFS, 6, TRCID_UXFER_DESC_SCATTER,
               "cxiUXfer: nDesc %d currOffset %d tmpLen %d "
               "dataAddrP 0x%lX currLen %d pageOffset %d pageLen %d plP 0x%lX\n",
               nDesc, currOffset, tmpLen,
               dataAddrP, currLen, pageOffset, pageLen, plP);

        for (;;)
        {
          /* Calculate how many bytes to move in or out of the current page of the
             I/O buffer */
          if (len < pageLen)
            pageLen = len;

          /* A scatter buffer size may be smaller than page size */
          if (currLen < pageLen)
            pageLen = currLen;

          /* Map current I/O buffer page into the kernel's address space
             temporarily, then copy data in or out of the page */
          cxiGetPagePtrs(plP, (unsigned long)dataAddrP, 1, &pageP);
          kaddr = (unsigned long)kmap(pageP);
          TRACE7(TRACE_KSVFS, 12, TRCID_UXFER_UIOMOVE_SCATTER,
                 "cxiUXfer: nDesc %d uiomove kaddr 0x%lX pageOffset %d pageLen %d "
                 "currLen %d len %d pageP 0x%lX\n",
                 nDesc, kaddr, pageOffset, pageLen,
                 currLen, len, pageP);

          rc = cxiUiomove((char *)(kaddr + pageOffset), pageLen, toIOBuffer, uioP);
          kunmap(pageP);

          /* Leave loop if an error occurred on the move */
          if (rc != 0)
            goto exit;

          /* Update length left to copy and test for loop termination */
          len -= pageLen;
          if (len <= 0)
            goto exit;

          currLen -= pageLen;
          if (currLen <= 0)
            break;

          /* Set up for next iteration */
          pageOffset = 0;
          dataAddrP += pageLen;
          pageLen = PAGE_SIZE;
        }  /* end of do forever */
      }

      descP = descP->nextP;
      rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
      if (rc != 0)
        goto exit;
      currOffset = currOffset + tmpLen;
      nDesc++;
    }
  }
exit:
  EXIT(0);
  return rc;
}


/* Perform cross-memory transfer of len bytes from user memory in current
   task to memory in specified address space.  If toXmem is true then
   copy is from userAddrP to udataP/xmemP, otherwise the opposite. */
IntRC 
cxiXmemXfer(char *userAddrP, int len, char *xdataP, cxiXmem_t* xmemP,
            Boolean toXmem)
{
  int rc = 0;
  int pageOffset, pageLen;
  char *kaddrP;
  struct page *pageP;
  struct cxiPageList_t* plP = (struct cxiPageList_t*)xmemP->pageListP;

  ENTER(0);
  TRACE5(TRACE_KSVFS, 5, TRCID_XMEMXFER_LINUX,
         "cxiXmemXfer: userAddrP 0x%lX len %d xdataP 0x%lX "
         "plP 0x%lX toXmem %d\n",
         userAddrP, len, xdataP, plP, toXmem);

  /* Transfer data in or out of as many pages as necessary to satisfy
     the data move request */
  pageOffset = ((unsigned long)xdataP - plP->plBaseAddr) % PAGE_SIZE;
  pageLen = PAGE_SIZE - pageOffset;
  for (;;)
  {
    /* Calculate how many bytes to move in or out of the current page of the
       I/O buffer */
    if (len < pageLen)
      pageLen = len;

    /* Map current I/O buffer page into the kernel's address space
       temporarily, then copy data in or out of the page */
    kaddrP = kmapPage(plP, xdataP, &pageP);
    TRACE4(TRACE_KSVFS, 12, TRCID_XMEMFER_COPY,
           "cxiXmemXfer: copy kaddrP 0x%lX pageOffset %d pageLen %d pageP 0x%lX\n",
           kaddrP, pageOffset, pageLen, pageP);

    if (toXmem)
      rc = cxiCopyIn(userAddrP, (char *)kaddrP + pageOffset, pageLen);
    else
      rc = cxiCopyOut((char *)kaddrP + pageOffset, userAddrP, pageLen);

    kunmapPage(pageP);

    /* Leave loop if an error occurred on the move */
    if (rc != 0)
      break;

    /* Update length left to copy and test for loop termination */
    len -= pageLen;
    if (len <= 0)
      break;

    /* Set up for next iteration */
    userAddrP += pageLen;
    xdataP += pageLen;
    pageOffset = 0;
    pageLen = PAGE_SIZE;
  }  /* end of do forever */

  EXIT(0);
  return rc;
}

#ifdef ZIP
/* Compress data residing in two contiguous kernel buffers, prefix and inBufP.
   Store the uncompressed data in outBufP.  The caller needs to ensure that the 
   outLen is exactly the same as the size of the uncompress data. */
IntRC 
cxiKUncompress(char* prefix, int prefixLen, char* inBufP, int inLen, char* outBufP, int outLen, int* avail_out)
{
  z_stream strm;
  int ret = 0, ret2;

  ENTER(0);
  
  // printk(KERN_WARNING "cxiKXfer: prefix 0x%p prefixLen %d inBufP 0x%p inLen %d, outBufP 0x%p outLen %d\n",
         // prefix, prefixLen, inBufP, inLen, outBufP, outLen);  change this to trace

  *avail_out = 0;

  strm.total_out = 0;
  strm.next_out = outBufP;
  strm.avail_out = outLen;

  if (prefixLen > 0)
  {
    strm.next_in = prefix;
    strm.avail_in = prefixLen; 
  }

  strm.workspace = vzalloc(zlib_inflate_workspacesize());
  if (!strm.workspace)
    return -ENOMEM;

  if (Z_OK != zlib_inflateInit2(&strm, -MAX_WBITS))
  {
    vfree(strm.workspace);
    strm.workspace = NULL;
    return -EINVAL;
  }   

  if (prefixLen > 0)
  {
    ret = zlib_inflate(&strm, Z_NO_FLUSH);
    if (ret != Z_OK && ret != Z_STREAM_END)
    {
      ret = -1;
      goto done;
    }
  }

  strm.avail_in = inLen; 
  strm.next_in = inBufP;
  ret = zlib_inflate(&strm, 0 /*Z_NO_FLUSH */);
  if (ret != Z_OK && ret != Z_STREAM_END)
  {
    ret = -1;
    goto done;
  }

  *avail_out = strm.total_out;

  if (strm.total_out > outLen)
  {
    // printk(KERN_WARNING "cxiKUncompress: strm.total_out = %lu, outLen = %d\n", strm.total_out, outLen);
    ret = -1;
  }
  else
    ret = 0;
done:
  if (strm.workspace) {
    zlib_inflateEnd(&strm);
    vfree(strm.workspace);
    strm.workspace = NULL;
  }

  return ret;
  EXIT(0);
}

#endif

/* Transfer len bytes beginning at offset bufOffset within I/O buffer *iobP
   to or from a contiguous kernel buffer.  The direction of the transfer
   is given with respect to the I/O buffer.  Returns EOK if successful,
   other error codes if unsuccessful. */
IntRC 
cxiKXfer(struct cxiIOBuffer_t* iobP, Boolean toIOBuffer,
         const struct cxiIOBufferAttachment_t* attachP,
         int bufOffset, int len, char* kBufP)
{
  char* dataAddrP;
  struct cxiPageList_t* plP = attachP->pageListP;
  unsigned long pageOffset;
  struct page * pageP;
  int pageLen;
  unsigned long kaddr;
  int rc = 0;
  int currOffset, currLen, tmpLen, nDesc;
  struct cxiMemoryDesc_t* descP;
  struct cxiMemoryMapping_t* memMapP;
  char *kaddrP;

  ENTER(0);
  /* Validate parameters */
  TRACE7(TRACE_KSVFS, 5, TRCID_KXFER_LINUX,
         "cxiKXfer: nDesc %d 1st dataPtr 0x%lX plP 0x%lX "
         "toIOBuf %d offset %d len %d kBufP 0x%lX\n",
         iobP->nDesc, iobP->daemonBufP, plP,
         toIOBuffer, bufOffset, len, kBufP);

  DBGASSERT(bufOffset >= 0);
  DBGASSERT(bufOffset+len <= iobP->ioBufLen);

  /* Transfer data in or out of as many pages as necessary to satisfy
     the data move request */
  if (iobP->nDesc <= 1)
  {
    /* Fast path for non-scatter buffers */
    DBGASSERT(iobP->ioBufLen/PAGE_SIZE <= plP->plNPages);

    dataAddrP = iobP->daemonBufP + bufOffset;
    pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
    pageLen = PAGE_SIZE - pageOffset;
    for (;;)
    {
      /* Calculate how many bytes to move in or out of the current page of the
         I/O buffer */
      if (len < pageLen)
        pageLen = len;

      /* Map current I/O buffer page into the kernel's address space
         temporarily, then copy data in or out of the page */
      kaddrP = kmapPage(plP, dataAddrP, &pageP);
      TRACE4(TRACE_KSVFS, 12, TRCID_KXFER_MEMCPY,
             "cxiKXfer: move kaddr 0x%lX pageOffset %d pageLen %d pageP 0x%lX\n",
             kaddrP, pageOffset, pageLen, pageP);

      if (toIOBuffer)
        memcpy(kaddrP + pageOffset, kBufP, pageLen);
      else
        memcpy(kBufP, kaddrP + pageOffset, pageLen);
      kunmapPage(pageP);

      /* Update length left to copy and test for loop termination */
      len -= pageLen;
      if (len <= 0)
        break;

      /* Set up for next iteration */
      dataAddrP += pageLen;
      kBufP += pageLen;
      pageOffset = 0;
      pageLen = PAGE_SIZE;
    }  /* end of do forever */
  }
  else
  {
    DBGASSERT(iobP->hDescP != NULL);
    descP = iobP->hDescP;
    DBGASSERT(IN_DIO_USER_BUFFER(descP) == false);

    rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
    if (rc != 0)
      goto exit;

    /* The daemon address of the 1st memory descriptor should be cached in
       the IO buffer and the page list ptr for 1st memory descriptor should
       be cached in the IO attachment data */
    DBGASSERT(iobP->daemonBufP == memMapP->vaddr + descP->offset);
    DBGASSERT(attachP->pageListP == memMapP->xmemDesc.pageListP);

    currOffset = 0;
    nDesc = 0;
    for (;;)
    {
      DBGASSERT(descP != NULL);
      DBGASSERT(memMapP != NULL);

      dataAddrP = memMapP->vaddr + descP->offset;
      tmpLen = currLen = GETLEN_BYTES(descP);

      /* if starting buffer offset is not in this scatter entry,
         then move to the next one */
      if (bufOffset >= currOffset + currLen)
      {
        TRACE5(TRACE_KSVFS, 6, TRCID_KXFER_SKIP_SCATTER,
               "cxiKXfer: ndesc %d skip dataAddrP 0x%lX currOffset %d "
               "currLen %d bufOffset %d\n",
               nDesc, dataAddrP, currOffset,
               currLen, bufOffset);
      }
      else
      {
        plP = memMapP->xmemDesc.pageListP;

        DBGASSERT(plP != NULL);
        DBGASSERT(currLen/PAGE_SIZE <= plP->plNPages);

        if (bufOffset > currOffset)
        {
          dataAddrP = dataAddrP + bufOffset - currOffset;
          currLen = currLen + currOffset - bufOffset;
        }

        pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
        pageLen = PAGE_SIZE - pageOffset;

        TRACE8(TRACE_KSVFS, 6, TRCID_KXFER_DESC_SCATTER,
               "cxiKXfer: nDesc %d currOffset %d tmpLen %d "
               "dataAddrP 0x%lX currLen %d pageOffset %d pageLen %d plP 0x%lX\n",
               nDesc, currOffset, tmpLen,
               dataAddrP, currLen, pageOffset, pageLen, plP);

        for (;;)
        {
          /* Calculate how many bytes to move in or out of the current page of the
             I/O buffer */
          if (len < pageLen)
            pageLen = len;

          /* A scatter buffer size may be smaller than page size */
          if (currLen < pageLen)
            pageLen = currLen;

          /* Map current I/O buffer page into the kernel's address space
             temporarily, then copy data in or out of the page */
          cxiGetPagePtrs(plP, (unsigned long)dataAddrP, 1, &pageP);
          kaddr = (unsigned long)kmap(pageP);
          TRACE5(TRACE_KSVFS, 12, TRCID_KXFER_MEMCPY_SCATTER,
                 "cxiKXfer: nDesc %d move kaddr 0x%lX pageOffset %d "
                 "pageLen %d pageP 0x%lX\n",
                 nDesc, kaddr, pageOffset, pageLen, pageP);

          if (toIOBuffer)
            memcpy((void *)(kaddr + pageOffset), kBufP, pageLen);
          else
            memcpy(kBufP, (void *)(kaddr + pageOffset), pageLen);
          kunmap(pageP);

          kBufP += pageLen;

          /* Update length left to copy and test for loop termination */
          len -= pageLen;
          if (len <= 0)
            goto exit;

          currLen -= pageLen;
          if (currLen <= 0)
            break;

          /* Set up for next iteration */
          dataAddrP += pageLen;
          pageOffset = 0;
          pageLen = PAGE_SIZE;
        }  /* end of do forever */
      }

      descP = descP->nextP;
      rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
      if (rc != 0)
        goto exit;
      currOffset = currOffset + tmpLen;
      nDesc++;
    }
  }
exit:
  EXIT(0);
  return rc;
}

/* Set len bytes beginning at offset bufOffset within I/O buffer *iobP
   to zero.  Returns EOK if successful, other error codes if unsuccessful. */
IntRC 
cxiKZero(struct cxiIOBuffer_t* iobP,
         const struct cxiIOBufferAttachment_t* attachP,
         int bufOffset, int len)
{
  struct cxiPageList_t* plP = attachP->pageListP;
  char* dataAddrP;
  unsigned long pageOffset;
  struct page * pageP;
  int pageLen;
  unsigned long kaddr;
  int currOffset, currLen, tmpLen, nDesc;
  struct cxiMemoryDesc_t* descP;
  struct cxiMemoryMapping_t* memMapP;
  char *kaddrP;
  int rc;

  ENTER(0);
  /* Validate parameters */
  TRACE5(TRACE_KSVFS, 5, TRCID_KZERO_LINUX,
         "cxiKZero: nDesc %d 1st dataPtr 0x%lX plP 0x%lX offset %d len %d\n",
         iobP->nDesc, iobP->daemonBufP, plP, bufOffset, len);

  DBGASSERT(bufOffset >= 0);
  DBGASSERT(bufOffset+len <= iobP->ioBufLen);

  /* Zero data in as many pages as necessary to complete the request */
  if (iobP->nDesc <= 1)
  {
    /* Fast path for non-scatter buffers */
    DBGASSERT(iobP->ioBufLen/PAGE_SIZE <= plP->plNPages);
    dataAddrP = iobP->daemonBufP + bufOffset;
    pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
    pageLen = PAGE_SIZE - pageOffset;
    for (;;)
    {
      /* Calculate how many bytes to zero in the current page of the I/O
         buffer */
      if (len < pageLen)
        pageLen = len;

      /* Map current I/O buffer page into the kernel's address space
         temporarily, then zero data in the page */
      kaddrP = kmapPage(plP, dataAddrP, &pageP);
      TRACE4(TRACE_KSVFS, 12, TRCID_KZERO_MEMSET,
             "cxiKZero: zero kaddr 0x%lX pageOffset %d pageLen %d pageP 0x%lX\n",
             kaddrP, pageOffset, pageLen, pageP);
      memset(kaddrP + pageOffset, 0, pageLen);
      kunmapPage(pageP);

      /* Update length left to zero and test for loop termination */
      len -= pageLen;
      if (len <= 0)
        break;

      /* Set up for next iteration */
      dataAddrP += pageLen;
      pageOffset = 0;
      pageLen = PAGE_SIZE;
    }  /* end of do forever */
  }
  else
  {
    DBGASSERT(iobP->hDescP != NULL);
    descP = iobP->hDescP;
    DBGASSERT(IN_DIO_USER_BUFFER(descP) == false);

    rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
    if (rc != 0)
      goto exit;

    /* The daemon address of the 1st memory descriptor should be cached in
       the IO buffer and the page list ptr for 1st memory descriptor should
       be cached in teh IO attachment data */
    DBGASSERT(iobP->daemonBufP == memMapP->vaddr + descP->offset);
    DBGASSERT(attachP->pageListP == memMapP->xmemDesc.pageListP);

    currOffset = 0;
    nDesc = 0;
    for (;;)
    {
      DBGASSERT(descP != NULL);
      DBGASSERT(memMapP != NULL);

      dataAddrP = memMapP->vaddr + descP->offset;
      tmpLen = currLen = GETLEN_BYTES(descP);

      /* if starting buffer offset is not in this scatter entry,
         then move to the next one */
      if (bufOffset >= currOffset + currLen)
      {
        TRACE5(TRACE_KSVFS, 6, TRCID_KZERO_SKIP_SCATTER,
               "cxiKZero: ndesc %d skip dataAddrP 0x%lX currOffset %d "
               "currLen %d bufOffset %d\n",
               nDesc, dataAddrP, currOffset,
               currLen, bufOffset);
      }
      else
      {
        plP = memMapP->xmemDesc.pageListP;

        DBGASSERT(plP != NULL);
        DBGASSERT(currLen/PAGE_SIZE <= plP->plNPages);

        if (bufOffset > currOffset)
        {
          dataAddrP = dataAddrP + bufOffset - currOffset;
          currLen = currLen + currOffset - bufOffset;
        }

        pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
        pageLen = PAGE_SIZE - pageOffset;

        TRACE8(TRACE_KSVFS, 6, TRCID_KZERO_DESC_SCATTER,
               "cxiKZero: nDesc %d currOffset %d tmpLen %d "
               "dataAddrP 0x%lX currLen %d pageOffset %d pageLen %d plP 0x%lX\n",
               nDesc, currOffset, tmpLen,
               dataAddrP, currLen, pageOffset, pageLen, plP);

        for (;;)
        {
          /* Calculate how many bytes to move in or out of the current page of the
             I/O buffer */
          if (len < pageLen)
            pageLen = len;

          /* A scatter buffer size may be smaller than page size */
          if (currLen < pageLen)
            pageLen = currLen;

          /* Map current I/O buffer page into the kernel's address space
             temporarily, then copy data in or out of the page */
          cxiGetPagePtrs(plP, (unsigned long)dataAddrP, 1, &pageP);
          kaddr = (unsigned long)kmap(pageP);
          TRACE5(TRACE_KSVFS, 12, TRCID_KZERO_MEMSET_SCATTER,
                 "cxiKZero: nDesc %d zero kaddr 0x%lX pageOffset %d "
                 "pageLen %d pageP 0x%lX\n",
                 nDesc, kaddr, pageOffset, pageLen, pageP);
          memset((void *)(kaddr + pageOffset), 0, pageLen);
          kunmap(pageP);

          /* Update length left to copy and test for loop termination */
          len -= pageLen;
          if (len <= 0)
            goto exit;

          currLen -= pageLen;
          if (currLen <= 0)
            break;

          /* Set up for next iteration */
          dataAddrP += pageLen;
          pageOffset = 0;
          pageLen = PAGE_SIZE;
        }  /* end of do forever */
      }
      descP = descP->nextP;
      rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
      if (rc != 0)
        goto exit;
      currOffset = currOffset + tmpLen;
      nDesc++;
    }
  }
exit:
  EXIT(0);
  return 0;
}

/* Map an I/O buffer so it can be read and written from kernel code
   running in the context of a user thread.  Depending on the platform, the
   addresses at which the I/O buffer gets mapped may not be contiguous.  The
   details of how the buffer got mapped are handled by the
   cxiDiscontiguousDirectoryBuffer_t object that is filled in by this call.
   On some platforms, mapping buffers using this call consumes scarce
   resources, so all cxiMapDiscontiguousRW calls should be promptly matched by
   cxiUnmapDiscontiguousRW calls as soon as the operation that required access
   to the I/O buffer completes.  Returns 0 if successful, other error codes
   if unsuccessful. */
IntRC 
cxiMapDiscontiguousRW(struct cxiIOBuffer_t* iobP,
                      const struct cxiIOBufferAttachment_t* attachP,
                      struct cxiDiscontiguousDirectoryBuffer_t* discontigP)
{
  /* ?? WARNING: Since this must kmap multiple pages, there is the
     possibility of deadlock if multiple threads are part of the way through
     executing this code, and LAST_PKMAP pages (512 or 1024) have already
     been kmapped.  There needs to be flow control whereby threads reserve
     enough pages to complete all of their kmaps before they begin acquiring
     pages. */
  struct cxiPageList_t* plP = attachP->pageListP;
  char* dataAddrP;
  int dirIndex;
  int mapPages;
  struct page * pageP;
  char *kaddrP;
  unsigned long pageoffSet;

  /* __CXI_BUFFERS_ARE_CONTIGUOUS is not #defined */

  /* Validate parameters */
  ENTER(0);
  TRACE4(TRACE_KSVFS, 2, TRCID_MAP_DISCONTIG_ENTER,
         "cxiMapDiscontiguousRW: ndesc %d dataPtr 0x%lX plP 0x%lX ioBufLen 0x%X\n",
         iobP->nDesc, iobP->daemonBufP, plP, iobP->ioBufLen);

  LOGASSERT(iobP->nDesc == 1);
  /* The mappable buffer memory may be longer than a directory block */
  mapPages = (iobP->ioBufLen + DISCONTIG_PAGE_SIZE - 1) / DISCONTIG_PAGE_SIZE;
  mapPages = MIN(mapPages, MAX_PAGES_PER_DIRBLOCK);

  pageoffSet = (unsigned long)iobP->daemonBufP % DISCONTIG_PAGE_SIZE;
  dataAddrP = iobP->daemonBufP - pageoffSet;
  /* Must be page aligned if more than 1 page */
  DBGASSERT(mapPages == 1 || pageoffSet == 0);
  for (dirIndex=0 ; dirIndex<mapPages ; dirIndex++)
  {
    kaddrP = kmapPage(plP, dataAddrP, &pageP);
    if (pageP == NULL
#ifdef DATA_IN_INODE
        && !plIsInMALLOC(plP)
#endif
        )
      break;

    TRACE4(TRACE_KSVFS, 12, TRCID_MAP_DISCONTIG_KMAP,
           "cxiMapDiscontiguousRW: dirIndex %d pageP 0x%lX kaddr 0x%lX pageoffSet 0x%lX\n",
           dirIndex, pageP, kaddrP, pageoffSet);

    DBGASSERT(dirIndex < MAX_PAGES_PER_DIRBLOCK);
    discontigP->userPagePointerArray[dirIndex] = kaddrP + pageoffSet;
    discontigP->osPagePointerArray[dirIndex] = (void*)pageP;

    dataAddrP += PAGE_SIZE;
  }

  discontigP->mappedLen = dirIndex * DISCONTIG_PAGE_SIZE;
  EXIT(0);
  return 0;
}


/* Unmap an I/O buffer previously mapped */
void 
cxiUnmapDiscontiguousRW(struct cxiIOBuffer_t* iobP,
                        struct cxiDiscontiguousDirectoryBuffer_t* discontigP)
{
  int checkPageIndex;
  struct page * pageP;
  int mappedPages;

  ENTER(0);
  TRACE4(TRACE_KSVFS, 4, TRCID_UNMAP_DISCONTIG_ENTER,
         "cxiUnmapDiscontiguousRW: nDesc %d dataPtr 0x%lX ioBufLen 0x%X mappedLen %d\n",
         iobP->nDesc, iobP->daemonBufP, iobP->ioBufLen, discontigP->mappedLen);

  /* Unmap all pages in discontiguous map.  If the osPagePointerArray entry
   * is NULL, it means that the last mapping was made via MapContiguousBuffer,
   * which did not do any kmaps that need to be kunmap'ped. 
   */
  mappedPages = (discontigP->mappedLen + DISCONTIG_PAGE_SIZE - 1) /
                DISCONTIG_PAGE_SIZE;

  for (checkPageIndex = 0; checkPageIndex < mappedPages; checkPageIndex++)
  {
    pageP = (struct page *)discontigP->osPagePointerArray[checkPageIndex];
    TRACE3(TRACE_KSVFS, 12, TRCID_UNMAP_DISCONTIG_KUNMAP,
           "cxiUnmapDiscontiguousRW: unmap checkPageIndex %d pageP 0x%lX "
           "kaddr 0x%lX\n", checkPageIndex, pageP,
           discontigP->userPagePointerArray[checkPageIndex]);

    if (pageP != NULL)
    {
      kunmap(pageP);
      discontigP->osPagePointerArray[checkPageIndex] = NULL;
    }
    discontigP->userPagePointerArray[checkPageIndex] = NULL;
  }
  discontigP->mappedLen = 0;
  EXIT(0);
}

/* Return an address in kernel memory that holds a contigous read-only
   copy of a portion of an I/O buffer.  If possible, this will be a
   mapping of the I/O buffer.  If necessary, this routine will allocate a
   new block of kernel memory and copy the requested data to it.  The
   returned cxiContiguousBuffer_t encapsulates what method was used, so
   that cxiUnmapContiguousRO can release whatever resources were obtained by
   this call.  Returns 0 if successful, other error codes if
   unsuccessful. */
IntRC 
cxiMapContiguousRO(struct cxiIOBuffer_t* iobP,
                   const struct cxiIOBufferAttachment_t* attachP,
                   int bufOffset, int len, const char** contigBasePP,
                   struct cxiContiguousBuffer_t* contigP)
{
  int startPageIndex;
  unsigned long pageOffset;
  char* dataAddrP;
  int endPageIndex;
  struct cxiPageList_t* plP = attachP->pageListP;
  struct page * pageP;
  char *kaddrP;
  char* tempBufP;
  Boolean usedKmalloc;
  int rc;

  /* Validate parameters */
  ENTER(0);
  TRACE6(TRACE_KSVFS, 4, TRCID_MAP_CONTIG_ENTER,
         "cxiMapContiguousRO: nDesc %d dataPtr 0x%lX ioBufLen %d plP 0x%lX bufOffset %d len %d",
         iobP->nDesc, iobP->daemonBufP, iobP->ioBufLen, plP, bufOffset, len);

  LOGASSERT(iobP->nDesc == 1);
  DBGASSERT(bufOffset >= 0);
  DBGASSERT(bufOffset+len <= iobP->ioBufLen);
  DBGASSERT(iobP->ioBufLen/PAGE_SIZE <= plP->plNPages);

  /* If the requested piece of the I/O buffer does not cross a page boundary,
     then map the page and return the mapped address within the page */
  startPageIndex = bufOffset / PAGE_SIZE;
  dataAddrP = iobP->daemonBufP + bufOffset;
  pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
  endPageIndex = (bufOffset+len-1) / PAGE_SIZE;

  TRACE4(TRACE_KSVFS, 5, TRCID_MAP_CONTIG_ENTER_2,
         "cxiMapContiguousRO: startPageIndex %d endPageIndex %d pageOffset 0x%lX dataAddrP 0x%lX\n",
         startPageIndex, endPageIndex, pageOffset, dataAddrP);

  if (startPageIndex == endPageIndex
#ifdef DATA_IN_INODE
      || plIsInMALLOC(plP)
#endif
      )
  {
    /* Map I/O buffer page into the kernel's address space */
    kaddrP = kmapPage(plP, dataAddrP, &pageP);

    /* Return address within the mapped page, and set map state so
       cxiUnmapContiguousRO knows to do kunmap */
    *contigBasePP = kaddrP + pageOffset;
    contigP->mallocedBaseP = NULL;
    contigP->usedKmalloc = false;
    contigP->pageP = pageP;
    TRACE2(TRACE_KSVFS, 5, TRCID_MAP_CONTIG_KMAP,
           "cxiMapContiguousRO: mapped pageP 0x%lX at 0x%lX\n",
           pageP, *contigBasePP);
    EXIT(0);
    return 0;
  }

  /* Otherwise, the requested part of the I/O buffer spans page boundaries.
     Allocate a contiguous buffer, and copy data from the I/O buffer to the
     temporary buffer. */
  else
  {
    if (len <= PAGE_SIZE)
    {
      tempBufP = (char *)kmalloc(len, GFP_KERNEL);
      usedKmalloc = true;
    }
    else
    {
      tempBufP = (char*)vmalloc(len);
      usedKmalloc = false;
    }
    if (tempBufP == NULL)
    {
      EXIT(0);
      return -ENOMEM;
    }
    rc = cxiKXfer(iobP, CXI_XFER_FROM_IOBUFFER, attachP, bufOffset, len,
                  tempBufP);
    if (rc != 0)
    {
      if (usedKmalloc)
        kfree((void*)tempBufP);
      else
        vfree((void*)tempBufP);
      EXIT(0);
      return rc;
    }
#ifdef MALLOC_DEBUG
    MallocDebugNew(tempBufP, len, 4);
#endif

    /* Return address within the contiguous temporary buffer, and set map
       state so cxiUnmapContiguousRO knows to do vfree */
    *contigBasePP = tempBufP;
    contigP->mallocedBaseP = tempBufP;
    contigP->usedKmalloc = usedKmalloc;
    contigP->pageP = NULL;
    TRACE1(TRACE_KSVFS, 5, TRCID_MAP_CONTIG_VMALLOC,
           "cxiMapContiguousRO: copied to 0x%lX\n", tempBufP);
    EXIT(0);
    return 0;
  }
}


/* Release a mapping or copy obtained with cxiMapContiguousRO */
void 
cxiUnmapContiguousRO(struct cxiIOBuffer_t* iobP,
                     struct cxiContiguousBuffer_t* contigP)
{
  ENTER(0);
  if (contigP->mallocedBaseP != NULL)
  {
    TRACE2(TRACE_KSVFS, 4, TRCID_UNMAP_CONTIG_VFREE,
           "cxiUnmapContiguousRO: dataPtr 0x%lX kfree/vfree 0x%lX\n",
           iobP->daemonBufP, contigP->mallocedBaseP);
    DBGASSERT(contigP->pageP == NULL);

    if (contigP->usedKmalloc)
      kfree((void*)contigP->mallocedBaseP);
    else
      vfree((void*)contigP->mallocedBaseP);

#ifdef MALLOC_DEBUG
    MallocDebugDelete(contigP->mallocedBaseP);
#endif
    contigP->mallocedBaseP = NULL;
  }
  else
  {
    TRACE2(TRACE_KSVFS, 4, TRCID_UNMAP_CONTIG_KUNMAP,
           "cxiUnmapContiguousRO: dataPtr 0x%lX kunmap 0x%lX\n",
           iobP->daemonBufP, contigP->pageP);
    kunmapPage((struct page *)contigP->pageP);
    contigP->pageP = NULL;
  }
  EXIT(0);
}

/* Increment ioqNCompleted, and if requested, wake-up the waiter. */
void
cxiSignalCompletion(struct cxiIORendezvous_t* renP, Boolean doWakeUp)
{

  if (doWakeUp)
  {
    unsigned long flags;

    /* We use the aioQueueSpinlock to serialize the wakeup for both the Linux
       AIO case and the non AIO case.  If the cxiIORendezvous_t has more than
       one IO (renP->ioqNDesired > 1), there may be multiple threads executing
       cxiSignalCompletion.  The aioQueueSpinlock will prevent multiple threads
       from executing the IO completion processing when renP->ioqNCompleted
       >= renP->ioqNDesired.

       For the Linux AIO case, the aioQueueSpinlock will prevent multiple
       threads from adding the AIO to the completion queue. PMR 87354,999,724.

       For the non Linux AIO case, the aioQueueSpinlock will prevent multiple
       threads from waking up the thread that is waiting for IO completion.
       The thread waiting for IO completion will free the cxiIORendezvous_t,
       therefore, we can not access renP->ioqWaitQ after the first wakeup. */

    spin_lock_irqsave(&aioQueueSpinlock, flags);

    atomic_inc(&renP->ioqNCompleted);

    /* Wake up waiting thread if there is one and this completion
       satisfies the wait */
    if (atomic_read(&renP->ioqNCompleted) >= atomic_read(&renP->ioqNDesired))
#ifndef GPFS_AIO_PER_CPU
    {
      if (renP->uioaioP)
      {
        struct cxiUioAio_t *uioaioP = renP->uioaioP;
        int rc;

        uioaioP->aioNextP = NULL;

        if (aioQueueHeadP)
          aioQueueTailP->aioNextP = uioaioP;
        else
          aioQueueHeadP = uioaioP;
        aioQueueTailP = uioaioP;

        if (!aioCompletionRunning)
          rc = schedule_work(&aioCompletionQueue);
      }
      else
        wake_up(&renP->ioqWaitQ);
    }
    spin_unlock_irqrestore(&aioQueueSpinlock, flags);
#else
    {
      if (renP->uioaioP)
      {
        struct gpfsPerCpuData_s *cpuDataP;
        struct cxiUioAio_t *uioaioP;
        int cpu = smp_processor_id();

        uioaioP = renP->uioaioP;
        renP->uioaioP = NULL;
        spin_unlock_irqrestore(&aioQueueSpinlock, flags);
        cpuDataP = per_cpu_ptr(perCpuDataP, cpu);
        uioaioP->cpuResp = cpu;
        if (cpuDataP->aioWork.aioQueueHeadP)
        {
          cpuDataP->aioWork.aioQueueTailP->aioNextP = uioaioP;
          cpuDataP->aioWork.aioQueueTailP = uioaioP;
        }
        else
        {
          cpuDataP->aioWork.aioQueueHeadP = uioaioP;
          cpuDataP->aioWork.aioQueueTailP = uioaioP;
          queue_work(aioWorkQueueP, &cpuDataP->aioWork.aio_work);
        }
      }
      else
      {
        wake_up(&renP->ioqWaitQ);
        spin_unlock_irqrestore(&aioQueueSpinlock, flags);
      }
    }
    else
    {
      spin_unlock_irqrestore(&aioQueueSpinlock, flags);
    }
#endif
  }
  else
  {
    atomic_inc(&renP->ioqNCompleted);
  }
}


/* Routine to call when the last I/O in a chunk list has finished.
   Reports completion and error status to higher-level layer and wakes
   up any waiting thread. */
static void chunkListDone(struct cxiBioChunk_t* bcHeadP)
{
  struct cxiIORendezvous_t* renP;
  struct cxiBioChunk_t* bcP;
  unsigned long elmtFlags;

  /* Lock chunk list to prevent a thread from changing the pointer to
     the cxiIORendezvous_t */
  spin_lock_irqsave(&bcHeadP->bioElementLock, elmtFlags);

  /* Callback to inform higher level that I/O is complete.  Must be done
     before a call to cxiWaitIO finds that it does not need to block so
     that the fields cxiCleanIO will examine will have been set.  Thus,
     the callback must be done before incrementing the number of
     completed I/Os below. */
  renP = bcHeadP->bcRendezvousP;
  bcHeadP->bcIntCallbackRtn(bcHeadP->bcCallbackDataP, renP != NULL);

  /* If there is an I/O rendezvous to be notified that this I/O has been
     completed, do so now */
  if (renP != NULL)
  {
    /* Clear pointer to rendezvous for cleanliness; not strictly
       necessary because setting bcDoneCalled prevents bcRendezvousP
       from being followed */
    bcHeadP->bcRendezvousP = NULL;
    cxiSignalCompletion(renP, true);
  }

  /* There can be no use of the chunk list by this routine after
     unlocking it, since the waiting thread may deallocate it.  Thus, do
     the unlock last. */
  spin_unlock_irqrestore(&bcHeadP->bioElementLock, elmtFlags);
}


/* iodone routine for struct bio (Linux 2.6) */
#if LINUX_KERNEL_VERSION >= 2062200
static void
bioDone(struct bio* bioP, int err)
#else
static int
bioDone(struct bio* bioP, unsigned int done, int err)
#endif
{
  struct cxiBioChunk_t* bcHeadP;
#if LINUX_KERNEL_VERSION < 2062200
  /* Ignore if bi_size is still non-zero */
  if (bioP->BI_SIZE)
    return 1;
#endif

  /* Decrement number of outstanding bios */
  bcHeadP = (struct cxiBioChunk_t*)bioP->bi_private;
  /* If this is the last bio in the chunk list, signal the rendezvous */
  if (atomic_dec_and_test(&bcHeadP->nBioDonesLeft))
    chunkListDone(bcHeadP);

#if LINUX_KERNEL_VERSION >= 2062700
  return;
#else
  return 0;
#endif
}

#define GPFS_COALESCE_IOVECS

/* Start a read or write of the given sectors from dev.  Data should be
   placed into the I/O buffer beginning at address userAddrP.  Returns 0
   on success, errno values on error. */
/* Linux 2.6 version */
int
cxiStartIO(int ioVecSize,
           cxiIOVecEntry* iovP,
           Boolean isWrite, cxiDev_t dev,
           UInt64 startSector, int sectorSize,
           struct cxiIORendezvous_t* renP,
           cxiIODoneIntCallback_t intCallbackRtn,
           void* callbackParmP,
           void** chunkHeadPP
#ifdef VDISK_LOOP_DEVICES
           , int vdiskLoopDeviceMajor,
           int vdiskLoopAdjustor
#endif
           )
{
  struct block_device* bdevP;
  int maxIOVec;
  int vecsAllocated;
  int nTotalPages;
  int iovIndex;
  int pageOffset;
  int sectorsThisPage;
  int i;
  int nSectors;
  int nBytes;
  unsigned long bufOffset;
  unsigned long bufEndOffset;
  struct bio* bioP;
  struct page* pageP;
  struct cxiBioChunk_t* bcP;
  struct cxiBioChunk_t* bcHeadP;
  struct cxiBioChunk_t* bcTailP;
  request_queue_t* reqQP;
  cxiXmem_t* xmemDescP;
  char* userAddrP;

  ENTER(0);
  /* Validate parameters */
  bdevP = bdget(new_decode_dev(dev));
  LOGASSERT(bdevP != NULL && bdevP->bd_disk != NULL);
  maxIOVec = bio_get_nr_vecs(bdevP); /* query max device vectors */
  CHECK_MAX_IO_VECS(maxIOVec, bdevP);
  /* Some drivers now report more vectors than what can be allocated from
     the kernel BIO slabs, so we need to limit them. */
  maxIOVec = MIN(maxIOVec, BIO_MAX_PAGES);

  /* ?? This function should really obey the limit in
     /sys/block/sd<X>/queue/max_sectors_kb, but the code to fetch this
     value (in 512-byte sectors) differs depending on the Linux release:
       maxDevSectors = bdev_get_queue(bdevP)->max_sectors;
         -or-
       maxDevSectors = queue_max_sectors(bdev_get_queue(bdevP));
     When max_sectors_kb has an odd value, such as for some virtual
     disks under KVM and possibly for loopback devices, this code does
     the wrong thing.  This may explain why the adjustment under ifdef
     VDISK_LOOP_DEVICES is currently needed. */

  TRACE8(TRACE_IO, 6, TRCID_KDOIO_LINUX_BIO,
         "cxiStartIO: ioVecSize %d isWrite %d dev 0x%X sector %llu renP 0x%lX "
         "maxIOVec %d bdevP 0x%lX bd_contains 0x%lX\n",
         ioVecSize, isWrite, dev, startSector, renP,
         maxIOVec, bdevP, bdevP->bd_contains);

#ifdef VDISK_LOOP_DEVICES
  /* Linux can report an inaccurate value from bio_get_nr_vecs
  *  for loop devices.  Apply necessary adjustments for experimental use. */
  if (bdevP->bd_disk->major == vdiskLoopDeviceMajor)
    maxIOVec -= vdiskLoopAdjustor;
#endif
  
  /* Allocate a single chunk and link it to itself.  Subsequent chunks
     may be needed and are allocated below.  */
  bcP = (struct cxiBioChunk_t*)kmem_cache_alloc(BioChunkCacheP, SLAB_KERNEL);
  bcHeadP = bcP;
  bcTailP = bcP;
  if (bcP == NULL)
    goto enomem;
  spin_lock_init(&bcP->bioElementLock);
  bcP->bdevP = bdevP;
  bcP->bcRendezvousP = renP;
  bcP->bcIntCallbackRtn = intCallbackRtn;
  bcP->bcCallbackDataP = callbackParmP;
  bcP->bcNextP = bcP; /* circular link to itself */
  bcP->nSlotsUsed = 0;

  /* Initialize number of I/Os remaining to 1 to prevent bioDone from
     deciding that the I/O is completely done before all of its chunks have
     been submitted. */
  atomic_set(&bcP->nBioDonesLeft, 1);

  /* Loop through the iovec list and compute the total number of pages
     spanned by all iovecs.  This number will be used, if possible, to
     size the bio that will be allocated below.  It is desirable (for
     performance) to use as few bios as possible, but the code below
     that submits bios will work correctly even if the number of pages
     computed here is inaccurate. */
  nTotalPages = 0;
  for (i=0; i<ioVecSize; i++)
  {
    xmemDescP = iovP[i].xmemDescP;
    userAddrP = iovP[i].baseEffAddr;
    nBytes = iovP[i].nBytes;

    bufOffset = userAddrP -
                (char*)(((struct cxiPageList_t*)(xmemDescP->pageListP))->plBaseAddr);
    bufEndOffset = bufOffset + nBytes - 1;
    nTotalPages += (bufEndOffset/PAGE_SIZE) - (bufOffset/PAGE_SIZE) + 1;
  }

  /* Initialize that no bio has yet been allocated.  They will be allocated
     on demand within the loop through all the input iovecs. */
  bioP = NULL;
  vecsAllocated = 0;
  iovIndex = vecsAllocated + 1;

  /* Generate sufficient bio structs to cover every buffer in the input ioVec */
  for (i=0; i<ioVecSize; i++)
  {
    xmemDescP = iovP[i].xmemDescP;
    userAddrP = iovP[i].baseEffAddr;
    nSectors = iovP[i].nSectors;
    DBGASSERT(nSectors > 0);
    nBytes = iovP[i].nBytes;

    bufOffset = userAddrP -
                (char*)(((struct cxiPageList_t*)(xmemDescP->pageListP))->plBaseAddr);
    pageOffset = bufOffset % PAGE_SIZE;
    DBGASSERT((pageOffset%512) == 0);

    TRACE6(TRACE_IO, 6, TRCID_KDOIO_LINUX_IOVEC_2,
           "cxiStartIO: iovP %d of %d userAddrP 0x%lX nBytes %d "
           "bufOffset 0x%lX pageOffset 0x%X\n",
           i, ioVecSize, userAddrP, nBytes,
           bufOffset, pageOffset);

    /* Add pages to the current bio and submit as many as necessary */
    while (nSectors > 0)
    {
      /* If the current bio does not have enough room left to hold all the
         pages of the current input iovec, submit the current bio and allocate
         another one */
      if (iovIndex >= vecsAllocated)
      {
        /* Submit current bio */
        if (bioP != NULL)
        {
          TRACE10(TRACE_IO, 4, TRCID_KDOIO_LINUX_BIO_SUBMIT_1,
                  "cxiStartIO: submit isWrite %d renP 0x%lX dev 0x%X "
                  "bi_sector %llu bi_size %d bi_vcnt %u "
                  "alloc %d max %d iovP %d of %d",
                  isWrite, renP, dev,
                  bioP->BI_SECTOR, bioP->BI_SIZE, (UInt32)bioP->bi_vcnt,
                  vecsAllocated, maxIOVec, i, ioVecSize);
          atomic_inc(&bcHeadP->nBioDonesLeft);
          submit_bio(isWrite, bioP);
        }

        /* Allocate a new bio.  Try to allocate a bio large enough to
           hold all pages from all remaining iovecs, subject to the size
           of the largest bio that is allowed for this device. */
        DBGASSERT(nTotalPages > 0);
        vecsAllocated = MIN(nTotalPages, maxIOVec);
        bioP = bio_alloc(GFP_NOIO, vecsAllocated);
        TRACE3(TRACE_IO, 5, TRCID_CXISTART_BIO,
               "cxiStartIO: allocated bio of size %d at 0x%lX, nTotalPages was %d",
               vecsAllocated, bioP, nTotalPages);
        if (bioP == NULL)
          goto enomem;
        nTotalPages -= vecsAllocated;

        /* Get another chunk of bio pointers if necessary */
        if (bcP->nSlotsUsed == BIOS_PER_CHUNK)
        {
          bcP = (struct cxiBioChunk_t*)kmem_cache_alloc(BioChunkCacheP, SLAB_KERNEL);
          if (bcP == NULL)
            goto enomem;
          bcP->nSlotsUsed = 0;
          bcP->bcNextP = bcHeadP;
          bcTailP->bcNextP = bcP;
          bcTailP = bcP;
        }

        /* Use next available pointer slot and increment used count */
        bcP->biop[bcP->nSlotsUsed] = bioP;
        bcP->nSlotsUsed += 1;

        /* Fill in header of new bio */
        bioP->bi_vcnt = 0;   /* accumulated below as number of bi_io_vecs */
        bioP->BI_IDX = 0;    /* used by lower layer for recording current index */
        bioP->BI_SIZE = 0;
        bioP->bi_bdev = bdevP;
        bioP->bi_end_io = bioDone;
        bioP->BI_SECTOR = startSector;
        iovIndex = 0;

        /* bio points to head of chunk list */
        bioP->bi_private = (void *)bcHeadP;
      }

      /* Put as many pages as will fit from the current iovec entry into
         the current bio */
      sectorsThisPage = MIN((PAGE_SIZE-pageOffset) / 512, nSectors);
      while (iovIndex < vecsAllocated  &&
             nSectors > 0)
      {
        cxiGetPagePtrs((struct cxiPageList_t*)(xmemDescP->pageListP),
                       (unsigned long)userAddrP & ~(PAGE_SIZE-1), 1, &pageP);
        DBGASSERT(pageP != NULL);

        TRACE8(TRACE_IO, 6, TRCID_KDOIO_LINUX_BIO_PAGE_2,
               "cxiStartIO: addr 0x%lX bcP 0x%lX bioP 0x%lX index %d sector "
               "%llu sectorsThisPage %d pageP 0x%lX pageOffset 0x%X\n",
               userAddrP, bcP, bioP, iovIndex, startSector, sectorsThisPage,
               pageP, pageOffset);
#ifndef GPFS_COALESCE_IOVECS
        bioP->bi_io_vec[iovIndex].bv_page = pageP;
        bioP->bi_io_vec[iovIndex].bv_len = sectorsThisPage * 512;
        bioP->bi_io_vec[iovIndex].bv_offset = pageOffset;
        iovIndex += 1;

        bioP->bi_vcnt = iovIndex;
#else
        /* Check if we can merge this iovec with the previous bi_io_vec */
        if (iovIndex != 0 &&
            bioP->bi_io_vec[iovIndex-1].bv_page == pageP &&
            bioP->bi_io_vec[iovIndex-1].bv_offset + bioP->bi_io_vec[iovIndex-1].bv_len == pageOffset)
        {
          bioP->bi_io_vec[iovIndex-1].bv_len += sectorsThisPage * 512;
        }
        else
        {
          bioP->bi_io_vec[iovIndex].bv_page = pageP;
          bioP->bi_io_vec[iovIndex].bv_len = sectorsThisPage * 512;
          bioP->bi_io_vec[iovIndex].bv_offset = pageOffset;
          iovIndex += 1;
          bioP->bi_vcnt = iovIndex;
        }
#endif
        userAddrP += (sectorsThisPage * 512);
        bioP->BI_SIZE += (sectorsThisPage * 512);

        /* Advance to next page */
        startSector += sectorsThisPage;
        nSectors -= sectorsThisPage;
        sectorsThisPage = MIN(nSectors, PAGE_SIZE/512);
        pageOffset = 0;
      }  /* end of 'while more room in the current bio and more sectors in the
            current iovec entry' */
    }  /* end of 'while more sectors in the current iovec entry' */
  }  /* end of 'for all iovec entries' */

  /* Submit the last (or hopefully only) bio */
  if (bioP != NULL)
  {
    TRACE10(TRACE_IO, 4, TRCID_KDOIO_LINUX_BIO_SUBMIT_2,
            "cxiStartIO: submit isWrite %d renP 0x%lX dev 0x%X "
            "bi_sector %llu bi_size %d bi_vcnt %u "
            "alloc %d max %d iovP %d of %d",
            isWrite, renP, dev,
            bioP->BI_SECTOR, bioP->BI_SIZE, (UInt32)bioP->bi_vcnt,
            vecsAllocated, maxIOVec, i, ioVecSize);
    atomic_inc(&bcHeadP->nBioDonesLeft);
    submit_bio(isWrite, bioP);
  }

  /* Return the list of cxiBioChunk_ts */
  *chunkHeadPP = bcHeadP;

  /* Unplug the device queue to avoid 3ms delay when no other I/O in
     progress on the device */
#ifdef PER_QUEUE_PLUGGING
  reqQP = bdev_get_queue(bdevP);
  if (reqQP->unplug_fn != NULL)
    reqQP->unplug_fn(reqQP);
#else
  /* how long delay if we don't explicitly unplug it? */
#endif


  /* Remove the extra count put in bcHeadP->nBioDonesLeft at the
     beginning of this routine.  If the count is now zero, perform chunk
     done handling */
  if (atomic_dec_and_test(&bcHeadP->nBioDonesLeft))
    chunkListDone(bcHeadP);

  EXIT(0);
  return 0;

  /* Failed to allocate memory.  Difficult to clean up, since some I/Os
     may have already been started. */
enomem:
  *chunkHeadPP = NULL;
  LOGASSERT(!"Cannot allocate memory in cxiStartIO");
  return ENOMEM;
}


/* Get disk parameters */
int 
GetDiskInfoX(cxiDev_t devId, struct cxiDiskInfo_t* diskInfoP)
{
  struct block_device *bdevP = bdget(new_decode_dev(devId));

  ENTER(0);
  LOGASSERT(bdevP != NULL && bdevP->bd_disk != NULL);

  /* Get the logical and physical block sizes of the device (in bytes). */
  diskInfoP->logicalBlockSize  = BDEV_LOGICAL_BLOCK_SIZE(bdevP);
  diskInfoP->physicalBlockSize = BDEV_PHYSICAL_BLOCK_SIZE(bdevP);

  /* Get the size of the device in bytes and convert to GPFS sectors. */
  DBGASSERT(bdevP->bd_inode != NULL);
  diskInfoP->totalSectors = i_size_read(bdevP->bd_inode) >> 9;

  /* Get the starting offset in GPFS sectors of the device/partition.
     The result is zero for complete disks and non-zero for
     partitions. Because both GPFS and Linux use a fixed internal sector
     size of 512, no conversion is needed. */
  diskInfoP->deviceOffsetSector = get_start_sect(bdevP);

  /* Get the number of GPFS sectors from the beginning of the disk to
     the first optimal storage boundary in bytes and convert to GPFS
     sectors. */
  diskInfoP->alignmentSectors = BDEV_ALIGNMENT_OFFSET(bdevP) >> 9;

  TRACE6(TRACE_IO, 2, TRCID_GET_DISKINFOX,
         "GetDiskInfoX: devId %08llX "
         "logicalBlockSize %d physicalBlockSize %d "
         "totalSectors %lld deviceOffsetSector %lld alignmentSectors %d\n",
         devId,
         diskInfoP->logicalBlockSize,
         diskInfoP->physicalBlockSize,
         diskInfoP->totalSectors,
         diskInfoP->deviceOffsetSector,
         diskInfoP->alignmentSectors);

  bdput(bdevP);

  EXIT(0);
  return 0;
}

/* Signal cxiWaitIO on I/O timeout. */
static void timeoutHandler(unsigned long int context)
{
  struct cxiIORendezvous_t *renP = (struct cxiIORendezvous_t *)context;

  atomic_set(&renP->ioqTimedOut, 1);
  wake_up(&renP->ioqWaitQ);
}


/* Wait for the given number of asynchronous I/Os to complete.  Return
   true if the wait terminates early, i.e. before nCompleted has reached
   nDesired.  This happens if we're using direct I/O and the completion
   is to be handled by the AIO completion thread, or we're doing regular
   I/O and the timeout was reached. */
Boolean cxiWaitIO(struct cxiIORendezvous_t* renP, int nDesired,
                  int msToWait, void* uioaioP)
{
  Boolean incomplete = false;

  ENTER(0);
  TRACE3(TRACE_IO, 6, TRCID_WAITIO_ENTER,
         "cxiWaitIO: renP 0x%lX nDesired %d ioqNCompleted %d\n",
         renP, nDesired, atomic_read(&renP->ioqNCompleted));

  DBGASSERT(nDesired >= 0);

  /* A non-NULL uioaioP indicates this is a wait for Linux AIO. */

  if (uioaioP)
  {
    unsigned long flags;

    /* We are running in the context of the application that is calling
       the Linux system call io_submit.  We use the aioQueueSpinlock to
       prevent a race between this thread and IO completion at interrupt and
       post AIO completion processing done in the context of the Linux AIO
       completion thread.  The cxiIORendezvous_t is freed in the context of
       the Linux AIO completion thread so we aquire the spinlock here to
       prevent the race condition. */

    spin_lock_irqsave(&aioQueueSpinlock, flags);

    /* Record the number of desired I/O completions */
    atomic_set(&renP->ioqNDesired, nDesired);
   
    if (atomic_read(&renP->ioqNCompleted) < nDesired)
    {
      /* The post AIO completion processing will be done by the Linux AIO
         completion thread.  Do not access the cxiUioAio_t after loading the
         ptr in the kernel IO completion queue as it can be freed asynch.  */
      renP->uioaioP = uioaioP;
      incomplete = true;
      ((struct cxiUioAio_t*)uioaioP)->cpuReq = smp_processor_id();
    }
    else
    {
      /* The IO has completed, return false so IO completion processing is done
         now as opposed to being done later by the AIO completion thread. */
    }
    spin_unlock_irqrestore(&aioQueueSpinlock, flags);
  }
  else
  {
    /* We do not need the aioQueueSpinlock here because the cxiIORendezvous_t
       is freed in the context of this thread.  Therefore, the race condition
       that exists for Linux AIO does not exist for non AIO.  However, we
       acquire the aioQueueSpinlock at interupt time to serialize the wakeup of
       this thread for the case of a cxiIORendezvous_t that has two or more IO.
       When there are two or more IOs, one interrupt thread may wake this
       thread resulting in the cxiIORendezvous_t being freed while the other
       interupt time thread is still accessing the cxiIORendezvous_t. */

    /* Record the number of desired I/O completions */
    atomic_set(&renP->ioqNDesired, nDesired);

    /* Init ioqTimedOut. */
    atomic_set(&renP->ioqTimedOut, 0);

    /* If a timeout was given, start the timer. */
    if (msToWait >= 0)
    {
      renP->ioqTimer.data     = (unsigned long int)renP;
      renP->ioqTimer.function = timeoutHandler;
      renP->ioqTimer.expires  = jiffies +
        (unsigned long int)msToWait * HZ / 1000;
      add_timer(&renP->ioqTimer);
    }

    /* Wait until enough I/Os have completed or timeout. */
    wait_event(renP->ioqWaitQ,
               (atomic_read(&renP->ioqNCompleted) >=
                atomic_read(&renP->ioqNDesired)) ||
               atomic_read(&renP->ioqTimedOut) != 0);

    /* Stop the timer. */
    if (msToWait >= 0)
      del_timer_sync(&renP->ioqTimer);

    /* If we saw a timeout, set the incomplete flag. */
    if (atomic_read(&renP->ioqTimedOut) != 0)
      incomplete = true;
  }

  EXIT(0);
  return incomplete;
}


/* Wait for the given number of asynchronous I/Os to complete */
void cxiWaitIOInterruptible(struct cxiIORendezvous_t* renP, int nDesired,
                            int msToWait)
{
  ENTER(0);

  TRACE3(TRACE_IO, 6, TRCID_WAITIO_INT_ENTER,
         "cxiWaitIOInterruptible: renP 0x%lX nDesired %d ioqNCompleted %d\n",
         renP, nDesired, atomic_read(&renP->ioqNCompleted));

  /* Record the number of desired I/O completions */
  atomic_set(&renP->ioqNDesired, nDesired);

  /* Wait until enough I/Os have completed or a signal becomes pending */
  wait_event_interruptible(renP->ioqWaitQ,                       \
                           (atomic_read(&renP->ioqNCompleted) >= \
                            atomic_read(&renP->ioqNDesired)));

  EXIT(0);
}


/* Clean up after or prepare for I/O completion.  If the I/O has
   completed, walk the list of cxiBioChunk_ts, summarizing the return
   codes and freeing storage.  If a pointer to an I/O rendezvous was
   provided, increment its count of the number of completed I/Os.  *rcP
   in this case will be the most severe return code seen.

   If the I/O has not yet completed, record the pointer to the I/O
   rendezvous.  This pointer may be NULL if the I/O rendezvous is about
   to be destroyed because kxLocalIO is about to return. */
void cxiCleanIO(void* chunkHeadP, struct cxiIORendezvous_t* renP,
                UInt32* ioStateP, Boolean* isCompleteP, int* rcP)
{
  struct cxiBioChunk_t* bcHeadP;
  struct cxiBioChunk_t* bcP = NULL;
  struct cxiBioChunk_t* nextBcP;
  struct block_device* bdevP;
  unsigned long elmtFlags;
  Boolean isDone;
  int rc;
  int i;

  ENTER(0);

  /* Lock chunk list to synchronize with the chunkListDone interrupt
     handler */
  bcHeadP = (struct cxiBioChunk_t *)chunkHeadP;
  spin_lock_irqsave(&bcHeadP->bioElementLock, elmtFlags);

  /* Test if the I/O is complete while the chunk list is locked, to
     prevent races with chunkListDone */
  isDone = (*ioStateP & DOIO_COMPLETE) != 0;
  if (isDone)
  {
    /* Currently assigned rendezvous must already be NULL because
       chunkListDone sets it to NULL under the same lock that is held
       while turning on the DOIO_COMPLETE bit */
    DBGASSERT(bcHeadP->bcRendezvousP == NULL);

    /* If just now assigning a rendezvous to this I/O, and the I/O is
       complete, simulate the processing that was missed in chunkListDone */
    if (renP != NULL)
    {
      /* Notify new rendezvous of another completed I/O.  No need to
         wake up a waiting thread since the thread in kxLocalIO has
         not tried to wait yet */
      cxiSignalCompletion(renP, false);
    }
  }
  /* Otherwise (I/O not done), set the pointer to the I/O rendezvous.
     This may be NULL if the rendezvous is about to be destroyed. */
  else
    bcHeadP->bcRendezvousP = renP;

  /* Unlock chunk list while performing actual scan and deallocation. */
  spin_unlock_irqrestore(&bcHeadP->bioElementLock, elmtFlags);

  /* If the I/O has not completed, nothing else to do.  Note that this
     test uses the value of the completion bit as it appeared while
     chunkListDone was disabled from running. */
  if (!isDone)
  {
    *isCompleteP = false;
    *rcP = 0;
    TRACE2(TRACE_IO, 6, TRCID_WAITIO_CHUNK_NOT_DONE,
           "cxiCleanIO: I/O not done yet; bcP 0x%lX nSlotsUsed %d\n",
           bcHeadP, bcHeadP->nSlotsUsed);
    EXIT(0);
    return;
  }

  /* The I/O is complete, so walk the list of chunks, accumulating the
     return code and freeing each chunk */
  LOGASSERT(atomic_read(&bcHeadP->nBioDonesLeft) == 0);
  bcP = bcHeadP;
  bdevP = bcHeadP->bdevP;
  rc = 0;
  do
  {
    TRACE2(TRACE_IO, 6, TRCID_WAITIO_CHUNK,
           "cxiCleanIO: freeing bcP 0x%lX nSlotsUsed %d\n",
           bcP, bcP->nSlotsUsed);

    /* Scan all bios in this chunk and compute whether or not any I/O
       errors were encountered */
    for (i=0; i<bcP->nSlotsUsed; i++)
    {
      TRACE3(TRACE_IO, 6, TRCID_WAITIO_BDEVP,
             "cxiCleanIO: bdevP 0x%lX, bi_bdev 0x%lX, bd_contains 0x%lX",
             bdevP, bcP->biop[i]->bi_bdev, bdevP->bd_contains);

      DBGASSERT(bcP->biop[i]->bi_bdev == bdevP ||
                bcP->biop[i]->bi_bdev == bdevP->bd_contains);

      if (!test_bit(BIO_UPTODATE, &bcP->biop[i]->bi_flags))
        rc = EIO;
      bio_put(bcP->biop[i]);
      bcP->biop[i] = NULL;
    }

    /* Remember the next chunk on the list, then deallocate the current
       chunk */
    nextBcP = bcP->bcNextP;
    kmem_cache_free(BioChunkCacheP, (void*)bcP);

    /* Advance to next chunk */
    bcP = nextBcP;
  } while (bcP != bcHeadP);

  /* Release the reference on the block device */
  bdput(bdevP);

  /* Return most severe return code */
  EXIT(0);
  *isCompleteP = true;
  *rcP = rc;
}


/* Set up an I/O so its completion will be handled by the async I/O
   completion handler thread or a kernel work queue.  The I/O may have
   already been submitted and may even already be complete.  Depending
   on the state of the I/O, this routine will either move the completed
   I/O to the correct completion queue and wake up the waiting thread or
   set up the I/O so that chunkListDone will do this when the I/O
   completes later.  The last parameter is the address of the
   MBDoDiskIOParms object, needed by the callback routine that adds it
   to a completion queue. */
void cxiAssignAsyncIO(void* chunkHeadP, struct cxiIORendezvous_t* renP,
                      UInt32* ioStateP,
                      void (*completionCallbackP)(void*), void* p)
{
  struct cxiBioChunk_t* bcHeadP;
  unsigned long elmtFlags;

  ENTER(0);
  TRACE2(TRACE_IO, 4, TRCID_ASSIGN_ASYNC_LINUX,
         "cxiAssignAsyncIO: chunkHeadP 0x%lX ren 0x%lX\n", chunkHeadP, renP);

  /* In certain error cases, it's convenient to allow a request that
     has already been marked COMPLETE and CLEANED to be returned by the
     asynchronous error handler.  In this case, there is no chunk list
     to lock or clean -- all that's needed is to invoke the callback to
     put the request onto the asynchronous completion queue and signal
     completion to the Rendezvous. */
  if ((*ioStateP & DOIO_CLEANED) != 0)
  {
    DBGASSERT(chunkHeadP == NULL);
    DBGASSERT((*ioStateP & DOIO_COMPLETE) != 0);

    (*completionCallbackP)(p);
    cxiSignalCompletion(renP, true);
    goto exit;
  }

  /* Lock chunk list to synchronize with the chunkListDone interrupt
     handler */
  bcHeadP = (struct cxiBioChunk_t *)chunkHeadP;
  spin_lock_irqsave(&bcHeadP->bioElementLock, elmtFlags);

  /* If the I/O is already complete, and since this I/O did not have a
     rendezvous when it completed, perform the async-specific processing
     that was missed in chunkListDone */
  if ((*ioStateP & DOIO_COMPLETE) != 0)
  {
    /* Currently assigned rendezvous must already be NULL because
       chunkListDone sets it to NULL under the same lock that is held
       while turning on the DOIO_COMPLETE bit */
    DBGASSERT(bcHeadP->bcRendezvousP == NULL);

    /* Callback to append I/O request to async completion queue */
    (*completionCallbackP)(p);

    /* Notify new rendezvous of another completed I/O and wake up
       waiting async notification thread */
    DBGASSERT(renP->uioaioP == NULL);
    cxiSignalCompletion(renP, true);
  }

  /* Otherwise (I/O not done), set the pointer to the I/O rendezvous for
     the async completion handler */
  else
    bcHeadP->bcRendezvousP = renP;

  /* Unlock chunk list */
  spin_unlock_irqrestore(&bcHeadP->bioElementLock, elmtFlags);
exit:
  EXIT(0);
}


/* One-time initialization of an I/O rendezvous */
void cxiInitIORendezvous(struct cxiIORendezvous_t* renP)
{
  init_waitqueue_head(&renP->ioqWaitQ);
  atomic_set(&renP->ioqNCompleted, 0);
  atomic_set(&renP->ioqNDesired, MAX_IO_NDESIRED);
  atomic_set(&renP->ioqTimedOut, 0);
  init_timer(&renP->ioqTimer);
  renP->uioaioP = NULL;
}


/* Terminate an I/O rendezvous */
void cxiTermIORendezvous(struct cxiIORendezvous_t* renP)
{
}


/* Allocate an I/O rendezvous */
struct cxiIORendezvous_t* cxiAllocIORendezvous()
{
  struct cxiIORendezvous_t* renP;

  renP = (struct cxiIORendezvous_t*)
           cxiMallocPinned(sizeof(struct cxiIORendezvous_t));

  if (renP != NULL)
    cxiInitIORendezvous(renP);
  return renP;
}


/* Free an I/O rendezvous */
void cxiFreeIORendezvous(struct cxiIORendezvous_t* renP)
{
//  cxiTermIORendezvous(renP);
  DBGASSERT(!timer_pending(&renP->ioqTimer));
#ifdef DBGASSERTS
  cxiMemset(renP, 0xDD, sizeof(struct cxiIORendezvous_t));
#endif
  cxiFreePinned((void*)renP);
}


/* Reset an I/O rendezvous to reflect the number of completions that were
   actually processed.  Also reset the target number of completions, to
   reduce the number of calls to wake_up that occur when no thread is
   yet waiting. */
void cxiResetIORendezvous(struct cxiIORendezvous_t* renP, int nCompletionsSeen)
{
  atomic_sub(nCompletionsSeen, &renP->ioqNCompleted);
  atomic_set(&renP->ioqNDesired, MAX_IO_NDESIRED);
}


/* Forcibly awaken threads waiting on an I/O rendezvous.  Used during
   daemon shutdown. */
void cxiAwakenIORendezvous(struct cxiIORendezvous_t* renP)
{
  atomic_set(&renP->ioqNCompleted, MAX_IO_NDESIRED/2);
  atomic_set(&renP->ioqNDesired, 0);
  wake_up(&renP->ioqWaitQ);
}

#ifdef GPFS_ENC
/* This is an odd bird.  Linux aio finishes the i/o operation under
   a different process and thus cannot use uiomove() since the user
   address is elsewhere.  For this case we use an alternate copy
   mechanism */
IntRC
cxiKXferXmem(struct cxiIOBuffer_t* iobP,
             Boolean toIOBuffer,      /* to or from ioBuffer */
             const struct cxiIOBufferAttachment_t* attachDataP,
                                      /* i/o buffer attachment */
             int bufOffset,           /* offset in ioBuffer */
             size_t nBytes,           /* size of transfer */
             char *userAddrP,         /* address within user app context */
             cxiXmem_t* xmemP,        /* user app cross memory */
             int* nBytesTransferredP) /* (out) bytes transferred */
{
  int rc = 0;
  char* kaddrP;
  unsigned long pageOffset;
  int pageLen;
  struct page* pageP;

  *nBytesTransferredP = 0;
  for (;;)
  {
    pageOffset = (unsigned long)userAddrP % PAGE_SIZE;
    pageLen = MIN(PAGE_SIZE - pageOffset, nBytes);

    kaddrP = kmapPage(xmemP->pageListP, userAddrP, &pageP) + pageOffset;
    rc = cxiKXfer(iobP, toIOBuffer,
                  attachDataP, bufOffset, pageLen, kaddrP);

    kunmapPage(pageP);
    if (rc != 0)
      break;

    *nBytesTransferredP += pageLen;
    nBytes -= pageLen;

    if (nBytes <= 0)
      break;

    userAddrP += pageLen;
    bufOffset += pageLen;
  }
  return rc;
}
/*
 * START kernel crypto abstraction layer
 */
#if defined(GPFS_CRYPTO_KERNELPATH) && defined(HAS_NEW_CRYPTO_API)

#include <linux/crypto.h>
#include <linux/scatterlist.h>
#include <linux/err.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/unistd.h>

#include <linux/linkage.h>
#include <linux/errno.h>

#include <linux/sched.h>

#define GCRYPTO_CCTXP_T void *
#define MAX_LEN PAGE_SIZE

/*
 * TODO: the day we want to use something else than AES,
 * switch to dynamic block length
 */
#define BLOCKLEN GCRYPTO_AES_BLOCKLEN

static Int32 genIV(gcryptoCtx_t *ctxP,
    UInt64 blockNum,
    unsigned char *IVP,
    UInt32 ivtablen,
    void * cctxP);

static const char* getCipherMode(int cipher, int mode);
static const char* getCipher(int cipher);

static void getKeyP(gcryptoCtx_t *ctxP, unsigned char** encKeyP,
                        unsigned char** ivKeyP)
{
  switch (ctxP->cipherMode)
  {
    case GCRYPTO_CIPHER_MODE_CBC:
      if (encKeyP != NULL)
        *encKeyP = ctxP->der.key.enc;
      if (ivKeyP != NULL)
        *ivKeyP = ctxP->der.key.iv;
      break;
    case GCRYPTO_CIPHER_MODE_XTS:
      if (encKeyP != NULL)
        *encKeyP = ctxP->der.encIVkey;
      if (ivKeyP != NULL)
        *ivKeyP = ctxP->der.encIVkey + ctxP->keyLen;
      break;
    default:
      {
        bool gcrypto_unknown_cipher_mode = false;
        LOGASSERT(gcrypto_unknown_cipher_mode);
        break;
      }
  }
}

/*
 * Provides non-padded encryption/decryption, ECB mode only
 */
static int gc_crypt(char *data_out, const char *data_in, unsigned int len,
    const u8 *key, unsigned int keylen, 
    int enc, int cipher, int mode)
{
  struct crypto_cipher *tfm;
  int i;
  int ret;

  ret = EINVAL;
  /* TODO all EINVAL */

  if (mode != GCRYPTO_CIPHER_MODE_ECB)
    goto out;

  TRACE8(TRACE_GCRYPTO, 5, TRCID_GCK_GC_ENTER,
        "gc_crypt: enter: data_out 0x%lX data_in 0x%lX len %u "
        "key 0x%lX keylen %u "
        "enc %d, cipher %d, mode %d ",
        data_out, data_in, len, key, keylen, 
        enc, cipher, mode);
  if (len % BLOCKLEN) {
    TRACE2(TRACE_GCRYPTO, 1, TRCID_GCK_GC_LENBLOCK,
	"gc_crypt: len %u not a multiple of the blocksize %d", len, BLOCKLEN);
    goto out;
  }

  tfm = crypto_alloc_cipher(getCipher(cipher), 0, 0);
  if (IS_ERR(tfm))  {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GC_ALLOC,
	"gc_crypt: crypto_alloc_blkcipher allocation failed");
    goto out;
  }

  if (crypto_cipher_setkey(tfm, key, keylen)) {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GC_SETKEY,
	"gc_crypt: crypto_blkcipher_setkey failed");
    goto out_free;
  }

  if (enc) {
    TRACE3(TRACE_GCRYPTO, 7, TRCID_GCK_GC_ENC,
        "gc_crypt: encrypting: data_in=0x%lX, data_out=0x%lX, len=%u", 
        data_in, data_out, len);
    for (i = 0; i < len; i += BLOCKLEN)
    {
      crypto_cipher_encrypt_one(tfm, data_out, data_in);
      data_in += BLOCKLEN;
      data_out += BLOCKLEN;
    }
  } else {
    TRACE3(TRACE_GCRYPTO, 7, TRCID_GCK_GC_DEC,
        "gc_crypt: decrypting: data_in=0x%lX, data_out=0x%lX, len=%u", 
        data_in, data_out, len);
    for (i = 0; i < len; i += BLOCKLEN)
    {
      crypto_cipher_decrypt_one(tfm, data_out, data_in);
      data_in += BLOCKLEN;
      data_out += BLOCKLEN;
    }
  }

  ret = 0;

out_free:
  crypto_free_cipher(tfm);
out:
  TRACE2(TRACE_GCRYPTO, 5, TRCID_GCK_GC_RET,
      "gc_crypt: ret=%d, len=%u", ret, len);
  return ret;

}

/* Receives a scatterlist *vector* and not just a scatterlist.
 * The reason of that is that we need to change IV every ENCRYPTION_BLOCKLEN
 * (currently, 512 bytes) - which means we need to make a new call to the Linux
 * kernel crypto API each time.
 */

static int gc_crypt_sgt(struct scatterlist *sgtab_out,
    struct scatterlist *sgtab_in,
    unsigned int size,
    const u8 *key, unsigned int keylen, const char *ivtab,
    unsigned int ivtablen, unsigned int ivlen, int enc, int cipher, int mode)
{
  struct blkcipher_desc desc;
  struct scatterlist *sg_in, *sg_out;
  unsigned int expected_ivlen;
  char m_iv[GCRYPTO_MAX_IVLEN];
  const char *din;
  char *dout;
  int ret, i;
  unsigned int len = size * (ivtablen/ivlen);

  ret = -EINVAL;

  TRACE11(TRACE_GCRYPTO, 6, TRCID_GCK_GCB_ENTER,
        "gc_crypt_sgt: enter: sgtab_out 0x%lX sgtab_in 0x%lX size %u "
        "key 0x%lX keylen %u ivtab 0x%lX ivtablen %u ivlen %u "
        "enc %d, cipher %d, mode %d",
        sgtab_out, sgtab_in, size, key, keylen, ivtab, ivtablen, ivlen,
        enc, cipher, mode);

  if (size > MAX_LEN) {
    TRACE1(TRACE_GCRYPTO, 1, TRCID_GCK_GCB_LEN,
	"gc_crypt_sgt: len %u too big", size);
    goto out;
  }

  if (ivtablen % ivlen) {
    TRACE2(TRACE_GCRYPTO, 1, TRCID_GCK_GCB_LENMULT,
	"gc_crypt_sgt: ivtablen %u not a multiple of the ivlen %d", 
        ivtablen, ivlen);
    goto out;
  }

  LOGASSERT(ivtab);
  desc.tfm = crypto_alloc_blkcipher(getCipherMode(cipher, mode), 0, 0);
  if (IS_ERR(desc.tfm))  {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GCB_ALLOC,
	"gc_crypt_sgt: crypto_alloc_blkcipher allocation failed");
    goto out;
  }
  desc.flags = 0;

  if (crypto_blkcipher_setkey(desc.tfm, key, keylen)) {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GCB_SETKEY,
	"gc_crypt_sgt: crypto_blkcipher_setkey failed");
    goto out_free;
  }

  expected_ivlen = crypto_blkcipher_ivsize(desc.tfm);
  if (ivlen != expected_ivlen || ivlen > GCRYPTO_MAX_IVLEN) {
    TRACE1(TRACE_GCRYPTO, 1, TRCID_GCK_GCB_IVLEN,
	"gc_crypt_sgt: unexpected IV length provided (expected %u)", 
        expected_ivlen);
    goto out_free;
  }


  /*
   * Note: do *not* use crypto_blkcipher_set_iv
   * It doesn't work (yet?) with CBC-IV
   * */

  for(i = 0, sg_in = sgtab_in, sg_out = sgtab_out;
      i < ivtablen;
      i += ivlen, sg_in++, sg_out++) {
    memcpy(m_iv, ivtab+i, ivlen);
    /* crypto_blkcipher_*crypt_iv will overwrite desc.info  */
    desc.info = &m_iv;
    TRACE1(TRACE_GCRYPTO, 8, TRCID_GCK_GCB_IVSTART,
        "gc_crypt_sgt: iv starts with: %08x", ((unsigned int*) desc.info)[0]);

    if (enc) {
      TRACE3(TRACE_GCRYPTO, 6, TRCID_GCK_GCB_IV_ENC,
          "gc_crypt_sgt: encrypting: sg_in=0x%lX, sg_out=0x%lX, size=%u", \
          sg_in, sg_out, size);
      ret = crypto_blkcipher_encrypt_iv(&desc, sg_out, sg_in, size);
    } else {
      TRACE3(TRACE_GCRYPTO, 6, TRCID_GCK_GCB_IV_DEC,
          "gc_crypt_sgt: decrypting: sg_in=0x%lX, sg_out=0x%lX, size=%u", \
          sg_in, sg_out, size);
      ret = crypto_blkcipher_decrypt_iv(&desc, sg_out, sg_in, size);
    }

    if (ret)
      goto out_free;
  }
out_free:
  crypto_free_blkcipher(desc.tfm);
out:
  TRACE3(TRACE_GCRYPTO, 6, TRCID_GCK_GCB_RET,
    "gc_crypt_sgt: ret = %d, failed flags=%x, len=%u", ret, desc.flags, len);
  return ret;

}
static inline Int32 gcKernCrypt(gcryptoCtx_t *ctxP,
    struct scatterlist *srcsgt,
    struct scatterlist *dstsgt,
    UInt32 len,
    UInt64 blockNum,
    Int32 encdec)
{

  //UInt32 outlen;
  UInt32 ivtablen;
  Int32 ret;
  int toret = -127;
  unsigned char *ivtab;
  void *cctxP = NULL;
  unsigned char* encKey = NULL;
  unsigned int keylen = 0;


  TRACE6(TRACE_GCRYPTO, 5, TRCID_GCK_GCKC_ENTER,
"gcKernCrypt ctxP 0x%lX srcP 0x%lX "
      "dstP 0x%lX L %d BN %lld cipher bl sz %d",
      ctxP, srcsgt, dstsgt, len, blockNum,
      (ctxP)?ctxP->cipherBlockSize: -1);

  if (!ctxP || !srcsgt || !dstsgt || len == 0)
  {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GCK_B,
	"gcKernCrypt error: invalid arguments");
    return -1;
  }


  if (len % ENC_BASIC_BLOCK_SIZE != 0)
  {
    TRACE1(TRACE_GCRYPTO, 1, TRCID_GCK_GCK_LEN,
	"gcKernCrypt: length %u is not a multiple of the encryption "
        "basic block size!", len);
    toret = -1;
    goto exit;
  }

  ivtablen = len/ENC_BASIC_BLOCK_SIZE * ctxP->cipherBlockSize;
  if ((ivtab = (unsigned char *) kmalloc(ivtablen, GFP_KERNEL)) == NULL)
  {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GCK_ALLOC,
	"gcKernCrypt: allocation failed");
    toret = -1;
    goto exit;
  }

  if ((ret = genIV(ctxP, blockNum, ivtab, ivtablen, cctxP)) < 0)
  {
    TRACE1(TRACE_GCRYPTO, 1, TRCID_GCK_GCK_GENIV,
	"gcKernCrypt error: genIV returned %d", ret);
    toret = -1;
    goto exit_free_ivtab;
  }

  getKeyP(ctxP, &encKey, NULL);
  switch(ctxP->cipherMode)
  {
    case GCRYPTO_CIPHER_MODE_XTS:
      keylen = 2*ctxP->keyLen;
      break;
    case GCRYPTO_CIPHER_MODE_CBC:
      keylen = ctxP->keyLen;
      break;
  }
  toret = gc_crypt_sgt(dstsgt, srcsgt, ENC_BASIC_BLOCK_SIZE,
      encKey, keylen, ivtab, ivtablen, ctxP->cipherBlockSize,
      encdec, ctxP->cipher, ctxP->cipherMode);

  //LOGASSERT(outlen == len);

exit_free_ivtab:
  kfree(ivtab);
exit:
  return toret;
}

static Int32 gcryptoEncECB(const unsigned char *toEncP,
    UInt32 encLen,
    unsigned char *bufP,
    UInt32 *bufLen,
    const unsigned char *keyP,
    UInt32 keyLen,
    Int32 cipher,
    Int32 padding,
    const char *errPfix,
    GCRYPTO_CCTXP_T cctxP)
{
  int ret = -1;
  if (padding != GCRYPTO_PAD_NONE)
    goto exit;
  if (gc_crypt(bufP, toEncP, encLen, keyP, keyLen, 
      1 /* enc */, cipher, GCRYPTO_CIPHER_MODE_ECB))
    goto exit;
  *bufLen = encLen;
  ret = 0;
exit:
  return ret;
}
static Int32 gcryptoDecECB(const unsigned char *toDecP,
    UInt32 encLen,
    unsigned char *bufP,
    UInt32 *bufLen,
    const unsigned char *keyP,
    UInt32 keyLen,
    Int32 cipher,
    Int32 padding,
    const char *errPfix,
    GCRYPTO_CCTXP_T cctxP)
{
  int ret = -1;
  if (padding != GCRYPTO_PAD_NONE)
    goto exit;
  if (gc_crypt(bufP, toDecP, encLen, keyP, keyLen,
      0 /* dec */, cipher, GCRYPTO_CIPHER_MODE_ECB))
    goto exit;
  *bufLen = encLen;
  ret = 0;
exit:
  return ret;
}
static Int32 genIV(gcryptoCtx_t *ctxP,
    UInt64 blockNum,
    unsigned char *IVP,
    UInt32 ivtablen,
    void * cctxP)
{
  UInt32 outlen;
  int toret = -127;
  UInt32 i;
  UInt32 bSize;
  UInt64 tmpNum;
  unsigned char *toEnc = IVP; // encrypt in-place
  unsigned char* ivKey = NULL;

  if (!ctxP || !IVP)
  {
    TRACE0(TRACE_GCRYPTO, 1, TRCID_GCK_GIV_B,
	"genIV error: invalid arguments");
    return -1;
  }

  bSize = ctxP->cipherBlockSize;
  TRACE2(TRACE_GCRYPTO, 1, TRCID_GCK_GIV_ENTER,
	"genIV enter: BN %lld ivtablen %u", blockNum, ivtablen);

  if (ivtablen % bSize != 0 || ivtablen == 0)
  {
    TRACE1(TRACE_GCRYPTO, 1, TRCID_GCK_GIV_MULT,
	 "genIV: IV table length %u is not a multiple of the cipher "
        "block size!", ivtablen);
    toret = -1;
    goto exit;
  }

  LOGASSERT(bSize >= 2*sizeof(UInt64));
  for (i = 0; i < ivtablen/bSize; i++)
  {
    tmpNum = CPUToBigEnd64(blockNum + i);
    memcpy(toEnc + i*bSize, &tmpNum, sizeof(tmpNum));
    LOGASSERT(ctxP->rndFileIDLen == GCRYPTO_RNDID_LENGTH);
    memcpy(toEnc + i*bSize + sizeof(tmpNum), ctxP->rndFileIDBytes, 
        ctxP->rndFileIDLen);
  }
  switch (ctxP->cipherMode)
  {
    case GCRYPTO_CIPHER_MODE_XTS:
      toret = 0;
      break;
    case GCRYPTO_CIPHER_MODE_CBC:
      getKeyP(ctxP, NULL, &ivKey);
      toret = gc_crypt(toEnc, toEnc, ivtablen, ivKey, ctxP->keyLen, 
          1 /* enc */, ctxP->cipher, GCRYPTO_CIPHER_MODE_ECB);
      break;
  }
exit:
  return toret;
}

static const char* getCipherMode(int cipher, int mode)
{
  int no_such_cipher = 0;
  int no_such_mode = 0;

  switch (cipher)
  {
    case GCRYPTO_CIPHER_AES:
      switch (mode)
      {
        case GCRYPTO_CIPHER_MODE_XTS:
          return "xts(aes)";
        case GCRYPTO_CIPHER_MODE_CBC:
          return "cbc(aes)";
        case GCRYPTO_CIPHER_MODE_ECB:
          return "ecb(aes)";
        default:
          LOGASSERT(no_such_mode == 1);
          return NULL;
      }
    default:
      LOGASSERT(no_such_cipher == 1);
      return NULL;
  }
}
static const char* getCipher(int cipher)
{
  int no_such_cipher = 0;

  switch (cipher)
  {
    case GCRYPTO_CIPHER_AES:
          return "aes";
    default:
      LOGASSERT(no_such_cipher == 1);
      return NULL;
  }
}
static Int32 getCipherBlockLen(Int32 cipher)
{
  int no_such_cipher = 0;
  switch (cipher)
  {
    case GCRYPTO_CIPHER_AES:
      return GCRYPTO_AES_BLOCKLEN;
    default:
      LOGASSERT(no_such_cipher == 1);
  }
  return 0;
}
/*
 * END kernel crypto abstraction layer
 */

/* Transforms an IOBuffer into a table of Linux kernel scatterlists of size
 * ENC_BASIC_BLOCK_SIZE, suitable for being passed to the kernel crypto API
 *
 * On success, creates exactly nmemb_max scatterlists.
 */
static int getSGfromIOBuffer(struct scatterlist *sgtP,
    size_t nmemb_max, struct cxiIOBuffer_t *iobP)
{
  size_t nmemb = 0;
  struct cxiMemoryDesc_t* descP;
  char* dataAddrP;
  struct cxiPageList_t* plP;
  struct page * pageP;
  int pageLen;
  struct cxiMemoryMapping_t* memMapP;
  unsigned long pageOffset;
  int rc = 0;
  int currOffset, tmpLen, nDesc, off;
  int currLen = iobP->ioBufLen;
  int len = iobP->ioBufLen;
  struct scatterlist *sgP = sgtP;

  DBGASSERT(PAGE_SIZE % ENC_BASIC_BLOCK_SIZE == 0);
  DBGASSERT(iobP->hDescP != NULL);
  descP = iobP->hDescP;
  DBGASSERT(IN_DIO_USER_BUFFER(descP) == false);

  rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
  if (rc != 0)
    goto exit;

  /* The daemon address of the 1st memory descriptor should be cached in
     the IO buffer */
  DBGASSERT(iobP->daemonBufP == memMapP->vaddr + descP->offset);

  currOffset = 0;
  nDesc = 0;
  for (;;)
  {
    DBGASSERT(descP != NULL);
    DBGASSERT(memMapP != NULL);

    dataAddrP = memMapP->vaddr + descP->offset;
    tmpLen = currLen = GETLEN_BYTES(descP);

    plP = memMapP->xmemDesc.pageListP;

    DBGASSERT(plP != NULL);
    DBGASSERT(currLen/PAGE_SIZE <= plP->plNPages);


    pageOffset = (unsigned long)dataAddrP % PAGE_SIZE;
    pageLen = PAGE_SIZE - pageOffset;

    TRACE8(TRACE_GCRYPTO, 5, TRCID_GETSG_DESC_SCATTER,
        "getSGfromIOBuffer: nDesc %d currOffset %d tmpLen %d "
        "dataAddrP 0x%lX currLen %d pageOffset %d pageLen %d plP 0x%lX",
        nDesc, currOffset, tmpLen,
        dataAddrP, currLen, pageOffset, pageLen, plP);

    for (;;)
    {
      if (len < pageLen)
        pageLen = len;

      /* A scatter buffer size may be smaller than page size */
      if (currLen < pageLen)
        pageLen = currLen;

      cxiGetPagePtrs(plP, (unsigned long)dataAddrP, 1, &pageP);

      /* Chunk in ENC_BASIC_BLOCK_SIZE */
      DBGASSERT(pageLen % ENC_BASIC_BLOCK_SIZE == 0);
      for(off = 0; off < pageLen; off += ENC_BASIC_BLOCK_SIZE)
      {
        sg_init_table(sgP, 1);
        sg_set_page(sgP, pageP, ENC_BASIC_BLOCK_SIZE, pageOffset + off);
        sgP++;
        nmemb++;
        if (nmemb >= nmemb_max)
          break;
        /* treat case where the end isn't ENC_BASIC_BLOCK_SIZE-sized?
         * shouldn't happen... see assert above. */
      }

      /* Update length left to copy and test for loop termination */
      len -= pageLen;
      if (len <= 0)
        goto exit;

      currLen -= pageLen;
      if (currLen <= 0)
        break;

      if (nmemb >= nmemb_max)
        goto exit;

      /* Set up for next iteration */
      dataAddrP += pageLen;
      pageOffset = 0;
      pageLen = PAGE_SIZE;
    }  /* end of do forever */

    descP = descP->nextP;
    rc = gpfs_ops.gpfsGetMemMap(descP->vindex, &memMapP);
    if (rc != 0)
      goto exit;
    currOffset = currOffset + tmpLen;
    nDesc++;
  }


exit:
  if (rc == 0)
    LOGASSERT(nmemb == nmemb_max);
  return rc;
}

int cxiKEncryptDecrypt(gcryptoCtx_t *ctxP,
    void *srcP,
    void *dstP,
    UInt32 len,
    UInt64 blockNum,
    Int32 isEncrypt)
{
  struct cxiIOBuffer_t *sbuf;
  size_t nmemb, check_nmemb, bpg;
  struct scatterlist *sgt, *sg;
  int rc = 0;

  TRACE6(TRACE_GCRYPTO, 5, TRCID_CXIENCDEC_ENTER,
      "cxiKEncryptDecrypt: enter ctxP 0x%lX srcP 0x%lX dstP"
      " 0x%lX len %u BN %llu"
      " isenc %d", ctxP, srcP, dstP, len, blockNum, isEncrypt);
  sbuf = (struct cxiIOBuffer_t *) srcP;

  LOGASSERT(srcP == dstP); // only support in-place for now
  LOGASSERT(len > 0);
  LOGASSERT(len % ENC_BASIC_BLOCK_SIZE == 0);

  nmemb = len / ENC_BASIC_BLOCK_SIZE;

  sgt = kmalloc(nmemb * sizeof(struct scatterlist), GFP_KERNEL);
  if (!sgt)
  {
    rc = ENOMEM;
    goto exit2;
  }

  rc = getSGfromIOBuffer(sgt, nmemb, sbuf);
  if (rc != 0)
    goto exit;

  rc = gcKernCrypt(ctxP, sgt, sgt, len, blockNum, isEncrypt);

exit:
  kfree(sgt);
exit2:
  TRACE1(TRACE_GCRYPTO, 5, TRCID_CXIENCDEC_EXIT,
      "cxiKEncryptDecrypt: returns %d", rc);
  return rc;
}

#ifdef CONFIG_CRYPTO_FIPS
extern int fips_enabled;
#else
static int fips_enabled = 0;
#endif /* CONFIG_CRYPTO_FIPS */

/* 
 * Returns ENOSYS if kernel crypto cannot be found / initialized 
 * Returns GCRYPTO_KERN_CRYPTO_OK or GCRYPTO_KERN_CRYPTO_OK_FIPS on success
 */
int cxiInitKernelCrypto(void)
{
  /* TODO: self-test */

  if (fips_enabled)
    return GCRYPTO_KERN_CRYPTO_OK_FIPS;
  else
    return GCRYPTO_KERN_CRYPTO_OK;
}

#else /* GPFS_CRYPTO_KERNELPATH && HAS_NEW_CRYPTO_API */
int cxiKEncryptDecrypt(gcryptoCtx_t *ctxP,
    void *srcP,
    void *dstP,
    UInt32 len,
    UInt64 blockNum,
    Int32 isEncrypt)
{
  return ENOSYS;
}
int cxiInitKernelCrypto(void)
{
  return ENOSYS;
}
#endif /* GPFS_CRYPTO_KERNELPATH && HAS_NEW_CRYPTO_API */
#endif /* GPFS_ENC */
