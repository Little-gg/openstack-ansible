/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)07       1.19  src/avs/fs/mmfs/ts/kernext/gpl-linux/Shark-gpl.h, mmfs, avs_rfks1, rfks1s007a_addw 10/24/11 08:34:17 */
/*
 * Portability layer equivalent of <Shark.h>.
 *
 */

#ifndef _h_shark_gpl
#define _h_shark_gpl

/* Indicate portability source code */
#define GPFS_GPL

/* Try to ensure that this is the first file included in source code */
#ifdef _KERNEL
#if defined(_LINUX_TYPES_H) || defined(_LINUX_KERNEL_H) || defined(_LINUX_MODULE_H)
#error Shark-gpl.h must be included first; kernel file already seen
#endif
#else  /* !_KERNEL */
#ifdef _FEATURES_H
#error Shark-gpl.h must be included first; features.h already seen
#endif
#endif /* _KERNEL */

#ifdef _KERNEL
/* errno needs to be predeclared for kernel code */
extern int errno;

/* Include <linux/types.h> in kernel code for cxiTypes.h */
#include <linux/types.h>
/* need statfs stuff (fsid_t) */
#include <linux/vfs.h>
#endif /* _KERNEL */
#include <cxiTypes.h>

/* Avoid various AIX specific header includes */
#define _H_SLEEP
#define _H_LOCK_DEFINE

#ifdef _KERNEL
/* Virtual memory page size.  Used for aligning I/O buffers. */
#include <asm/page.h>     /* PAGE_SIZE */

#endif /* _KERNEL */

/* Macros to compute minimum and maximum of two numbers */
#ifndef MIN
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#endif

#ifndef NOOP
#define NOOP ((void)0)
#endif
#endif /* _h_shark_gpl */
