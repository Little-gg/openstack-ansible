/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)02       1.22  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiLinkList.h, mmfs, avs_rfks1, rfks1s007a_addw 10/16/13 09:34:24 */

#ifndef _h_CXILINKLIST
#define _h_CXILINKLIST

#include <cxiSystem.h>
#include <cxiTypes.h>

#ifdef __cplusplus

/* A macro that generates double linked list element classes.  The
   parameters of the macro are the class name, the type of the pointer
   fields within the class, the type of temporary pointers used
   within the class members, and the name of the complex list class
   that can manipulate lists using this class. */
#define DLink_template(_class,_memberPtrType,_lclPtrType,_listHeadType)  \
class _class                                                             \
{                                                                        \
  friend class _listHeadType;                                            \
public:                                                                  \
  _memberPtrType nextP;                                                  \
  _memberPtrType prevP;                                                  \
                                                                         \
  /* The head element of the list is initialized to point to itself,     \
   * signifying no elements on the list.                                 \
   */                                                                    \
  inline void init()                                                     \
  {                                                                      \
    nextP = this;                                                        \
    prevP = this;                                                        \
  }                                                                      \
                                                                         \
  _class()                                                               \
  {                                                                      \
    init();                                                              \
  }                                                                      \
                                                                         \
  /* Add an element or circular linked list of elements, immediately     \
   * after this (head of the list)                                       \
   */                                                                    \
  inline void enqueueHead(_lclPtrType *elementP)                         \
  {                                                                      \
    _lclPtrType *saveP = elementP->prevP;                                \
                                                                         \
    saveP->nextP = nextP;                                                \
    nextP->prevP = saveP;                                                \
    elementP->prevP = this;                                              \
    nextP = elementP;                                                    \
  }                                                                      \
                                                                         \
  /* Add an element or circular linked list of elements, immediately     \
   * preceding this (tail of the list)                                   \
   */                                                                    \
  inline void enqueueTail(_lclPtrType *elementP)                         \
  {                                                                      \
    _lclPtrType *saveP = elementP->prevP;                                \
                                                                         \
    prevP->nextP = elementP;                                             \
    elementP->prevP = prevP;                                             \
    prevP = saveP;                                                       \
    saveP->nextP = this;                                                 \
  }                                                                      \
                                                                         \
  /* Enqueue on unordered list; chose head arbitrarily. */               \
  void enqueue(_lclPtrType *elementP) { enqueueHead(elementP); }         \
                                                                         \
  /* Remove a single element from the linked list and                    \
   * initialize it as a linked list pointing to itself                   \
   */                                                                    \
  inline _lclPtrType *dequeue()                                          \
  {                                                                      \
    prevP->nextP = nextP;                                                \
    nextP->prevP = prevP;                                                \
    init();                                                              \
                                                                         \
    return this;                                                         \
  }                                                                      \
                                                                         \
  /* Remove the element immediately after this (head of the list)        \
   * and initialize it as a linked list pointing to itself.              \
   */                                                                    \
  inline _lclPtrType *dequeueHead()                                      \
  {                                                                      \
    return nextP->dequeue();                                             \
  }                                                                      \
                                                                         \
  /* Remove the element immediately preceeding this (tail of the list)   \
   * and initialize it as a linked list pointing to itself.              \
   */                                                                    \
  inline _lclPtrType *dequeueTail()                                      \
  {                                                                      \
    return prevP->dequeue();                                             \
  }                                                                      \
                                                                         \
  inline Boolean isEmpty() const                                         \
  {                                                                      \
    return (nextP == this);                                              \
  }                                                                      \
                                                                         \
  inline Boolean isNonEmpty() const                                      \
  {                                                                      \
    return (nextP != this);                                              \
  }                                                                      \
                                                                         \
  inline _lclPtrType *next() const                                       \
  {                                                                      \
    return nextP;                                                        \
  }                                                                      \
                                                                         \
  inline _lclPtrType *prev() const                                       \
  {                                                                      \
    return prevP;                                                        \
  }                                                                      \
                                                                         \
  inline _lclPtrType *head() const                                       \
  {                                                                      \
    return nextP;                                                        \
  }                                                                      \
                                                                         \
  inline _lclPtrType *tail() const                                       \
  {                                                                      \
    return prevP;                                                        \
  }                                                                      \
}

/* Define a doubly-linked element class that uses general swizzled pointers */
DLink_template(DLinkSwizzled_t, DLinkSwizzled_tSXPtr, DLinkSwizzled_t,  \
               DSwizzledListHead_t);

/* Define a doubly-linked element class that uses regular pointers */
DLink_template(DLink_t, DLink_t*, DLink_t, DListHead_t);

#else

/* The same class as above, declared as a structure for C code */
struct DLinkSwizzled_t
{
  /* Use standard pointers here for the portability layer / kernel. */
  struct DLinkSwizzled_t *nextP;
  struct DLinkSwizzled_t *prevP;
};

typedef struct DLinkSwizzled_t DLinkSwizzled_t;
#endif /* __cplusplus */


/* Inline functions mimic'ing the class members of the DLink class.
 * Can be used in either C or C++ code.
 */
static inline void
DLinkInit(DLinkSwizzled_t *thisP)
{
  thisP->nextP = thisP;
  thisP->prevP = thisP;
}

/* Add an element or circular linked list of elements, immediately
 * after this (head of the list)
 */
static inline void 
DLinkEnqueueHead(DLinkSwizzled_t *thisP, DLinkSwizzled_t *elementP)
{
  DLinkSwizzled_t *saveP = elementP->prevP;
 
  saveP->nextP = thisP->nextP;
  thisP->nextP->prevP = saveP;
  elementP->prevP = thisP;
  thisP->nextP = elementP;
}
 
/* Add an element or circular linked list of elements, immediately 
 * preceding this (tail of the list) 
 */
static inline void
DLinkEnqueueTail(DLinkSwizzled_t *thisP, DLinkSwizzled_t *elementP)
{
  DLinkSwizzled_t *saveP = elementP->prevP;

  thisP->prevP->nextP = elementP;
  elementP->prevP = thisP->prevP;
  thisP->prevP = saveP;
  saveP->nextP = thisP;
}

/* Remove a single element from the linked list and 
 * initialize it as a linked list pointing to itself
 */
static inline DLinkSwizzled_t *
DLinkDequeue(DLinkSwizzled_t *thisP)
{
  thisP->prevP->nextP = thisP->nextP;
  thisP->nextP->prevP = thisP->prevP;
  DLinkInit(thisP);

  return thisP;
}

/* Remove the element immediately after this (head of the list)
 * and initialize it as a linked list pointing to itself.
 */
static inline DLinkSwizzled_t *
DLinkDequeueHead(DLinkSwizzled_t *thisP)
{
  return DLinkDequeue(thisP->nextP);
}

/* Remove the element immediately preceeding this (tail of the list)
 * and initialize it as a linked list pointing to itself.
 */
static inline DLinkSwizzled_t *
DLinkDequeueTail(DLinkSwizzled_t *thisP)
{
  return DLinkDequeue(thisP->prevP);
}

static inline Boolean
DLinkIsEmpty(DLinkSwizzled_t *thisP)
{
  return (thisP->nextP == thisP);
}

/* Given a class type, a pointer to the class member, and the 
 * member name, return a pointer to the base class.
 */
#define MemberToClass(CLASSTYPE, PTRMEMBER, MEMBERNAME) \
  ((CLASSTYPE *)(((char *)PTRMEMBER) - OFFSET_OF(MEMBERNAME, CLASSTYPE)))


/* A more complex list type.  The list header contains a count of the
   number of elements on the list (exclusive of the header), and all
   list operations update the counter.  This implies that all list
   operations must be members of the list header class. */
#ifdef __cplusplus
class DListHead_t
{
private:
  /* List head.  Doubly-linked with the list element links. */
  DLink_t head;

  /* Number of items on list, not counting the header */
  unsigned count;

public:
  /* If the symbol VALIDATE_LISTS is defined, list integrity will be
     verified before and after every operation that changes a list.  If
     VALIDATE_LISTS is not defined, a validation routine will still be
     defined, but it will be a no-op and will not be called from the
     inline routines in this file.  The non-trivial list validation
     routine will be defined in ts/classes/basic/listutils.C if
     VALIDATE_LISTS is defined. */
#ifdef VALIDATE_LISTS
  void validateList(const char* labelP) const;
#define VL(_label) validateList(_label)
#else
  void validateList(const char* labelP) const { };
#define VL(_label)
#endif

  /* Make the list be empty */
  inline void init()
    {
      head.init();
      count = 0;
    }

  /* Initialize a list to empty */
  DListHead_t() { init(); }

  /* Return the number of elements on the list */
  inline int getSize() const { return count; }

  /* Return true if the list is empty */
  inline Boolean isEmpty() const { return count == 0; }

  /* Return true if the list is non-empty */
  inline Boolean isNonEmpty() const { return count != 0; }

  /* Return true if the given entry is the list head */
  inline Boolean isHead(const DLink_t* p) const { return p == &head; }

  /* Return a pointer to the list head */
  inline DLink_t* getHeadP() { return &head; }

  /* Append the given single element to the list */
  inline void append(DLink_t* p)
    {
      VL("append enter");
      head.enqueueTail(p);
      count += 1;
      VL("append exit");
    }
  inline void enqueueTail(DLink_t* p) { append(p); }

  /* Prepend the given single element to the list */
  inline void prepend(DLink_t* p)
    {
      VL("prepend enter");
      head.enqueueHead(p);
      count += 1;
      VL("prepend exit");
    }
  inline void enqueueHead(DLink_t* p) { prepend(p); }

  /* Insert the given single element after the named element */
  inline void insertAfter(DLink_t* p, DLink_t* afterP)
    {
      VL("insertAfter enter");
      afterP->enqueueHead(p);
      count += 1;
      VL("insertAfter exit");
    }

  /* Append the given list to the list.  Empties the given list. */
  inline void appendList(DListHead_t* lP)
    {
      VL("appendList enter");
#ifdef VALIDATE_LISTS
      lP->validateList("appendList parm enter");
#endif
      if (lP->count == 0)
        return;
      DLink_t* p = lP->head.head();
      lP->head.dequeue();
      head.enqueueTail(p);
      count += lP->count;
      lP->count = 0;
#ifdef VALIDATE_LISTS
      lP->validateList("appendList parm exit");
#endif
      VL("appendList exit");
    }

  /* Return the newest element of the list without changing the list.
     Return NULL if the list is empty. */
  inline DLink_t* getNewest() const
    {
      if (count == 0)
        return NULL;
      return head.tail();
    }

  inline DLink_t *getHeadTail() const {return head.tail();}

  /* Return the oldest element of the list without changing the list.
     Return NULL if the list is empty. */
  inline DLink_t* getOldest() const
    {
      if (count == 0)
        return NULL;
      return head.head();
    }

  inline DLink_t *getHeadHead() const {return head.head();}

  /* Remove the oldest element from the list.  Return NULL if the list is
     empty. */
  inline DLink_t* removeOldest()
    {
      DLink_t* p;
      VL("removeOldest enter");
      if (count == 0)
        return NULL;
      count -= 1;
      p = head.dequeueHead();
      VL("removeOldest exit");
      return p;
    }
  inline DLink_t* dequeueHead() { return removeOldest(); }

  /* Remove the newest element from the list.  Return NULL if the list is
     empty. */
  inline DLink_t* removeNewest()
    {
      DLink_t* p;
      VL("removeNewest enter");
      if (count == 0)
        return NULL;
      count -= 1;
      p = head.dequeueTail();
      VL("removeNewest exit");
      return p;
    }
  inline DLink_t* dequeueTail() { return removeNewest(); }

  /* Remove the given element from the list */
  inline void remove(DLink_t* p)
    {
      VL("remove enter");
      p->dequeue();
      DBGASSERT(count > 0);
      count -= 1;
      VL("remove exit");
    }
  inline void dequeue(DLink_t* p) { remove(p); }

  /* Move the given element to the 'new' end of the list */
  inline void moveNewest(DLink_t* p)
    {
      VL("moveNewest enter");
      p->dequeue();
      head.enqueueTail(p);
      VL("moveNewest exit");
    }

  /* Move the given element to the 'old' end of the list */
  inline void moveOldest(DLink_t* p)
    {
      VL("moveOldest enter");
      p->dequeue();
      head.enqueueHead(p);
      VL("moveOldest exit");
    }
#undef VL
};

class DListSwizzledHead_t
{
private:
  /* List head.  Doubly-linked with the list element links. */
  DLinkSwizzled_t head;

  /* Number of items on list, not counting the header */
  unsigned count;

public:
  /* If the symbol VALIDATE_LISTS is defined, list integrity will be
     verified before and after every operation that changes a list.  If
     VALIDATE_LISTS is not defined, a validation routine will still be
     defined, but it will be a no-op and will not be called from the
     inline routines in this file.  The non-trivial list validation
     routine will be defined in ts/classes/basic/listutils.C if
     VALIDATE_LISTS is defined. */
#ifdef VALIDATE_LISTS
  inline void validateCount() const
    { LOGASSERTRC((count == 0) == head.isEmpty(), count,  head.isEmpty(), 0); }
  void validateList(const char* labelP) const;
#define VL(_label) validateList(_label)
#else
  inline void validateCount() const { };
  void validateList(const char* labelP) const { };
#define VL(_label)
#endif

  /* Make the list be empty */
  inline void init()
    {
      head.init();
      count = 0;
    }

  /* Initialize a list to empty */
  DListSwizzledHead_t() { init(); }

  /* Return the number of elements on the list */
  inline unsigned getSize() const { return count; }

  /* Return true if the list is empty */
  inline Boolean isEmpty() const { validateCount(); return count == 0; }

  /* Return true if the list is non-empty */
  inline Boolean isNonEmpty() const { validateCount(); return count != 0; }

  /* Return true if the given entry is the list head */
  inline Boolean isHead(const DLinkSwizzled_t* p) const { return p == &head; }

  /* Return a pointer to the list head */
  inline DLinkSwizzled_t* getHeadP() { return &head; }

  /* Append the given single element to the list */
  inline void append(DLinkSwizzled_t* p)
    {
      VL("append enter");
      head.enqueueTail(p);
      count += 1;
      VL("append exit");
    }
  inline void enqueueTail(DLinkSwizzled_t* p) { append(p); }

  /* Prepend the given single element to the list */
  inline void prepend(DLinkSwizzled_t* p)
    {
      VL("prepend enter");
      head.enqueueHead(p);
      count += 1;
      VL("prepend exit");
    }
  inline void enqueueHead(DLinkSwizzled_t* p) { prepend(p); }

  /* Insert the given single element after the named element */
  inline void insertAfter(DLinkSwizzled_t* p, DLinkSwizzled_t* afterP)
    {
      VL("insertAfter enter");
      afterP->enqueueHead(p);
      count += 1;
      VL("insertAfter exit");
    }

  /* Append the given list to the list.  Empties the given list. */
  inline void appendList(DListSwizzledHead_t* lP)
    {
      VL("appendList enter");
#ifdef VALIDATE_LISTS
      lP->validateList("appendList parm enter");
#endif
      if (lP->count == 0)
        return;
      DLinkSwizzled_t* p = lP->head.head();
      lP->head.dequeue();
      head.enqueueTail(p);
      count += lP->count;
      lP->count = 0;
#ifdef VALIDATE_LISTS
      lP->validateList("appendList parm exit");
#endif
      VL("appendList exit");
    }

  /* Return the newest element of the list without changing the list.
     Return NULL if the list is empty. */
  inline DLinkSwizzled_t* getNewest() const
    {
      if (count == 0)
        return NULL;
      return head.tail();
    }

  inline DLinkSwizzled_t *getHeadTail() const {return head.tail();}

  /* Return the oldest element of the list without changing the list.
     Return NULL if the list is empty. */
  inline DLinkSwizzled_t* getOldest() const
    {
      if (count == 0)
        return NULL;
      return head.head();
    }

  inline DLinkSwizzled_t *getHeadHead() const {return head.head();}

  /* Remove the oldest element from the list.  Return NULL if the list is
     empty. */
  inline DLinkSwizzled_t* removeOldest()
    {
      DLinkSwizzled_t* p;
      VL("removeOldest enter");
      if (count == 0)
        return NULL;
      count -= 1;
      p = head.dequeueHead();
      VL("removeOldest exit");
      return p;
    }
  inline DLinkSwizzled_t* dequeueHead() { return removeOldest(); }

  /* Remove the newest element from the list.  Return NULL if the list is
     empty. */
  inline DLinkSwizzled_t* removeNewest()
    {
      DLinkSwizzled_t* p;
      VL("removeNewest enter");
      if (count == 0)
        return NULL;
      count -= 1;
      p = head.dequeueTail();
      VL("removeNewest exit");
      return p;
    }
  inline DLinkSwizzled_t* dequeueTail() { return removeNewest(); }

  /* Remove the given element from the list */
  inline void remove(DLinkSwizzled_t* p)
    {
      VL("remove enter");
      p->dequeue();
      DBGASSERT(count > 0);
      count -= 1;
      VL("remove exit");
    }
  inline void dequeue(DLinkSwizzled_t* p) { remove(p); }

  /* Move the given element to the 'new' end of the list */
  inline void moveNewest(DLinkSwizzled_t* p)
    {
      VL("moveNewest enter");
      p->dequeue();
      head.enqueueTail(p);
      VL("moveNewest exit");
    }

  /* Move the given element to the 'old' end of the list */
  inline void moveOldest(DLinkSwizzled_t* p)
    {
      VL("moveOldest enter");
      p->dequeue();
      head.enqueueHead(p);
      VL("moveOldest exit");
    }
#undef VL
};

#endif /* __cplusplus */

#endif /* _h_CXILINKLIST */
