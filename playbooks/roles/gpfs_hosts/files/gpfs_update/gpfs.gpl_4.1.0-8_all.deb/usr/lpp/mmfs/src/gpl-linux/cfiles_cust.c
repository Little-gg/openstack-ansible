/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)53       1.14  src/avs/fs/mmfs/ts/kernext/gpl-linux/cfiles_cust.c, mmfs, avs_rfks1, rfks1s007a_addw 4/14/11 17:13:25 */
/* This file is used to generate a customized mmfslinux kernel module. */

#if !defined( GPL_KBUILD )
#define KBUILD_MODNAME mmfslinux
#endif

/* We don't want to use the stuff in mm_track.h with page table operations
   on x86 (due to shared segment code w/o ptr swizzling in ss.c). */
#ifdef CONFIG_MEM_MIRROR
#  undef CONFIG_MEM_MIRROR
#endif

#ifndef GPL_KBUILD
/* We have to define __SMALL_STACK for s390x kernels with 8K stacks, otherwise
   THREAD_SIZE will be set wrong. Since we use our own build environment we
   have to do this by ourself. */
#if defined(GPFS_ARCH_S390X) && defined(CONFIG_SMALL_STACK)
#  define __SMALL_STACK
#endif
#endif

#ifndef KTRACE
#define DEFINE_TRACE_GBL_VARS
#endif
#define DEFINE_VFSSTATS_GBL_VARS
#define DEFINE_DYNASSERT_GBL_VARS

#include "cfiles.c"
