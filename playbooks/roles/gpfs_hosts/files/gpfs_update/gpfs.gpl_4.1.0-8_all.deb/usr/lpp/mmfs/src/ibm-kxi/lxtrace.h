/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)35	1.31  src/avs/fs/mmfs/ts/kernext/ibm-kxi/lxtrace.h, mmfs, avs_rfks1, rfks1s007a_addw 4/1/14 13:50:32 */

#ifndef _h_lxtrace
#define _h_lxtrace

/*
 * Interfaces to the Linux kernel trace device
 *
 * Contents:
 *   trc_datahdr_t
 *   trc_noseq_header_t
 *   trc_header_t
 *   trc_comp_header_t
 *   OverwriteHdr_t
 *   TraceRecord_t
 *
 *   TrcSegmentIdxAndOffset_t
 *   TrStreamDesc_t
 *   TraceSegmentHdr_t
 *   TraceBufferSegment_t
 *   SharedTraceBufferHeader_t
 *
 *   enum TraceIOCTLs
 *   struct kArg
 *
 *   i2nSpec_t
 *   enum trcdev_state_t
 *   typedef struct trcdev_anchor_t
 */

#ifndef _LINUX_TIME_H
#include <sys/time.h>
#endif

#define LXTRACE_MAX_DATA 512
#define LXTRACE_MAGIC 0xACE98271
#define LXTRACE_COMP_MAGIC 0xACE98272
#define LXTRACE_SEQ_MAGIC 0xACE98273
#define LXTRACE_OVERWRITE_MAGIC 0x764F   // "Ov" reversed
#define LXTRACE_FILLER 0x3040FFFF
#define LXTRACE_NODATA_MAGIC 0x0

#define LXTRACE_NR_CPUS 256
/* Number of "$n" substitutions supported in a single trace record */
#define LXTRACE_MAX_FORMAT_SUBS 20

#define LXTRACE_NEITHER   0x0
#define LXTRACE_BLK       0x1
#define LXTRACE_OVERWRITE 0x2

#define RL_DISABLE 0x0
#define RL_FLUSH 0x4
#define RL_NB_PAUSE 0x8
 /* While running in NB mode, we will briefly enable BLK mode to
    copy the data out. We also set this flag so we know that this is
    temporary */

/* Values for RelayFlags in lxtrace.c */
#define RL_BUF_GLOBAL 0x1
#define RL_BUF_PERCPU 0x2
#define RL_BUF_CTIME  0x4

#define DEBUG_DIR "/sys/kernel/debug/gpfs"

#define LXTRACE_PROJID 0xff

#define LXTRACE_MTYPE 0x1

#define LXTRACE_DIO_ALIGN 4096
#define LXTRACE_DIO_MASK (~(LXTRACE_DIO_ALIGN-1)) 
//#define LXTRACE_DEBUG
/* Convenience macros for printing error and debug messages */
#if defined(GPFS_LINUX)
#define DP(fmt,args...) fprintf(stderr, fmt, ## args)
#define DFP(fmt,args...) if (lxtraceDebug) fprintf(stderr, fmt, ## args)
#elif defined(GPFS_WINDOWS)
#define DP(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)
#ifdef LXTRACE_DEBUG
#define DFP(fmt,...) fprintf(stderr, fmt, __VA_ARGS__)
#else
#define DFP(fmt, ...) ((void)0)
#endif
typedef unsigned int Boolean;
#define false 0
#define true 1
#endif /* GPFS_... */


#if defined( __64BIT__) || defined(_LP64)
# define ARGTYPE long long
typedef long long argType;
#define ARGLEN sizeof(long long)
#define TRC_ARG(N) (((long long *)&application_data)[N])
#else
# define ARGTYPE int
typedef int argType;
#define ARGLEN sizeof(int)
#define TRC_ARG(N) (((int *)&application_data)[N])
#endif // __64BIT__ || __LP64

/* Formatting style for timestamps */
typedef enum
{
  fRawCycles,   /* absolute cycle count */
  fRelCycles,   /* cycles since first trace record */
  fLocal,       /* time-of-day, converted to a string via ctime */
  fTOD,         /* seconds since 1/1/1970 */
  fRelativeSecs /* relative seconds since the first trace record */
} TimestampStyle_t;
extern TimestampStyle_t TimestampStyle;

/* Header of a trace record to be passed to the trace device.  Also
   used in overwrite trace mode following an OverwriteHdr_t. */
typedef struct
{
  uint trHook;          /* Trace hook word that uniquely identifies the
                           format of this trace record */
  char trNArgs;         /* Number of integer arguments.  Each argument
                           is as long as the word width of the machine.
                           Does not count string, generic, or float
                           arguments. */
  unsigned char trSPos; /* Position of string argument within argument
                           list.  May also take on special values to
                           indicate all integers or all integers followed
                           by a float. */
  short trSLen;         /* If format is string or generic, contains the
                           length of the variable part, rounded up to a
                           multiple of the word size */
} trc_datahdr_t;
/* followed by char arg[LXTRACE_MAX_DATA-sizeof(trc_datahdr_t)] */

/* Definitions of the trace record format */
typedef struct
{
  uint trMagic;         /* Magic number to allow resynch after trace
                           wraparound */
  struct timeval trTime; /* Timestamp of trace record */
  pid_t trProcess;      /* ID of process making the trace */
  unsigned char trBuf;  /* bufNum of buffer used for trace */
  unsigned char trCPU;  /* CPU number of process making the trace */
  short trLength;       /* Number of bytes that follow, consisting of a
                           trc_datahdr_t followed by the application
                           data */
} trc_noseq_header_t;


typedef struct
{
  uint trMagic;         /* Magic number to allow resynch after trace
                           wraparound */
  struct timeval trTime; /* Timestamp of trace record */
  pid_t trProcess;      /* ID of process making the trace */
  unsigned char trBuf;  /* bufNum of buffer used for trace */
  unsigned char trCPU;  /* CPU number of process making the trace */
  short trLength;       /* Number of bytes that follow, consisting of a
                           trc_datahdr_t followed by the application
                           data */
  unsigned long long trSeq;            /* sequence number */
} trc_header_t;


typedef struct
{
  uint trMagic;         /* Magic number to allow resynch after trace
                           wraparound */
  int dataLength;       /* original data length */
  int compLength;       /* compressed data length */
} trc_comp_header_t;

/* Followed by the application trace data "char data[Length]" */


/* Header of a trace record when in overwrite mode */
typedef struct
{
  UInt16 oMagic;        /* Magic number for format checking */
  UInt16 oLength;       /* Total number of bytes in this trace record,
                           including this header, the trc_datahdr_t, and
                           the data that follows it */
  UInt32 oProcess;      /* ID of process making the trace */
  UInt64 oTime;         /* CPU cycle count of trace */
} OverwriteHdr_t;
/* Followed by a trc_datahdr_t and the arguments for the record */


/* Size of trace data temporary buffer */
#define _TRC_BUFSIZE (LXTRACE_MAX_DATA - sizeof(trc_datahdr_t) - sizeof(OverwriteHdr_t))


/* Trace record as it appears in the overwrite trace buffer */
typedef struct
{
  OverwriteHdr_t oHdr;
  trc_datahdr_t dHdr;
  ARGTYPE dataWords[_TRC_BUFSIZE/ARGLEN];
} TraceRecord_t;


#define HDRSIZE (sizeof(OverwriteHdr_t) + sizeof(trc_datahdr_t))


/* Number of bytes of trace between TOD records.  This must be a power of
   2 much larger than any trace record. */
#define TOD_INTERVAL (1uLL << 21)


/* Type used to hold the identity of a buffer segment and the offset
   within that segment where the next trace record should be appended.
   These are both packed into a single UInt64 so they can be updated
   together atomically.  The high-order bits give the subscript of the
   buffer segment within trbSegSpace, and the low-order bits record the
   append offset within the buffer segment.  A value of NO_TRC_SEGMENT
   in the high-order bits indicates that no buffer segment has been
   assigned.

   When it appears in a TrStreamDesc_t, this compound UInt64 will be
   updated using atomic add.  It is impossible for this atomic add to
   cause a carry into the high-order portion of the word that holds
   the segment index because of the following logic: the maximum that
   any thread will ever add is limited to LXTRACE_MAX_DATA.  If an
   increment done by some thread causes the buffer segment offset to
   exceed TRACE_BUFFER_SEGMENT_BYTES, the thread will not perform
   another increment until it has obtained a fresh buffer segment
   using the TrGetBufferSegment ioctl.  Thus, the maximum value of
   the buffer offset subfield is limited by the number of threads
   that can have concurrently incremented the word and could be
   waiting for a new buffer segment to be allocated.  With the current
   value for LXTRACE_MAX_DATA, it would require nearly 8M threads to
   simultaneously call TrGetBufferSegment without any of them returning
   from that ioctl to cause an overflow into the high-order bits. */
typedef UInt64 TrcSegmentIdxAndOffset_t;
#define IDX_AND_OFFSET_2_TRCWORD(_idx,_off) ((((UInt64)(_idx)) << 32) | (_off))
#define TRCWORD_2_INDEX(_w)  ((_w) >> 32)
#define TRCWORD_2_OFFSET(_w) ((_w) & 0xFFFFFFFFuLL)
#define NO_TRC_SEGMENT 0x0FFFFFFF

/* Trace stream descriptor.  There will be one of these for each
   processor doing kernel traces, and one of these for each hash bucket
   used by daemon traces.  Each descriptor is aligned on a cache line
   boundary. */
typedef struct
{
  /* Magic number of stream descriptor */
  UInt32 stMagic;
#define TRC_STREAM_MAGIC 0x4D525453  /* "STRM" reversed for little-endian */

  /* Stream index - helpful in dumps */
  UInt32 stStreamIndex;

  /* Index of the buffer segment currently owned by this stream, and the
     append position within that segment */
  volatile TrcSegmentIdxAndOffset_t stSegmentAndOffset;

  /* Count of the number of buffer segments assignments for this stream */
  UInt64 stSegmentAllocs;

  /* Count of the number of calls to assign a buffer segment that
     found a segment already allocated.  Useful as a proxy for
     the amount of contention on this stream. */
  UInt64 stNSegmentAlreadyAlloc;

  /* Fields filled in only just before the shared trace buffer is
     dumped to a file */

  /* Number of buffer segments in output file for this stream */
  UInt64 stNSegmentsDumped;

  /* Padding to cache line boundary */
  char stPadding[CACHE_LINE_SIZE - sizeof(TrcSegmentIdxAndOffset_t) -
                 3*sizeof(UInt64) - 2*sizeof(UInt32)];
} TrStreamDesc_t;

/* Number of trace streams.  The lowest-numbered streams are used by
   kernel code. */
#define N_KERNEL_TRACE_STREAMS 64
#define N_DAEMON_TRACE_STREAMS 128
#define TOTAL_STREAMS (N_KERNEL_TRACE_STREAMS+N_DAEMON_TRACE_STREAMS)

/* Stream index denoting 'no stream'.  Must be larger than the sum of the
   N_xxx_TRACE_STREAMS above. */
#define NO_TRACE_STREAM 0xFFFF

/* Size of each trace buffer segment.  At most one segment will be
   active for each stream at a time.  Cannot be larger than 64K, because
   the length field in an overwrite header is only 16 bits, and it
   must be capable of describing a filler record that fills an entire
   segment. */
#define TRACE_BUFFER_SEGMENT_BYTES (64*1024uLL)

/* Boundary to round each trace record in overwrite mode.  There is
   no need to round to a cache line boundary, since the next append
   to the same cache line is very likely to come from the same
   processor, so there will be little false sharing. */
#define TRACE_ROUND 8

/* Minimum number of bytes needed to store a trace record.  Used to
   determine if there will be enough space left in a buffer segment to
   hold a filler record. */
#define MIN_TRACE_RECORD \
  (ROUNDUP((sizeof(OverwriteHdr_t)+sizeof(trc_datahdr_t)), TRACE_ROUND))


/* Format of the header of a buffer segment.  Fields in this segment
   header structure will only be examined or modified in the kernel
   while holding the trace spin lock. */
typedef struct
{
  /* Magic number of a trace buffer segment */
  UInt32 segMagic;
#define TRC_SEGMENT_MAGIC 0x4D474553  /* "SEGM" reversed for little-endian */

  /* Segment index - helpful in dumps */
  UInt32 segThisIndex;

  /* The trace stream for which this segment holds trace records */
  UInt64 segStream;

  /* In retired segments, index within the shared trace buffer of the
     next younger retired buffer segment, with NO_TRC_SEGMENT used
     as a NULL pointer.  Will be NO_TRC_SEGMENT for active segments.
     Links retired buffer segments onto a global LRU list anchored by
     trbOldestRetiredIdx. */
  UInt32 segYoungerRetiredIdx;

  /* Index within the shared trace buffer of the previous segment
     assigned to the same stream as this segment, or NO_TRC_SEGMENT
     if there is no such segment.  It is possible that the segment
     identified by this index no longer belongs to this stream, or
     that it has recently been reused as an active segment.  The
     segStreamOlderTimestamp field of this segment must match
     segTimestamp in the segment given by this index for this index to
     be considered valid. */
  UInt32 segStreamOlderIdx;

  /* Value of segTimestamp in the buffer segment identified by
     segStreamOlderIdx */
  UInt64 segStreamOlderTimestamp;

  /* Cycle counter at the time this buffer segment last became active */
  UInt64 segTimestamp;

  /* Cycle counter of the filler record at the end of this segment.
     Will be 0 for active segments. */
  UInt64 segFillerTimestamp;

  /* Padding to a cache line boundary */
  char segPadding[CACHE_LINE_SIZE - 4*sizeof(UInt64) - 4*sizeof(UInt32)];
} TraceSegmentHdr_t;


/* Overall format of a buffer segment.  Each segment has a header that
   describes its current usage, followed by the area in which trace
   records are appended.  Segments can either be 'active', meaning that
   they are pointed to by some stream descriptor, or 'retired', meaning
   that they have been filled and moved to the global LRU list. */
typedef struct
{
  /* First cache line holds the segment header */
  TraceSegmentHdr_t segHdr;

  /* Area that holds trace records */
  char segTrace[TRACE_BUFFER_SEGMENT_BYTES - sizeof(TraceSegmentHdr_t)];
} TraceBufferSegment_t;


/* Alignment of stream descriptors and buffer segments within
   SharedTraceBufferHeader_t */
#define STREAM_ALIGNMENT 4096
#define SEGMENT_ALIGNMENT 4096

/* Format of the shared buffer when tracing in overwrite mode.  The buffer
   will be aligned on a page boundary. */
typedef struct
{
  /* The first set of fields in the header are not updated frequently */

  /* Magic number.  Must be OVERWRITE_MAGIC, which is "OVERWRIT"
     reversed for little-endian. */
  UInt64 trbMagic;
#define OVERWRITE_MAGIC 0x544952575245564FuLL

  /* Total number of bytes in this vmalloc'ed area */
  UInt64 trbSize;

  /* Total number of segments dumped for all streams.  Filled in
     only when flushing a trace buffer to disk. */
  UInt64 trbTotalSegmentsDumped;

  /* Number of streams within the shared trace buffer */
  UInt32 trbNStreams;

  /* Number of buffer segments within the shared trace buffer */
  UInt32 trbNSegments;

  /* Offset of 0th stream descriptor within the shared trace buffer -
     helpful in dumps */
  UInt32 trbStreamOffset;

  /* Offset of the 0th buffer segment within the shared trace buffer -
     helpful in dumps */
  UInt32 trbSegmentOffset;

  /* If known, the rate at which the cycle counter increments, as reported
     by the OS */
  UInt64 trbOSTimerRatePerSecond;

  /* Time-of-day and cycle count when shared trace buffer was created and
     kernel tracing was enabled */
  UInt64 trbStartTimeStamp;
  struct timeval trbStartTOD;

  /* Time-of-day and cycle count when daemon tracing was enabled */
  UInt64 trbDaemonStartTimeStamp;
  struct timeval trbDaemonStartTOD;

  /* Time-of-day and timestamp when tracing was quiesced */
  UInt64 trbQuiesceTimeStamp;
  struct timeval trbQuiesceTOD;

  /* Earliest time at which all streams contain data.  Filled in just
     before dumping the trace buffer to a file. */
  UInt64 trbAllStreamsHaveDataTimeStamp;

  /* Number of bytes in all fields above here */
#define _HDR_PREFIX_SIZE (4*sizeof(UInt32) + \
                          8*sizeof(UInt64) + \
                          3*sizeof(struct timeval))

  /* Padding to cache line boundary */
  char trbPadding1[CACHE_LINE_SIZE - (_HDR_PREFIX_SIZE%CACHE_LINE_SIZE)];

  /* The next few fields are updated whenever new segments are assigned,
     so they are segregated into their own cache line to ensure that
     they all fit within a single cache line */

  /* Indices within the shared trace buffer of the oldest and youngest
     retired buffer segments.  Updates are protected by a kernel spin
     lock.  There are always enough buffer segments to guarantee that
     the oldest and youngest retired buffers will be distinct. */
  UInt32 trbOldestRetiredIdx;
  UInt32 trbYoungestRetiredIdx;

  /* Number of TrGetBufferSegment ioctls */
  UInt64 trbNGetSegmentIoctls;

  /* Padding to cache line boundary */
  char trbPadding2[CACHE_LINE_SIZE - (sizeof(UInt64) + 2*sizeof(UInt32))];

  /* Number of bytes in all fields above here */
#define _HDR_SIZE                                            \
  ( _HDR_PREFIX_SIZE +                                       \
    (CACHE_LINE_SIZE - (_HDR_PREFIX_SIZE%CACHE_LINE_SIZE)) + \
    CACHE_LINE_SIZE )

  /* Padding to stream descriptor boundary */
  char trbPadding3[STREAM_ALIGNMENT - _HDR_SIZE];

  /* Array of stream descriptors.  There will be one of these for each
     processor doing kernel traces, and one of these for each hash bucket
     used by daemon traces.  Each descriptor is aligned on a cache line
     boundary. */
  TrStreamDesc_t trbStream[TOTAL_STREAMS];

  /* Number of bytes in all fields above here */
#define _HDR_PLUS_STREAMS                    \
  ( _HDR_SIZE +                              \
    (STREAM_ALIGNMENT - _HDR_SIZE) +         \
    (TOTAL_STREAMS*sizeof(TrStreamDesc_t)) )

  /* Padding to a segment alignment boundary */
  char trbPadding4[SEGMENT_ALIGNMENT - (_HDR_PLUS_STREAMS%SEGMENT_ALIGNMENT)];

  /* As many buffer segments as fit in the remaining buffer space.
     Initially, all buffer segments will be linked onto the list
     of retired buffers anchored by trbOldestRetiredIdx and
     trbYoungestRetiredIdx. */
  TraceBufferSegment_t trbSegSpace[0];
} SharedTraceBufferHeader_t;


/* The following device operations are supported for the trace device:
    trc_open     Prepare the device for tracing
    trc_ioctl    Device control operation (see the trace_op definition)
    trc_write    Trace records are writen to the device
    trc_close    Terminate tracing and close the device
 */

/* Device ioctl operations */
enum TraceIOCTLs
{
  /* Query current trace mode (none, blocking, or overwrite) */
  TrQueryKernelTraceMode = 10,

  /* Allocate a new shared trace buffer */
  TrAllocateSharedBuffer = 11,

  /* Start blocking tracing using a private kernel buffer */
  TrStartBlockingTrace = 12,

  /* Start overwrite tracing using a shared buffer */
  TrStartOverwriteTrace = 13,

  /* Stop tracing to shared or private buffer */
  TrStopTrace = 14,

  /* Deallocate shared trace buffer */
  TrDeallocateSharedBuffer = 15,

  /* Return the size of the shared trace buffer */
  TrQuerySharedBufferSize = 16,

  /* Record the identity of the trace daemon process so it can be signalled */
  TrRegisterTraceDaemon = 17,

  /* Get a new trace buffer segment for a trace stream */
  TrGetBufferSegment = 18,

  /* Signal the trace daemon to dump its current buffer and continue
     tracing */
  TrRecycleTrace = 19,

  /* Append a trace record to the private kernel trace buffer */
  TrAppendPrivateBuffer = 20,

  /* Set kernel trace mode */
  TrSetKernelTraceMode = 21,

  /* Acknowledge that daemon overwrite tracing has been enabled */
  TrAckDaemonOverwriteTracing = 22,

  /* Append a trace record to the shared trace buffer, only for
     GPFS stand alone utility trace */
  TrAppendSharedBuffer = 23
};

/* Structure for passing parameters to the trace device through ioctls */
struct kArgs
{
  long arg1;
  long arg2;
  long arg3;
  long arg4;
  long arg5;
};

#ifdef __cplusplus
extern "C"
{
#endif
  int trc_fsync();
#ifdef __cplusplus
}
#endif


/* Allowable file sizes for the lxtrace command */
#define MIN_TRC_FILESIZE 1*1024*1024
#define DEF_TRC_FILESIZE 128*1024*1024
#define MAX_TRC_FILESIZE 16*1024*1024*1024LL

/* Allowable buffer sizes for the lxtrace command.  Two buffers of this
   size will be allocated in blocking mode. */
#define MIN_TRC_BUFSIZE 1*1024*1024 
#define DEF_TRC_BUFSIZE 4*1024*1024
#define MAX_TRC_BUFSIZE 64*1024*1024

/* Total buffer size */
#define MIN_TRC_OVERWRITE_BUFSIZE 64*1024*1024
#define DEF_TRC_OVERWRITE_BUFSIZE 128*1024*1024

/* Allowable per-cpu buffer number for relay */
#define MIN_TRC_BUFNUM 2
#define DEF_TRC_BUFNUM 4
#define MAX_TRC_BUFNUM 32

/* Allowable per-cpu buffer number for relay */
#define MIN_TRC_COMPLEVEL 0
#define DEF_TRC_COMPLEVEL 6
#define MAX_TRC_COMPLEVEL 9

// Default flush interval for relay 
#define DEF_TRC_INT 0 

/* Trace device name */
#define TRC_DEVICE "/dev/trace0"

#define LXTRACE_CMD_PATH "/usr/lpp/mmfs/bin/lxtrace"

/* Structure of mesage queue messages from the lxtrace daemon process to
   an lxtrace main process */
#define LXTRACE_MSG_LEN 16
typedef struct TraceDaemonMsg
{
  long mtype;      /* message type, must be > 0 */
  char mtext[LXTRACE_MSG_LEN];  /* message data */
} TraceDaemonMsg_t;
#define LXTRACE_INIT_OK "success"
#define LXTRACE_INIT_ERR "error"

#define TRC_MAX_ID2NAME 128
typedef struct { char s[TRC_MAX_ID2NAME]; } idname_t;
#ifdef GPFS_WINDOWS
#define TRCFMT_NAME "tstrcfmt"
#else
#define TRCFMT_NAME "lxtrace format"
#endif

/* id2name conversion specifier. */
typedef struct i2nSpec_t
{
  int argNum;       // number of the argument to be converted
  char *i2nNameP;   // conversion function name
} i2nSpec_t;


#ifdef __KERNEL__

/* Possible states of the trace device.  Do not rearrange these; code in
   isTraced depends on the relative order of state values. */
typedef enum trcdev_state_t
{
  TrcStateInitialized,        /* header constructed */
  TrcStateOpened,             /* device opened      */
  TrcStateStopped,            /* tracing disabled   */
  TrcStateActiveKernelBuffer, /* tracing using private kernel buffer
                                 (blocking mode) */
  TrcStateActiveSharedBuffer, /* tracing using shared buffer (overwrite
                                 mode) */
} trcdev_state_t;

typedef struct trcdev_anchor_t
{
  int major;                /* major number of the trace device */
  int minor;                /* minor number of the trace device */
  int nOpens;               /* number of times the device is open */
  trcdev_state_t state;     /* status of the trace device */
} trcdev_anchor_t;

#endif /* __KERNEL __ */

#endif /* _h_lxtrace */
