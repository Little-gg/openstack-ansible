/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)62       1.19  src/avs/fs/mmfs/ts/kernext/gpl-linux/relaytrc.c, mmfs, avs_rfks1, rfks1s007a_addw 10/30/13 13:22:39 */

/**************************************************************************
 *
 * Relayfs kernel trace functions
 *
 **************************************************************************/
#ifndef GPFS_PRINTF

#ifndef __KERNEL__
#  define __KERNEL__
#endif

#if defined(GPFS_LINUX)

#include <Shark-gpl.h>
#include <verdep.h>
#include <lxtrace.h>

#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>

#if (defined(SUSE_LINUX) && (LINUX_KERNEL_VERSION <= 2061646) )
#include <linux/relayfs_fs.h>
#else
#include <linux/relay.h>
#endif
#include <linux/debugfs.h>

/* GPFS relay channel/control files appear in /sys/kernel/debug/gpfs */

/* app data */
static struct rchan *  chan;
static struct dentry *  dir;
static int    rl_logging;
static int    rl_buf_create;
static int    mappings;
static int    suspended;
static size_t    subbuf_size = 262144;
static size_t    n_subbufs = 4;

/* channel-management control files */
static struct dentry  *enabled_control;
static struct dentry  *create_control;
static struct dentry  *subbuf_size_control;
static struct dentry  *n_subbufs_control;
static struct dentry  *dropped_control;

/* produced/consumed control files */
static struct dentry  *produced_control[LXTRACE_NR_CPUS];
static struct dentry  *consumed_control[LXTRACE_NR_CPUS];

/* control file fileop declarations */
struct file_operations  enabled_fops;
struct file_operations  create_fops;
struct file_operations  subbuf_size_fops;
struct file_operations  n_subbufs_fops;
struct file_operations  dropped_fops;
struct file_operations  produced_fops;
struct file_operations  consumed_fops;

/* forward declarations */
static int create_controls(void);
static void destroy_channel(void);
static void remove_controls(void);

static wait_queue_head_t waitq;
extern spinlock_t seqLock;
extern volatile unsigned long long TraceSeq;

//use read-write lock for percpu buffer instead of spinlock to improve the performance
static rwlock_t percpuLock;

//use 64bit atomic for sequence number
//on 32bit system or 64bit old kernels, use spinlock to protect a 64bit number instead
#if (defined(__64BIT__) && (LINUX_KERNEL_VERSION > 2061400) )
static atomic64_t percpuSeq;
#define INC_SEQ(n) n=atomic64_inc_return(&percpuSeq);
#define INIT_SEQ atomic64_set(&percpuSeq,0);
#else
static unsigned long long percpuSeq;
#define INC_SEQ(n) \
spin_lock(&seqLock); \
n=++percpuSeq; \
spin_unlock(&seqLock);
#define INIT_SEQ percpuSeq=0; 
#endif

static atomic_t dropped;
//processing > 0 means relay buffer are accessed and we can not make a safe relayf flush
static volatile int processing;

int isRLEnabled()
{
  return rl_logging;
}

int isRLBufFull(struct rchan_buf *buf)
{
  int full;

  spin_lock(&seqLock);
  //In overwrite (aka NB) mode if we have full buffers then we just overwrite
  //an existing buffer. RL_NB_PAUSE is for when we switch NB mode to blocking
  //to copy data out of the kernel
  if (rl_logging == RL_DISABLE  ||
     (rl_logging & RL_NB_PAUSE) != 0 ||
     (rl_logging & LXTRACE_OVERWRITE) != 0)
  {
    spin_unlock(&seqLock);
    return 0;
  }

  full = relay_buf_full(buf);
  spin_unlock(&seqLock);

  return full;
}

/* Add count bytes to a sub-buffer's commit count
 */
void
commit(struct rchan_buf *buf, unsigned char subbuf_idx, unsigned count)
{
  size_t *commit;

  commit = buf->start + subbuf_idx * buf->chan->subbuf_size;
  *commit += count;
}

/* Write trace record into relay buffer
 */
void rl_trc_write(const char *bufP, size_t nBytes, int nb)
{
  struct rchan_buf *buf;
  void *reserved, *p;
  int len = sizeof(trc_header_t) + nBytes; // + sizeof(size_t);
  trc_header_t tHdr;
  int retry=0;
  struct timespec ts;

  if (rl_logging == RL_DISABLE)
    return;

  /* Construct the trace record header */
  tHdr.trMagic = LXTRACE_SEQ_MAGIC;
  tHdr.trProcess = current->pid;
  tHdr.trLength = nBytes;

  //try to reserve a relay buffer until succceed
  if (rl_buf_create & RL_BUF_PERCPU)
  {
    //using per-CPU buffer
    while (1)
    {
      read_lock(&percpuLock);
      if (rl_logging == RL_DISABLE)
      {
        read_unlock(&percpuLock);
        return;
      }
      //hold on for relay buffer flush
      if ((rl_logging & RL_FLUSH) != 0)
      {
        read_unlock(&percpuLock);
        continue;
      }
        
      tHdr.trCPU = get_cpu();
      buf = chan->buf[tHdr.trCPU];
      reserved = p = relay_reserve(chan, len);
      if (reserved)
      {
        tHdr.trBuf = ( reserved - buf->start ) / buf->chan->subbuf_size;
        //use coarse-grained timestamp to avoid clock overhead
        if (rl_buf_create & RL_BUF_CTIME )
        {
          ts = current_kernel_time();
          tHdr.trTime.tv_sec = ts.tv_sec;
          tHdr.trTime.tv_usec = ts.tv_nsec / 1000;
        }
        else
          do_gettimeofday(&tHdr.trTime);
        INC_SEQ(tHdr.trSeq);
        memcpy(reserved, &tHdr, sizeof(trc_header_t));
        memcpy(reserved+sizeof(trc_header_t), bufP, nBytes);
        commit(buf, tHdr.trBuf, len);
        put_cpu();
        read_unlock(&percpuLock);
        break;
      }
      else
      {
        put_cpu();
        retry++;
        read_unlock(&percpuLock);
        if (nb ) 
        {
          atomic_inc(&dropped);
          break;
        }
        //      schedule();
        set_current_state(TASK_INTERRUPTIBLE);
  
        schedule_timeout(1);
      }
    }
  } // per-cpu buffer
  else
  {
    //using global trace buffers and single spinlock for protection
    while (1)
    {
      spin_lock(&seqLock);
      if (rl_logging == RL_DISABLE)
      {
        spin_unlock(&seqLock);
        return;
      }
      //hold on for relay buffer flush
      else if ((rl_logging & RL_FLUSH) != 0)
      {
        spin_unlock(&seqLock);
        continue;
      }
      tHdr.trCPU = smp_processor_id();
      buf = chan->buf[tHdr.trCPU];
      reserved = p = relay_reserve(chan, len);
      if (reserved)
      {
        tHdr.trBuf = ( reserved - buf->start ) / buf->chan->subbuf_size;
        //use coarse-grained timestamp to avoid clock overhead
        if (rl_buf_create & RL_BUF_CTIME )
        {
          ts = current_kernel_time();
          tHdr.trTime.tv_sec = ts.tv_sec;
          tHdr.trTime.tv_usec = ts.tv_nsec / 1000;
        }
        else
          do_gettimeofday(&tHdr.trTime);
        tHdr.trSeq = ++TraceSeq;
        memcpy(reserved, &tHdr, sizeof(trc_header_t));
        memcpy(reserved+sizeof(trc_header_t), bufP, nBytes);
        commit(buf, tHdr.trBuf, len);
        spin_unlock(&seqLock);
        break;
      }
      else
      {
        spin_unlock(&seqLock);
        retry++;
        if (nb ) 
        {
          atomic_inc(&dropped);
          break;
        }
        wait_event(waitq, !isRLBufFull(buf));
      }
    }
  } // global buffer
}

void rl_trc_stop(void)
{
  if (rl_buf_create & RL_BUF_PERCPU)
  {
    write_lock(&percpuLock);
    rl_logging = RL_DISABLE;
    write_unlock(&percpuLock);
  }
  else
  {
    spin_lock(&seqLock);
    rl_logging = RL_DISABLE;
    spin_unlock(&seqLock);
    
  }
  wake_up(&waitq);
  destroy_channel();
}
/*
 * init - initialize relay
 *
 * relay files will be named /sys/kernel/debug/gpfs/cpuXXX
 */
int rl_init(void)
{
  dir = debugfs_create_dir("gpfs", NULL);
  if (!dir)
  {
    printk("Couldn't create relay app directory.\n");
    return -ENOMEM;
  }

  if (create_controls())
  {
    debugfs_remove(dir);
    return -ENOMEM;
  }
  rwlock_init(&percpuLock);
  init_waitqueue_head(&waitq);
  return 0;
}

/*
 * cleanup - destroy channel and remove probe
 */
void rl_cleanup(void)
{
  destroy_channel();
  remove_controls();
  if (dir)
    debugfs_remove(dir);
}

/*
 * subbuf_start() relay callback.
 */
static int subbuf_start_handler(struct rchan_buf *buf,
                                void *subbuf,
                                void *prev_subbuf,
                                size_t prev_padding)
{
  // reserve spots for commit count, padding
  unsigned int start_reserve = 2 * sizeof(size_t);

  if (prev_subbuf)
  {
    //printk("%d commit\n",*((size_t *)prev_subbuf));
    /* skip over commit count, padding is 2nd val */
    prev_subbuf += sizeof(size_t);
    *((size_t *)prev_subbuf) = prev_padding;
    //printk("%d padding\n",prev_padding);
  }

  if ((rl_logging & LXTRACE_BLK) != 0)
  {
    //for blocking mode return failure and let caller retry
    if (relay_buf_full(buf))
    {
      if (!suspended)
      {
        suspended = 1;
        //printk("cpu %d buffer full!!!\n", smp_processor_id());
      }
      return 0;
    }
    else if (suspended)
    {
      suspended = 0;
      //printk("cpu %d buffer no longer full.\n", smp_processor_id());
    }
  }

  //for overwrite mode, always start with oldest buffer
  subbuf_start_reserve(buf, start_reserve);
  // commit count is value at beginning of sub-buffer
  // do not reset this for the last buffer in overwrite mode
  if (rl_logging != RL_DISABLE)
    *((size_t *)subbuf) = 0;

  return 1;
}


/**
 *  remove_channel_controls - removes produced/consumed control files
 */
static void remove_channel_controls(void)
{
  int i;

  for (i = 0; i < LXTRACE_NR_CPUS; i++)
  {
    if (produced_control[i])
    {
      debugfs_remove(produced_control[i]);
      produced_control[i] = NULL;
      continue;
    }
    break;
  }

  for (i = 0; i < LXTRACE_NR_CPUS; i++)
  {
    if (consumed_control[i])
    {
      debugfs_remove(consumed_control[i]);
      consumed_control[i] = NULL;
      continue;
    }
    break;
  }
}

/**
 *  create_channel_controls - creates produced/consumed control files
 *
 *  Returns channel on success, negative otherwise.
 */
static int create_channel_controls(struct dentry *parent,
                                   const char *base_filename,
                                   struct rchan *chan)
{
  unsigned int i;
  char *tmpname = kmalloc(NAME_MAX + 1, GFP_KERNEL);
  if (!tmpname)
    return -ENOMEM;

  for_each_online_cpu(i)
    {
      sprintf(tmpname, "%s%d.produced", base_filename, i);
      produced_control[i] = debugfs_create_file(tmpname, 0, parent, chan->buf[i], &produced_fops);
      if (!produced_control[i])
      {
        printk("Couldn't create relay control file %s.\n",
               tmpname);
        goto cleanup_control_files;
      }

      sprintf(tmpname, "%s%d.consumed", base_filename, i);
      consumed_control[i] = debugfs_create_file(tmpname, 0, parent, chan->buf[i], &consumed_fops);
      if (!consumed_control[i])
      {
        printk("Couldn't create relay control file %s.\n",
               tmpname);
        goto cleanup_control_files;
      }
      
      //just create control files for the global buffer
      if (!(rl_buf_create & RL_BUF_PERCPU))
        break;
    }

  return 0;

cleanup_control_files:
  remove_channel_controls();
  return -ENOMEM;
}

/*
 * file_create() callback.  Creates relay file in debugfs.
 */
#ifdef NEW_MODE_TYPE
static struct dentry *create_buf_file_handler(const char *filename,
                                              struct dentry *parent,
                                              umode_t mode,
                                              struct rchan_buf *buf,
                                              int *is_global)
#else
static struct dentry *create_buf_file_handler(const char *filename,
                                              struct dentry *parent,
                                              int mode,
                                              struct rchan_buf *buf,
                                              int *is_global)
#endif
{
  struct dentry *buf_file;

  buf_file = debugfs_create_file(filename, mode, parent, buf,
                                 &relay_file_operations);

  if ( !(rl_buf_create & RL_BUF_PERCPU) )
    *is_global = 1;
  return buf_file;
}

/*
 * file_remove() default callback.  Removes relay file in debugfs.
 */
static int remove_buf_file_handler(struct dentry *dentry)
{
  debugfs_remove(dentry);

  return 0;
}

/*
 * relay callbacks
 */
static struct rchan_callbacks relay_callbacks =
{
  .subbuf_start = subbuf_start_handler,
  .create_buf_file = create_buf_file_handler,
  .remove_buf_file = remove_buf_file_handler,
};

/**
 *  create_channel - creates channel /debug/gpfs/cpuXXX
 *
 *  Creates channel along with associated produced/consumed control files
 *
 *  Returns channel on success, NULL otherwise
 */
static struct rchan *create_channel(unsigned subbuf_size,
                                    unsigned n_subbufs)
{
  struct rchan *chan;

  chan = RELAY_OPEN("cpu", dir, subbuf_size,
                    n_subbufs, &relay_callbacks);

  if (!chan)
  {
    printk("relay app channel creation failed\n");
    return NULL;
  }

  if (create_channel_controls(dir, "cpu", chan))
  {
    relay_close(chan);
    return NULL;
  }

  rl_logging = RL_DISABLE;
  mappings = 0;
  suspended = 0;
  atomic_set(&dropped, 0);
  INIT_SEQ;

  return chan;
}

/**
 *  destroy_channel - destroys channel /debug/gpfs/cpuXXX
 *
 *  Destroys channel along with associated produced/consumed control files
 */
static void destroy_channel(void)
{
  if (chan)
  {
    relay_close(chan);
    chan = NULL;
  }
  remove_channel_controls();
}

/**
 *  remove_controls - removes channel management control files
 */
static void remove_controls(void)
{
  if (enabled_control)
    debugfs_remove(enabled_control);

  if (subbuf_size_control)
    debugfs_remove(subbuf_size_control);

  if (n_subbufs_control)
    debugfs_remove(n_subbufs_control);

  if (create_control)
    debugfs_remove(create_control);

  if (dropped_control)
    debugfs_remove(dropped_control);
}

/**
 *  create_controls - creates channel management control files
 *
 *  Returns 0 on success, negative otherwise.
 */
static int create_controls(void)
{
  enabled_control = debugfs_create_file("enabled", 0, dir,
                                        NULL, &enabled_fops);
  if (!enabled_control)
  {
    printk("Couldn't create relay control file 'enabled'.\n");
    goto fail;
  }

  subbuf_size_control = debugfs_create_file("subbuf_size", 0, dir,
                                            NULL, &subbuf_size_fops);
  if (!subbuf_size_control)
  {
    printk("Couldn't create relay control file 'subbuf_size'.\n");
    goto fail;
  }

  n_subbufs_control = debugfs_create_file("n_subbufs", 0, dir,
                                          NULL, &n_subbufs_fops);
  if (!n_subbufs_control)
  {
    printk("Couldn't create relay control file 'n_subbufs'.\n");
    goto fail;
  }

  create_control = debugfs_create_file("create", 0, dir,
                                       NULL, &create_fops);
  if (!create_control)
  {
    printk("Couldn't create relay control file 'create'.\n");
    goto fail;
  }

  dropped_control = debugfs_create_file("dropped", 0, dir,
                                        NULL, &dropped_fops);
  if (!dropped_control)
  {
    printk("Couldn't create relay control file 'dropped'.\n");
    goto fail;
  }

  return 0;
fail:
  remove_controls();
  return -1;
}

/*
 * control file fileop definitions
 */

/*
 * control files for relay channel management
 */

static ssize_t enabled_read(struct file *filp, char __user *buffer,
                            size_t count, loff_t *ppos)
{
  char buf[16];

  snprintf(buf, sizeof(buf), "%d\n", rl_logging);
  return simple_read_from_buffer(buffer, count, ppos,
                                 buf, strlen(buf));
}

static ssize_t enabled_write(struct file *filp, const char __user *buffer,
                             size_t count, loff_t *ppos)
{
  char buf[16];
  char *tmp;
  int enabled;

  if (count > sizeof(buf))
    return -EINVAL;

  memset(buf, 0, sizeof(buf));

  if (copy_from_user(buf, buffer, count))
    return -EFAULT;

  enabled = simple_strtol(buf, &tmp, 10);
  if (tmp == buf)
    return -EINVAL;

  if (chan)
  {
    //for trace stop or flush, hold on all write request until relay buffer is flushed
    if (rl_buf_create & RL_BUF_PERCPU)
    {
      write_lock(&percpuLock);
      rl_logging = enabled;
      if (enabled & RL_FLUSH )
      {
        relay_flush(chan);
        rl_logging &= ~(RL_FLUSH);
      }
      else if (!enabled)
        relay_flush(chan);
      write_unlock(&percpuLock);
    }
    else
    {
      spin_lock(&seqLock);
      rl_logging = enabled;
      if ((enabled & RL_FLUSH) != 0)
      {
        relay_flush(chan);
        rl_logging &= ~(RL_FLUSH);
      }
      else if (enabled == RL_DISABLE)
        relay_flush(chan);
      spin_unlock(&seqLock);
    }   
  }

  return count;
}

/*
 * 'enabled' file operations - boolean r/w
 *
 *  toggles logging to the relay channel
 */
struct file_operations enabled_fops =
{
  .owner =  THIS_MODULE,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .read =  enabled_read,
  .write =  enabled_write,
};

static ssize_t create_read(struct file *filp, char __user *buffer,
                           size_t count, loff_t *ppos)
{
  char buf[16];

  snprintf(buf, sizeof(buf), "%d\n", !!chan);

  return simple_read_from_buffer(buffer, count, ppos,
                                 buf, strlen(buf));
}

static ssize_t create_write(struct file *filp, const char __user *buffer,
                            size_t count, loff_t *ppos)
{
  char buf[16];
  char *tmp;

  if (count > sizeof(buf))
    return -EINVAL;

  memset(buf, 0, sizeof(buf));

  if (copy_from_user(buf, buffer, count))
    return -EFAULT;

  rl_buf_create = simple_strtol(buf, &tmp, 10);
  if (tmp == buf)
    return -EINVAL;

  if (rl_buf_create)
  {
    destroy_channel();
    chan = create_channel(subbuf_size, n_subbufs);
    if (!chan)
      return -ENOMEM;
  }
  else
    destroy_channel();

  return count;
}

/*
 * 'create' file operations - boolean r/w
 *
 *  creates/destroys the relay channel
 */
struct file_operations create_fops =
{
  .owner =  THIS_MODULE,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .read =    create_read,
  .write =  create_write,
};

static ssize_t subbuf_size_read(struct file *filp, char __user *buffer,
                                size_t count, loff_t *ppos)
{
  char buf[16];

  snprintf(buf, sizeof(buf), "%zu\n", subbuf_size);

  return simple_read_from_buffer(buffer, count, ppos,
                                 buf, strlen(buf));
}

static ssize_t subbuf_size_write(struct file *filp, const char __user *buffer,
                                 size_t count, loff_t *ppos)
{
  char buf[16];
  char *tmp;
  size_t size;

  if (count > sizeof(buf))
    return -EINVAL;

  memset(buf, 0, sizeof(buf));

  if (copy_from_user(buf, buffer, count))
    return -EFAULT;

  size = simple_strtol(buf, &tmp, 10);
  if (tmp == buf)
    return -EINVAL;

  subbuf_size = size;

  return count;
}

/*
 * 'subbuf_size' file operations - r/w
 *
 *  gets/sets the subbuffer size to use in channel creation
 */
struct file_operations subbuf_size_fops =
{
  .owner =  THIS_MODULE,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .read =    subbuf_size_read,
  .write =  subbuf_size_write,
};

static ssize_t n_subbufs_read(struct file *filp, char __user *buffer,
                              size_t count, loff_t *ppos)
{
  char buf[16];

  snprintf(buf, sizeof(buf), "%zu\n", n_subbufs);

  return simple_read_from_buffer(buffer, count, ppos,
                                 buf, strlen(buf));
}

static ssize_t n_subbufs_write(struct file *filp, const char __user *buffer,
                               size_t count, loff_t *ppos)
{
  char buf[16];
  char *tmp;
  size_t n;

  if (count > sizeof(buf))
    return -EINVAL;

  memset(buf, 0, sizeof(buf));

  if (copy_from_user(buf, buffer, count))
    return -EFAULT;

  n = simple_strtol(buf, &tmp, 10);
  if (tmp == buf)
    return -EINVAL;

  n_subbufs = n;

  return count;
}

/*
 * 'n_subbufs' file operations - r/w
 *
 *  gets/sets the number of subbuffers to use in channel creation
 */
struct file_operations n_subbufs_fops =
{
  .owner =  THIS_MODULE,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .read =    n_subbufs_read,
  .write =  n_subbufs_write,
};

static ssize_t dropped_read(struct file *filp, char __user *buffer,
                            size_t count, loff_t *ppos)
{
  char buf[sizeof(int)];

  snprintf(buf, sizeof(buf), "%d\n", atomic_read(&dropped));

  return simple_read_from_buffer(buffer, count, ppos,
                                 buf, strlen(buf));
}

/*
 * 'dropped' file operations - r
 *
 *  gets the number of dropped events seen
 */
struct file_operations dropped_fops =
{
  .owner =  THIS_MODULE,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .read =    dropped_read,
};


/*
 * control files for relay produced/consumed sub-buffer counts
 */

static int produced_open(struct inode *inode, struct file *filp)
{
  filp->private_data = inode->PRVINODE;

  return 0;
}

static ssize_t produced_read(struct file *filp, char __user *buffer,
                             size_t count, loff_t *ppos)
{
  struct rchan_buf *buf = filp->private_data;

  return simple_read_from_buffer(buffer, count, ppos,
                                 &buf->subbufs_produced,
                                 sizeof(buf->subbufs_produced));
}

/*
 * 'produced' file operations - r, binary
 *
 *  There is a .produced file associated with each per-cpu relay file.
 *  Reading a .produced file returns the number of sub-buffers so far
 *  produced for the associated relay buffer.
 */
struct file_operations produced_fops =
{
  .owner =  THIS_MODULE,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .open =    produced_open,
  .read =    produced_read
};

static int consumed_open(struct inode *inode, struct file *filp)
{
  filp->private_data = inode->PRVINODE;

  return 0;
}

static ssize_t consumed_read(struct file *filp, char __user *buffer,
                             size_t count, loff_t *ppos)
{
  struct rchan_buf *buf = filp->private_data;

  return simple_read_from_buffer(buffer, count, ppos,
                                 &buf->subbufs_consumed,
                                 sizeof(buf->subbufs_consumed));
}

static ssize_t consumed_write(struct file *filp, const char __user *buffer,
                              size_t count, loff_t *ppos)
{
  struct rchan_buf *buf = filp->private_data;
  size_t consumed;

  if (copy_from_user(&consumed, buffer, sizeof(consumed)))
    return -EFAULT;

  relay_subbufs_consumed(buf->chan, buf->cpu, consumed);

  smp_mb();
  wake_up(&waitq);
  return count;
}

/*
 * 'consumed' file operations - r/w, binary
 *
 *  There is a .consumed file associated with each per-cpu relay file.
 *  Writing to a .consumed file adds the value written to the
 *  subbuffers-consumed count of the associated relay buffer.
 *  Reading a .consumed file returns the number of sub-buffers so far
 *  consumed for the associated relay buffer.
 */
struct file_operations consumed_fops =
{
  .owner =  THIS_MODULE,
  .open =    consumed_open,
#ifdef MUST_DEFINE_SEEK_METHOD_FOR_DEBUGFS
  .llseek =  default_llseek,
#endif
  .read =    consumed_read,
  .write =  consumed_write,
};
#endif // GPFS_LINUX
#endif //GPFS_PRINTF
