/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
static char sccsid[] = "@(#)37	1.170.1.1  src/avs/fs/mmfs/ts/kernext/gpl-linux/lxtrace.c, mmfs, avs_rfks1, rfks1s007a_addw 2/6/15 16:38:41";
/**************************************************************************
 *
 * lxtrace : the command.  Turns tracing on/off and formats trace files.
 *
 *  "lxtrace { on | off | recycle | format | dump | fsync | query }
 *
 *  See Usage() for command line details.
 *
 **************************************************************************/
#ifdef GPFS_LINUX
/* Added for LFS */
#define _LARGEFILE_SOURCE
#define _FILE_OFFSET_BITS 64
#include <Shark-gpl.h>
#else
#include <cxiTypes.h>          // needed by windows per Demyn
#endif

#include <sys/types.h>
#include <sys/time.h>
#include <sys/ioctl.h>

#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/mman.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <dlfcn.h>
#include <limits.h>

#include <Trace.h>
#define ROUNDUP(_addr, _align) \
   (((long)_addr + (long)_align - 1L) & ~((long)_align - 1L))
#include <lxtrace.h>
#ifndef O_DIRECT
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
#define O_DIRECT 0400000
#else
#define O_DIRECT 040000
#endif
#endif

#if defined(GPFS_LINUX)
extern int RelayDump(void);
extern int BlockingTraceDaemonBody(long long outSize, int bufSize,
                                   int bufNum, int interval, int level);
#endif
static int (*uncompress)(char *dst, unsigned long *dlen, 
                         char *src, unsigned long slen);
extern int GetMsgQueue(int flags);
extern unsigned int cpuNum;
extern size_t compLevel;
extern int useDIO;
extern long long percpuOutSize;
extern size_t subBufSize;
extern int writeMode;
extern int noWrap;
extern char percpuOutBasename[PATH_MAX];
extern Boolean lxtraceDebug;

/* Functions defined in overwrite.c */
extern int OverwriteTraceDaemonBody(int msgQueue);
extern int dumpOverwriteTrcBuf(const char* outFileNameP,
                               const char* bufferBaseP);
extern int RecycleOverwrite(const char* outFileNameP, Boolean isRecycle,
                            int traceDeviceFD, int kTraceMode);
extern int RecycleOverwriteFromDump(const char* rawDataDumpFileP,
                                    const char* outFileNameP);
extern int FormatOverwriteTrace(const char* trcPrefixP, FILE* outFileP,
                                int verbose,
                                Int64* nRecordsProcessedP);
extern void DumpOverwriteFormatStats(FILE* statFileP);


/* If LOG_LXTRACE is defined, each invocation of the lxtrace program
   will append a timestamp, its arguments, the value of the environment
   variable CONTEXT, and the output of 'ps -ef' into the file
   /var/mmfs/gen/lxtrace.log.  This can be helpful when debugging the mm
   script environment. */
/* #define LOG_LXTRACE */

#ifdef LOG_LXTRACE
FILE* LogFileP = NULL;
#endif  /* LOG_LXTRACE */

/*  DFP debug is controlled by the environment LXTRACE_DEBUG=1 to 
    allow runtime debugging on the systems expereining problem to 
    cut down PD time.  */ 
#define LXTRACE_DEBUG_ENV  "LXTRACE_DEBUG"

/* Formatting style for timestamps */
TimestampStyle_t TimestampStyle = fRelativeSecs;


/* Examples of formatted trace output:

   Default options:

    Timestamp   Pid  COMPONENT_TAG: application trace record
   ----------- ----- ---------------------------------------
      0.000000 21499 TRACE_VNODE: gpfs_i_revalidate enter:

   -v option:

    Timestamp   Pid  P Hookword COMPONENT_TAG: application trace record
   ----------- ----- - -------- ---------------------------------------
      0.000000 21499 1 307004B3 TRACE_VNODE: gpfs_i_revalidate enter:

   -T option:

      Timestamp      Pid  COMPONENT_TAG: application trace record
   ---------------- ----- ---------------------------------------
   970706704.711164 21499 TRACE_VNODE: gpfs_i_revalidate enter:

   -T and -v options:

      Timestamp      Pid  P Hookword COMPONENT_TAG: application trace record
   ---------------- ----- - -------- ---------------------------------------
   970706704.711164 21499 1 307004B3 TRACE_VNODE: gpfs_i_revalidate enter:

 */

/* Define fragments of header lines and the corresponding trace printf format
   strings for each field on a trace output line */
#define H1_TS       " Timestamp  "
#define H2_TS       "----------- "
#define FMT_TS      "%4d.%06d "
#define H1_TS_T     "    Timestamp     "
#define H2_TS_T     "----------------- "
#define FMT_TS_T    "%10d.%06d "

#define H1_PID      "  Pid  "
#define H2_PID      "------ "
#define FMT_PID     "%6d "

#define H1_SEQ      " Sequence  "
#define H2_SEQ      "---------- "
#define FMT_SEQ     "%10llu "

#define H1_TS_D     "           Date            "
#define H2_TS_D     "-------------------------- "
#define FMT_TS_D    "%19s.%06d "

#define H1_P_HW_V   "P B Hookword "
#define H2_P_HW_V   "- - -------- "
#define FMT_P_HW_V  "%1d %1d %08X "

#define H1_TAG      "COMPONENT_TAG: application trace record\n"
#define H2_TAG      "---------------------------------------\n"
#define FMT_TAG     "%s: "

/* Bytes in an "_id2name" formatting substitution */

#define FMT_TRC_BEGIN "Trace begins: %s\n"
#define FMT_TRC_END "Trace ends  : %s%s\n"
#define FMT_COMP_RATIO "Trace compression ratio: %2d\n"
#define FMT_LOST_COUNT "Trace records lost in total: %10llu\n"

#define FILE_WRAP_STR " (file wrapped)"
#define FILE_NOWRAP_STR "               "
#ifndef MIN
#define MIN(a,b)  ((a)<(b) ? (a) : (b))
#endif

#define TRC_ARGLIST argP[0] , argP[1] , argP[2] , argP[3] , argP[4] , argP[5], \
                    argP[6] , argP[7] , argP[8] , argP[9] , argP[10], argP[11],\
                    argP[12], argP[13], argP[14], argP[15], argP[16], argP[17],\
                    argP[18], argP[19]
#define TRC_ARGLIST1F argP[0], *d
#define TRC_ARGLIST2F argP[0], argP[1], *d
#define TRC_ARGLIST3F argP[0], argP[1], argP[2], *d
#define TRC_ARGLIST4F argP[0], argP[1], argP[2], argP[3], *d
#define TRC_ARGLIST5F argP[0], argP[1], argP[2], argP[3], argP[4], *d
#define TRC_ARGLIST6F argP[0], argP[1], argP[2], argP[3], argP[4], argP[5], *d
#define TRC_ARGLIST7F argP[0], argP[1], argP[2], argP[3], argP[4], argP[5], \
                      argP[6], *d
#define TRC_ARGLIST8F argP[0], argP[1], argP[2], argP[3], argP[4], argP[5], \
                      argP[6], argP[7], *d
#define TRC_ARGLIST9F argP[0], argP[1], argP[2], argP[3], argP[4], argP[5], \
                       argP[6], argP[7], argP[8], *d
#define TRC_ARGLIST10F argP[0], argP[1], argP[2], argP[3], argP[4], argP[5], \
                       argP[6], argP[7], argP[8], argP[9], *d


/* Offsets of the various fields in the formatting file */
#define GFR_TRCID 0
#define GFR_HOOKID 15
#define GFR_COMPID 24
#define GFR_FORMAT 44

/* Max length of COMPID in the formatting file */
# define MAX_COMPID_LEN (GFR_FORMAT - GFR_COMPID - 1)

/* Thread IDs greater than this are really message handlers.
   FirstMsgHandlerThread is also defined in ThreadNames.h. */
#define FirstMsgHandlerThread 0x200

/* Size of the hash tables for in-memory format file and its hash functions.
   HOOK_HASH is for looking up format strings by hook id.
   I2N_HASH is for looking up id2name conversions by conversion name and id
   value; the I2NHASH hash function uses the first 4 chars of the conversion
   name, relying on the fact that these names are at least 4 chars long,
   because they all end in "_id2name". */
#define HOOK_HASH_TABLE_SIZE 0x100000
/* The full hookid values for hookhash are of the form YYY0XXXX, where Y is the
   sharkhookid and X is the trace id. The sharkhookids are one of 30[6-9], so only
   the last digit of the hookid is important. */
int hookhash(int H)
{
  int hookid = ((H & 0x00F00000) >> 4); //we don't need the 0 in the middle
  int trcid = (H & 0x0000FFFF);
  return (hookid | trcid);
}

#define I2N_HASH_TABLE_SIZE 0x4000
#ifndef ALIGNED_DATA_ACCESS
#define I2NHASH(F,I) ((*(int*)(F) + (I)) & 0x3FFF)
#else
static inline int I2NHASH(char *F, int I)
{
  int tmp;

  memcpy(&tmp, F, sizeof(int));
  return (tmp + I) & 0x3FFF;
}
#endif

/* combined device and application trace data headers */
typedef struct trc_hdrs_t
{
  trc_header_t hdr;  /* device header */
  trc_datahdr_t rec; /* application header */
} trc_hdrs_t;

/* Each format record has one of these headers describing it. */
typedef struct fmtDesc_t
{
  int       hookid;             // hookid or id2name value
  char      *cidP;              // component identifier or id2name tag
  char      *fmtP;              // format string or id2name string
  i2nSpec_t *i2nSpecP;          // array of id2name conversion specifiers
  struct fmtDesc_t *fmtNextP;   // next in the hash chain
  Int64 numHits;                //number of times we see this hookid
  Int64 totalSpace;             //total space in the trcfile for this hookid
  int largestEntry;             //the largest entry (by space) for this hookid
                                //in the trcfile
} fmtDesc_t;


/* Hash tables for finding format records. */
fmtDesc_t * hookHashP[HOOK_HASH_TABLE_SIZE];
fmtDesc_t * i2nHashP[I2N_HASH_TABLE_SIZE];

typedef struct I2NValueList
{
  int nValues;                  // number of hookid values found
  int nAllocated;               // size of the values array
  char *cidP;                   // id2name tag
  UInt64 *valuesP;              // array of hookid values
  struct I2NValueList *vlNextP; // next ptr in the hash table
} I2NValueList;

/* Hash table for finding all hookid values for a given id2name tag/cid. */
I2NValueList * i2nValueListHashP[I2N_HASH_TABLE_SIZE];

/* Allocate a new structure and initialize its members */
I2NValueList *newI2NValueList(char *newCidP)
{
  I2NValueList *newVLP = NULL;
  if ((newVLP = (I2NValueList *)malloc(sizeof(I2NValueList))) == NULL)
    return NULL;

  newVLP->cidP = newCidP;
  newVLP->nValues = 0;
  newVLP->nAllocated = 0;
  newVLP->valuesP = NULL;
  newVLP->vlNextP = NULL;
  return newVLP;
}

/* Add a new value to the values array, create the
   array or increase its size if necessary */
int addValue(I2NValueList* vlP, UInt64 value)
{
  /* Increase the size of the values array if needed */
  if (vlP->nValues == vlP->nAllocated)
  {
    UInt64 *oldvaluesP = vlP->valuesP;
    vlP->nAllocated += 64;

    if (NULL ==
        (vlP->valuesP = (UInt64 *)malloc(vlP->nAllocated * sizeof(UInt64))))
      return ENOMEM;

    if (vlP->nValues > 0 && oldvaluesP != NULL)
    {
      memcpy(vlP->valuesP, oldvaluesP, vlP->nValues*sizeof(UInt64));
      free(oldvaluesP);
    }
  }

  /* add the new value to the values array */
  vlP->valuesP[vlP->nValues++] = value;
  return 0;
}

/* find an entry in the I2NValueList hash table, create if necessary */
int findI2NValueListInHashTable(char *cidP, I2NValueList **curI2NVLPP,
                                int createIfNotFound)
{
  I2NValueList *nextP = NULL;
  int hashVal = I2NHASH(cidP, 0); // for the id2name tag/cid

  /* search hash chain for the specified tag/cid */
  for (nextP = i2nValueListHashP[hashVal];
       nextP != NULL;
       nextP = nextP->vlNextP)
  {
    if (strcmp(nextP->cidP, cidP) == 0)
    {
      *curI2NVLPP = nextP; // an existing value list is found
      return 0;
    }
  }

  /* A value list with the same cid is not found */
  if (createIfNotFound == 0)
  {
    *curI2NVLPP = NULL;
    return ENOENT;
  }

  /* create the new value list */
  if ((nextP = newI2NValueList(cidP)) == NULL)
    return ENOMEM;

  /* add the new value list to the hash table */
  nextP->vlNextP = i2nValueListHashP[hashVal];
  i2nValueListHashP[hashVal] = nextP;
  *curI2NVLPP = nextP;

  return 0;
}

/* Returns a positive number if the 2nd value is larger to allow
   the values to be sorted in descending numerical order */
int compareHookid(const void *p1, const void *p2)
{
  if (*(UInt64*)p2 > *(UInt64*)p1)
    return 1;
  else if (*(UInt64*)p2 < *(UInt64*)p1)
    return -1;
  else
    return 0;
}

void sortValues(I2NValueList *vlP)
{
  qsort (vlP->valuesP, vlP->nValues, sizeof(UInt64), compareHookid);
}

void sortI2NValueLists()
{
  int l, j;
  I2NValueList *next = NULL;
  
  for (l = 0; l < I2N_HASH_TABLE_SIZE; l++)
    for (next = i2nValueListHashP[l]; next != NULL; next = next->vlNextP)
      sortValues(next);

#ifdef DEBUG_I2N_VL
  for (l = 0; l < I2N_HASH_TABLE_SIZE; l++)
    for (next = i2nValueListHashP[l]; next != NULL; next = next->vlNextP)
    {
      fprintf(stderr, "I2NValueLists: l=%d cidP=%s nValues=%d nAllocated=%d\n",
              l, next->cidP, next->nValues, next->nAllocated);
      for (j = 0; j < next->nValues; j++)
        fprintf(stderr, "0x%lX ", next->valuesP[j]);
      fprintf(stderr, "\n");
    }
#endif
}

/* Hash lookup statistics */
static int nHookLookup = 0;
static int nHookCheck = 0;
static int nI2NLookup = 0;
static int nI2NCheck = 0;
static int nI2NFail = 0;

/* static state information */
int TraceDeviceFD = -1; // file descriptor for the trace device
static long long outSize;       // out_fd filesize
static Int64 bufSize = 0;       // size of the trace buffers (device and daemon)
static int bufNum;
static int interval;
static char *bufP;        // the daemon trace read buffer
static int hdrSize[LXTRACE_NR_CPUS];  // trace header size, for backward compatibility
unsigned long long totalPostCompSize = 0;
unsigned long long totalTrcfileProcessedSize = 0; //I need to track this seperately since overwrite mode doesn't do compression
unsigned long long totalCompSize = 0;

static int nWraps;        // number of times the output file has wrapped
static off_t currentPos;  // position of next write to output file
static off_t fileEnd=0;  // position of next write to output file
static int curCPU;
extern int msgQueue;
extern int RelayFlags;
static int genStats = 0;
/* The previous time is used to validate a wrap point when we
   think we've encountered one. */
static struct timeval prevTime[LXTRACE_NR_CPUS];
struct timeval tzero = { 0, 0 }; /* Used for the first trace entry */
/* Keep track of start/end times in the trace file */
static time_t startTime, stopTime;

#ifndef GPFS_WINDOWS
static char *formatFileP;     // malloc'ed buffer holding formatting data
static char *fmtDescSpaceP;   // fmtData_t space for each format record
static int  nRecords;         // Number of fmtDesc records
#else
extern char *formatFileP;     // malloc'ed buffer holding formatting data
extern char *fmtDescSpaceP;   // fmtData_t space for each format record
extern int  nRecords;         // Number of fmtDesc records
#endif

static int allowed_usec_wobble = 2; // allowed timestamp wobble before declaring a wrap.

char *TODFmtP = "The current timestamp is %lld.%lld.\n";
char *TODcidP = "TRACE_TIME";
char *FillerFmtP = "\n";
char*FillerCidP = "TRACE_FILLER";
Int64 wrapOffset;
int wrapNumber;
double tscSpeed = -1; /* If tscSpeed is -1 (ie not xlinux) then we use approximations */

typedef struct refTOD
{
  long long cycleCount;
  struct timeval timestamp;
  double cpuSpeed;
} refTOD;

static struct timeval zeroTime = { 0, 0};
int currTOD;
int firstTOD = 1; /* Traces before the first TOD still use the first TOD */
struct refTOD **TODList;
int TODMaxListSize = 4096;
int currTODCount = 0;

/* Convert ascii representation of a hexadecimal to int */
int axtoi(char s[])
{
  int i, n;

  n = 0;
  for (i = 0; s[i] != '\0'; i++)
  {
    if (s[i] >= '0' && s[i] <= '9')
      n = 16 * n + (s[i] - '0');
    else if (s[i] >= 'A' && s[i] <= 'F')
      n = 16 * n + (s[i] - 'A' + 10);
    else if (s[i] >= 'a' && s[i] <= 'f')
      n = 16 * n + (s[i] - 'a' + 10);
    else
      break;
  }
  return n;
}


/* Parse a quoted format string: removes enclosing quotes, removes trailing
   white-space, and converts escape sequences \n, \r, \t, \", etc.
   It's ok to call this function to convert a string in-place (outP == inP),
   since the conversion only makes the string shorter (removes surrounding
   quotes and reduces escape sequences to a single char).
   Returns a pointer to the next character in inP following the ending quotes,
   or NULL if there are no more characters following the quoted string. */
char *ParseFormatString(char *inP, char *outP)
{
  char *initialOutP = outP;
  int b = 1;

  /* skip initial quote */
  if (*inP == '"')
    inP++;

  /* copy string until ending quote */
  while (*inP && *inP != '"')
  {
    if (*inP == '\\' && *(inP + 1))
    {
      inP++;
      switch (*inP)
      {
        case 'n': *outP++ = '\n'; inP++; break;
        case 'r': *outP++ = '\r'; inP++; break;
        case 't': *outP++ = '\t'; inP++; break;
        default:  *outP++ = *inP++;
      }
    }
    else if (*inP == '%')
    {
      *outP++ = *inP++;
      if (*inP == '%')
        *outP++ = *inP++;
      else
      {
        if (*inP == '+' || *inP == '-')
          *outP++ = *inP++;
        while (isdigit(*inP))
          *outP++ = *inP++;
        b <<= 1;
      }
    }
    else
      *outP++ = *inP++;
  }

  /* remove trailing white space from the string */
  while (outP > initialOutP && isspace(outP[-1]))
    outP--;
  *outP = '\0';

  /* Return pointer to next character after the string or NULL if no ending
     quote was found */
  return *inP? inP + 1: NULL;
}


/* Parse a string containing a list of id2name conversion specifiers of the
   form "$n=xxx_id2name $m=yyy_id2name ...".  Returns a "null-terminted" array
   of i2nSpec_t structures, i.e., the array contains one more entry than the
   number of conversion specifiers found, and argNum/i2nNameP in the last
   array entry are set to 0/NULL. */
i2nSpec_t *ParseI2N(char *i2nP)
{
  i2nSpec_t i2n[LXTRACE_MAX_FORMAT_SUBS];
  i2nSpec_t *i2nSpecP;
  char *p;
  int n, argNum, a, nll;
  unsigned int m;

  for (n = 0, p = strtok(i2nP, " \t\n");
       p && n < LXTRACE_MAX_FORMAT_SUBS;
       n++, p = strtok(NULL, " \t\n"))
  {
    if (*p != '$')
      break;
    p++;
    argNum = atoi(p);
    p = strchr(p, '=');
    if (argNum <= 0 || p == NULL)
      break;

    i2n[n].argNum = argNum;
    i2n[n].i2nNameP = p + 1;
  }
  if (n == 0)
    return NULL;  // ?? print msg about bad id2name specifiers

  i2nSpecP = (i2nSpec_t *)malloc((n + 1)*sizeof(i2nSpec_t));
  if (i2nSpecP != NULL)
  {
    memcpy(i2nSpecP, i2n, n*sizeof(i2nSpec_t));
    i2nSpecP[n].argNum = 0;
    i2nSpecP[n].i2nNameP = NULL;
  }
  return i2nSpecP;
}

/* The formatting records are read into memory and parsed.  A fmtDesc_t header
   is constructed for each and is then inserted into a hash table. */
int BuildFormatTable(FILE *fP)
{
  char buf[2048];
  long fileSize;   /* size (bytes) of the formatting file */
  int  hookid;     /* hookid of current record */
  int  hashVal;    /* hash value */
  struct fmtDesc_t *nextDescP;
  char *curFmtRecordP, *nextFmtRecordP;
  char *trcidP;
  char *hookP;
  char *cidP;
  char *fmtP;
#ifdef DBGASSERTS
  char *formatFileEndP;
  char *fmtDescSpaceEndP;
#endif // DBGASSERTS
  I2NValueList *curI2NVLP = NULL;
  int rc = 0;

  /* Clear all entries in the hash table */
  memset(hookHashP, 0, sizeof(hookHashP));
  memset(i2nHashP,  0, sizeof(i2nHashP));
  memset(i2nValueListHashP,  0, sizeof(i2nValueListHashP));

  rewind(fP);

  /* Count the number of formatting records */
  nRecords = 0;
  while (fgets(buf, sizeof(buf), fP) != NULL)
    nRecords += 1;

  /* Now that we are at the end of the file, see how big it is */
  fileSize = ftell(fP);
  if (fileSize < 0)
    return errno;

  /* Allocate the buffer for the file contents.
     Add 1 for possible trailing zero. */
  if (NULL == (formatFileP = (char *)malloc(fileSize+1)))
    return ENOMEM;

  /* Allocate space for the fmtData_t for all of the records. */
  if (NULL == (fmtDescSpaceP = (char *)malloc(nRecords * sizeof(fmtDesc_t))))
    return ENOMEM;
  nextDescP = (fmtDesc_t *)fmtDescSpaceP;

#ifdef DBGASSERTS
  formatFileEndP = formatFileP + fileSize;
  fmtDescSpaceEndP = fmtDescSpaceP + (nRecords * sizeof(fmtDesc_t));
#endif // DBGASSERTS

  rewind(fP); /* back to the beginning of the file */

  /* Read each record in one-at-a-time, parse the record, and insert it into
     the right hash table. */
  curFmtRecordP = formatFileP;
  while (fgets(curFmtRecordP, sizeof(buf), fP) != NULL)
  {
    nextFmtRecordP = curFmtRecordP + strlen(curFmtRecordP);

    /* The TRCID identifier, hookid, component id, and format string are at
       fixed offsets */
    trcidP = curFmtRecordP + GFR_TRCID;
    hookP  = curFmtRecordP + GFR_HOOKID;
    cidP   = curFmtRecordP + GFR_COMPID;
    fmtP   = curFmtRecordP + GFR_FORMAT;

    /* parse the format record. */
    hookid = axtoi(hookP) & 0xFFFFFFFF;
    nextDescP->hookid = hookid;
    nextDescP->cidP = strtok(cidP, " ");
    nextDescP->fmtP = fmtP;

    /* find the end of the format string */
    fmtP = ParseFormatString(fmtP, fmtP);

    /* check for id2name conversion specifiers following the format string */
    nextDescP->i2nSpecP = NULL;
    if (fmtP)
    {
      while (isspace(*fmtP))
        fmtP++;
      if (*fmtP)
        nextDescP->i2nSpecP = ParseI2N(fmtP);
    }

    /* Place the format record descriptor into the right hash table. */
    if (strncmp(trcidP, "TRCID_", 6) == 0)
    {
      /* this record contains a format string */
      strcat(nextDescP->fmtP, "\n");
      hashVal = hookhash(hookid);
      nextDescP->fmtNextP = hookHashP[hashVal];
      hookHashP[hashVal] = nextDescP;
      if (genStats)
      {
        hookHashP[hashVal]->numHits = 0;
        hookHashP[hashVal]->totalSpace = 0;
        hookHashP[hashVal]->largestEntry = 0;
      }
    }
    else
    {
      /* this record contains an id2name conversion value */
      hashVal = I2NHASH(nextDescP->cidP, hookid);
      nextDescP->fmtNextP = i2nHashP[hashVal];
      i2nHashP[hashVal] = nextDescP;

      /* If the current value list cannot be used, get a new one */
      if (curI2NVLP == NULL ||
          (strcmp(curI2NVLP->cidP, nextDescP->cidP) != 0))
      {
        if ((rc = findI2NValueListInHashTable(nextDescP->cidP,
                                              &curI2NVLP, 1)) != 0)
          return rc;
      }

      /* Add the new hookid value to the current value list */
      if ((rc = addValue(curI2NVLP, hookid)) != 0)
        return rc;
    }
    /* Advance to the next fmtDesc and format record */
    nextDescP++;
    curFmtRecordP = nextFmtRecordP;
  }

#ifdef DBGASSERTS
  /* verify that we didn't overrun our buffers */
  if ((char *)nextDescP > fmtDescSpaceEndP)
  {
    DP("%s: overwrote format descriptor memory!\n", TRCFMT_NAME);
    return -1;
  }
  if (nextFmtRecordP > formatFileEndP)
  {
    DP("%s: overwrote format file memory!\n", TRCFMT_NAME);
    return -1;
  }
#endif // DBGASSERTS

  sortI2NValueLists();

  return 0;
}

/* Find a format record by hookid. */
int GetFormatRecord(int hookid, char **cidPP, char **fmtPP,
                    i2nSpec_t **i2nPP,
                    Int64 spaceUsed)
{
  fmtDesc_t *nextP;

  DFP("GetFormatRecord(0x%X, 0x%X, 0x%X, 0x%X)\n",
      hookid, bufSize, bufP, cidPP);

  nHookLookup++;
  if (hookid == LXTRACE_FILLER)
  {
    *cidPP = FillerCidP;
    *fmtPP = FillerFmtP;
    *i2nPP = NULL;
    DFP("GetFormatRecord for id %X is: %s\n", hookid, *fmtPP);
    return 0;
  }

  /* search hash chain for the specified hookid */
  for (nextP = hookHashP[hookhash(hookid)];
       nextP != NULL;
       nextP = nextP->fmtNextP)
  {
    nHookCheck++;

    /* Check whether hookid matches. */
    if (nextP->hookid == hookid)
    {
      /* Hookid and the record type match.  Copy to work area. */
      *cidPP = nextP->cidP;
      *fmtPP = nextP->fmtP;
      *i2nPP = nextP->i2nSpecP;
      if (genStats)
      {
        nextP->numHits++;
        nextP->totalSpace += spaceUsed;
        if (nextP->largestEntry < spaceUsed)
          nextP->largestEntry = spaceUsed;
        totalTrcfileProcessedSize += spaceUsed;
      }
      DFP("GetFormatRecord for id %X is: %s\n", hookid, *fmtPP);
      return 0;
    }
  }

  /* not found */
  return -1;
}

/* For genStats (--statfile flag), sort the hookids for display */
int hookhashComparator(const void *p1, const void *p2)
{
  fmtDesc_t *a = *((fmtDesc_t**) p1);
  fmtDesc_t *b = *((fmtDesc_t**) p2);

  if (a == NULL && b == NULL)
    return 0;
  else if (a == NULL)
    return 1;
  else if (b == NULL)
    return -1;

  /* Sort first by hits, then by total space.  Reverse the sort order
     so the most popular traces are shown first. */
  if (a->numHits > b->numHits)
    return -1;
  else if (a->numHits < b->numHits)
    return 1;

  if (a->totalSpace > b->totalSpace)
    return -1;
  else if (a->totalSpace < b->totalSpace)
    return 1;

  return 0;
}

/* Find an id2name string by conversion name ("tag") and id value */
int GetID2NameRecord(char *tagP,
                     int id, int bufSize, char *bufP)
{
  fmtDesc_t *nextP;

  DFP("GetID2NameRecord(0x%X, 0x%X, 0x%X, 0x%X)\n",
      tagP, id, bufSize, bufP);

  nI2NLookup++;

  /* search hash chain for the specified hookid and tag */
  for (nextP = i2nHashP[I2NHASH(tagP, id)];
       nextP != NULL;
       nextP = nextP->fmtNextP)
  {
    nI2NCheck++;

    /* Check whether hookid and tag match. */
    if (nextP->hookid == id &&
        strncmp(nextP->cidP, tagP, MAX_COMPID_LEN) == 0)
    {
      DFP("GetID2NameRecord for id %X is: %s\n", id, nextP->fmtP);
      strncpy(bufP, nextP->fmtP, bufSize);
      return 0;
    }
  }

  /* not found */
  nI2NFail++;
  return -1;
}

/* Find an id2name string by conversion name ("tag") and id value.
   The id value may be a combination of serveral single values */
int GetID2NameRecords(char *tagP,
                      UInt64 id, int bufSize, char *bufP)
{
  /* First, see if the id is a single value or not */
  if (0 == GetID2NameRecord(tagP, (int)id, bufSize, bufP))
    return 0;

  /* If not, try to find the hookid list for the id2name tag */
  I2NValueList *curI2NVLP = NULL;
  if (findI2NValueListInHashTable(tagP, &curI2NVLP, 0) != 0)
    return -1;

  /* Found the hookid list for the id2name tag, now extract the single values */
  UInt64 *valuesP = curI2NVLP->valuesP;
  UInt64 myvalues[TRC_MAX_ID2NAME];
  int nValues = curI2NVLP->nValues;

  /* Quick check to see whether the id value is out of range or not */
  if (id < valuesP[nValues-1])
    return -1;

  int i = 0;
  int match = 0;
  for (i = 0; i < nValues; i++)
  {
    if (id >= valuesP[i])
    {
      /* Don't take the value 0 if other values are already found */
      if (valuesP[i] == 0 && match > 0)
        break;

      /* Expect the single values to take a unique bit, or along the same
         lines such that the combination won't be as large as 2 times of
         the largest single value. */
      id -= valuesP[i];
      if (id >= valuesP[i])
        return -1;

      /* found a single value */
      myvalues[match++] = valuesP[i];

      /* Mission accomplished */
      if (id == 0)
        break;

      /* limit the number of single values to find */
      if (match == TRC_MAX_ID2NAME)
        break;
    }
  }

  /* If there is no perfect match, there is no match */
  if (id > 0)
    return -1;

  /* Extract the names of the single id values */
  int used = 0;
  for (i = 0; i < match; i++)
  {
    /* Find the name of each single id value */
    if (0 != GetID2NameRecord(tagP, myvalues[i], bufSize-used, bufP+used))
      return -1;

    /* Make sure the bufP is NULL terminated */
    bufP[bufSize-1] = '\0';

    /* Append a <+> after each new value except the last one */
    used = strlen(bufP);
    if (i < (match - 1) && used < (bufSize - 1))
      bufP[used++] = '+';

    /* The buffer is not large enough for all of the name values */
    if (i < (match - 1) && used >= (bufSize - 1))
      return -1;
  }

  /* Found, so nI2NFail count from the first GetID2NameRecord can be removed */
  nI2NFail--;

  return 0;
}


void ID2Name(trc_datahdr_t *recP, i2nSpec_t* i2nP,
             idname_t* id2nameP, argType *argP)
{
  int i, j, id;
  Boolean msgHandler;
  /* Update the argP[] array as necessary to do the substitutions */
  if (i2nP != NULL)
  {
    /* This loop proceses each of the substitution strings */
    for (i = 0; i2nP[i].i2nNameP != NULL; i++)
    {
      int whichSub = i2nP[i].argNum - 1;
      char *argtP  = i2nP[i].i2nNameP;
      char *sP = id2nameP[whichSub].s;

      id = argP[whichSub];

      /* Thread_id2name conversion need special treatment */
      msgHandler = false;
      if (strcmp(argtP, "Thread_id2name") == 0)
      {
        /* Thread IDs >= FirstMsgHandlerThread are really message
           handler IDs, so look for a tscMsg_id2name entry in that case.
           Thread IDs < FirstMsgHandlerThread are "standard" thread IDs,
           so look for StdThread_id2name in that case. */
        if (id >= FirstMsgHandlerThread)
        {
          /* Adjust id value and conversion function.  Set a flag to
             remember to insert "Msg handler" in front of the name that
             is found. */
          id -= FirstMsgHandlerThread;
          argtP = "tscMsg_id2name";
          msgHandler = true;
        }
        else
          argtP = "StdThread_id2name";
      }

      /* Now look-up the substitution for argtP (xx_id2name) that is
         associated with the appropriate traced value (id). */
      if (0 != GetID2NameRecords(argtP, id, TRC_MAX_ID2NAME, sP))
      {
        /* Unable to find the formatting (substitution) information */

        /* Special notation for NodeAddrs */
        if (0 == strcmp(argtP, "nodeaddr_id2name"))
        {
          unsigned int cl, idx;
          switch (id)
          {
            case -1: sprintf(id2nameP[whichSub].s, "<none>"); break;
            case -2: sprintf(id2nameP[whichSub].s, "<invalid>"); break;
            case -3: sprintf(id2nameP[whichSub].s, "<loopback>"); break;
            default:
              cl = (id >> 24) & 0xff;
              idx = id & 0xffff;
              if (id & 0x10000)
                sprintf(id2nameP[whichSub].s, "<c%dp%d>", cl, idx);
              else
                sprintf(id2nameP[whichSub].s, "<c%dn%d>", cl, idx);
              break;
          }
        }

        /* IpAddrs are traced as four words and printed in either
           IPv4 or IPv6 format. */
        else if (0 == strcmp(argtP, "ipaddr_id2name"))
        {
          union { unsigned int w[4]; unsigned char c[16]; } a;

          a.w[0] = a.w[1] = a.w[2] = a.w[3] = 0;
          for (j = 0;
               j < 4 && whichSub + j < LXTRACE_MAX_FORMAT_SUBS;
               j++)
            a.w[j] = argP[whichSub + j];
          *sP = '\0';

          if (a.w[0] == -1U && a.w[1] == -1U &&
              a.w[2] == -1U && a.w[3] == -1U)
            sprintf(sP, "<none>");
          else if (a.w[0] == 0 && a.w[1] == 0 &&
                   a.c[8] == 0 && a.c[9] == 0 &&
                   a.c[10] == 0xff && a.c[11] == 0xff)
            /* Treat IPv4-mapped IPv6 addresses as IPv4 */
            inet_ntop(AF_INET, &a.c[12], sP, TRC_MAX_ID2NAME);
#ifdef AF_INET6
          //not supported on windows yet
          else
            inet_ntop(AF_INET6, a.c, sP, TRC_MAX_ID2NAME);
#endif
          /* Shift following arguments left */
          for (j = whichSub + 1;
               j < recP->trNArgs && j + 3 < LXTRACE_MAX_FORMAT_SUBS;
               j++)
            argP[j] = argP[j + 3];
        }

        /*  ObjKey is traced as three 64-bit hex numbers */
        else if (0 == strcmp(argtP, "objkey_id2name"))
        {
#if defined( __64BIT__) || defined(_LP64)
          long long *w = argP + whichSub;
          const int shift = 2;
#else
          long long w[3];
          const int shift = 5;
          argType *aP = argP + whichSub;
          w[0] = ((unsigned long long)aP[0] << 32) + (unsigned long)aP[1];
          w[1] = ((unsigned long long)aP[2] << 32) + (unsigned long)aP[3];
          w[2] = ((unsigned long long)aP[4] << 32) + (unsigned long)aP[5];
#endif
          if (w[2] == 0xFFFFFFFFFFFFFFFFLL)
            sprintf(sP, "%08X:%08X:%08X:%08X",
                    High32(w[0]), Low32(w[0]), High32(w[1]), Low32(w[1]));
          else
            sprintf(sP, "%016llX:%016llX:%016llX", w[0], w[1], w[2]);

          /* Shift following arguments left */
          for (j = whichSub + 1;
               j < recP->trNArgs && j + shift < LXTRACE_MAX_FORMAT_SUBS;
               j++)
            argP[j] = argP[j + shift];
        }

        /* lockState to string conversions. */
        else if ((0 == strcmp(argtP, "lockstateHigh_id2name")))
        {
          #define lsAcqPend  0x80000000
          #define lsLxLock   0x40000000
          #define lsXwLock   0x20000000
          #define lsWaLock   0x10000000
          #define lsWwLock   0x08000000
          #define lsRvkLock  0x04000000
          #define lsRoCount  0x03FFF800
          #define lsRoUnit   0x00000800
          #define lsWoCount  0x000007FF
          #define lsWoUnit   0x00000001
          char buf1[32], buf2[32];
          buf1[0]='\0';
          buf2[0]='\0';
          if (id & lsRoCount)
            sprintf(buf1, " ro:%d", (id & lsRoCount)/lsRoUnit);
          if (id & lsWoCount)
            sprintf(buf2, " wo:%d", (id & lsWoCount)/lsWoUnit);
          sprintf(sP, "[%s%s%s%s%s%s%s%s",
                  (id & lsAcqPend) ? " acq" : "",
                  (id & lsLxLock) ? " lx" : "",
                  (id & lsXwLock) ? " xw" : "",
                  (id & lsWaLock) ? " wa" : "",
                  (id & lsWwLock) ? " ww" : "",
                  (id & lsRvkLock) ? " rvk" : "",
                  buf1, buf2);

        }

        /* lockState to string conversions. */
        else if ((0 == strcmp(argtP, "lockstateLow_id2name")))
        {
          #define lsRfCount  0x7FF00000
          #define lsRfUnit   0x00100000
          #define lsWfCount  0x000FFE00
          #define lsWfUnit   0x00000200
          #define lsRsCount  0x000001FF
          #define lsRsUnit   0x00000001
          char buf1[32], buf2[32], buf3[32];
          buf1[0]='\0';
          buf2[0]='\0';
          buf3[0]='\0';
          if (id & lsRfCount)
            sprintf(buf1, " rf:%d", (id & lsRfCount)/lsRfUnit);
          if (id & lsWfCount)
            sprintf(buf2, " wf:%d", (id & lsWfCount)/lsWfUnit);
          if (id & lsRsCount)
            sprintf(buf3, " rs:%d", (id & lsRsCount)/lsRsUnit);
          sprintf(sP, "%s%s%s ]", buf1, buf2, buf3);
        }

        /* lockFlags to string conversions. */
        else if ((0 == strcmp(argtP, "lockflags_id2name")))
        {
          #define lfDaemonWriter      0x0001
          #define lfRevokePending     0x0002
          #define lfRevokeProcessing  0x0004
          #define lfAcqGranted        0x0008
          #define lfWakeupAll         0x0010
          sprintf(sP, "[%s%s%s%s%s ]",
                  (id & lfDaemonWriter)     ? " dmn" : "",
                  (id & lfRevokePending)    ? " rvk" : "",
                  (id & lfRevokeProcessing) ? " pro" : "",
                  (id & lfAcqGranted)       ? " gra" : "",
                  (id & lfWakeupAll)        ? " wka" : "");
        }

        /* Any other case is a lack of proper formatting information
           for the generated trace record.  Insert "unknown" into the
           formatted output and continue. */
        else
        {
#ifdef DBGASSERTS
          DP("%s: %s substitution %d (value=%d) not found (used in hook %08X).\n",
             TRCFMT_NAME, argtP, whichSub+1, argP[whichSub],
             (recP->trHook&0xFFFFFFFF));
          // To debug one of these, exit here.
          // goto exit_format;
#endif // DBGASSERTS
          sprintf(sP, "unknown(%d)", argP[whichSub]);
        }
      }

      /* If we are converting the thread ID of a message handler,
         insert "Msg handler" in front of the name. */
      if (msgHandler)
      {
        char tmpBuff[TRC_MAX_ID2NAME];
        strncpy(tmpBuff, sP, sizeof(tmpBuff));
        snprintf(sP, TRC_MAX_ID2NAME, "Msg handler %s", tmpBuff);
      }

      /* Alter the TRC_ARGLIST for this substituted parameter */
      argP[whichSub] = (argType)sP;
    } /* for each substitution string */

  } /* End-substitutions */

}


#ifndef GPFS_WINDOWS

/* Everything from here to the end of the file is ifdef'ed out on
   Windows.  The tstrcfmt program compiles this file because it depends
   on BuildFormatTable, GetFormatRecord, and ID2Name, defined in this
   file.

   This structure is unspeakably hideous.  The common functions should
   be moved to their own file. */

/* Convert timestamp to string format. */
extern char *ctime_r(const time_t *, char *);
char *fmtTime(time_t time, char *timeStr)
{
  /* ctime_r returns a null-terminated, readable string that includes
   * a newline char which we remove.  When ctime_r cannot convert the
   * supplied timestamp, it returns NULL.
   */
  if (!ctime_r(&time, timeStr) || time == -1)
    // append space for formatting
    return "unknown                 ";

  timeStr[strlen(timeStr) - 1] = '\0';
  return timeStr;
}

static struct timeval wrap_prev = { 0, 0 };
static struct timeval wrap_next = { 0, 0 };

/* isWrapPoint:
 * See if consecutive timestamps are backwards (indicates a wrap-point).
 */
int isWrapPoint(struct timeval prev, struct timeval next)
{
  /* Detect timestamps going backwards.  This could be the wrap-point
   * or just wobble.
   */
  if ((prev.tv_sec > next.tv_sec) ||
      ((prev.tv_sec == next.tv_sec)
        && (prev.tv_usec - next.tv_usec > allowed_usec_wobble)))
  {
    /* Prepare for simple subtraction (do any necessary borrowing) */
    if (prev.tv_usec < next.tv_usec)
    {
      prev.tv_usec += 1000000;
      prev.tv_sec  -= 1;
    }

    DFP("isWrapPoint: wrap delta %d.%06d (prev %d.06d, next %d.06d)\n",
        (prev.tv_sec - next.tv_sec), (prev.tv_usec - next.tv_usec),
        prev.tv_sec, prev.tv_usec, next.tv_sec, next.tv_usec);

    /* Detect and warn if multiple wrap points are detected. */
    if (((wrap_prev.tv_sec != 0) &&
         ((wrap_prev.tv_sec != prev.tv_sec) || (wrap_prev.tv_usec != prev.tv_usec))) ||
        ((wrap_next.tv_sec != 0) &&
         ((wrap_next.tv_sec != next.tv_sec) || (wrap_next.tv_usec != next.tv_usec))))
    {
      DP("%s", "Multiple wrap-points found:\n");
      DP("\t%d.%06d-%d.%06d (delta %d.%06d)\n",
         wrap_prev.tv_sec, wrap_prev.tv_usec,
         wrap_next.tv_sec, wrap_next.tv_usec,
         (wrap_prev.tv_sec - wrap_next.tv_sec),
         (wrap_prev.tv_usec - wrap_next.tv_usec));
      DP("\t%d.%06d-%d.%06d (delta %d.%06d)\n",
         prev.tv_sec, prev.tv_usec, next.tv_sec, next.tv_usec,
         (prev.tv_sec - next.tv_sec), (prev.tv_usec - next.tv_usec));
    }

    /* Keep track of what we have now declared to be a wrap point */
    wrap_prev = prev;
    wrap_next = next;

    return true;
  }

  return false;
}


/* Figure out if we have a trcfile from overwrite mode or blocking mode */
int checkTraceFileMode(char *trcPrefixP)
{
  char trcFileP[PATH_MAX];
  struct stat statBuf;
  int traceFD;
  int bytesRead;
  Int64 first8;

  sprintf(trcFileP, "%s.cpu%d", trcPrefixP, 0);
  traceFD = open(trcFileP, O_RDONLY);
  if (traceFD < 0)
  {
    DP("Cannot find file %s\n", trcFileP);
    exit(1);
  }

  if (stat(trcFileP, &statBuf) == 0)
  {
    if (statBuf.st_size <= 0)
    {
      DP("%s is empty. No trace entries detected.\n", trcFileP);
      exit(1);
    }
  }

  /* If the file begins with OVERWRITE_MAGIC, this is an overwrite trace.
     Otherwise, assume a blocking trace. */
  first8 = 0;
  bytesRead = read(traceFD, &first8, sizeof(first8));
  close(traceFD);
  if (first8 == OVERWRITE_MAGIC)
    return LXTRACE_OVERWRITE;
  else
    return LXTRACE_BLK;
}


/* Read the next trace header from the raw trace file.  Normally, this just
   involves the read() for the specified file.  However, it also needs to
   check for wrapping of the file and make the necessary adjustments when we
   reach the wrap point. */
int ReadNextTrcHeader(FILE *rawFileP, trc_hdrs_t* hdrP, int cpu,
                      long long prevSeq[])
{
  int nRead;
  off_t off1, off2;
  off1 = off2 = 0;

  if (0 < (nRead = fread(hdrP, 1, hdrSize[cpu], rawFileP)))
  {
    /* Successful read.  Validate the header. */
    if (hdrP->hdr.trMagic != LXTRACE_MAGIC &&
        hdrP->hdr.trMagic != LXTRACE_SEQ_MAGIC)
    {
      /* Maybe we've reached the wrap point.  See if we can get oriented.
         Backup and try 1 byte further until we find a valid header.  This
         should be the wrap point.  If we can verify this, return the header.
       */
      fseek(rawFileP, 1-nRead, SEEK_CUR);
      off1 = ftell(rawFileP) - 1;
      while (0 < (nRead = fread(hdrP, 1, hdrSize[cpu], rawFileP)))
      {
        /* Keep inching forward looking for a valid device header that
         * includes timestamps that also indicate a wrap ocurred. */
        if ((hdrP->hdr.trMagic == LXTRACE_SEQ_MAGIC &&
             prevSeq[cpu] > hdrP->hdr.trSeq)  ||
            (hdrP->hdr.trMagic == LXTRACE_MAGIC &&
             isWrapPoint(prevTime[cpu], hdrP->hdr.trTime)))
        {
          DFP("ReadNextTrcHeader: wrap point between %d.%d %llu and %d.%d %llu\n",
              hdrP->hdr.trTime.tv_sec, hdrP->hdr.trTime.tv_usec, prevSeq[cpu],
              prevTime[cpu].tv_sec, prevTime[cpu].tv_usec, hdrP->hdr.trSeq);

          prevSeq[cpu] = hdrP->hdr.trSeq;
          /* We've found what appears to be a valid header. */
          prevTime[cpu] = hdrP->hdr.trTime; /* timestamp of the last valid record */
          nWraps += 1;
          DFP("ReadNextTrcHeader: wrap point at %d gap %d\n", off1, off2-off1);

          /* Save the oldest timestamp that we've found */
          if (hdrP->hdr.trTime.tv_sec < startTime)
            startTime = hdrP->hdr.trTime.tv_sec;

          return nRead;
        }
        else if (hdrP->hdr.trMagic == LXTRACE_MAGIC ||
                 hdrP->hdr.trMagic == LXTRACE_SEQ_MAGIC)
        {
          /* We've found a valid header some ways from the beginning of
             the file, but it's not a wrap point.  This could be due to
             some garbage in the file.  Try to skip garbage data. */
          prevSeq[cpu] =hdrP->hdr.trSeq;
          /* timestamp of the last valid record */
          prevTime[cpu] = hdrP->hdr.trTime;

          /* Save the latest timestamp we've found */
          if (hdrP->hdr.trTime.tv_sec > stopTime)
            stopTime = hdrP->hdr.trTime.tv_sec;

          /* Save the oldest timestamp that we've found */
          if (hdrP->hdr.trTime.tv_sec < startTime)
            startTime = hdrP->hdr.trTime.tv_sec;

          return nRead;
        }
        fseek(rawFileP, 1-nRead, SEEK_CUR);
        off2 = ftell(rawFileP);
      }
      DP("%s", "lxtrace format: ReadNextTrcHeader failed to find a valid record!\n");
    }
    else
    {
      /* Valid header found, but this could still be a wrap-point if the
       * alignment worked out exactly.
       */
      if ((hdrP->hdr.trMagic == LXTRACE_SEQ_MAGIC &&
           prevSeq[cpu] > hdrP->hdr.trSeq)  ||
          (hdrP->hdr.trMagic == LXTRACE_MAGIC &&
           isWrapPoint(prevTime[cpu], hdrP->hdr.trTime)))
      {
        DFP("ReadNextTrcHeader: wrap point between %d.%d %llu and %d.%d %llu\n",
            hdrP->hdr.trTime.tv_sec, hdrP->hdr.trTime.tv_usec, prevSeq[cpu],
            prevTime[cpu].tv_sec, prevTime[cpu].tv_usec, hdrP->hdr.trSeq);

        nWraps += 1;
        DFP("ReadNextTrcHeader: wrap point at %d gap %d\n", off1, off2-off1);

        prevSeq[cpu] = hdrP->hdr.trSeq;
        /* timestamp of the last valid record */
        prevTime[cpu] = hdrP->hdr.trTime;

        /* Save the oldest timestamp that we've found */
        if (hdrP->hdr.trTime.tv_sec < startTime)
          startTime = hdrP->hdr.trTime.tv_sec;
      }
      else
      {
        prevSeq[cpu] = hdrP->hdr.trSeq;
        /* timestamp of the last valid record */
        prevTime[cpu] = hdrP->hdr.trTime;

        /* Save the latest timestamp we've found */
        if (hdrP->hdr.trTime.tv_sec > stopTime)
          stopTime = hdrP->hdr.trTime.tv_sec;

        /* Save the oldest timestamp that we've found */
        if (hdrP->hdr.trTime.tv_sec < startTime)
          startTime = hdrP->hdr.trTime.tv_sec;
      }
    }

  }
  return nRead;
}

/* Read the next trace header from the raw trace file.  Normally, this just
   involves the read() for the specified file.  However, it also needs to
   check for wrapping of the file and make the necessary adjustments when we
   reach the wrap point. */
int ReadNextCompHeader(FILE *rawFileP, trc_comp_header_t *hdrP)
{
  int nRead;

  if (0 < (nRead = fread(hdrP, 1, sizeof(trc_comp_header_t), rawFileP)))
  {
    /* Successful read.  Validate the header. */
    if (hdrP->trMagic != LXTRACE_COMP_MAGIC)
    {
      DFP("possible wrap point at %d\n",
          ftell(rawFileP)-sizeof(trc_comp_header_t));
      /* Maybe we've reached the wrap point.  See if we can get oriented.
         Backup and try 1 byte further until we find a valid header.  This
         should be the wrap point.  If we can verify this, return the header.
       */
      fseek(rawFileP, 1-nRead, SEEK_CUR);
      while (0 < (nRead = fread(hdrP, 1, sizeof(trc_comp_header_t), rawFileP)))
      {
        if (hdrP->trMagic == LXTRACE_COMP_MAGIC )
        {
          DFP("wrap point found at %d\n", ftell(rawFileP)-sizeof(trc_comp_header_t));
          nWraps++;
          return nRead;
        }
        fseek(rawFileP, 1-nRead, SEEK_CUR);
      }
    }
  }
  return nRead;
}


FILE* findWrapPoint(char *rawPrefix, char *rawSuffix, int cpu,
                    int nTrcHdrs[], Boolean hasWrapped[],
                    long long prevSeq[])
{
  char rawTraceFileNameP[PATH_MAX];
  trc_hdrs_t h;
  FILE* rawFileP = NULL;
  int ret;

  if (rawPrefix != NULL)
  {
    if (rawSuffix != NULL)
      sprintf(rawTraceFileNameP, "%s.%s.cpu%d", rawPrefix, rawSuffix, cpu);
    else
      sprintf(rawTraceFileNameP, "%s.cpu%d", rawPrefix, cpu);
  }
  else
    return NULL;
  /* Open the trace file. */
  if (NULL == (rawFileP = fopen(rawTraceFileNameP, "r")))
  {
    return NULL;
  }
  hasWrapped[cpu] = false; /* Signal format processing below we have a wrap file */
  nWraps = 0;         /* ReadNextTrcHeader counts wrap points it encounters.*/
  nTrcHdrs[cpu] = 0;
  while (0 < ReadNextTrcHeader(rawFileP, &h, cpu, prevSeq))
  {
    nTrcHdrs[cpu]++;

    /* If ReadNextTrcHeader detects a wrap, leave and begin formating. */
    if (nWraps)
      break;

    /* skip over trace data */
    fseek(rawFileP, h.hdr.trLength - sizeof(trc_datahdr_t), SEEK_CUR);
  }

  /* If a wrap point was located, back-up so the header can be read again
     as formatting begins with this record.  If the file never wrapped,
     reset to the top of the file and process top-to-bottom. */
  if (nWraps)
  {
    fseek(rawFileP, -hdrSize[cpu], SEEK_CUR);
    hasWrapped[cpu] = true; /* Signal format procesing below to handle the wrap */
  }
  else
    rewind(rawFileP);
  return rawFileP;
}

/* Defect 816587. lxtrace wants a prefix passed in,
   and lxtrace will append the cpuX suffix
   if you pass in the full name of a file, make sure that
   it doesn't end in "cpuX".
   This is done as a preprocessing optimization to prevent
   unnecessary renaming of trcfiles
*/
void checkFileNamePrefix(char *rawPrefix)
{
  DFP("checking the file name prefix for %s\n", rawPrefix);
  struct stat statBuf;
  int dateStamp, hour, minute, second, noWrapNum;
  char hostName[PATH_MAX];  
  int strlength = strlen(rawPrefix);
  int i = strlength;

  int rc = gethostname(hostName, PATH_MAX);
  if (rc != 0)
    return;

  if (stat(rawPrefix, &statBuf) != 0) //if the file doesn't exist, just return
    return;
  if (strstr(hostName, "cpu")) //if the hostName has "cpu" in it, return
    return;

  //now check if the end of the string is "cpu%d"
  for (i = strlength -1; rawPrefix[i] != '.'; i--)
  {
    if (!isdigit(rawPrefix[i]))
      break;
    if (i == 0)
      break;
  }
  if (i < 3) //If we might look before the start of the string, abort now
    return;
  if (rawPrefix[i] == 'u' && rawPrefix[i-1] == 'p' && 
      rawPrefix[i-2] == 'c' && rawPrefix[i-3] == '.')
    rawPrefix[i-3] = '\0';
}

//find raw files
int findRawFiles(char *rawPrefix)
{
  char fileName[PATH_MAX];
  int nCPU = 0;
  int rc;
  struct stat statBuf;

  if (stat(rawPrefix, &statBuf) == 0)
  {
    if (statBuf.st_size <= 0)
    {
      errno = ENOENT; /* we use the errno as the return code from lxtrace */
      return 0;
    }
    sprintf(fileName, "%s.cpu0", rawPrefix);
    rename(rawPrefix, fileName);
    return 1;
  }
 
  while (1)
  {
    sprintf(fileName, "%s.cpu%d", rawPrefix, nCPU);
    if (stat((const char*)fileName, &statBuf) != 0)
      break;
    nCPU++;
  }

  return nCPU;
}

//uncompress raw trace file
FILE *unComp(char *compPrefix, char *compSuffix, int cpu,
             Boolean hasWrapped[])
{
  char compTraceFileNameP[PATH_MAX];
  char uncompFileNameP[PATH_MAX];
  FILE *compressedFileP; /* raw trace data file */
  FILE *outFileP; /* output file */
  trc_comp_header_t cmp_hdr;
  unsigned long dlen;
  Boolean compressed;
  void *libz_handle = NULL;
  char *error;

  compressedFileP = outFileP = NULL;
  /* work buffers */
  char *src = NULL;   /* compressed  trace data */
  char *dst = NULL;   /* uncompressed trace data */
  int ret;

  sprintf(compTraceFileNameP, "%s.cpu%d", compPrefix, cpu);
  /* Open the trace file. */
  if (NULL == (compressedFileP = fopen(compTraceFileNameP, "r")))
  {
    goto exit_uncomp;
  }

  if (fread(&cmp_hdr, 1, sizeof(trc_comp_header_t), compressedFileP) > 0)
  {
    //search wrap point
    if (cmp_hdr.trMagic == LXTRACE_COMP_MAGIC)
    {
      hdrSize[cpu] = sizeof(trc_hdrs_t);
      fseek(compressedFileP, 0, SEEK_SET);
      src = malloc(cmp_hdr.dataLength);
      if (src == NULL)
        goto exit_uncomp;
      dst = malloc(cmp_hdr.dataLength);
      if (dst == NULL)
        goto exit_uncomp;
      nWraps = 0;
      //read compression record until wrap point found or reach file tail
      while (ReadNextCompHeader(compressedFileP, &cmp_hdr) > 0)
      {
        DFP("unComp: find record %d at %d\n",
            cmp_hdr.compLength, ftell(compressedFileP));
        if (nWraps)
        {
          break;
        }
        fseek(compressedFileP, cmp_hdr.compLength, SEEK_CUR);
      }
      //no wrap point found, go back to head
      if (!nWraps)
        rewind(compressedFileP);
      //find wrap point, seek to it
      else
      {
        fseek(compressedFileP, -sizeof(trc_comp_header_t), SEEK_CUR);
        hasWrapped[cpu] = true;
      }
    }
    else
    {
      //for backward compatibility
      //previous trace header do not have sequence number
      //Also, non-blocking (LXTRACE_OVERWRITE) traces aren't compressed
      if (cmp_hdr.trMagic == LXTRACE_MAGIC)
        hdrSize[cpu] = sizeof(trc_noseq_header_t) + sizeof(trc_datahdr_t);
      else if (cmp_hdr.trMagic == LXTRACE_SEQ_MAGIC)
        hdrSize[cpu] = sizeof(trc_hdrs_t);
      DFP("unComp: header magic %x header size %d\n",
          cmp_hdr.trMagic, hdrSize[cpu]);
      goto exit_uncomp;
    }

    //open uncompressed raw trace file
    sprintf(uncompFileNameP, "%s.%s.cpu%d", compPrefix, compSuffix, cpu);


    outFileP = fopen(uncompFileNameP, "w+");
    if (outFileP == NULL)
    {
      DP("lxtrace format: could not open file %s, errno %d\n",
         uncompFileNameP, errno);
      goto exit_uncomp;
    }
    //load libz.so.1
    libz_handle = dlopen("libz.so.1", RTLD_NOW);
    if (libz_handle == NULL)
    {
      DP("lxtrace format: dlopen libz.so.1 error: %s\n", dlerror());
      goto exit_uncomp;
    }
    //clear previous dlerror
    dlerror();
    uncompress = dlsym(libz_handle, "uncompress");
    if ((error = dlerror()) != NULL)
    {
      DP("lxtrace format: dlsym uncompress error: %s\n", error);
      goto exit_uncomp;
    }
    //start uncompression from wrap point
    nWraps = 0;
    while (1)
    {
      if (ReadNextCompHeader(compressedFileP, &cmp_hdr) > 0)
      {
        if (nWraps)
          break;
        ret = fread(src, 1, cmp_hdr.compLength, compressedFileP);
        if (ret == cmp_hdr.compLength)
        {
          dlen = cmp_hdr.dataLength;
          ret = uncompress(dst, &dlen, src, cmp_hdr.compLength);
          if (ret != 0)
          {
            if (ret == -3)
              DP("%s", "lxtrace format: uncompression data error\n");
            else if (ret == -5)
              DP("%s", "lxtrace format: uncompression buffer error\n");
            else
              DP("%s", "lxtrace format: uncompression error %d\n", ret);
          }
          else if (dlen != 0)
          {
            totalCompSize += cmp_hdr.compLength;
            totalPostCompSize += dlen;
            ret = fwrite(dst, dlen, 1, outFileP);
            if (ret == 0)
            {
              DP("lxtrace format: fwrite error %s\n", strerror(errno));
              goto exit_uncomp;
            }
          }
        }
        else
          DP("lxtrace format: compressed file incomplete. Sought %d bytes, get %d bytes\n",
             cmp_hdr.compLength, ret);
      }
      //go back to file head and uncompress
      else if (hasWrapped[cpu])
      {
        rewind(compressedFileP);
        hasWrapped[cpu] = false;
      }
      else break;
    }
  }

exit_uncomp:
  if (libz_handle != NULL)
    dlclose(libz_handle);
  if (src != NULL)
    free(src);
  if (dst != NULL)
    free(dst);
  if (compressedFileP != NULL) fclose(compressedFileP);
  if (outFileP != NULL)
  {
    rewind(outFileP);
  }
  return outFileP;
}


/* Obtain the next header; newHdr is a return parameter */
trc_hdrs_t* PickNextTrcHeader(FILE* rawFileP[], int nCPU,
                              trc_hdrs_t cpuHdr[],
                              Boolean hasWrapped[], long long prevSeq[])
{

  int i;
  if (nCPU == 1)
  {
    if (ReadNextTrcHeader(rawFileP[0], &cpuHdr[0], 0, prevSeq) > 0)
    {
      if (nWraps ) // ReadNextTrcHeader detected and processed a wrap-point
      {
        DFP("%s", "lxtrace format: ending after processing records 0 to wrap-point\n");
        nWraps = 0;
        return NULL;
      }
      return &cpuHdr[0];
    }
    else
      return NULL;
  }

#if defined(GPFS_LINUX)
  //this cpu raw file still have trace data
  if (cpuHdr[curCPU].hdr.trMagic != LXTRACE_NODATA_MAGIC)
  {
    //read trace data from last accessed cpu file. Note that
    //the shared trace buffer case doesn't do per-cpu tracing so it
    //doesn't need to be accounted for
    if (ReadNextTrcHeader(rawFileP[curCPU], &cpuHdr[curCPU], curCPU, prevSeq) > 0)
    {
      /* Since we always start AFTER the wrap point, we should only see a
         wrap if we had reached the end of the file and then gone back to
         the beginning to get the records from there up to the wrap point.
         So, if we see this, we have formatted all the records and are done. */

      if (nWraps ) // ReadNextTrcHeader detected and processed a wrap-point
      {
        DFP("%s", "lxtrace format: ending after processing records 0 to wrap-point\n");
        cpuHdr[curCPU].hdr.trMagic = LXTRACE_NODATA_MAGIC;
        nWraps = 0;
      }
    }
    //go back to caller for rewind
    else if (hasWrapped[curCPU])
      return NULL;
    //no data left
    else
      cpuHdr[curCPU].hdr.trMagic = LXTRACE_NODATA_MAGIC;

  }

  //find next cpu file which has data to read
  curCPU = nCPU;
  for (i = 0; i < nCPU; i++)
  {
    if (cpuHdr[i].hdr.trMagic != LXTRACE_NODATA_MAGIC)
    {
      curCPU = i;
      break;
    }
  }
  //all cpu files are consumed
  if (curCPU>=nCPU) return NULL;

  //only last cpu file has data
  if (curCPU == nCPU - 1)
    return &cpuHdr[curCPU];

  //pick up oldest trace record from each cpu trace file
  for (i=curCPU+1; i<nCPU; i++)
  {
    if (cpuHdr[i].hdr.trMagic != LXTRACE_NODATA_MAGIC)
    {
      if (cpuHdr[i].hdr.trSeq < cpuHdr[curCPU].hdr.trSeq)
      {
        curCPU = i;
      }
    }
  }
#endif
  return &cpuHdr[curCPU];
}


int formatOneTraceRecordPrefix(char *compP, trc_hdrs_t *h, trc_datahdr_t *recP,
                               FILE *outFileP, char *fmtString,
                               int verbose, int sequence, int useLocal)
{
  char timeBufP[26]; /* timestamp in string format */
  int i;
  int rc;

  if (verbose)
  {
    if (sequence)
      rc = fprintf(outFileP, fmtString,
                   h->hdr.trSeq, h->hdr.trTime.tv_sec, h->hdr.trTime.tv_usec,
                   h->hdr.trProcess,
                   h->hdr.trCPU, h->hdr.trBuf, recP->trHook,
                   compP);
    else
      rc = fprintf(outFileP, fmtString,
                   h->hdr.trTime.tv_sec, h->hdr.trTime.tv_usec,
                   h->hdr.trProcess, h->hdr.trCPU, h->hdr.trBuf,
                   recP->trHook, compP);
  }
  else
  {
    if (sequence)
      rc = fprintf(outFileP, fmtString,
                   h->hdr.trSeq, h->hdr.trTime.tv_sec, h->hdr.trTime.tv_usec,
                   h->hdr.trProcess,
                   compP);
    else
    {
      if (useLocal)
        rc = fprintf(outFileP, fmtString,
                     fmtTime(h->hdr.trTime.tv_sec, timeBufP),
                     h->hdr.trTime.tv_usec, h->hdr.trProcess,
                     compP);
      else
        rc = fprintf(outFileP, fmtString,
                     h->hdr.trTime.tv_sec, h->hdr.trTime.tv_usec,
                     h->hdr.trProcess, compP);
    }
  }

  if (rc < 0)
  {
    DP("lxtrace format: fprintf error %s\n", strerror(errno));
    return 1;
  }

  return 0;
}


int formatOneTraceRecord(char *fmtP, i2nSpec_t *i2nP, char* dataP, int dataLen,
                         trc_datahdr_t *recP, FILE *outFileP)
{
  /* Array of pointers to the args for the fprintf that formats the output */
  argType argP[LXTRACE_MAX_FORMAT_SUBS];

  /* work buffer containing raw trace data */
  char application_data[LXTRACE_MAX_DATA];

  /* Array of id2name substitutions to be made */
  idname_t id2nameP[LXTRACE_MAX_FORMAT_SUBS];

  int rc;
  int i;
  double *d;
  memset(application_data, '\0', LXTRACE_MAX_DATA);
  memcpy(application_data, dataP, MIN(dataLen, LXTRACE_MAX_DATA));

  DFP("raw data: %X %X %X %X %X\n",
      TRC_ARG(0), TRC_ARG(1), TRC_ARG(2), TRC_ARG(3), TRC_ARG(4));
  /* Format-specific processing. */
  if (recP->trSPos == _TR_FORMAT_I)
  {
    /* Trace data consists of n integer values */
    for (i=0; i < recP->trNArgs; i++)
      argP[i] = TRC_ARG(i);
  }
  else if (recP->trSPos < LXTRACE_MAX_FORMAT_SUBS)
  {
    /* Trace data contains null terminated string at TRC_ARG(rec.trSPos);
       the length of the string is given by rec.trSLen (rounded up to a
       multiple of ARGLEN).  Get a pointer to the string, make sure it's
       null-terminated (so we don't blow up if the trace data is trash),
       and compute how many extra TRC_ARG words are occupied by the
       string. */
    // ?? should validate trSLen!
    char *s = (char *)&TRC_ARG(recP->trSPos);
    int xi = recP->trSLen/ARGLEN - 1;
    DFP("string at %d; total args %d . application data: 0x%lX, s: 0x%lX, xi: %d, s[%d] = '0', s = %s, argP[0] \n",
       recP->trSPos, recP->trNArgs, application_data, s, xi, recP->trSLen-1, s);
     s[recP->trSLen - 1] = '\0';
     for (i = 0; i < recP->trSPos; i++)
      argP[i] = TRC_ARG(i);
    argP[i++] = (argType)s;
     for (; i <= recP->trNArgs; i++)
      argP[i] = TRC_ARG(i + xi);

  }
  else if (recP->trSPos == _TR_FORMAT_F)
  {
    /* First n words are integer values; a double value is stored at
       TRC_ARG(rec.trNArgs) */
    d = (double *)&TRC_ARG(recP->trNArgs);

    for (i = 0; i < recP->trNArgs; i++)
      argP[i] = TRC_ARG(i);
  }
  else if (recP->trSPos == _TR_FORMAT_X)
  {

    /* XTrace type (preformatted) record. */

    fputs(application_data, outFileP);
    i = strlen(application_data);
    if (i == 0 || application_data[i-1] != '\n')
      putc('\n', outFileP);
    return 0;
  }
  else
  {
    DP("lxtrace format: format %d not supported\n", recP->trSPos);
    fprintf(outFileP, "Unsupported format %d\n", recP->trSPos);
    return 1;
  }
  /* Perform id2name substitutions */
  /* Defect 801461, always do this check instead of having it under DEBUGASSERTS*/
  if (i2nP == NULL &&
      (recP->trSPos==_TR_FORMAT_I || recP->trSPos==_TR_FORMAT_F) &&
      strstr(fmtP, "%s"))
  {
    DP("lxtrace format: hook %X is %s format record containing a string specification.\n",
       (recP->trHook&0xFFFFFFFF),
       (recP->trSPos==_TR_FORMAT_I) ? (char *) "an integer" :
       (recP->trSPos==_TR_FORMAT_F)? (char *) "a float":
       (char *) "an unknown");
    fprintf(outFileP, "lxtrace format: hook %X is %s format record with %d integer args containing a string specification.\n",
            (recP->trHook&0xFFFFFFFF),
            (recP->trSPos==_TR_FORMAT_I) ? (char *) "an integer" :
            (recP->trSPos==_TR_FORMAT_F)? (char *) "a float":
            (char *) "an unknown",
            recP->trNArgs);
    //print to both the outfile and stderr
    DP("%s", "               The formatting information for this record does not provide any substitutions.\n");
    fprintf(outFileP, "%s", "The formatting information for this record does not provide any substitutions:\n");
    fprintf(outFileP, "%s\n", fmtP);
    return 0;
  }
  ID2Name(recP, i2nP, id2nameP, argP);
  if (recP->trSPos == _TR_FORMAT_F)
  {
    DFP("Double %f, case %i\n", *d, recP->trNArgs);
    switch(recP->trNArgs)
    {
       case 1: rc = fprintf(outFileP, fmtP, TRC_ARGLIST1F); break;
       case 2: rc = fprintf(outFileP, fmtP, TRC_ARGLIST2F); break;
       case 3: rc = fprintf(outFileP, fmtP, TRC_ARGLIST3F); break;
       case 4: rc = fprintf(outFileP, fmtP, TRC_ARGLIST4F); break;
       case 5: rc = fprintf(outFileP, fmtP, TRC_ARGLIST5F); break;
       case 6: rc = fprintf(outFileP, fmtP, TRC_ARGLIST6F); break;
       case 7: rc = fprintf(outFileP, fmtP, TRC_ARGLIST7F); break;
       case 8: rc = fprintf(outFileP, fmtP, TRC_ARGLIST8F); break;
       case 9: rc = fprintf(outFileP, fmtP, TRC_ARGLIST9F); break;
       case 10: rc = fprintf(outFileP, fmtP, TRC_ARGLIST10F); break;
    }
  }
  else
    rc = fprintf(outFileP, fmtP, TRC_ARGLIST);

//  DFP("Invoked %d, errno %d <%s>\n", rc, errno, strerror(errno));
  /* end processing this trace record */
  return 0;
}

/* Print command syntax and exit */
void Usage()
{
  DP("%s",
"Usage: lxtrace { on | off | recycle | format | dump | fsync | query |\n"
"                 startOverwriteTrace  | startBlockingTrace    |\n"
"                 quiesceBlockingTrace | quiesceOverwriteTrace |\n"
"                 resumeBlockingTrace  | resumeOverwriteTrace  |\n"
"                 cleanupBlockingTrace | cleanupOverwriteTrace }\n"
"\n"
"Command line format for lxtrace on:\n"
"  lxtrace on --blocking-mode [options] <outputFile>\n"
"    -or-\n"
"  lxtrace on --overwrite-mode [options]\n"
"Options for 'lxtrace on --blocking-mode'\n"
"  --buffer-size n           Size of blocking mode buffer.  Default 4M.\n"
"  --log-file <fn>           Name of optional log file to log all lxtrace\n"
"                              daemon activity.  Default is not to log\n"
"                              daemon activity.\n"
"  --out-file-size n         Output file size.  A value of 0 means that\n"
"                               the trace file grows indefinitely.  Default\n"
"                               is 128M.\n"
"  --compression-level n     zlib compression level for output file.\n"
"                               Default 6.\n"
#ifdef SHOW_UNSUPPORTED_OPTIONS
"  --per-cpu-bufs            Turn on per-cpu buffer trace\n"
"  --coarse-timestamps       Turn on coarse-grained timestamp for lower\n"
"                              overhead\n"
"  --rename-on-wrap          Rename raw trace file upon file wrap to keep\n"
"                              all trace data\n"
"  --relay-buffers n         Number of buffers to use in blocking mode.\n"
"                              Default 4.\n"
"  --flush-interval n        Seconds between trace file flushes .  Default\n"
"                              0, which implies no flushes.\n"
#endif
"  <outputFile>              Name of raw trace file to be created\n"
"Options for 'lxtrace on --overwrite-mode'\n"
"  --buffer-size n           Size of overwrite mode buffer.  Default\n"
"                              128M.\n"
"  --log-file <fn>           Name of optional log file to log all lxtrace\n"
"                              daemon activity.  Default is not to log\n"
"                              daemon activity.\n"
"\n"
"Command line format for lxtrace off and lxtrace recycle when using --blocking-mode:\n"
"  lxtrace off/recycle\n"
"Command line format for lxtrace off and lxtrace recycle when using --overwrite-mode:\n"
"  lxtrace off/recycle outFile\n"
"\n"
"Command line format for lxtrace format:\n"
"  lxtrace format <timestamp style> [options] [-o outFile] [trcFile]\n"
"<timestamp style> options for lxtrace format (at most 1 allowed):\n"
"  --relative-seconds        Display timestamps as seconds after the first\n"
"                              trace record.  This is the default.\n"
"  --absolute-seconds        Display timestamps as seconds since 1/1/1970.\n"
"  --local-time              Display timestamps in local calendar format\n"
"  --raw-cycle-count         In overwrite mode, display timestamps as raw\n"
"                              cycle counts\n"
"  --relative-cycle-count    In overwrite mode, display timestamps as the\n"
"                              number of cycles since the beginning of the\n"
"                              trace.\n"
"Other options for lxtrace format:\n"
" --raw-memory-data          The input file contains raw data dumped from\n"
"                            trace memory buffer by analysis tool.\n"   
"  --verbose                 Verbose mode.  Include additional information\n"
"                              for each trace record.  In overwrite mode,\n"
"                              formats all trace records, not just those after\n"
"                              the time at which all trace streams have valid\n"
"                              data.  Default is non-verbose mode.\n"
"  --wobble n                Number of microseconds wobble allowed in\n"
"                              timestamps.  An apparent wrap within the wobble\n"
"                              limit will be ignored.  Default 2.  Blocking\n"
"                              mode only.\n"
"  --sequence                Display trace sequence numbers.  Blocking mode\n"
"                              only.  Default off.\n"
"  --statfile <fn>           Name of file to receive formatting statistics\n"
"                              about the trcfile being formatted.  Default\n"
"                              is no trace statistics.\n"
"  --format-desc-file        Name of file containing trace formats.  Default\n"
"                              is /usr/lpp/mmfs/mmfs.trcfmt.\n"
"  outFile                   Name of file to receive formatted trace output.\n"
"                              Default is standard output.\n"
"  trcFile                   Name of input raw trace file.  Default is\n"
"                              /tmp/lxtrace.trc.\n"
"\n"
     );
  if (TraceDeviceFD != -1)
    close(TraceDeviceFD);
  exit(1);
}

/* The lxtrace command.  */
int main(int argc, char *argv[])
{
  int rc = 0;
  struct kArgs args; // command arguments
  int i;
  int nTrcHdrs[LXTRACE_NR_CPUS];
  Boolean hasWrapped[LXTRACE_NR_CPUS] = { 0 };

#ifdef LOG_LXTRACE
  const char* envP;
  char ctimeBufP[32];
  struct timeval now;
  time_t micros;
  time_t secs;

  LogFileP = fopen("/var/mmfs/gen/lxtrace.log", "a");
  setlinebuf(LogFileP);
  gettimeofday(&now, NULL);
  secs = (time_t) now.tv_sec;
  micros = (time_t) now.tv_usec;

  ctime_r(&secs, ctimeBufP);
  ctimeBufP[19] = '\0';
  fprintf(LogFileP, "\nEnter pid %d %s.%06d\n", getpid(), ctimeBufP, micros);
  envP = getenv("CONTEXT");
  if (envP != NULL)
    fprintf(LogFileP, "  Calling context is '%s'\n", envP);
  for (i=0; i<argc; i++)
    fprintf(LogFileP, "  argv[%d] = '%s'\n", i, argv[i]);
  fclose(LogFileP);
  system("/bin/ps -ef >> /var/mmfs/gen/lxtrace.log");
  LogFileP = fopen("/var/mmfs/gen/lxtrace.log", "a");
  setlinebuf(LogFileP);
#endif  /* LOG_LXTRACE */

  if (argc < 2)
    Usage();

   /* check if LXTRACE_DEBUG environment variable is set to enable DFP debugs */
   if ((getenv(LXTRACE_DEBUG_ENV) != NULL) && atoi(getenv(LXTRACE_DEBUG_ENV)) == 1)
     lxtraceDebug = true;

  /* lxtrace on: A new trace is being started.  Validate the options,
     open the files, start the daemon and configure the device. */
  if (strcmp(argv[1], "on") == 0)
  {
    int hw, dpid;
    struct sigaction action;
    char* trcFileNameP = NULL;
    TraceDaemonMsg_t msg;
    int mode;
    char *daemonLogFileP = NULL;
    /* Initialize local state fields. */

    bufP = NULL;
    outSize = DEF_TRC_FILESIZE;
    bufNum = DEF_TRC_BUFNUM;
    interval = DEF_TRC_INT;
    compLevel = DEF_TRC_COMPLEVEL;
    currentPos = 0;
    nWraps = 0;

    /* Parse arguments */
    for (i = 2; i < argc; i++)
    {
      if (strcmp(argv[i], "--blocking-mode") == 0)
        writeMode = LXTRACE_BLK;
      else if (strcmp(argv[i], "--overwrite-mode") == 0)
        writeMode = LXTRACE_OVERWRITE;
      else if (strcmp(argv[i], "--per-cpu-bufs") == 0)
        RelayFlags |= RL_BUF_PERCPU;
      else if (strcmp(argv[i], "--coarse-timestamps") == 0)
        RelayFlags |= RL_BUF_CTIME;
      else if (strcmp(argv[i], "--rename-on-wrap") == 0)
        noWrap = 1;
      else if ((strcmp(argv[i], "--out-file-size") == 0)
               &&  i+1<argc)
      {
        i += 1;
        /* Save the output filesize.  If the size is explicitly given as zero,
           do not wrap. This parameter is not used in overwrite mode. */
        outSize = atoll(argv[i]);
      }
      else if ((strcmp(argv[i], "--buffer-size") == 0)
               &&  i+1<argc)
      {
        i += 1;
        bufSize = atoll(argv[i]) & 0xfffffffffffff000uLL;
      }
      else if ((strcmp(argv[i], "--relay-buffers") == 0)
               &&  i+1<argc)
      {
        i += 1;
        bufNum = atoi(argv[i]);
        if (bufNum < MIN_TRC_BUFNUM || bufNum > MAX_TRC_BUFNUM)
        {
          Usage();
          DP("Buffer number must be between %d and %d\n",
             MIN_TRC_BUFNUM, MAX_TRC_BUFNUM);
        }
      }
      else if ((strcmp(argv[i], "--flush-interval") == 0)
               &&  i+1<argc)
      {
        i += 1;
        interval = atoi(argv[i]);
        if (interval < -1)
        {
          Usage();
          DP("Interval must be more than %d\n", -1);
        }
      }
      else if ((strcmp(argv[i], "--compression-level") == 0)
               &&  i+1<argc)
      {
        i += 1;
        compLevel = atoi(argv[i]);
        if (compLevel < MIN_TRC_COMPLEVEL || compLevel > MAX_TRC_COMPLEVEL)
        {
          Usage();
          DP("Compression level must be between %d and %d\n",
             MIN_TRC_COMPLEVEL, MAX_TRC_COMPLEVEL);
        }
      }
      else if ((strcmp(argv[i], "--log-file") == 0)
               &&  i+1<argc)
      {
        i += 1;
        daemonLogFileP = strdup(argv[i]);
        if (daemonLogFileP == NULL)
        {
          DP("E_NOMEM in strdup for -l\n");
          exit(1);
        }
      }

      else
        trcFileNameP = argv[i];
    }

    if (writeMode == LXTRACE_NEITHER)
    {
      DP("Must specify either --blocking-mode or --overwrite-mode\n");
      rc = EINVAL;
      goto exit;
    }

    /* Get output file name or use default */
    if (trcFileNameP == NULL )
      trcFileNameP = "/tmp/lxtrace.trc";
    strcpy(percpuOutBasename, trcFileNameP);

    /* set default buffer size */
    if (bufSize == 0)
    {
      if (writeMode == LXTRACE_OVERWRITE)
        bufSize = DEF_TRC_OVERWRITE_BUFSIZE;
      else
        bufSize = DEF_TRC_BUFSIZE;
    }

    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      /* Device does not exist, wrong type, or already open, ... */
      DP("trace daemon: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    /* Do some additional parameter validation for blocking mode */
    if (writeMode == LXTRACE_BLK)
    {
      /* The output filesize must be at least as big as the selected buffer size. */
      if ((outSize < MIN_TRC_FILESIZE || outSize > MAX_TRC_FILESIZE) &&
          outSize != 0)
      {
        Usage();
        DP("Output file size must be 0 or between %d and %lld\n",
           MIN_TRC_FILESIZE, MAX_TRC_FILESIZE);
      }

      if (outSize != 0 && outSize < bufSize)
      {
        Usage();
        DP("lxtrace: the filesize (%d) must be at least as large as the bufsize (%d)\n",
           outSize, bufSize);
      }

      if (bufSize < MIN_TRC_BUFSIZE)
      {
        DP("lxtrace: trace buffer has size %lld instead of the requested %lld\n",
           MIN_TRC_BUFSIZE, bufSize);
        bufSize = MIN_TRC_BUFSIZE;
      }
      else if (bufSize > MAX_TRC_BUFSIZE)
      {
        DP("lxtrace: trace buffer has size %lld instead of the requested %lld\n",
           MAX_TRC_BUFSIZE, bufSize);
        bufSize = MAX_TRC_BUFSIZE;
      }
    }

    /* Set up shared trace buffer and turn on kernel tracing for
       overwrite mode */
    if (writeMode == LXTRACE_OVERWRITE)
    {
      /* No compression in overwrite mode */
      compLevel = 0;

      if (bufSize < MIN_TRC_OVERWRITE_BUFSIZE)
      {
        DP("lxtrace: overwrite buffer has size %lld instead of the requested %lld\n",
           MIN_TRC_OVERWRITE_BUFSIZE, bufSize);
        bufSize = MIN_TRC_OVERWRITE_BUFSIZE;
      }

      args.arg1 = (long)&bufSize;
      DFP("Calling TrAllocateSharedBuffer ioctl with arg1 at 0x%lX\n",
          args.arg1);
      int rc = ioctl(TraceDeviceFD, TrAllocateSharedBuffer, &args);
      if (rc != 0)
      {
        DP("TrAllocateSharedBuffer ioctl failed, rc %d!\n", rc);
        exit(1);
      }
      else
        DFP("ioctl succeeds\n");
    }

    /* Create message queue for communication between this parent process
       and the forked lxtrace daemon we are about to create */
    msgQueue = GetMsgQueue(IPC_CREAT | 0666);
    if (msgQueue == -1)
    {
      DP("trace daemon: msgget error %d\n", errno);
      rc = errno;
      goto exit;
    }

    /* Create the trace daemon.  It lives until "trace off" sends it a
       SIGTERM signal. */
    dpid = fork();
    if (dpid < 0)
    {
      DP("%s", "lxtrace on: unable to fork trace daemon");
      rc = EAGAIN;
      goto exit;
    }

    if (dpid != 0)
    {
      /* Parent */
      /* Wait for child daemon initialization message */
      for (i = 0; i < 100; i++)
      {
       /* Do not wait in case the child exits abnormally so the parent
          will not be blocked forever */
        rc = msgrcv(msgQueue, &msg, LXTRACE_MSG_LEN, LXTRACE_MTYPE, IPC_NOWAIT);
        if (rc == -1)
        {
          rc = errno;
          //no message, sleep for 1/10th second and retry
          if (errno == ENOMSG )
          {
            usleep(100000);
          }
          else
          {
            DP("lxtrace on: msgrcv error %d\n", errno);
            break;
          }
        }
        else
        {
          rc = 0;
          break;
        }
      }
      DFP("lxtrace on: receive message from daemon: %s\n", msg.mtext);
      msgctl(msgQueue, IPC_RMID, NULL);
      //return initialization result to mmtrace
      if (rc != 0 || strcmp(msg.mtext, LXTRACE_INIT_ERR) == 0)
        rc = -1;
      else
        rc = 0;
      goto exit;
    }  /* end of 'if parent' */

    else
    { /* Child/Daemon */

      /* Close file descriptors that were opened by the parent process */
#ifdef LOG_LXTRACE
      if (LogFileP != NULL)
        close(fileno(LogFileP));
#endif
      close(TraceDeviceFD);

      /* Make this process into a daemon so parent processes can
         terminate */
      daemon(0 /* cd to / */, 0 /* redirect stdXXX to /dev/null */);
      chdir("/var/mmfs/gen");

      /* Set up daemon log file if requested */
      if (daemonLogFileP != NULL)
      {
        int daemonLogFD =
          open(daemonLogFileP, O_CREAT | O_RDWR | O_TRUNC, 0644);
        if (daemonLogFD >= 0)
        {
          dup2(daemonLogFD, fileno(stdout)); //reroute stdout to daemonLogFD
          dup2(daemonLogFD, fileno(stderr)); // reroute stderr to daemonLogFD
        }
      }

      if (writeMode == LXTRACE_BLK)
      {
        /* Call body of lxtrace daemon for blocking trace.  Does not
           return until tracing is shut down. */
        rc = BlockingTraceDaemonBody(outSize, bufSize, bufNum,
                                     interval, compLevel);
      }
      else if (writeMode == LXTRACE_OVERWRITE)
      {
        /* Call body of lxtrace daemon for overwrite trace.  Does not
           return until tracing is shut down. */
        rc = OverwriteTraceDaemonBody(msgQueue);
      }
      else
        rc = -1;

      if (rc != 0)
      {
        /* initialization failure, send message to parent.  The parent will
           remove the message queue. */
        msg.mtype = LXTRACE_MTYPE;
        strcpy(msg.mtext, LXTRACE_INIT_ERR);
        msgsnd(msgQueue, &msg, strlen(msg.mtext)+1, 0);
        DFP("trace daemon: send message to parent: %s\n", msg.mtext);
      }
      /* exit here for failures during daemon initialization. */
      DFP("trace daemon exiting\n");
      if (TraceDeviceFD >= 0)
        close(TraceDeviceFD);
      goto exitNoLogging;
    }  /* end of 'else child/daemon' */
  }


  /* lxtrace format: format the trace file. */
  else if (strcmp(argv[1], "format") == 0)
  {
    FILE *rawFileP[LXTRACE_NR_CPUS] = { NULL }; /* raw trace data file */
    FILE *formatFilePtr; /* the application formatting file */
    FILE *outFileP; /* output file */
    FILE *statFileP; /* output file for statistics */
    trc_hdrs_t *h;
    int useRelSeconds = 0; /* true if --relative-seconds given */
    int useTOD = 0;        /* true if --absolute-seconds option given */
    int useLocal = 0;      /* true if --local-time option given */
    int useRawCycles = 0;  /* true if --raw-cycle-count option given */
    int useRelCycles = 0;  /* true if --relative-cycle-count option given */
    int rawMemoryData = 0; /* true if --raw-memory-data option given */
    int verbose = 0;   /* true if -v option given */
    int sequence = 0;   /* true if -s option given */
    char* formatFileNameP = "/usr/lpp/mmfs/mmfs.trcfmt";
    char* outputFileNameP = NULL;
    char *statFileNameP = NULL;
    char* rawTraceFileNameP = "/tmp/lxtrace.trc";
    char* compSuffix = "uncomp";
    char *compP, *fmtP;
    i2nSpec_t *i2nP;
    Int64 nRecordsProcessed = 0;
    int i, j, id;
    Boolean msgHandler;
    char timeBufP[26]; /* timestamp in string format */
    FILE *versionFileP;
    trc_datahdr_t *recP;
    trc_hdrs_t cpuHdr[LXTRACE_NR_CPUS];

    TODList = (refTOD **)malloc(sizeof(refTOD)*TODMaxListSize);
    if (TODList == NULL)
    {
      rc = ENOMEM;
      goto exit_format;
    }
    memset(TODList, '0', sizeof(refTOD)*TODMaxListSize);
    currTOD = 0;

    unsigned long long prevSeq[LXTRACE_NR_CPUS];
    int prevWrapPt;
    /* work buffers */
    char application_data[LXTRACE_MAX_DATA];   /* raw trace data */

    /* Array of id2name substitutions to be made */
    idname_t id2nameP[LXTRACE_MAX_FORMAT_SUBS];
    char fmtString[256];

    /* Array of pointers to the args for the fprintf that formats the output */
    argType argP[LXTRACE_MAX_FORMAT_SUBS];

    int nCPU = 1;
    int fileWrapped = 0;
    formatFilePtr = outFileP = statFileP = NULL;

    formatFileP = NULL;
    fmtDescSpaceP = NULL;

    unsigned long long lastSeq = 0;
    unsigned long long lostRecords = 0;
#if (defined(__64BIT__) || defined(_LP64))
    startTime = 9223372036854775807;
#else
    startTime = 2147483647;
#endif
    stopTime = 0;

    /* Parse arguments */
    for (i = 2; i < argc; i++)
    {
      if (strcmp(argv[i], "--absolute-seconds") == 0)
        useTOD = 1;
      else if (strcmp(argv[i], "--relative-seconds") == 0)
        useRelSeconds = 1;
      else if (strcmp(argv[i], "--local-time") == 0)
        useLocal = 1;
      else if (strcmp(argv[i], "--raw-cycle-count") == 0)
        useRawCycles = 1;
      else if (strcmp(argv[i], "--relative-cycle-count") == 0)
        useRelCycles = 1;
      else if (strcmp(argv[i], "--raw-memory-data") == 0)
        rawMemoryData = 1;
      else if (strcmp(argv[i], "--verbose") == 0)
        verbose = 1;
      else if (strcmp(argv[i], "--sequence") == 0)
        sequence = 1;
      else if (strcmp(argv[i], "--statfile") == 0  &&  i+1<argc)
        {
          i += 1;
          statFileNameP = argv[i];
        }
      else if (strcmp(argv[i], "--wobble") == 0  &&  i+1<argc)
      {
        char *endptr;
        i += 1;
        allowed_usec_wobble = strtol(argv[i], &endptr, 10);
        if ((*endptr != 0) || (allowed_usec_wobble < 0))
        {
          DP("%s", "lxtrace format: --wobble requires an integer argument greater than or equal to zero.\n");
          rc = 12;
          goto exit_format;
        }
      }
      else if ((strcmp(argv[i], "--format-desc-file") == 0)
               &&  i+1<argc)
      {
        i += 1;
        formatFileNameP = argv[i];
      }
      else if (strcmp(argv[i], "-o") == 0  &&  i+1<argc)
      {
        i += 1;
        outputFileNameP = argv[i];
      }
      else
        rawTraceFileNameP = argv[i];
    }

    /* Verify that at most one timestamp style was given */
    if (useRelSeconds+useTOD+useLocal+useRawCycles+useRelCycles == 0)
      useRelSeconds = 1;
    else if (useRelSeconds+useTOD+useLocal+useRawCycles+useRelCycles > 1)
    {
      Usage();
      DP("lxtrace format: at most one timestamp style can be given\n");
      goto exit_format;
    }

    if (useRelSeconds > 0)
      TimestampStyle = fRelativeSecs;
    else if (useTOD > 0)
      TimestampStyle = fTOD;
    else if (useLocal > 0)
      TimestampStyle = fLocal;
    else if (useRawCycles > 0)
      TimestampStyle = fRawCycles;
    else if (useRelCycles > 0)
      TimestampStyle = fRelCycles;

    /* Open the formatting file. */
    if (NULL == (formatFilePtr = fopen(formatFileNameP, "r")))
    {
      DP("lxtrace format: could not open file %s, errno %d\n",
         formatFileNameP, errno);
      rc = errno;
      goto exit_format;
    }

    if (0 != (rc = BuildFormatTable(formatFilePtr)))
    {
      DP("lxtrace format: could not parse file: %s errno %d\n",
         formatFileNameP, errno);
      rc = errno;
      goto exit_format;
    }

    /* Open and truncate the output file. (defaults to stdout) */
    if (outputFileNameP == NULL)
      outFileP = stdout;
    else
    {
      outFileP = fopen(outputFileNameP, "w");
      if (outFileP == NULL)
      {
        DP("lxtrace format: could not open file %s, errno %d\n",
           outputFileNameP, errno);
        rc = errno;
        goto exit_format;
      }
    }

    /* Open and truncate the stat file if --statfile option was given */
    if (statFileNameP != NULL)
    {
      statFileP = fopen(statFileNameP, "w");
      if (statFileP == NULL)
      {
        DP("lxtrace format: could not open file %s, errno %d\n",
           statFileNameP, errno);
        rc = errno;
        goto exit_format;
      }
      else
        genStats = 1;
    }

    //the code wants this to be a file prefix, not the full filename
    //make sure this is the case
    checkFileNamePrefix(rawTraceFileNameP);

    nCPU = findRawFiles(rawTraceFileNameP);
    if (nCPU == 0)
    {
      DP("lxtrace format: could not find raw file %s, errno %d\n",
         rawTraceFileNameP, errno);
      rc = errno;
      goto exit_format;
    }
    writeMode = checkTraceFileMode(rawTraceFileNameP);

    /* Verify only legal modes used in blocking mode */
    if (writeMode == LXTRACE_BLK  &&
        useRawCycles+useRelCycles > 0)
    {
      Usage();
      DP("lxtrace format: bad timestamp style for blocking mode\n");
      goto exit_format;
    }

    /* Process overwrite trace file */
    if (writeMode == LXTRACE_OVERWRITE)
    {
      DFP("Detected trace file using overwrite mode\n");
      char outFileName[PATH_MAX];
      if (rawMemoryData)
      {
        char rawDataDumpFileName[PATH_MAX];
        sprintf(rawDataDumpFileName, "%s.cpu%d",rawTraceFileNameP, 0);
        sprintf(outFileName, "%s.recyle.cpu%d", rawTraceFileNameP, 0);
        RecycleOverwriteFromDump(rawDataDumpFileName, outFileName);
        /* Reuse outFileName array to store the file name prefix as
           FormatOverwriteTrace() needs that. */
        sprintf(outFileName, "%s.recyle", rawTraceFileNameP);
        rawTraceFileNameP = outFileName;
      }
      rc=FormatOverwriteTrace(rawTraceFileNameP, outFileP, verbose,
                           &nRecordsProcessed);
      goto exitFormatOverwrite;
    }
    else
      DFP("Detected trace file using blocking mode\n");

    /* ****** no overwrite processing after here ****** */

    /* The trace file (rawFileP) is a wrap-around file.  We need to read it to
       see if it ever wrapped.  If it never wrapped, rewind and process it
       top-to-bottom.  If the file did wrap, set the file pointer to the oldest
       record and begin processing from there.  ReadNextTrcHeader detects the
       wrap point.  When formatting of a wrapped file reaches end-of-file, it
       must then go back and read starting at the beginning and stop when
       the wrap point is again reached. */
    /* rawMemoryData: nothing special for blocking mode for now */
    for (i=0; i<nCPU; i++)
    {
      //uncompress and find wrap point
      rawFileP[i] = unComp(rawTraceFileNameP, compSuffix, i, hasWrapped);
      if (rawFileP[i] == NULL)
      {
        /* no compression, find wrap point directly */
        rawFileP[i] = findWrapPoint(rawTraceFileNameP, NULL, i,
                                  nTrcHdrs, hasWrapped, prevSeq);
      }
      else
      {
        /* Compression was used, so we need to scan through for the
           start/end times. During unComp(), the resulting trcfile.uncomp
           files should have had the wrap point placed at the beginning
           of the file. This scan is just to find the timestamps. */
        Boolean hasWrapped_tmp[LXTRACE_NR_CPUS]; //just a placeholder
        (void) findWrapPoint(rawTraceFileNameP, compSuffix, i,
                             nTrcHdrs, hasWrapped_tmp, prevSeq);
      }
      if (rawFileP[i] == NULL)
      {
        rc = 1;
        goto exit_format;
      }
      /* Show the point we interpreted as the wrap-point */
      if (nWraps)
      {
        DFP("CPU %d Wrap point  : %d.%06d-%d.%06d (delta %d.%06d)\n", i,
            wrap_prev.tv_sec, wrap_prev.tv_usec,
            wrap_next.tv_sec, wrap_next.tv_usec,
            (wrap_prev.tv_sec-wrap_next.tv_sec),
            (wrap_prev.tv_usec-wrap_next.tv_usec));
      }
      DFP("wrap analysis: nTrcHdrs %d nWraps %d seekpos %d\n",
          nTrcHdrs[i], nWraps, ftell(rawFileP[i]) - hdrSize[i]);
    }

    /* Begin printing out header information */
    fprintf(outFileP, FMT_TRC_BEGIN, fmtTime(startTime, timeBufP));
    fprintf(outFileP, FMT_TRC_END, fmtTime(stopTime, timeBufP),
            fileWrapped? FILE_WRAP_STR:FILE_NOWRAP_STR);
    /* Achieved compression ratio. Not used for overwrite mode */

    if (totalCompSize != 0)
      fprintf(outFileP, FMT_COMP_RATIO, totalPostCompSize / totalCompSize);
    else
      fprintf(outFileP, FMT_COMP_RATIO, 0);

    /* Write kernel version to the trace file.  This is the machine
     * where the format was done, but this would normally be the
     * same machine that generated the raw trace as well.
     */
    versionFileP = fopen("/proc/version", "r");
    if (versionFileP)
    {
      int verLen;
      const int verStrLen = 512;
      char version_str[verStrLen];

      memset(version_str, 0, verStrLen);
      if (0 < (verLen = fread(version_str, 1, verStrLen, versionFileP)))
      {
        version_str[verStrLen-1] = '\0';
        fprintf(outFileP, "Formatted on: %s\n\n", version_str);
      }

      fclose(versionFileP);
    }

    /* Reset to avoid reporting a wrap on the first record from the next
     * call to ReadNextTrcHeader.
     */
    for (i=0; i<nCPU; i++)
    {
      prevTime[i].tv_sec = 0;
      prevTime[i].tv_usec = 0;
      prevSeq[i] = 0;
    }
    /* Print first line of header and build trace format string */
    fmtString[0] = '\0';
    if (sequence)
    {
      fprintf(outFileP, H1_SEQ);
      strcat(fmtString, FMT_SEQ);
    }
    if (useTOD)
    {
      fprintf(outFileP, H1_TS_T);
      strcat(fmtString, FMT_TS_T);
    }
    else if (useLocal)
    {
      fprintf(outFileP, H1_TS_D);
      strcat(fmtString, FMT_TS_D);
    }
    else
    {
      fprintf(outFileP, H1_TS);
      strcat(fmtString, FMT_TS);
    }

    fprintf(outFileP, H1_PID);
    strcat(fmtString, FMT_PID);
    if (verbose)
    {
      fprintf(outFileP, H1_P_HW_V);
      strcat(fmtString, FMT_P_HW_V);
    }
    fprintf(outFileP, H1_TAG);
    strcat(fmtString, FMT_TAG);

    /* Print second line of header */
    fprintf(outFileP, H2_SEQ);
    if (useTOD)
      fprintf(outFileP, H2_TS_T);
    else if (useLocal)
      fprintf(outFileP, H2_TS_D);
    else
      fprintf(outFileP, H2_TS);
    fprintf(outFileP, H2_PID);
    if (verbose)
      fprintf(outFileP, H2_P_HW_V);
    fprintf(outFileP, H2_TAG);

#if defined(GPFS_LINUX)
    //for multiple raw trace file, read first trace record
    if (nCPU > 1)
    {
      cpuHdr[curCPU].hdr.trMagic = LXTRACE_SEQ_MAGIC;
      for (i=curCPU+1; i<nCPU; i++)
      {
        if (ReadNextTrcHeader(rawFileP[i], &cpuHdr[i], i, prevSeq)<0)
          cpuHdr[i].hdr.trMagic = LXTRACE_NODATA_MAGIC;
      }
    }
#endif


start_formatting:
    nWraps = 0; /* Reset the ReadNextTrcHeader wrap-found indicator. */

    /* Process raw trace records. Start by reading the device header. */
    while (0 < ( h = PickNextTrcHeader(rawFileP, nCPU, cpuHdr, hasWrapped, prevSeq)))
    {
      //trace records should not be missed if there's only one trace file
      //the per-CPU trace file may have this problem due to trace disbalance on each CPU
      if (nCPU ==1 && h->hdr.trMagic == LXTRACE_SEQ_MAGIC)
      {
        if (h->hdr.trSeq - lastSeq > 1 && lastSeq != 0)
        {
          fprintf(outFileP, "*** Missing %llu trace records ***\n",
                  h->hdr.trSeq - lastSeq - 1 );
          lostRecords += ( h->hdr.trSeq - lastSeq - 1 );
        }
        lastSeq = h->hdr.trSeq;
      }

      recP = (trc_datahdr_t*) ( (char*)h + hdrSize[curCPU] - sizeof(trc_datahdr_t));
      DFP("rec.trHook 0x%X rec.trNArgs %d rec.trSPos %d rec.trSLen %d\n",
          recP->trHook, recP->trNArgs, recP->trSPos, recP->trSLen);

      if (h->hdr.trLength < sizeof(trc_datahdr_t))
      {
        DP("lxtrace format: bad record length in %s at offset %d, trLength %d\n",
           rawTraceFileNameP, ftell(rawFileP[curCPU]), h->hdr.trLength);
        rc = EINVAL;
        if (hasWrapped[curCPU])
        {
          DP("%s", "lxtrace format: restart from wrap-point\n");
          fprintf(outFileP, "*** BAD trace record header ***\n");
          goto do_wrap;
        }
        goto exit_format;
      }

      /* application_data[] holds the raw trace data that follows the headers. */
      int dataRead = 0;

      if (0 > (dataRead = fread(application_data, 1,
                                h->hdr.trLength - sizeof(trc_datahdr_t), rawFileP[curCPU])))
      {
        DP("lxtrace format: could not read data from %s at offset %d, rc %d errno %d\n",
           rawTraceFileNameP, ftell(rawFileP[curCPU]), dataRead, errno);
        rc = errno;
        goto exit_format;
      }

      DFP("read %d bytes of application trace data\n", dataRead);

      /* If this is the first trace record, consider this time zero,
         unless the -T option was specified */
      if (tzero.tv_sec == 0  &&  !useTOD)
        tzero = h->hdr.trTime;

      /* Convert trace time to time since first trace record unless
         the -T option was specified */
      if (!useTOD)
      {
        h->hdr.trTime.tv_sec -= tzero.tv_sec;
        if (h->hdr.trTime.tv_usec >= tzero.tv_usec)
          h->hdr.trTime.tv_usec -= tzero.tv_usec;
        else
        {
          h->hdr.trTime.tv_sec--;
          h->hdr.trTime.tv_usec += 1000000 - tzero.tv_usec;
        }
      }
      /* Get the formatting record for the trace record with this hookid */
      if (0 != GetFormatRecord((int)(recP->trHook & 0xFFFFFFFF),
                               &compP, &fmtP, &i2nP,
                               dataRead + hdrSize[curCPU]))
      {
        DP("lxtrace format: No formatting record found for hook %X before input offset 0x%llX\n",
           recP->trHook, ftell(rawFileP[curCPU]));
        fprintf(outFileP, "Unknown hook id 0x%08X\n", recP->trHook);
        DFP("raw data: %X %X %X %X %X\n",
            TRC_ARG(0), TRC_ARG(1), TRC_ARG(2), TRC_ARG(3), TRC_ARG(4));

      }
      else
      {
        rc = formatOneTraceRecordPrefix(compP,
                                  h, recP, outFileP,
                                  fmtString, verbose, sequence,
                                  useLocal);
        rc = formatOneTraceRecord(fmtP, i2nP, application_data, dataRead,
                                  recP, outFileP);
        if (rc != 0)
        {
          DP("Error detected in formatting. Exit now\n");
          goto exit_format;
        }
        nRecordsProcessed += 1;

      } /* end processing this trace record */
    } /* while there are more unformatted trace records to process */

    if (hasWrapped[curCPU])
    {
do_wrap:
      DFP("Rewinding buffer!\n");
      rewind(rawFileP[curCPU]); /* On a wrapped file, need to go back to the top. */
      hasWrapped[curCPU] = false;  /* Clear this so we don't do this more than once. */
      DFP("%s", "lxtrace format: done with wrap-point to EOF.  Going back to record 0\n");
      fileWrapped++;
      goto start_formatting;
    }

    rc = 0;

exit_format:

    /* Lost records count (primarily for per-cpu traces). The
       rest of the associated trace metadata is at the top of the file */
    if (outFileP != NULL)
      fprintf(outFileP, FMT_LOST_COUNT, lostRecords);

    DFP("Wrap point: %d.%06d-%d.%06d (delta %d.%06d)\n",
        wrap_prev.tv_sec, wrap_prev.tv_usec, wrap_next.tv_sec, wrap_next.tv_usec,
        (wrap_prev.tv_sec-wrap_next.tv_sec), (wrap_prev.tv_usec-wrap_next.tv_usec));

exitFormatOverwrite:
    /* print hash lookup statistics */
    DFP("Stats: hook lookup %6d check %7d (%.1f)\n",
        nHookLookup, nHookCheck, (double)nHookCheck/(double)nHookLookup);
    DFP("        i2n lookup %6d check %7d (%.1f) fail %d\n",
        nI2NLookup, nI2NCheck, (double)nI2NCheck/(double)nI2NLookup, nI2NFail);

    if (genStats)
    {
      char fmtWork[4096];
      int fmtLen;
      int ctr;
      qsort(hookHashP, HOOK_HASH_TABLE_SIZE-1, sizeof(fmtDesc_t *),
            hookhashComparator);

      fprintf(statFileP, "Trace statistics:\n\n");

      for (ctr = 0; ctr < HOOK_HASH_TABLE_SIZE-1; ctr++)
      {
        if (hookHashP[ctr] != NULL)
        {
          if (hookHashP[ctr]->numHits > 0)
          {
            strcpy(fmtWork, hookHashP[ctr]->fmtP);
            fmtLen = strlen(fmtWork);
            if (fmtWork[fmtLen-1] = '\n')
              fmtWork[fmtLen-1] = '\0';

            fprintf(statFileP, "hook 0x%X format \"%s\"\n"
                             "  %lld uses, %lld total bytes, %.1f avg bytes, %d max bytes\n"
                             "  %.2f%% of uncompressed trcfile, %.2f%% of total traces\n",
                    hookHashP[ctr]->hookid,
                    fmtWork,

                    hookHashP[ctr]->numHits,
                    hookHashP[ctr]->totalSpace,
                    (double)hookHashP[ctr]->totalSpace / hookHashP[ctr]->numHits,
                    hookHashP[ctr]->largestEntry,

                    ((double)hookHashP[ctr]->totalSpace / totalTrcfileProcessedSize) * 100.0,
                    ((double)hookHashP[ctr]->numHits / nRecordsProcessed) * 100.0);
          }
        }
      }
      fprintf(statFileP, "\nUncompressed trcfile space: %lld bytes\n"
                       "Compressed trcfile space: %lld bytes\n"
                       "Total traces seen: %lld\n",
              totalTrcfileProcessedSize, totalCompSize, nRecordsProcessed);
      int elapsed = stopTime - startTime;
      if (elapsed == 0)
      {
        fprintf(statFileP, "Elapsed time is less than 1 second. Assume it's 1 second for calculations\n");
        elapsed = 1;
      }
      fprintf(statFileP, "Traces cover %d seconds. Trace throughput was %.1f traces/second\n",
              elapsed, (double)nRecordsProcessed/elapsed);
      fprintf(statFileP, "Uncompressed data: %.1f KB/sec, compressed data: %.1f KB/sec\n",
              (double)totalTrcfileProcessedSize/elapsed/1000,
              (double)totalCompSize/elapsed/1000);
      fprintf(statFileP, "\nNota Bene:\n");
      fprintf(statFileP, "  Uses ==> total number of times this hookid was seen\n");
      fprintf(statFileP, "  Total space ==> total space in the trcfile used by all traces with this hookid\n");
      fprintf(statFileP, "  Average ==> total space / uses\n");

      if (writeMode == LXTRACE_OVERWRITE)
        DumpOverwriteFormatStats(statFileP);
    }

    /* cleanup */
    if (formatFilePtr != NULL)
      fclose(formatFilePtr);
    if (formatFileP != NULL)
    {
      free(formatFileP);
      formatFileP = NULL;
    }
    if (fmtDescSpaceP != NULL)
    {
      int ctr;
      struct fmtDesc_t *nextDescP;
      nextDescP = (fmtDesc_t *)fmtDescSpaceP;
      for (ctr = 0; ctr < nRecords;  ++ctr)
      {
         if (nextDescP->i2nSpecP != NULL)
           free(nextDescP->i2nSpecP);
         ++nextDescP;
      }
      free(fmtDescSpaceP);
      fmtDescSpaceP = NULL;
    }
    for (i=0; i<nCPU; i++)
      if (rawFileP[i] != NULL)
        fclose(rawFileP[i]);
    if (outFileP != NULL)
    {
      fflush(outFileP);
      fclose(outFileP);
    }
  } /* "format" option */


  /* lxtrace dump: display the state information associated with the
     device. */
  else if (strcmp(argv[1], "dump") == 0)
  {
    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("lxtrace dump: device open failed errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

#if defined(GPFS_LINUX)
    if (RelayDump() < 0)
    {
      DP("lxtrace dump: failed to dump trace relay state\n");
      rc = EINVAL;
      goto exit;
    }
#endif

exit_dump:
    if (TraceDeviceFD >= 0)
      close(TraceDeviceFD);
  }


  /* lxtrace fsync: flush any data that is currently buffered in the
     device. */
  else if (strcmp(argv[1], "fsync") == 0)
  {
    TraceDeviceFD = open(TRC_DEVICE, O_RDONLY);
    if (TraceDeviceFD < 0)
    {
      DP("lxtrace fsync: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    if (0 != (rc = fsync(TraceDeviceFD)))
    {
      DP("lxtrace fsync: device fsync returns rc %d errno %d\n", rc, errno);
    }

exit_fsync:
    if (TraceDeviceFD >= 0)
      close(TraceDeviceFD);
  }


  /* lxtrace query: return current trace mode.  Parameters after argv[1]
     are ingnored and can be used for debugging. */
  else if (strcmp(argv[1], "query") == 0)
  {
    int kTraceMode;
    int rc;
    char* strP;

    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("Could not open %s\n", TRC_DEVICE);
      rc = ENODEV;
      goto exit_query;
    }

    kTraceMode = -1;
    args.arg1 = (long)&kTraceMode;
    rc = ioctl(TraceDeviceFD, TrQueryKernelTraceMode, &args);
    if (rc != 0)
    {
      DP("TrQueryKernelTraceMode ioctl failed, rc %d\n", rc);
      exit(1);
    }
    else
      DFP("TrQueryKernelTraceMode ioctl succeeds\n");

    switch (kTraceMode)
    {
      case TRACE_NONE:               strP = "none";              break;
      case TRACE_OVERWRITE_QUIESCED: strP = "overwriteQuiesced"; break;
      case TRACE_OVERWRITE_FROZEN:   strP = "overwriteFrozen";   break;
      case TRACE_OVERWRITE:          strP = "overwrite";         break;
      case TRACE_BLOCKING:           strP = "blocking";          break;
      case TRACE_BLOCKING_QUIESCED:  strP = "blockingQuiesced";  break;
      default:                       strP = "unknown";           break;
    }
    fprintf(stdout, "%s\n", strP);
#ifdef LOG_LXTRACE
    fprintf(LogFileP, "  returns '%s'\n", strP);
#endif
    rc = 0;

exit_query:
    if (TraceDeviceFD >= 0)
      close(TraceDeviceFD);
  }

  /* lxtrace start*: provide same effect as "tsctl start*", as
     tsctl command doesn't work for mmsdrserv daemon. */
  else if (strcmp(argv[1], "startBlockingTrace") == 0)
  {
    rc = 0;
    /* Don't need special handling for block mode for now */
    DFP("trace startBlockingTrace ops\n");
  }
  else if (strcmp(argv[1], "startOverwriteTrace") == 0)
  {
    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace startOverwriteTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }
    rc = ioctl(TraceDeviceFD, TrAckDaemonOverwriteTracing, NULL);
    if (rc != 0)
      DP("TrAckDaemonOverwriteTracing ioctl failed, rc %d\n", rc);
    close(TraceDeviceFD);
  }

  /* lxtrace quiesce*: provide same effect as "tsctl quiesce*", as
     tsctl command doesn't work for mmsdrserv daemon. */
  else if (strcmp(argv[1], "quiesceOverwriteTrace") == 0)
  {
    int oldTraceMode;

    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace quiesceOverwriteTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    args.arg1 = (long)&oldTraceMode;
    rc = ioctl(TraceDeviceFD, TrQueryKernelTraceMode, &args);
    if (rc != 0)
    {
      DP("TrQueryKernelTraceMode ioctl failed, rc %d\n", rc);
      close(TraceDeviceFD);
      goto exit;
    }
    if (oldTraceMode == TRACE_OVERWRITE)
    {
      DP("Suspend tracing in overwrite mode\n");
      args.arg1 = (long)TRACE_OVERWRITE_QUIESCED;
      rc = ioctl(TraceDeviceFD, TrSetKernelTraceMode, &args);
      if (rc != 0)
        DP("TrSetKernelTraceMode ioctl failed, rc %d\n", rc);
    }
    else
    {
      DP("Cannot quiesceOverwriteTrace; trace mode is %d\n",
                 oldTraceMode);
      rc = EINVAL;
    }
    close(TraceDeviceFD);
  }
  else if (strcmp(argv[1], "quiesceBlockingTrace") == 0)
  {
    int oldTraceMode;

    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace quiesceBlockingTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    args.arg1 = (long)&oldTraceMode;
    rc = ioctl(TraceDeviceFD, TrQueryKernelTraceMode, &args);
    if (rc != 0)
    {
      DP("TrQueryKernelTraceMode ioctl failed, rc %d\n", rc);
      close(TraceDeviceFD);
      goto exit;
    }
    if (oldTraceMode == TRACE_BLOCKING)
    {
      DP("Suspend tracing in blocking mode\n");
      args.arg1 = (long)TRACE_BLOCKING_QUIESCED;
      rc = ioctl(TraceDeviceFD, TrSetKernelTraceMode, &args);
      if (rc != 0)
        DP("TrSetKernelTraceMode ioctl failed, rc %d\n", rc);
    }
    else
    {
      DP("Cannot quiesceBlockingTrace; trace mode is %d\n",
                 oldTraceMode);
      rc = EINVAL;
    }
    close(TraceDeviceFD);
  }

  /* lxtrace resume*: provide same effect as "tsctl resume*", as
     tsctl command doesn't work for mmsdrserv daemon. */
  else if (strcmp(argv[1], "resumeOverwriteTrace") == 0)
  {
    int oldTraceMode;

    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace resumeOverwriteTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    args.arg1 = (long)&oldTraceMode;
    rc = ioctl(TraceDeviceFD, TrQueryKernelTraceMode, &args);
    if (rc != 0)
    {
      DP("TrQueryKernelTraceMode ioctl failed, rc %d\n", rc);
      close(TraceDeviceFD);
      goto exit;
    }
    if (oldTraceMode == TRACE_OVERWRITE_QUIESCED)
    {
      DP("Rsume tracing in overwrite mode\n");
      args.arg1 = (long)TRACE_OVERWRITE;
      rc = ioctl(TraceDeviceFD, TrSetKernelTraceMode, &args);
      if (rc != 0)
        DP("TrSetKernelTraceMode ioctl failed, rc %d\n", rc);
      else
      {
         rc = ioctl(TraceDeviceFD, TrAckDaemonOverwriteTracing, NULL);
         if (rc != 0)
           DP("TrAckDaemonOverwriteTracing ioctl failed, rc %d\n", rc);
      }
    }
    /* RecycleOverwrite would set the kernel trace mode back to
       TRACE_OVERWRITE. */
    else if (oldTraceMode == TRACE_OVERWRITE)
    {
      rc = ioctl(TraceDeviceFD, TrAckDaemonOverwriteTracing, NULL);
      if (rc != 0)
        DP("TrAckDaemonOverwriteTracing ioctl failed, rc %d\n", rc);
    }
    else
    {
      DP("Cannot resumeOverwriteTrace; trace mode is %d\n",
                 oldTraceMode);
      rc = EINVAL;
    }
    close(TraceDeviceFD);
  }
  else if (strcmp(argv[1], "resumeBlockingTrace") == 0)
  {
    int oldTraceMode;

    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace resumeBlockingTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    args.arg1 = (long)&oldTraceMode;
    rc = ioctl(TraceDeviceFD, TrQueryKernelTraceMode, &args);
    if (rc != 0)
    {
      DP("TrQueryKernelTraceMode ioctl failed, rc %d\n", rc);
      close(TraceDeviceFD);
      goto exit;
    }
    if (oldTraceMode == TRACE_BLOCKING_QUIESCED)
    {
      DP("Resume tracing in blocking mode\n");
      args.arg1 = (long)TRACE_BLOCKING;
      rc = ioctl(TraceDeviceFD, TrSetKernelTraceMode, &args);
      if (rc != 0)
        DP("TrSetKernelTraceMode ioctl failed, rc %d\n", rc);
    }
    else
    {
      DP("Cannot resumeBlockingTrace; trace mode is %d\n",
                 oldTraceMode);
      rc = EINVAL;
    }
    close(TraceDeviceFD);
  }

  /* lxtrace cleanup*: provide same effect as "tsctl cleanup*", as tsctl
     command doesn't work for mmsdrser daemon */
  else if (strcmp(argv[1], "cleanupOverwriteTrace") == 0)
  {
    DP("Tracing disabled\n");
    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace cleanupOverwriteTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    rc = ioctl(TraceDeviceFD, TrDeallocateSharedBuffer, &args);
    if (rc != 0)
      DP("TrSetKernelTraceMode ioctl failed, rc %d\n", rc);
    close(TraceDeviceFD);
  }
  else if (strcmp(argv[1], "cleanupBlockingTrace") == 0)
  {
    DP("Tracing disabled\n");
    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("trace cleanupOverwriteTrace: device open failed with errno %d\n", errno);
      rc = ENODEV;
      goto exit;
    }

    args.arg1 = (long)TRACE_NONE;
    rc = ioctl(TraceDeviceFD, TrSetKernelTraceMode, &args);
    if (rc != 0)
      DP("TrSetKernelTraceMode ioctl failed, rc %d\n", rc);
    close(TraceDeviceFD);
  }

  /* lxtrace recycle -or- lxtrace off: turn off trace and optionally
     restart it after creating an output file */
  else if (strcmp(argv[1], "recycle") == 0 ||
           strcmp(argv[1], "off") == 0)
  {
    int kTraceMode;
    key_t key;
    int msgQueue = -1;
    int retry = 0;
    TraceDaemonMsg_t msg;
    struct stat statBuf;
    time_t mtime;
    char *outFileP = NULL;

    /* Open trace device */
    TraceDeviceFD = open(TRC_DEVICE, O_RDWR);
    if (TraceDeviceFD < 0)
    {
      DP("Could not open %s\n", TRC_DEVICE);
      rc = ENODEV;
      goto exit_recycle;
    }

    /* Fetch current trace mode */
    kTraceMode = -1;
    args.arg1 = (long)&kTraceMode;
    rc = ioctl(TraceDeviceFD, TrQueryKernelTraceMode, &args);
    if (rc != 0)
    {
      DP("TrQueryKernelTraceMode ioctl failed, rc %d\n", rc);
      exit(1);
    }
    else
      DFP("TrQueryKernelTraceMode ioctl succeeds\n");
    switch (kTraceMode)
    {
      default:
      case TRACE_NONE:
        DP("Tracing is already off\n");
        exit(1);
        break;

      case TRACE_BLOCKING:
      case TRACE_BLOCKING_QUIESCED:
        writeMode = LXTRACE_BLK;
        break;

      case TRACE_OVERWRITE:
      case TRACE_OVERWRITE_QUIESCED:
      case TRACE_OVERWRITE_FROZEN:
        writeMode = LXTRACE_OVERWRITE;
        break;
    }

    for (i = 2; i < argc; i++)
    {
      if (outFileP != NULL)
      {
        DP("Output file name already specified\n");
        rc = EINVAL;
        goto exit_recycle;
      }
      else
        outFileP = argv[i];
    }

    if (writeMode == LXTRACE_OVERWRITE)
    {
      char outFileName[PATH_MAX];
      if (outFileP == NULL)
      {
        DP("Overwrite trace mode: output file name must be provided\n");
        goto exit_recycle;
      }
      if (strcmp(argv[1], "recycle") == 0)
        sprintf(outFileName, "%s.recycle.cpu0", outFileP);
      else
        sprintf(outFileName, "%s.cpu0", outFileP);
      rc = RecycleOverwrite(outFileName, strcmp(argv[1], "recycle") == 0,
                            TraceDeviceFD, kTraceMode);
      if (rc != 0)
        goto exit_recycle;
      rc = 0;
    }  /* end of 'if overwrite trace' */

    /* Create a message queue to receive the acknowledgement from the
       lxtrace daemon */
    msgQueue = GetMsgQueue(IPC_CREAT | 0666);
    if (msgQueue == -1)
    {
      DP("lxtrace %s: message queue creation failed with errno %d\n",
         argv[1], errno);
      rc = errno;
      goto exit;
    }
    DFP("lxtrace %s: message queue %d created\n", argv[1], msgQueue);

    /* Call into the trace kernel module to send a signal to the lxtrace
       daemon */
    TraceDeviceFD = open(TRC_DEVICE, O_RDONLY);
    if (TraceDeviceFD < 0)
    {
      rc = ENODEV;
      goto exit_recycle;
    }
    if (strcmp(argv[1], "recycle") == 0 )
    {
      rc = ioctl(TraceDeviceFD, TrRecycleTrace, NULL);
      if (rc != 0)
      {
        DP("lxtrace recycle: device recycle returns rc %d errno %d\n", rc, errno);
        goto exit_recycle;
      }
    }
    else
    {
      /* TrStopTrace terminates tracing. */
      rc = ioctl(TraceDeviceFD, TrStopTrace, NULL);
      if (rc < 0)
      {
        DP("lxtrace off: device end failed with errno %d\n", errno);
        rc = EINVAL;
        goto exit_recycle;
      }
    }

    /* Capture initial timestamp of output file */
    mtime = 0;
    if (outFileP != NULL)
    {
      if (stat(outFileP, &statBuf) == 0)
      {
        mtime = statBuf.st_mtime;
        DFP("lxtrace %s: trace file %s mtime %ld\n",
            argv[1], outFileP, mtime);
      }
    }

    /* Wait for the acknowledgement from the lxtrace daemon process */
    for (;;)
    {
      rc = msgrcv(msgQueue, &msg, 0, LXTRACE_MTYPE, IPC_NOWAIT);
      if (rc == -1)
      {
        rc = errno;

        /* No message, sleep for 1/10th second and retry for up to
           20 seconds, longer if the output file continues to be updated */
        if (rc == ENOMSG)
        {
          if (retry++ >= 200)
          {
            /* If the trace file is still being updated, reset retry count
               and continue to wait */
            if (outFileP != NULL  &&  stat(outFileP, &statBuf) == 0)
            {
              DFP("lxtrace %s: trace file %s mtime %ld\n",
                  argv[1], outFileP, statBuf.st_mtime);
              if (statBuf.st_mtime > mtime)
              {
                mtime = statBuf.st_mtime;
                retry = 0;
                continue;
              }
              else
                DFP("lxtrace %s: trace file %s not updated in last 20 seconds\n",
                    argv[1], outFileP);
            }
            DFP("lxtrace %s: msgrcv timeout error %d\n", argv[1], errno);
            break;
          }
          else
            usleep(100000);
          DFP("lxtrace %s: msgrcv return %d\n", argv[1], rc);
        }
        else
        {
          DP("lxtrace %s: msgrcv error %d\n", argv[1], rc);
          break;
        }
      }

      /* Got the desired message; finished waiting */
      else
      {
        DFP("lxtrace %s: msgrcv succeed\n", argv[1]);
        rc = 0;
        break;
      }
    }

exit_recycle:
    msgctl(msgQueue, IPC_RMID, NULL);
    close(TraceDeviceFD);
  }  /* end of 'lxtrace recycle/off' */

  /* lxtrace <bad option> */
  else
    Usage();
exit:

#ifdef LOG_LXTRACE
  gettimeofday(&now, NULL);
  secs = (time_t) now.tv_sec;
  micros = (time_t) now.tv_usec;
  ctime_r(&secs, ctimeBufP);
  ctimeBufP[19] = '\0';
  fprintf(LogFileP, "  Exit pid %d %s.%06d\n", getpid(), ctimeBufP, micros);
  fclose(LogFileP);
#endif

exitNoLogging:
  return rc;
}

#endif //GPFS_WINDOWS

