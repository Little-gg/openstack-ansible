/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)92       1.155  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiSystem.h, mmfs, avs_rfks1, rfks1s007a_addw 9/11/14 09:06:11 */
/*
 * Interface definitions for basic common services, platform independent
 * version. Interfaces in the first section of this file may be used by code
 * running either in a process or in the kernel, while interfaces defined
 * in the second section of this file may only be used by code running in the
 * kernel.
 *
 * Process and kernel interfaces:
 *   cxiGetThreadId - get thread identifier
 *
 * Kernel-only memory allocation services:
 *   void* cxiMallocPinned(int nBytes)
 *   void* cxiMallocUnpinned(int nBytes)
 *   void cxiFreePinned(void* p)
 *   void cxiFreeUnpinned(void* p)
 *
 * Kernel-only interfaces:
 *   cxiIsSuperUser - return true if caller has maximum authorization
 *   cxiGetMaxFileSize - return the maximum file size the calling process
 *     is allowed to create.  A value of cxiUnlimitedFileSize means file
 *     sizes are not limited.
 *   cxiUiomove - transfer data from buffer(s) in user space to or from
 *     a buffer in the kernel.
 *
 */

#ifndef _h_cxiSystem
#define _h_cxiSystem

#include <cxiTypes.h>

/* Prototypes for OS dependent entry points called by GPFS.
 * If any of these should become macros for certain OSes then
 * this definition will have to move into the platform specific
 * system file.
 */
#ifndef GPFS_WINDOWS
EXTERNC_BEGIN
#endif

IntRC cxiFindOSNode(void *osVfsP, struct cxiNode_t *, void **osNodePP,
                    Boolean);
IntRC cxiNewOSNode(void *osVfsP, struct cxiNode_t **, void **osNodePP,
                   cxiIno_t, int, void *opaqueP);
void cxiRemoveInodeHash(void *osNodeP);
IntRC cxiReactivateOSNode(void *osVfsP, struct cxiNode_t *, void **osNodePP);

int cxiRefOSNode(void *osVfsP, struct cxiNode_t *, void *osNodeP, int);
int cxiRefOSNodeNoWait(struct cxiNode_t *, void *osNodeP);
int cxiInactiveOSNode(void *osVfsP, struct cxiNode_t *, void *osNodeP,
                      Boolean *, Boolean *);
void cxiPrintInode(void *iP);


IntRC cxiRegisterCleanup();

IntRC cxiRegisterCifsCleanup(void **vPP, int *fdP);
void cxiCleanupCifsFile(void *vP, int fd);

IntRC cxiDataSize(void *vfsP, pcacheAttr_t *, UInt64 *, UInt64 *, UInt32 *);
void cxiSetNlink(struct cxiNode_t* cnP, UInt32 nlink);
void cxiPutOSNode(void *vP);
void cxiDestroyOSNode(void *vP);
void cxiDumpOSNode(struct cxiNode_t *, int ino);
void cxiFreeOSNode(void *osVfsP, struct cxiNode_t *, void *osNodeP);
void cxiReinitOSNode(void *osVfsP, struct cxiNode_t *, void *osNodeP);
IntRC cxiPruneDCacheEntry(cxiNode_t *cnP);

IntRC cxiInvalidateDCacheEntry(cxiNode_t *cnP, int flags);
#define CXI_INVALIDATE_DISCONNECTED_ONLY 0x1

void cxiDropInvalidDCacheEntry(cxiNode_t *cnP);
void cxiDropSambaDCacheEntry(cxiNode_t *cnP);
IntRC cxiInvalidateNegDCacheEntry(cxiNode_t *cnP);
void cxiInvalidatePerm(cxiNode_t *cnP);
void cxiUpdateInode(cxiNode_t *cnP, cxiVattr_t *attrP, int what,
                    Boolean doPutOSNode, int flags);
#ifdef GANESHA
IntRC cxiCheckInode(cxiNode_t *cnP, cxiVattr_t *attrP, int what, int flags);
#endif
Boolean cxiSameInode(cxiNode_t *cnP, cxiVattr_t *attrP, int what);

void cxiSetOSNodeType(cxiNode_t *cnP, cxiMode_t mode, cxiDev_t dev);
void cxiSetOSNode(void *osVfsP, cxiNode_t *cnP, cxiVattr_t *vattrP, int flags);

IntRC cxiSetMountInfo(void *osVfsP, cxiDev_t, int bsize, void *osRootNodeP,
                      struct cxiNode_t *cnRootP, Boolean *releRootP,
                      void *gnRootP, fsid_t fsid);
IntRC cxiUnmount(void *osVfsP, Boolean force, Boolean doDMEvents);
IntRC cxiIsVfsMounted(void *osVfsP);

IntRC cxiFcntlLock(void *fP, int cmd, void *flP,
                   cxiFlock_t *flockP, int (*retryCB)(),
                   cxiOff64_t size, cxiOff64_t offset,
                   UIntPtr *retry_idP);
IntRC cxiFcntlReset(void *vfsP, cxiPid_t mmfsd_pid);
void cxiFcntlUnblock(void *retry_idP);
IntRC cxiTrace(cxiTrace_t trace);
void cxiFlockToVFS(eflock_t* lckdatP, void* vP);
void cxiVFSToFlock(void *vP, eflock_t* lckdatP);
IntRC cxiVFSCallback(eflock_t* lckreqP, eflock_t* lckdatP,
                     int(* callback)(void *, void *, int), int result);

void cxiOpenNFS(void *vP);
IntRC cxiCloseNFS(void *vP, void *viP, void *kopP);
void cxiSetNFSCluster(int set);
IntRC cxiGetNFSCluster();
cxiIno_t cxiGetInodeNum(void *fP);
cxiIno_t cxiGetInodeNumber(void *vP);
void cxiSetPNFSmds(int set);
Boolean cxisPNFSon();
int cxiNFSError(int rc, struct gpfsVfsData_t *pvp, int error, const char *str);
#define cxiErrorNFS(rc, pvp, error) cxiNFSError(rc, pvp, error, __FUNCTION__)

void *cxiGetNfsP(void *vP);
void  cxiSetNfsP(void *vP, void *newP);
void *cxiGetCnP(void *vP);
void *cxiGetPvP(void *vP);
void *cxiGNPtoVP(void *vP);
Boolean cxiIsGpfsVP(void *vP);
void *cxiGetPrivVfsP(void *vP);
void *cxiGetVinfoP(int fd);

#ifdef _KERNEL
cxiPid_t cxiStartKProc(struct cxiKProcData_t *);
void cxiStopKProc(struct cxiKProcData_t *);
#ifdef QOSIO
void cxiUsleep(unsigned long usecs);
#endif /* end of #ifdef QOSIO */
#endif
void cxiSleep(int ms);
void cxiUnInerruptibleSleep(int ms);

#ifdef SMB_LOCKS
void *cxiCheckOpen(struct cxiNode_t* cnP);
IntRC setSMBOpenLockControl(void *kopP, void *vP, void *infoP, int command, int lockmode);
IntRC setSMBOplock(void *vP, void *infoP, int accessWant, int oplockWant,
                   void *breakArgP, int *oplockGrantedP, Boolean isAsync);
IntRC breakSMBOplock(cxiDev_t dev, cxiIno_t ino, int oplockCurrent, int oplockNew,
                   void *breakArgP, void *fileArgP, void *nfs4_cookie,
                   int timeoutSeconds);
IntRC cxiInitBreakQ();
IntRC cxiTermBreakQ();
IntRC cxiBreakOplock(void *breakArgP, int oplockNew);
IntRC cxiWaitForBreak(void *fileArgP, int oplockCurrent, int timeoutSeconds);
IntRC cxiSendBreakMsg(void *ofP);
#endif

/* Routines to manipulate locks used to synchronize between an I/O
   interrupt handler and thread-level kernel driver code.  The area
   passed to cxiInitIntLock must be large enough to hold the lock word
   and the area where the interrupt flags words will be stored.  On
   Linux, SPINLOCK_T_SIZE+sizeof(long) is sufficient. */
int cxiInitIntLock(void* lockAreaP, int lockAreaSize);
void cxiTermIntLock(void* lockAreaP);
void cxiDisableLock(void* lockAreaP);
void cxiUnlockEnable(void* lockAreaP);

#ifndef _KERNEL
# ifdef GPFS_WINDOWS
#   define cxiIsSuperUser() (gwin::IsAdminUser())
#   define SUPERUSER_NAME "Administrator"
# else
#   define cxiIsSuperUser() (getuid() == 0)
#   define SUPERUSER_NAME "root"
# endif
#endif

/* Insure that our type definitions match any OS definitions */
IntRC cxiCheckTypes();

#ifdef DISK_LEASE_DMS
#define MAX_DMS_INDEX 32
void cxiStartDMS(int idx, int delay, int (*funcP)(int));
void cxiStopDMS(int idx);
IntRC cxiInitDMS();
void cxiShutdownDMS();
#else
#define MAX_DMS_INDEX 1
#endif

#ifdef GPFS_CACHE
#define PCACHE_LOCALLS_GID  42949670
#define PCACHE_LOCALRM_GID  42949671
#define PCACHE_TSPCACHE_GID 42949672
#define PCACHE_LOCALSTAT_GID 42949673
#define PCACHE_LISTDIRTY_GID 42949674
#define PCACHE_NATIVE_GID   42949675
#endif

#ifndef GPFS_WINDOWS
EXTERNC_END
#endif

/* values for lookup intent */
#define GPFS_LOOKUP_NONE    (0x0000)
#define GPFS_LOOKUP_OPEN    (0x0001)
#define GPFS_LOOKUP_CREATE  (0x0002)
#define GPFS_LOOKUP_DPARENT (0x0004)

/* Values for 'what' parameter to cxiUpdateInode and statUpdateOSNode:
   Selectively updated the OS node attributes. */
#define CXIUP_NLINK    0x00000001   /* update nlink */
#define CXIUP_MODE     0x00000002   /* update mode and ctime */
#define CXIUP_OWN      0x00000004   /* update mode,uid,gid and ctime */
#define CXIUP_SIZE     0x00000008   /* update fsize */
#define CXIUP_SIZE_BIG 0x00000010   /* update fsize if bigger */
#define CXIUP_TIMES    0x00000020   /* update all times */
#define CXIUP_ATIME    0x00000040   /* update atime only, other flags are not
                                         checked */
#define CXIUP_PERM     0x00000080   /* update fields needed for permission
                                         checking */
#define CXIUP_RENAME   0x00000100   /* this is a rename op */
#define CXI_CLEAR_DESTROY_FLAG   0x00000200   /* clear destroyIfDelInode flag */
#define CXIUP_GANESHA  0x00000400   /* this is a ganesha op */
#define CXIUP_SYNC     0x00000800   /* this is the sync thread op */

#define cxiDev32Major(x) (Int32)((unsigned)(x)>>16)
#define cxiDev32Minor(x) (Int32)((x)&0xFFFF)

/* Maximum number of simultaneous threads (must be a power of 2)
   and less than PTHREAD_THREADS_MAX */
#ifdef __64BIT__
#define MAX_GPFS_THREADS 16384
#define MAX_RCVWORKER_POOL 256
#else
#define MAX_GPFS_THREADS 512
#define MAX_RCVWORKER_POOL 128
#endif

#ifndef GPFS_WINDOWS
#define cxiLocalMode(x) (x)
#else
/* Give user and group the same permissions on Windows */
inline cxiMode_t cxiLocalMode(cxiMode_t mode)
{
  return (mode & ~0070) | ((mode & 0700) >> 3);
}
#endif

/* Return number of CPUs */
extern int cxiGetNCPUs();

/* Include platform-specific versions of interfaces to common exported
   services */
#include <cxiSystem-plat.h>

#define MAX_READDIR_BUF_SIZE 65536

#ifdef NFS4_ACL
/* Kernel routine to be called for NFSv4 audit ACL entries */
EXTERNC IntRC cxiAuditWrite(int numargs, ...);

/* Kernel routine to be called for NFSv4 alarm ACL entries */
static __inline IntRC cxiAlarmWrite(int numargs, ...) { return -1; }

/* Values for gpfsOpen internal flags (iflags) argument  */
#define GPFS_OPEN_NO_SMBLOCK 0x00000001 /* Don't obtain OpenLk */
#define GPFS_OPEN_VCM_OBJECT 0x00000002 /* No SMB locking      */
#endif /* NFS4_ACL */
#define GPFS_INTERNAL_CALL   0x00000008 /* Called by GPFS thread */

#ifdef CLONE_FILE
/* Operation types for gpfsCloneFile */
typedef enum
{
  coSnap,       /* Create an immutable clone parent from a source file */
  coCopy,       /* Create a clone copy of an immutable clone parent file */
} CloneOp;

/* Operation types for gpfsDeclone */
typedef enum
{
  dcCopy,       /* Remove CDITTOs by copying data from clone parent */
  dcSplit,      /* Split child file from clone parent */
  dcUnsnap      /* Change childless clone parent back to a normal file */
} DecloneOp;
#endif

/* WaitForDebugger suspends the current thread until a debugger attaches to the
   process. When printWaitingMessage is true, the routine first prints a
   message stating the process is waiting for a debugger.

   WaitForDebuggerIfFlagged is the same as WaitForDebugger, but is conditioned
   on the existence of a file in the root directory specified by the name
   parameter plus the extension ".dbgwait" (e.g. /mmfsd.dbgwait when name=mmfsd).

   Currently, these routines are only implemented on Windows. */
#ifdef GPFS_WINDOWS
void WaitForDebugger(bool printWaitingMessage);
void WaitForDebuggerIfFlagged(const char* name, bool printWaitingMessage);
#else
#define WaitForDebugger(printWaitingMessage) NOOP
#define WaitForDebuggerIfFlagged(name, printWaitingMessage) NOOP
#endif

#endif  /* _h_cxiSystem */
