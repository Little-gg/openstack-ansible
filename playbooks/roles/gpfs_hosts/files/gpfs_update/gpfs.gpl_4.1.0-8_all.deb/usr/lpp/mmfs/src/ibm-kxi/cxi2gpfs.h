/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)67       1.224.1.1  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxi2gpfs.h, mmfs, avs_rfks1, rfks1s007a_addw 12/9/14 14:57:46 */
/*
 * Interface definitions for gpfs kernel services, platform independent version
 *
 * Contents:
 *   vfs services:
 */

#ifndef _h_cxi2gpfs
#define _h_cxi2gpfs

#ifdef _KERNEL

/* Describes the entry points into the OS independent portion of
 * GPFS from the dependent virtual file system layer.
 */
struct gpfsVfsData_t;
struct ext_cred_t;
struct MMFSVInfo;
struct cxiUio_t;
struct cxiIOBufferAttachment_t;
#ifdef SMB_LOCKS
struct SMBTokenDescription;
#endif
struct KernelOperation;
struct KernelOperationMMap;
struct fileHandleCommon_t;

/* GPFS OS independent entry point prototypes */
#ifdef GPFS_SOLARIS
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#endif /* GPFS_SOLARIS */
IntRC gpfsFsync(struct gpfsVfsData_t *, struct MMFSVInfo *, cxiNode_t *, int, struct ext_cred_t *);
IntRC gpfsSyncNFS(struct gpfsVfsData_t *, cxiNode_t *, int, struct ext_cred_t *);
IntRC gpfsMkdir(struct gpfsVfsData_t *, struct KernelOperation *kopP, cxiNode_t *cnDirP,
                void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                void *dentryP, caddr_t nameP, Boolean caseSensitive,
                cxiMode_t mode, cxiMode_t umask, struct ext_cred_t *);
IntRC gpfsLink(struct gpfsVfsData_t *, cxiNode_t *, cxiNode_t *,
               void *, char *, Boolean, Boolean, struct ext_cred_t *);
IntRC gpfsOpen(struct gpfsVfsData_t *, cxiNode_t *, void *, int, int, int,
               struct MMFSVInfo **, struct ext_cred_t *, 
	       struct KernelOperation *);
IntRC gpfsInodeRead(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                    cxiIno_t ino, void *opaque);
IntRC gpfsInodeDelete(struct gpfsVfsData_t *, cxiNode_t *, Boolean isGPFS);
int gpfsInodeFindActor(cxiNode_t *, cxiIno_t, void *);
int gpfsEncodeFileHandle(cxiNode_t *, cxiNode_t *, int *,
                         unsigned int, unsigned int *);
int gpfsGetHashValue(struct gpfsVfsData_t *, caddr_t nameP);
IntRC gpfsRemove(struct gpfsVfsData_t *, cxiNode_t *, cxiNode_t *,
                 char *, Boolean, struct MMFSVInfo *, struct ext_cred_t *);
IntRC gpfsRename(struct gpfsVfsData_t *, cxiNode_t *, cxiNode_t *,
                 caddr_t, cxiNode_t *, cxiNode_t *, caddr_t,
                 Boolean, Boolean, struct ext_cred_t *);
IntRC gpfsRmdir(struct gpfsVfsData_t *, cxiNode_t *, cxiNode_t *,
                char *, Boolean, struct ext_cred_t *);
IntRC gpfsSetattr(struct gpfsVfsData_t *, struct KernelOperation *, cxiNode_t *,
                  IntPtr, IntPtr, IntPtr, IntPtr, struct ext_cred_t *);
IntRC gpfsSymlink(struct gpfsVfsData_t *, struct KernelOperation *,
                  cxiNode_t *dcnP, void **vPP, cxiNode_t **cnPP,
                  cxiIno_t *iNumP, void *dentryP, caddr_t nameP,
                  Boolean caseSensitive, char *symlinkTargetP,
                  struct ext_cred_t *);
IntRC gpfsFsyncRange(struct gpfsVfsData_t *, cxiNode_t *, int, offset_t,
                     offset_t, struct ext_cred_t *);
IntRC gpfsClose(struct gpfsVfsData_t *, cxiNode_t *, int,
                struct MMFSVInfo *, Boolean dmEvents,
                struct KernelOperation *);
IntRC gpfsUnmap(struct gpfsVfsData_t *, cxiNode_t *, int);
IntRC gpfsFattr(struct gpfsVfsData_t *, cxiNode_t *, struct MMFSVInfo *,
                int, int, void *, void *, struct ext_cred_t *);
IntRC gpfsFsAttr(int, void *);
IntRC gpfsFclear(struct gpfsVfsData_t *, cxiNode_t *,
                 int, offset_t, offset_t, struct MMFSVInfo *, struct ext_cred_t *);
IntRC gpfsFalloc(struct gpfsVfsData_t *, cxiNode_t *,
                 int, offset_t, offset_t, int, struct MMFSVInfo *, struct ext_cred_t *);
IntRC gpfsFtrunc(struct gpfsVfsData_t *, cxiNode_t *, int, offset_t,
                 struct MMFSVInfo *, struct ext_cred_t *, Boolean dmEvents);
IntRC gpfsRead(struct gpfsVfsData_t *, struct KernelOperation *, cxiNode_t *, int,
               struct cxiUio_t *, struct MMFSVInfo *, cxiVattr_t *, cxiVattr_t *,
               struct ext_cred_t *, void *, int);
IntRC gpfsWrite(struct gpfsVfsData_t *, struct KernelOperation *, cxiNode_t *, int,
                struct cxiUio_t *, struct MMFSVInfo *, cxiVattr_t *, cxiVattr_t *,
                struct ext_cred_t *, void *, int);
IntRC gpfsGetattr(struct gpfsVfsData_t *, cxiNode_t *, cxiVattr_t *,
                  int flags);
IntRC gpfsAccess(struct gpfsVfsData_t *, cxiNode_t *, int, int,
                 void*, int*, struct ext_cred_t *);
IntRC gpfsReaddir(struct gpfsVfsData_t *, cxiNode_t *, void *, cxiFillDir_t,
         offset_t *, cxiContext_t, struct KernelOperation *kopP, void *dP, int);
IntRC gpfsGetLongName(struct gpfsVfsData_t *, cxiNode_t *, int snOffset,
                      cxiContext_t, char **namePP);
IntRC gpfsGetHashName(struct KernelOperation *, struct gpfsVfsData_t *,
                      cxiNode_t *, char *namePP, int len, cxiNode_t *,
                      UInt32 foldVal, void *);
IntRC gpfsReadlink(struct gpfsVfsData_t *, cxiNode_t *, struct cxiUio_t *,
                   cxiContext_t opcontext, struct KernelOperation *kopP);
IntRC gpfsCreate(struct gpfsVfsData_t *privVfsP, struct KernelOperation *kopP,
                 cxiNode_t *dcnP, void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                 int gen, int flags, void *dentryP, caddr_t nameP,
                 Boolean caseSensitive, cxiMode_t mode, cxiMode_t umask,
                 caddr_t *infoPP, struct ext_cred_t *, Boolean *fileExistP);
IntRC gpfsMknod(struct gpfsVfsData_t *privVfsP, struct KernelOperation *kopP,
                cxiNode_t *cnDirP, void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                void *dentryP, caddr_t nameP, Boolean caseSensitive,
                cxiMode_t mode, cxiMode_t umask,
                cxiDev_t dev, struct ext_cred_t *credP);
IntRC gpfsRele(struct gpfsVfsData_t *, cxiNode_t *, void *);
IntRC gpfsLookup(struct gpfsVfsData_t *, void *dvP, cxiNode_t *cnDirP,
                 void *dentryP, void *ndP, char *nameP, UInt32 flags,
                 void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP, cxiVattr_t *,
                 cxiMode_t *, struct ext_cred_t *, Boolean caseSensitive,
                 void **dentryPP, int *snOffsetP, char *rFNameP, int *rFNameLenP);
IntRC gpfsMount(void *, int, char *, char *, char *, struct gpfsVfsData_t **,
                cxiNode_t **, cxiIno_t *iNumP, struct gpfsVfsData_t *, pid_t,
                unsigned int mountId, Boolean, Boolean);
IntRC gpfsStatfs(struct gpfsVfsData_t *, cxiStatfs_t *, cxiNode_t *, 
		 struct KernelOperation *);

typedef enum
{
  GPFS_SYNC_LEGACY,
  GPFS_SYNC_INCOMPLETE,
  GPFS_SYNC_COMPLETE
} gpfsSyncType_t;
IntRC gpfsSyncfs(struct gpfsVfsData_t *, gpfsSyncType_t syncMode);
void gpfsQueueBufs(cxibuf_t *bufP);
void gpfsMmapFlushLock(cxiNode_t *cnP);
void gpfsMmapFlushUnlock(cxiNode_t *cnP);

IntRC gpfsUncache(struct gpfsVfsData_t *privVfsP);

IntRC gpfsCleanupCifs();
Boolean gpfsIsCifs();
Boolean gpfsIsCifsBypassTraversalChecking();

#ifdef GPFS_CACHE
IntRC gpfsUnmountPcache(struct gpfsVfsData_t *privVfsP, Boolean forced);
IntRC gpfsEncodePcacheFH(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, cxiFH_t *fhP);
IntRC gpfsDecodePcacheFH(struct gpfsVfsData_t *privVfsP, cxiFH_t *fhP, void **vPP);
#endif
IntRC gpfsUnmount(struct gpfsVfsData_t *privVfsP, Boolean forced);
void gpfsFinishUnmount(struct gpfsVfsData_t *privVfsP);
IntRC gpfsFcntl(void *vkopP,
                struct gpfsVfsData_t *privVfsP,
                void *vP,               // struct vnode* or NULL
                void *advObjP,          // struct gnode* or struct file*
                void *flP,              // NULL or struct file_lock*
                cxiNode_t *cnP,
                offset_t offset,
                eflock_t *lckdatP,
                int cmd,                // F_SETLK, F_SETLKW, F_GETLK
                int(*retry_fcn)(),
                UIntPtr *retry_idP,
                struct ext_cred_t *credP,
                struct MMFSVInfo *vinfoP);
IntRC gpfsFcntlReset(void *advObjP, cxiPid_t mmfsd);

IntRC gpfsGetAcl(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, int flags,
                 void *aclP, struct ext_cred_t *credP);
IntRC gpfsPutAcl(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, int flags,
                 void *aclP, struct ext_cred_t *credP);

IntRC gpfsQuotactl(struct gpfsVfsData_t *privVfsP, int cmd, int qid, 
                   void *bufferP, struct ext_cred_t *credP, cxiNode_t *cnP);
#ifdef FILESETMAPPING_API
IntRC gpfsGetFilesetId(struct gpfsVfsData_t *privVfsP, const char *name,
                       int *idP, struct ext_cred_t *credP);
#endif

#ifdef LOCK_TRACING
IntRC gpfsInsertTraceInfo(void *, int, UChar);
#endif

#ifdef GPFS_LINUX
IntRC gpfsLinuxAIOComplete(struct cxiUioAio_t *uioaioP,
                           struct gpfsVfsData_t *privVfsP,
                           cxiNode_t *cnP,
                           struct MMFSVInfo *vinfoP,
                           size_t bytesProcessed,
                           int mbAioErr, Boolean mbAioCallback);
IntRC gpfsAioDaemonCallback(struct cxiUioAio_t *uioaioP,
                           struct gpfsVfsData_t *privVfsP);
IntRC gpfsParseDirEntry(void *fddP, UInt32 *modeP, void *dirBufP);
#endif

IntRC gpfsGetNFS(void *, void *, struct MMFSVInfo **, int *);
IntRC gpfsGetOpenNFS(void *, struct MMFSVInfo **, int *);
IntRC gpfsReleaseNFS(void *);
int gpfsReady();
IntRC gpfsMmap(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, void *vP,
               struct ext_cred_t *credP, Boolean writeAccess,
               Boolean explicit_mmap,long long offset, long long length, void *dP);

#ifdef SMB_LOCKS
IntRC SMBOpenLockControl(void *kopP, int command, int lockmode,
                         int inode_n, struct MMFSVInfo * vinfoP,
                         struct gpfsVfsData_t *privVfsP);
int SMBGetOplockState(void *fileArgP);
int SMBGetOplockStateV(struct MMFSVInfo * vinfoP);
IntRC gpfsSetSMBOplock(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                       struct MMFSVInfo *vinfoP, int accessWant,
                       int oplockWant, void *breakArgP,
                       int *oplockGrantedP, Boolean isAsync);
IntRC gpfsReserveShare(void *vP, void *infoP, 
                       struct gpfsVfsData_t *privVfsP, int flags, int share,
                       cxiNode_t *cnP, struct ext_cred_t *credP,
		       struct KernelOperation *kopP);
IntRC gpfsReserveDelegation(void *vp, void *infoP, 
                            struct gpfsVfsData_t *privVfsP, int oplockWant,
                            int flags, void *cb_token, void *cookie,
			    struct KernelOperation *kopP);
#endif  //SMB_LOCKS
IntRC callDaemonToDie(const char *srcFileName, UInt32 srcLineNumber,
                      Int32 retCode, Int32 reasonCode, const char *dataStr,
                      const char *failingExpr);
IntRC gpfsCleanup();
#ifdef UIDREMAP
int UIDremapOn();
#endif
void gpfsSwapdEnqueue(cxiNode_t *cnP, Boolean xferUseCount);
void gpfsSwapdDequeue(cxiNode_t *cnP);
void gpfsGrace(int on_off);
#ifdef P_NFS4
IntRC gpfsGetOpenState(struct gpfsVfsData_t *privVfsP,
                       struct MMFSVInfo **vinfoP, cxiNode_t *cnP,
                       int nodeId, void *p, int len, struct ext_cred_t *credP);
IntRC gpfsLayoutReturn(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                       void *p, int len);
IntRC gpfsGetDeviceInfo(struct gpfsVfsData_t *privVfsP, void *devidP, void *xdrP);
IntRC gpfsGetLayout(Int64 ino, struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                    void *args,void *res, void *xdr, struct ext_cred_t *credP,
                    int flags);
IntRC gpfsGotIOnodes(struct gpfsVfsData_t *privVfsP);
int gpfsGetMyDevID(struct gpfsVfsData_t *privVfsP);
#endif
void gpfsGetVerifier(struct gpfsVfsData_t *privVfsP, UInt32 *p);
int gpfsGetNodeID(struct gpfsVfsData_t *privVfsP, Boolean *sync);
void gpfsGetFSID(struct gpfsVfsData_t *privVfsP, int *fsid, cxiNode_t *cnP,
                int *fsetid);
IntRC gpfsCheckStatus(struct gpfsVfsData_t *privVfsP);

IntRC gpfsDmUnmountEvent(Boolean preunmount, Boolean force,
                         struct gpfsVfsData_t *privVfsP, cxiNode_t *rootCNP,
                         Boolean *dmDoUnmountEventP, void **sgUidP,
                         void **eventlistP, void **sessLocP, int vnoprc);

#ifdef USER_EXIT_ENTENSIONS
IntRC gpfsGenFsUnmountCallback(Boolean isPreUnmount, Boolean force, struct gpfsVfsData_t *privVfsP, char** sgNameP, Boolean cleanUpOnly); 
#endif  
  
#ifdef GPFS_WINDOWS
IntRC gpfsSetAllocFileSize(gpfsVfsData_t *privVfsP, DiskUID sgUid,
                           FileUID fileId, offset_t fileSize, 
                           offset_t allocSize, struct ext_cred_t *credP);
#endif

#ifdef GPFS_LINUX
ssize_t
rdwrInternal(struct file *fP, cxiRdWr_t op, const struct cxiIovec_t *iovecP,
             unsigned long count, loff_t *offsetP, struct cxiUio_t *uioP,
             int options);

IntRC gpfs_seek_internal(struct file *fP, int origin, offset_t *offset,
                         offset_t *len, offset_t *filesize);

IntRC gpfsNFSIget(struct gpfsVfsData_t *privVfsP, struct cxiIGetArg_t *argP,
                  UInt32 generation, void **vPP);
#endif
IntRC gpfsOpenNFS(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, int flags,
                  struct MMFSVInfo *vinfoP, struct ext_cred_t *credP);

IntRC gpfsSeek(struct gpfsVfsData_t *privVfsP, struct KernelOperation *kopP,
               cxiNode_t *cnP, int flags, struct cxiUio_t* uioP,
               struct  ext_cred_t *credP, int rdwrOpts);

IntRC gpfsSetWinBasicInfo(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, struct MMFSVInfo *vinfoP,
                          cxiWinBasicInfo_t *info, struct ext_cred_t *credP);
IntRC gpfsGetWinBasicInfo(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                          cxiWinBasicInfo_t *info, struct ext_cred_t *credP);
IntRC gpfsWinOps(int op, int flags, void *genArg1,  struct gpfsVfsData_t *privVfsP,
                 cxiNode_t *cnP, cxiWinBasicInfo_t *infoP, struct ext_cred_t *credP);

IntRC gpfsSetTimes(int flags, void *times, 
		   struct gpfsVfsData_t *privVfsP,
		   cxiNode_t *cnP, struct ext_cred_t *credP);

IntRC gpfsSupportSambaLookup();
#define IS_CASE_SENSITIVE() (!cxiIsSambaThread() || !gpfs_ops.gpfsSupportSambaLookup())


IntRC gpfsLookupFileWithFileId(cxiNode_t *cnDirP, const char *fileNameP,
                               Boolean caseSensitive, struct gpfsVfsData_t *vP,
                               struct ext_cred_t *credP, cxiNode_t *cnFileP, 
                               char *actualFileNameP, int *lenP);

IntRC gpfsLookupRealName(cxiNode_t *cnDirP,
                         const char *fileNameP,
                         struct gpfsVfsData_t *privVfsP,
                         struct ext_cred_t *credP,
                         char *realFileNameP,
                         int *lenP);

#ifdef CLONE_FILE
IntRC gpfsCloneFile(struct gpfsVfsData_t *privVfsP, CloneOp clop,
                    cxiNode_t *cnP, cxiNode_t *cnDirP, void *osSpecificInfoP,
                    const char *nameP, Boolean caseSensitive,
                    cxiMode_t umask, ext_cred_t *credP);
IntRC gpfsDeclone(struct gpfsVfsData_t *privVfsP, DecloneOp dcop,
                  cxiNode_t *cnP, int ancLimit, Int64 nBlocks,
                  void *osSpecificInfoP, ext_cred_t *credP, Int64 *offsetP);
#endif

#if defined(GPFS_LINUX) || defined(GPFS_WINDOWS)
IntRC gpfsSetXattr(struct gpfsVfsData_t *, cxiNode_t *,
                   int, void *, struct ext_cred_t *);
IntRC gpfsGetOrListXattr(struct gpfsVfsData_t *, cxiNode_t *,
                         int, void *, struct ext_cred_t *,
                         Boolean nonBlocking);
void gpfsGetTime(struct gpfs_timestruc *time);
#endif

#ifdef GANESHA
IntRC gpfsGaneshaUpdate(struct gpfsVfsData_t *privVfsP, int *fh, int *len,
                    cxiVattr_t *vattrP, struct glock *glockP, int *reason,
                    UInt32 *addrP, UInt32 *devIDseqNo, UInt32 *expire_attr,
                    Int32 tid, UInt32 *poolId);
IntRC gpfsGaneshaLock(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                     struct glock *flockP, void *flP, int reason);
IntRC gpfsGaneshaRecall(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                        int reason, void *vP);
IntRC gpfsGaneshaThread(struct gpfsVfsData_t *privVfsP, int *reason, void *sgP,
                        int poolId);
IntRC gpfsGaneshaNotify(struct gpfsVfsData_t *privVfsP, int *reason, void *sgP);
IntRC gpfsGaneshaGrace(struct gpfsVfsData_t *privVfsP, int grace_sec);
IntRC gpfsRevalidateInterval(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                            int *retval);
#endif


#ifdef LIGHT_WEIGHT_EVENT
IntRC gpfslweCreateSession(lwe_sessid_t   oldsid,        /* IN */
                            char          *sessinfop,     /* IN */
                            lwe_sessid_t  *newsidp        /* OUT */
                            );

IntRC gpfslweDestroySession(lwe_sessid_t sid);         /* IN */

IntRC gpfslweGetAllSessions(unsigned int   nelem,      /* IN */
                             lwe_sessid_t  *sidbufp,    /* OUT */
		             unsigned int  *nelemp);    /* OUT */


IntRC gpfslweQuerySession(lwe_sessid_t   sid,     /* IN */
                           size_t         buflen,  /* IN */
		           void          *bufp,    /* OUT */
		           size_t        *rlenP);  /* OUT */

IntRC gpfslweGetEvents(lwe_sessid_t  sid,     /* IN  */
                       unsigned int  maxmsgs, /* IN  */
                       unsigned int  flags,   /* IN  */
	               size_t        buflen,  /* IN  */
		       void         *bufp,    /* OUT */
		       size_t       *rlenp);  /* OUT */

IntRC gpfslweRespondEvent(lwe_sessid_t   sid,       /* IN */
                          lwe_token_t    token,     /* IN */
	    	          lwe_resp_t     response,  /* IN */
		          int            reterror); /* IN */
#endif /* LIGHT_WEIGHT_EVENT */

IntRC gpfsGetMemMap(int vindex, struct cxiMemoryMapping_t **memMapP);

#ifdef GPFS_SOLARIS
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* GPFS_SOLARIS */

struct gpfs_operations
{
  IntRC (*mmfs)(int cmd);
  IntRC (*gpfsMount)(void *, int, char *, char *, char *, struct gpfsVfsData_t **,
                     cxiNode_t **, cxiIno_t *iNumP, struct gpfsVfsData_t *, pid_t,
                     unsigned int, Boolean, Boolean);
  IntRC (*gpfsStatfs)(struct gpfsVfsData_t *, cxiStatfs_t *, cxiNode_t *,
		      struct KernelOperation *);
  IntRC (*gpfsSyncfs)(struct gpfsVfsData_t *, gpfsSyncType_t);
  void (*gpfsQueueBufs)(cxibuf_t *bufP);
  void (*gpfsMmapFlushLock)(cxiNode_t *cnP);
  void (*gpfsMmapFlushUnlock)(cxiNode_t *cnP);
  IntRC (*gpfsFsync)(struct gpfsVfsData_t *, struct MMFSVInfo *, cxiNode_t *, int,
                     struct ext_cred_t *credP);
  IntRC (*gpfsSyncNFS)(struct gpfsVfsData_t *, cxiNode_t *, int,
                       struct ext_cred_t *credP);
  IntRC (*gpfsMkdir)(struct gpfsVfsData_t *privVfsP, struct KernelOperation *kopP,
                     cxiNode_t *cnDirP, void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                     void *dentryP, char *dirNameP, Boolean caseSensitive,
                     cxiMode_t mode, cxiMode_t umask, struct ext_cred_t *credP);
  IntRC (*gpfsLink)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                    cxiNode_t *dcnP, void *dentryP, char *name,
                    Boolean caseSensitive, Boolean isRelink, struct ext_cred_t *credP);
  IntRC (*gpfsOpen)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, void *fileP,
                    int flags, int iflags, int ext, struct MMFSVInfo **infoPP,
                    struct ext_cred_t *credP, struct KernelOperation *kopP);
  IntRC (*gpfsInodeRead)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                         cxiIno_t ino, void *opaque);
  IntRC (*gpfsInodeDelete)(struct gpfsVfsData_t *, cxiNode_t *, Boolean isGPFS);
  int (*gpfsInodeFindActor)(cxiNode_t *, cxiIno_t, void *);
  int (*gpfsEncodeFileHandle)(cxiNode_t *, cxiNode_t *, int *, unsigned int, 
                              unsigned int *);
  int (*gpfsGetHashValue)(struct gpfsVfsData_t *, caddr_t nameP);
  IntRC (*gpfsRemove)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                      cxiNode_t *dcnP, char *nameP, Boolean, 
		              struct MMFSVInfo *vinfoP, struct ext_cred_t *credP);
  IntRC (*gpfsRename)(struct gpfsVfsData_t *privVfsP, cxiNode_t *sourceCNP,
                      cxiNode_t *sourceDirCNP, caddr_t oldNameP,
                      cxiNode_t *targetCNP, cxiNode_t *targetDirCNP,
                      caddr_t newNameP, Boolean caseSensitive,
                      Boolean replaceIfExists, struct ext_cred_t *credP);
  IntRC (*gpfsRmdir)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                     cxiNode_t *dcnP, char *nameP, Boolean caseSensitive, struct ext_cred_t *credP);
  IntRC (*gpfsSetattr)(struct gpfsVfsData_t *privVfsP, struct KernelOperation *,
                       cxiNode_t *cnP, IntPtr cmd, IntPtr arg1, IntPtr arg2, IntPtr arg3,
                       struct ext_cred_t *credP);
  IntRC (*gpfsSymlink)(struct gpfsVfsData_t *privVfsP,
                       struct KernelOperation *kopP,
                       cxiNode_t *dcnP, void **vPP, cxiNode_t **cnPP,
                       cxiIno_t *iNumP, void *dentryP, caddr_t nameP,
                       Boolean caseSensitive, char *symlinkTargetP,
                       struct ext_cred_t *credP);
  IntRC (*gpfsFsyncRange)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                          int flags, offset_t offset, offset_t length,
                          struct ext_cred_t *credP);
  IntRC (*gpfsClose)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                     int flags, struct MMFSVInfo *vinfoP,
                     Boolean dmEvents, struct KernelOperation *kernOpP);
  IntRC (*gpfsUnmap)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                     int flag);
  IntRC (*gpfsFattr)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                     struct MMFSVInfo *vinfoP, int rwflag, int command,
                     void *argP, void *rCodeP, struct ext_cred_t *credP);
  IntRC (*gpfsFsAttr)(int command, void *argP);
  IntRC (*gpfsFclear)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                      int flags, offset_t offset, offset_t len,
                      struct MMFSVInfo *vinfoP, struct ext_cred_t *credP);
  IntRC (*gpfsFalloc)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                      int flags, offset_t offset, offset_t len, int allocFlags,
                      struct MMFSVInfo *vinfoP, struct ext_cred_t *credP);
  IntRC (*gpfsFtrunc)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                      int flags, offset_t offset, struct MMFSVInfo *vinfoP,
                      struct ext_cred_t *credP, Boolean dmEvents);
  IntRC (*gpfsRead)(struct gpfsVfsData_t *privVfsP, struct KernelOperation *,
                    cxiNode_t *cnP, int flags, struct cxiUio_t* uioP, 
                    struct MMFSVInfo *vinfoP, cxiVattr_t *vpreP, 
                    cxiVattr_t *vattrP, struct ext_cred_t *credP, void *plP, 
                    int);
  IntRC (*gpfsWrite)(struct gpfsVfsData_t *privVfsP, struct KernelOperation *,
                     cxiNode_t *cnP, int flags, struct cxiUio_t* uioP, 
                     struct MMFSVInfo *vinfoP, cxiVattr_t *vpreP, 
                     cxiVattr_t *vattrP, struct ext_cred_t *credP, void *plP,
                     int);
  IntRC (*gpfsGetattr)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                       cxiVattr_t *vattrP, int flags);
  IntRC (*gpfsAccess)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                      int mode, int who, void* v4maskP, int* grantedPermsP,
                      struct ext_cred_t *credP);
  IntRC (*gpfsReaddir)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                       void *fillDirArgP, cxiFillDir_t fillDirP,
                       offset_t *offsetP, cxiContext_t opcontext,
                       struct KernelOperation *kopP, void *dP, int);
  IntRC (*gpfsGetHashName)(struct KernelOperation *, struct gpfsVfsData_t *,
                           cxiNode_t *, char *nameP, int len, cxiNode_t *,
                           UInt32 foldVal, void *);
  IntRC (*gpfsReadlink)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                        struct cxiUio_t* uioP, cxiContext_t opcontext,
			struct KernelOperation *kopP);
  IntRC (*gpfsCreate)(struct gpfsVfsData_t *privVfsP, struct KernelOperation *kopP,
                      cxiNode_t *dcnP, void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                      int gen, int flags, void *dentryP, caddr_t nameP,
                      Boolean caseSensitive, cxiMode_t mode, cxiMode_t umask,
                      caddr_t *infoPP, struct ext_cred_t *credP, Boolean *fileExistP);
  IntRC (*gpfsMknod)(struct gpfsVfsData_t *privVfsP, struct KernelOperation *kopP,
                     cxiNode_t *cnDirP, void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                     void *dentryP, caddr_t nameP, Boolean caseSensitive,
                     cxiMode_t mode, cxiMode_t umask,
                     cxiDev_t dev, struct ext_cred_t *credP);
  IntRC (*gpfsRele)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, void *vP);
  IntRC (*gpfsLookup)(struct gpfsVfsData_t *privVfsP, void *dvP, cxiNode_t *dcnP,
                      void *dentryP, void *ndP, char *nameP, UInt32 flags,
                      void **vPP, cxiNode_t **cnPP, cxiIno_t *iNumP,
                      cxiVattr_t *vattrP, cxiMode_t *modeP,
                      struct ext_cred_t *credP, Boolean caseSensitive,
                      void **dentryPP, int *snOffsetP, char *rFNameP, int *rFNameLenP);
  IntRC (*gpfsFcntl)(void *vkopP,
                     struct gpfsVfsData_t *privVfsP,
                     void *vP,                  // struct vnode* or NULL
                     void *advObjP,             // struct gnode* or struct file*
                     void *flP,                 // NULL or struct file_lock*
                     cxiNode_t *cnP,
                     offset_t offset,
                     eflock_t *lckdatP,
                     int cmd,                   // F_SETLK, F_SETLKW, F_GETLK
                     int(*retry_fcn)(),
                     UIntPtr *retry_idP,
                     struct ext_cred_t *credP,
                     struct MMFSVInfo *vinfoP);
  IntRC (*gpfsFcntlReset)(void *advObjP, cxiPid_t mmfsd);
  IntRC (*gpfsUncache)(struct gpfsVfsData_t *privVfsP);
  IntRC (*gpfsCleanupCifs)();
  Boolean (*gpfsIsCifs)();
  Boolean (*gpfsIsCifsBypassTraversalChecking)();

#ifdef GPFS_CACHE
  IntRC (*gpfsUnmountPcache)(struct gpfsVfsData_t *privVfsP, Boolean forced);
  IntRC (*gpfsEncodePcacheFH)(struct gpfsVfsData_t *, cxiNode_t *, cxiFH_t *);
  IntRC (*gpfsDecodePcacheFH)(struct gpfsVfsData_t *, cxiFH_t *, void **);
#endif
  IntRC (*gpfsUnmount)(struct gpfsVfsData_t *privVfsP, Boolean forced);
  void (*gpfsFinishUnmount)(struct gpfsVfsData_t *privVfsP);

  IntRC (*gpfsGetAcl)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, int flags,
                      void *aclP, struct ext_cred_t *credP);
  IntRC (*gpfsPutAcl)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, int flags,
                      void *aclP, struct ext_cred_t *credP);
  
  IntRC (*gpfsGetNFS)(void *vP, void *osInfoP, struct MMFSVInfo **vinfoPP, int *flagsP);
  IntRC (*gpfsGetOpenNFS)(void *vP, struct MMFSVInfo **vinfoPP, int *flagsP);
  IntRC (*gpfsReleaseNFS)(void *vP);
  int (*gpfsReady)();
  IntRC (*gpfsMmap)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, void * vP,
                    struct ext_cred_t *credP, Boolean writeAccess,
                    Boolean explicit_mmap,long long offset,long long length, void *dP);
#ifdef SMB_LOCKS
  IntRC (*SMBOpenLockControl)(void *kopP, int command, int lockmode,
                              int inode_n, struct MMFSVInfo * vinfoP,
                              struct gpfsVfsData_t *privVfsP);
  int (*SMBGetOplockState)(void *fileArgP);
  int (*SMBGetOplockStateV)(struct MMFSVInfo * vinfoP);
  IntRC (*gpfsSetSMBOplock)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                            struct MMFSVInfo *vinfoP, int accessWant,
                            int oplockWant, void *breakArgP,
                            int *oplockGrantedP, Boolean isAsync);
  IntRC (*gpfsReserveShare)(void *, void *, struct gpfsVfsData_t *, int, int,
                            cxiNode_t *cnP, struct ext_cred_t *credP,
			    struct KernelOperation *kopP);
  IntRC (*gpfsReserveDelegation)(void *vp, void *infoP, 
                                 struct gpfsVfsData_t *privVfsP, int oplockWant,
                                 int, void *cb_token, void *cookie,
				 struct KernelOperation *kopP);
#endif
  IntRC (*gpfsDaemonToDie)(const char *srcFileName, UInt32 srcLineNumber,
                           Int32 retCode, Int32 reasonCode, const char *dataStr,
                           const char *failingExpr);
  IntRC (*gpfsCleanup)();
#ifdef UIDREMAP
  int (*UIDremapOn)();
#endif
  void (*gpfsSwapdEnqueue)(cxiNode_t *cnP, Boolean xferUseCount);
  IntRC (*gpfsDmUnmountEvent)(Boolean preunmount, Boolean force,
                              struct gpfsVfsData_t *privVfsP, cxiNode_t *rootCNP,
                              Boolean *dmDoUnmountEventP, void **sgUidPP, 
                              void **eventlistPP, void **sessLocPP, int vnoprc);
#ifdef GPFS_LINUX
  IntRC (*gpfsNFSIget)(struct gpfsVfsData_t *privVfsP, struct cxiIGetArg_t *argP,
                       UInt32 generation, void **vPP);
  IntRC (*gpfsParseDirEntry)(void *fddP, UInt32 *modeP, void *dirBufP);
#endif
  IntRC (*gpfsOpenNFS)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                       int flags, struct MMFSVInfo *vinfoP, struct ext_cred_t *credP);
  IntRC (*gpfsSeek)(struct gpfsVfsData_t *privVfsP,
                    struct KernelOperation *kopP, cxiNode_t *cnP, int flags,
                    struct cxiUio_t* uioP, struct  ext_cred_t *credP,
                    int rdwrOpts);
  void (*gpfsGrace)(int on_off);
#ifdef P_NFS4
  IntRC (*gpfsGetOpenState)(struct gpfsVfsData_t *privVfsP,
                         struct MMFSVInfo **vinfoP, cxiNode_t *cnP,
                         int nodeId, void *p, int len, struct ext_cred_t *credP);
  IntRC (*gpfsLayoutReturn)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                            void *p, int len);
  IntRC (*gpfsGetDeviceInfo)(struct gpfsVfsData_t *privVfsP, void *devidP,
                             void *xdrP);
  IntRC (*gpfsGetLayout)(Int64 ino, struct gpfsVfsData_t *privVfsP,
                         cxiNode_t *cnP, void *args, void *res, void *xdr,
                         struct ext_cred_t *credP, int flags);
  IntRC (*gpfsGotIOnodes)(struct gpfsVfsData_t *privVfsP);
  IntRC (*gpfsGetDeviceList)(struct gpfsVfsData_t *privVfsP, void *buf);
  int (*gpfsGetMyDevID)(struct gpfsVfsData_t *privVfsP);
#endif
  void (*gpfsGetVerifier)(struct gpfsVfsData_t *privVfsP, UInt32 *p);
  int (*gpfsGetNodeID)(struct gpfsVfsData_t *privVfsP, Boolean *sync);
  void (*gpfsGetFSID)(struct gpfsVfsData_t *privVfsP, int *fsid, cxiNode_t *cnP,
                     int *fsetid);
  IntRC (*gpfsCheckStatus)(struct gpfsVfsData_t *privVfsP);
  IntRC (*gpfsQuotactl)(struct gpfsVfsData_t *privVfsP,
                        int cmd, int qid, void *bufferP, 
                        struct ext_cred_t *credP, cxiNode_t *cnP);
#ifdef FILESETMAPPING_API
  IntRC (*gpfsGetFilesetId)(struct gpfsVfsData_t *privVfsP,
                            const char *name, int *idP,
                            struct ext_cred_t *credP);
#endif
#ifdef LOCK_TRACING
  IntRC (*gpfsInsertTraceInfo)(void *, int, UChar);
#endif
  IntRC (*gpfsLookupFileWithFileId) (cxiNode_t *cnDirP, const char *fileNameP,
                                     Boolean caseSensitive, 
                                     struct gpfsVfsData_t *vfsdataP,
                                     struct ext_cred_t *credP,
                                     cxiNode_t *cnFileP, char *actualFileNameP,
                                     int *lenP);
  IntRC (*gpfsLookupRealName) (cxiNode_t *cnDirP,
                               const char *fileNameP,
                               struct gpfsVfsData_t *privVfsP,
                               struct ext_cred_t *credP,
                               char *realFileNameP,
                               int *lenP);
#ifdef GPFS_LINUX
  IntRC (*gpfsLinuxAIOComplete)(struct cxiUioAio_t *uioaioP,
                                struct gpfsVfsData_t *privVfsP,
                                cxiNode_t *cnP,
                                struct MMFSVInfo *vinfoP,
                                size_t bytesProcessed,
                                int mbAioErr, Boolean mbAioCallback);
  IntRC (*gpfsAioDaemonCallback)(struct cxiUioAio_t *uioaioP,
                                struct gpfsVfsData_t *privVfsP);
#endif
  IntRC (*gpfsSupportSambaLookup)();
  IntRC (*gpfsGetWinBasicInfo)(struct gpfsVfsData_t *privVfsP,
                               cxiNode_t *cnP,
                               cxiWinBasicInfo_t *infoP,
                               struct ext_cred_t *credP);
  IntRC (*gpfsSetWinBasicInfo)(struct gpfsVfsData_t *privVfsP,
                               cxiNode_t *cnP,
                               struct MMFSVInfo *vinfoP,
                               cxiWinBasicInfo_t *infoP,
                               struct ext_cred_t *credP);
  IntRC (*gpfsWinOps)(int op, int flags, void *genArg1,  struct gpfsVfsData_t *privVfsP,
                      cxiNode_t *cnP, cxiWinBasicInfo_t *infoP, struct ext_cred_t *credP);
#ifdef USER_EXIT_ENTENSIONS
  IntRC (*gpfsGenFsUnmountCallback)(Boolean isPreUnmount, Boolean force, struct gpfsVfsData_t *privVfsP, char** sgNameP, Boolean cleanUpOnly); 
#endif    
#ifdef CLONE_FILE
  IntRC (*gpfsCloneFile)(struct gpfsVfsData_t *privVfsP, CloneOp clop,
                         cxiNode_t *cnP, cxiNode_t *cnDirP,
                         void *osSpecificInfoP, const char *nameP,
                         Boolean caseSensitive, cxiMode_t umask,
                         ext_cred_t *credP);
  IntRC (*gpfsDeclone)(struct gpfsVfsData_t *privVfsP, DecloneOp dcop,
                       cxiNode_t *cnP, int ancLimit, Int64 nBlocks,
                       void *osSpecificInfoP, ext_cred_t *credP,
                       Int64 *offsetP);
#endif
IntRC (*gpfsSetTimes)(int flags, void *times, 
		      struct gpfsVfsData_t *privVfsP,
		      cxiNode_t *cnP, struct ext_cred_t *credP);

#ifdef GPFS_LINUX

  IntRC (*gpfsSetXattr)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, 
                        int op_flag, void *argP, struct ext_cred_t *credP);
  IntRC (*gpfsGetOrListXattr)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP, 
                              int command, void *argP,
                              struct ext_cred_t *credP,
                              Boolean nonBlocking);
  void (*gpfsGetTime)(struct gpfs_timestruc *time);

#ifdef GANESHA
  IntRC (*gpfsGaneshaUpdate)(struct gpfsVfsData_t *privVfsP, int *fh, int *len,
                        cxiVattr_t *vattrP, struct glock *glockP, int *reason,
                        UInt32 *addrP, UInt32 *devIDseqNo, UInt32 *expire_attr,
                        Int32 tid, UInt32 *poolId);
  IntRC (*gpfsGaneshaLock)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                          struct glock *flockP, void *flP, int reason);
  IntRC (*gpfsGaneshaRecall)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                             int reason, void *vP);
  IntRC (*gpfsGaneshaThread)(struct gpfsVfsData_t *privVfsP, int *reason,
                             void *sgP, int poolId);
  IntRC (*gpfsGaneshaNotify)(struct gpfsVfsData_t *privVfsP, int *reason,
                             void *sgP);
  IntRC (*gpfsGaneshaGrace)(struct gpfsVfsData_t *privVfsP, int grace_sec);
  IntRC (*gpfsRevalidateInterval)(struct gpfsVfsData_t *privVfsP, cxiNode_t *cnP,
                                 int *retval);
#endif

#ifdef LIGHT_WEIGHT_EVENT
  IntRC (*gpfslweCreateSession)(lwe_sessid_t   oldsid,
                                char          *sessinfop, 
                                lwe_sessid_t  *newsidp);
  IntRC (*gpfslweDestroySession)(lwe_sessid_t sid);
  IntRC (*gpfslweGetAllSessions)(unsigned int   nelem,
                                 lwe_sessid_t  *sidbufp,
 		                 unsigned int  *nelemp);
  IntRC (*gpfslweQuerySession)(lwe_sessid_t   sid,
                               size_t         buflen,
  		               void          *bufp, 
		               size_t        *rlenP);
  IntRC (*gpfslweGetEvents)(lwe_sessid_t sid, 
                            unsigned int maxmsgs, 
			    unsigned int flags,
                            size_t buflen, 
			    void* bufp, 
			    size_t *rlenp);
  IntRC (*gpfslweRespondEvent)(lwe_sessid_t sid, 
                               lwe_token_t token,
                               lwe_resp_t response, 
			       int reterror);
#endif /* LIGHT_WEIGHT_EVENT */

#endif /* GPFS_LINUX */

  IntRC (*gpfsGetMemMap)(int vindex, struct cxiMemoryMapping_t **memMapP);
};
extern struct gpfs_operations gpfs_ops;

#endif  /* _KERNEL */

#endif  /* _h_cxi2gpfs */

