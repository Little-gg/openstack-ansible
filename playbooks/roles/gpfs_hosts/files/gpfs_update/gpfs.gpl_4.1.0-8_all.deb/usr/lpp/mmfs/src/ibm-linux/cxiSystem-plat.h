/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)65       1.237.1.2  src/avs/fs/mmfs/ts/kernext/ibm-linux/cxiSystem-plat.h, mmfs, avs_rfks1, rfks1s007a_addw 12/9/14 14:57:50 */
/*
 * Interface definitions for basic common services, Linux version
 *
 * Contents:
 *   cxiGetThreadId - get thread identifier
 *   cxiUiomove - transfer data between kernel buffer and user buffer(s)
 *   cxiCopyIn - copy data from user to kernel buffer (kernel service)
 *   cxiCopyOut - copy data from kernel to user buffer (kernel service)
 *   cxiCopyInstr - copy string from user to kernel space (kernel service)
 *
 */

#ifndef _h_cxiSystem_plat
#define _h_cxiSystem_plat

#ifndef _h_cxiSystem
#error Platform header (XXX-plat.h) should not be included directly
#endif

/* Size of stack to allocate for GPFS threads */
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
#define GPFS_STACK_SIZE (512*1024UL)
#define PAGE_SIZE_MAX (65536)
#endif /* GPFS_ARCH_POWER */
#ifdef GPFS_ARCH_X86_64
#define GPFS_STACK_SIZE (512*1024UL)
#define PAGE_SIZE_MAX (4096)
#endif /* GPFS_ARCH_POWER */
#ifdef GPFS_ARCH_S390X
#define GPFS_STACK_SIZE (512*1024UL)
#define PAGE_SIZE_MAX (4096)
#endif /* GPFS_ARCH_S390X */

/* -------------------------------------------------------------- */
/* Interfaces usable from both kernel code and process-level code */
/* -------------------------------------------------------------- */

/* Main module device name */
#define GPFS_DEVNAME "/dev/ss0"

/* mmfslinux kernel module gets PAGE_SIZE from kernel headers
   mmfs kernel module gets PAGE_SIZE from mmfslinux (PageSizeKernel)
   mmfsd gets page size from the posix sysconf() API (PageSizeDaemon) */

#ifdef _KERNEL
#ifndef GPFS_GPL
extern unsigned long PageSizeKernel;
#define PAGE_SIZE (PageSizeKernel)
#endif
#else
extern unsigned long PageSizeDaemon;
#define PAGE_SIZE (PageSizeDaemon)
#endif /* _KERNEL */

#ifdef GPFS_ARCH_S390X
/* If a user space program is build as position independent executable (PIE),
 * it will be loaded above 2TB addresses.  The user space stack starts at 4TB
 * and grows downwards followed by memory mappings and heap.
 * To distinguish addresses between user space and kernel space, an artificial
 * constant, USERSPACE_MMAP_BOUNDARY, is introduced.  Addresses above the
 * USERSPACE_MMAP_BOUNDARY are considered to be kernel addresses.
 *
 * NOTE: Any changes to USERSPACE_MMAP_BOUNDARY, IS_KERNEL_ADDR(), or
 *	 IS_USER_ADDR() must be also reflected in
 *	 ts/tasking/s390x/[dk]SynchFast.S.
 */
#define USERSPACE_MMAP_BOUNDARY	(1UL << 44)
#define IS_KERNEL_ADDR(P) ((unsigned long)(P) > USERSPACE_MMAP_BOUNDARY)
#define IS_USER_ADDR(P) (!IS_KERNEL_ADDR(P))
#endif	/* GPFS_ARCH_S390X */

/* Process operations */
#if !defined(GPFS_GPL)
EXTERNC pid_t getpid() __THROW;
EXTERNC uid_t getuid() __THROW;
EXTERNC uid_t geteuid() __THROW;
#else
/* use of THROW causes conflicts in portability kernel code */
EXTERNC uid_t getuid();
EXTERNC uid_t geteuid();
EXTERNC pid_t getpid();
#endif /* !GPFS_GPL */

/* Get the kernel thread ID, which is guaranteed to be non-zero.  In a
 * process, this just calls getpid.  Within the kernel, this calls a routine
 * that extracts the process ID from the current process block.
 */

#ifdef _KERNEL

EXTERNC cxiThreadId cxiGetThreadId();
#ifdef QOSIO
#  define cxiGetQosId() cxiGetQosIdd(QOSID_A_PROCESS)
EXTERNC unsigned int cxiGetQosIdd(unsigned int dfltid);
#endif
EXTERNC pid_t cxiGetProcessId();
EXTERNC void cxiSetGaneshaPid(int pid);
EXTERNC pid_t cxiGetGaneshaPid();
EXTERNC void cxiInitBlockGanesha();

EXTERNC UIntPtr cxiGetKernelStackSize();

EXTERNC int cxiInitVFS(int vfsType);
#define cxiTermVFS()

#else   /* not _KERNEL */

#include <unistd.h>

EXTERNC cxiThreadId kxGetThreadID();
EXTERNC int kxGetTimeOfDay(cxiTimeStruc_t *tP);
/* sys_gettid is defined in kernel, but sys call not implemented in glibc,
   so use our own ioctl with kxGetThreadID */
#define cxiGetTid() (kxGetThreadID())

/* cxiGetThreadId returns kernel thread id */
extern pthread_key_t pid_key;
#define cxiGetThreadId() ((cxiThreadId)(PTR_TO_INT32(pthread_getspecific(pid_key))))
#endif  /* _KERNEL */

#ifdef _KERNEL
/* Convert a kernel stack address to the thread ID of the thread that uses
   that stack */
EXTERNC int cxiStackAddrToThreadId(char* stackP, cxiThreadId* tidP);
/* Convert a kernel thread pointer to the corresponding thread ID */
EXTERNC int cxiThreadPtrToThreadId(char* threadP, cxiThreadId* tidP);
#endif  /* _KERNEL */

#ifdef _KERNEL
/* Transfer data from buffer(s) in user space to or from a buffer in the
 *  kernel.
 */
EXTERNC int cxiUiomove(char* kBufP, size_t nBytes, Boolean toKernel,
                       struct cxiUio_t* uioP);

EXTERNC void * cxiGetFcntlOwner(eflock_t *flP);
#define cxiSetEflockOwner(eflockP, flP) (eflockP->l_owner = cxiGetFcntlOwner(flP))
#define FL_OFFSET_MAX (loff_t)(~0ULL>>1)
#endif  /* _KERNEL */


/* System priority operations */

/* Define priority constants inherited from AIX;  priority can only be
 * relatively adjusted in Linux and not set directly.
 * AIX setpri priority numbers 0-99 (as recorded in the mmfs.cfg file)
 * will be decremented by 60 (PUSER+20) to get to the setpriority range
 * of -20 to 20. Linux setpriority will then bound anything outside that
 * range to the edges of the range.
 */
#define PRI_SCHED    16
#define PUSER        40

#define cxiSetPri(pid, newpri) (setpriority(PRIO_PGRP, (int)pid, \
                                            (int)newpri-(PUSER+20)))
#define cxiGetPri(pid) ((PUSER+20) + getpriority(PRIO_PGRP, (int)pid))

/* Threads are actually a cloned process with separate signal masks */
#define cxiSigThreadMask(a,b,c)  sigprocmask((a),(b),(c));

#ifndef _KERNEL
/* Assertion functions */
#include <assert.h>
#define cxiAssertFailed(STRING,FILE,LINE) \
          __assert_fail((STRING),(FILE),(LINE),__ASSERT_FUNCTION)
#endif

void dump_trace_back(const char *failingExpr, const char *srcFileName,
                     int srcLineNumber);

#ifdef INSTRUMENT_LOCKS
/* Statistics kept per lock class: number of lock acquisitions and the
   number of times the lock appeared to be held before it was requested */
struct BlockingMutexStats
{
  UInt64 bmsAcquires;                   /* number of times lock obtained */
  UInt64 bmsConflicts;                  /* number of lock conflicts */
};

#define MAX_GPFS_LOCK_NAMES 48

#ifdef _KERNEL
EXTERNC struct BlockingMutexStats BlockingMutexStatsTable[MAX_GPFS_LOCK_NAMES];
EXTERNC void InitBlockingMutexStats();
#endif
#endif  /* INSTRUMENT_LOCKS */



#ifdef _KERNEL
/* String functions for the kernel */
static inline size_t cxiStrlen(const char *str1)
{
  const char *beg1;

  if (str1 == NULL)
    return 0;

  for (beg1 = str1; *str1; str1++);

  return str1 - beg1;
}

static inline char *cxiStrcpy(char *str1, const char *str2)
{
  char *beg1 = str1;

  while ((*str1++ = *str2++));

  return beg1;
}

static inline char *cxiStrcat(char *str1, const char *str2)
{
  char *beg1;

  for (beg1 = str1; *str1; str1++);

  while ((*str1++ = *str2++));

  return beg1;
}

static inline int cxiStrcmp(const char *str1, const char *str2)
{
  /* This cannot have an ENTER macro because it is used to implement ENTER
     processing */
  for (; *str1 == *str2; str1++, str2++)
    if (*str1 == '\0')
      return 0;

  return *str1 - *str2;
}

static inline int cxiStrncmp(const char *str1, const char *str2, size_t num)
{
  for ( ; num > 0; str1++, str2++, num--)
  {
    if (*str1 != *str2) return *str1 - *str2;
    else if (*str1 == '\0') return 0;
  }
  return 0;
}

static inline char *cxiStrncpy(char *str1, const char *str2, size_t num)
{
  char *beg1 = str1;

  while (num)
  {
    num--;
    if ((*str1++ = *str2++) == '\0')
      break;
  }

  /* strncpy is defined to null out the total length */
  while (num)
  {
    num--;
    *str1++ = '\0';
  }

  return beg1;
}

static inline char *cxiStrncat(char *str1, const char *str2, size_t num)
{
  char *beg1;

  for (beg1 = str1; *str1; str1++);

  while (num-- && (*str1 = *str2++))
   str1++;

  *str1 = '\0';

  return beg1;
}

static inline char *cxiStrrchr(const char *str1, int ch)
{
  char *ret = NULL;

  do
  {
    if (*str1 == (char)ch)
      ret = (char *)str1;
  }
  while (*str1++);

  return ret;
}

static inline char *cxiStrchr(const char *str1, int ch)
{
  char *ret = NULL;

  do
  {
    if (*str1 == (char)ch)
    {
      ret = (char *)str1;
      break;
    }
  }
  while (*str1++);

  return ret;
}

static inline int cxiMemcmp(const void *v1, const void *v2, size_t num)
{
  char *str1 = (char *)v1;
  char *str2 = (char *)v2;

  for (; num && (*str1 == *str2); str1++, str2++, num--);

  if (num)
    return *str1 - *str2;
  else
    return 0;
}

static inline void *cxiMemcpy(void *v1, const void *v2, size_t num)
{
  char *str1 = (char *)v1;
  char *str2 = (char *)v2;

  while (num--)
    *str1++ = *str2++;

  return v1;
}

static inline void *cxiMemset(void *v1, int c, size_t num)
{
  char *str1 = (char *)v1;

  while (num--)
    *str1++ = c;

  return v1;
}
#endif  /* _KERNEL */

/* Local file system list */
#define FILESYSTEM_FILE "/etc/fstab"
#define VI_FILE         "/bin/vi"
#define ROOT_GROUP      "root"
#define ROOT_USER       "root"

/* AIX inherited constants from device.h */
#define CFG_INIT 0x1
#define CFG_TERM 0x2

#ifdef _KERNEL
/* AIX inherited constants from sleep.h */
/* flags for e_thread_sleep */
#define INTERRUPTIBLE           (1)     /* sleep is interruptible */
#define LOCK_HANDLER            (2)     /* lock used by interrupt handlers */
//#define LOCK_READ             (4)     /* complex lock read mode specified */
#define LOCK_SIMPLE             (8)     /* simple lock specified */
//#define LOCK_WRITE            (16)    /* complex lock write mode specified */
/* return values from e_thread_block */
#define THREAD_AWAKENED         (1)     /* normal wakeup value */
#define THREAD_TIMED_OUT        (2)     /* sleep timed out */
#define THREAD_INTERRUPTED      (4)     /* sleep interrupted by signal */
#define THREAD_OTHER            (4096)  /* Beginning of subsystem values */
#endif /* _KERNEL */


/* --------------------------------------- */
/* Interfaces usable only from kernel code */
/* --------------------------------------- */

#ifdef _KERNEL

/* Macros to convert Linux kernel version to a decimal integer that can
   be compared to the symbol LINUX_KERNEL_VERSION.
   See the description of LINUX_KERNEL_VERSION in site.mcr.proto. */
#define GPFS_KERNEL_VERSION(_major,_minor,_sub,_mod) \
   ( (_major)*1000000 + (_minor)*10000 + (_sub)*100 + (_mod))

/*
 * Kernel memory allocation services:
 *
 * These are implemented as subroutines in gpl-linux/kxiSystem.C.  All
 * allocations use storage class GFP_KERNEL.  There is no distinction
 * between pinned and unpinned kernel memory in Linux, so the unpinned
 * interfaces are defined in terms of the pinned interfaces as macros.
 */
EXTERNC void* cxiMallocPinned(int nBytes);
#define cxiMallocUnpinned(nBytes)  cxiMallocPinned(nBytes)
EXTERNC void cxiFreePinned(void* p);
#define cxiFreeUnpinned(p)         cxiFreePinned(p)

EXTERNC void *cxiBigMalloc(int size);
EXTERNC void cxiBigFree(char *ptr);


/* cxiIsSuperUser - return true if caller has maximum authorization (is root) */
EXTERNC Boolean cxiIsSuperUser();

#ifdef LOCK_TRACING
/* cxiGetCPUId - return the CPU ID on which the current thread is running */
EXTERNC Int32 cxiGetCPUId();
EXTERNC Int32 cxiLockTracingStart();
EXTERNC Int32 cxiLockTracingStop();
EXTERNC Int32 cxiIsLockTacingSafe();
#endif

/* cxiGetMaxFileSize - return the maximum file size the calling process
 * is allowed to create.
 */
EXTERNC Int64 cxiGetMaxFileSize();

/* NFS services for Linux */
/* nfsd calls open and release for every file read/write.  Provide a way
   to detect that nfsd is the caller and avoid the extra overhead. */
EXTERNC Boolean cxiIsNFSThread();

/* nfsd4 opens should not block waiting for conflicting oplocks to be 
 * broken.  They can accept EAGAIN and translate to NFS4ERR_DELAY as
 * it does if it initiates a delegation recall.
 */
EXTERNC Boolean cxiIsNFS4Thread();

EXTERNC Boolean cxiIsGPFSThread();

EXTERNC Boolean cxiIsTSPcacheThread();

EXTERNC Boolean cxiIsCriticalThread();

EXTERNC Boolean cxiIsLockdThread();

EXTERNC Boolean cxiIsGpfsSwapdThread();

EXTERNC Boolean cxiIsGaneshaThread();

EXTERNC Int32 cxiFcntlCancel(void *flP);

EXTERNC Int32 cxiLockFile(void *flP);

/* See if a cxiFlock_t belongs to NFS (lockd) */
#define cxiGetLockCaller(lockP) ((lockP)->l_caller)
#define cxiIsNFSLock(lockP)     ((lockP)->l_caller == L_CALLER_LOCKD)

/* kupdate services for Linux */
/* Use to identify syncs from kupdate that are generated way
   too often by Linux (every 5 seconds). */
EXTERNC Boolean cxiIsKupdateThread();

#ifdef SMB_LOCKS
/* Samba services for Linux */
/* smbd calls open and subsequently makes calls to set open deny modes and
   op locks.  Provide a way to distinguish these Samba calls from calls
   from other users for which default actions on open and op locks must
   be taken */
EXTERNC Boolean cxiIsSambaOrLockdThread();

/* Samba services for Linux */
/* Provide a way to distinguish Samba calls from calls
   from other users */
EXTERNC Boolean cxiIsSambaThread();

/* Control sync at various metadata updates required by Samba */
#define cxiAllowSambaFsync() (cxiIsSambaThread() && Shared.syncSambaMetadataOps)

#endif

#ifdef GPFS_CACHE
EXTERNC Boolean cxiIsPcacheLsThread();
EXTERNC Boolean cxiIsPcacheStatThread();
EXTERNC Boolean cxiIsPcacheRmThread();
EXTERNC Boolean cxiIsPcacheListdirtyThread();
EXTERNC Boolean cxiIsPcacheNativeThread();
#endif

/* The nfsd threads are allowed to FSYNC their writes. */
#define cxiAllowNFSFsync() (cxiIsNFSThread() || cxiIsGaneshaThread())

/* OS dependent VFS calls */
#define cxiDisconnectVfs(PVP)   /* nothing ??? */

EXTERNC void cxiDeleteMmap(cxiVmid_t);  /* delete memory map */

/* Set OS dependent virtual node type and device */
EXTERNC void cxiSetOSNodeType(struct cxiNode_t *cnP, cxiMode_t mode,
                              cxiDev_t rdev);
#define cxiOSNodeTypeIs(CNP,VTYPE) (((CNP)->nType) == (VTYPE))

EXTERNC Boolean cxiCanUncacheOSNode(void *osVfsP, struct cxiNode_t *cnP, void **vPP);

#ifdef __cplusplus
EXTERNC void *cxiAddOSNode(void *dentryP, void *vP, DentryOpTableTypes dopTabType, int lookup = 0);
#endif

/* Kernel operations to copy data between user and kernel space */
EXTERNC int cxiCopyIn(const char *from, char *to, size_t size);
EXTERNC int cxiCopyOut(const char *from, char *to, size_t size);
EXTERNC int cxiCopyInstr(const char *from, char *to, size_t size,
                         size_t *len);

EXTERNC long cxiSafeGetLong(long* from);
EXTERNC void cxiSafePutLong(long val, long* to);
EXTERNC int cxiSafeGetInt(int* from);
EXTERNC void cxiSafePutInt(int val, int* to);
#if 0
/* Needed if we want to access 64 bit values from 32 bit architectures
   and share the values between kernel and daemon code */
EXTERNC long long cxiSafeGetLongLong(volatile long long* from);
#endif

/* Adhere to XPG 1170 behaviour */
#define cxiIsXPG()	1

/* Routine to send a signal to the current thread/process */
EXTERNC void cxiSendSigThread(int sig);

/* Routines to manipulate cxiWaitEvent_t objects. */
EXTERNC void cxiWaitEventInit(cxiWaitEvent_t* weP);
EXTERNC Boolean cxiWaitEventHasWaiters(cxiWaitEvent_t* weP);

/* Kernel-only synchronization primitives.  A cxiBlockingMutex_t can be used
   to protect a critical section.  Requests to acquire a cxiBlockingMutex
   that is already held by another thread will block the caller.  Must
   initialize the mutex before acquiring it, and must terminate it before
   deallocating the storage it occupies.  Implemented using semaphores on
   Linux. */
EXTERNC void cxiBlockingMutexInit(cxiBlockingMutex_t* mP, int bmNameIdx);
EXTERNC void cxiBlockingMutexAcquire(cxiBlockingMutex_t* mP) REGPARMS;
EXTERNC void cxiBlockingMutexAcquireFast(cxiBlockingMutex_t* mP) REGPARMS;
EXTERNC void cxiBlockingMutexRelease(cxiBlockingMutex_t* mP) REGPARMS;
EXTERNC void cxiBlockingMutexReleaseFast(cxiBlockingMutex_t* mP) REGPARMS;
EXTERNC void cxiBlockingMutexTerm(cxiBlockingMutex_t* mP);
EXTERNC Boolean cxiBlockingMutexHeldByCaller(cxiBlockingMutex_t* mP);
EXTERNC Boolean cxiBlockingMutexHasWaiters(cxiBlockingMutex_t* mP);

/* Yield the CPU to allow other processes to run */
EXTERNC void cxiYield();

/* Well defined portability interface calling changing (depending on kernel
 * level) linux interface
 */
EXTERNC int cxiFillDir(void *argP, const char *nameP, int namelen,
                       offset_t offset, int snOffset, cxiIno_t ino, void *eP);

/* A cxiWaitEvent_t can be used like a condition variable using the calls
   below.  There must be an associated cxiBlockingMutex_t held when calling
   cxiWaitEventWait that will be reacquired before returning.  The routine
   cxiWaitEventSignal wakes up one thread waiting in cxiWaitEventWait,
   while cxiWaitEventBroadcast wakes all such waiting threads.  The
   cxiWaitEventWakeupOne routine is the same as cxiWaitEventSignal except
   that multiple calls will each pick a different thread.  The flags
   parameter to cxiWaitEventWait indicates whether or not the wait can be
   interrupted by a signal.  It should be set to INTERRUPTIBLE if
   interrupts due to signals are desired, otherwise set to 0. */
EXTERNC int cxiWaitEventWait(cxiWaitEvent_t* weP, cxiBlockingMutex_t* mutexP,
                             int waitFlags);
EXTERNC void cxiWaitEventSignal(cxiWaitEvent_t* weP);
EXTERNC void cxiWaitEventWakeupOne(cxiWaitEvent_t* weP);
EXTERNC void cxiWaitEventBroadcast(cxiWaitEvent_t* weP);
EXTERNC void cxiWaitEventBroadcastRC(cxiWaitEvent_t* weP, int rc);

/* Kill the system due to a fatal error */
EXTERNC VCWARN_NORETURN void cxiPanic(const char* panicStrP);

/* Get the address of the first byte not addressible by processes */
EXTERNC UIntPtr cxiGetKernelBoundary();

/* Get the kernel page size */
EXTERNC unsigned long cxiGetKernelPageSize();

/* get the fixed addresses and size of page pool and TM pool */
EXTERNC void cxiGetFixedAddrs(char **kPagePoolLowerPP, char **kPagePoolUpperPP,
                              char **kTMPoolPP, Int64 *kTMPoolSizeP);

/* Return true if this process holds the big kernel lock (BKL) */
EXTERNC Boolean cxiHoldsBKL();

EXTERNC void cxiExportModuleStruct(void *modAddr);
EXTERNC void cxiIncModuleCounter(int up);

EXTERNC void cxiSetBit(unsigned long *flagP, int flag_bit);
EXTERNC void cxiClearBit(unsigned long *flagP, int flag_bit);
EXTERNC Boolean cxiTestBit(unsigned long *flagP, int  flag_bit);

/* Tell OS if a thread is involved in handling VM page-out requests */
EXTERNC Boolean cxiSetPageoutThread();
EXTERNC void cxiClearPageoutThread();

EXTERNC int cxiIS64U(char *addr);

#endif  /* _KERNEL */

/* Return current time of day in seconds and nanoseconds. */
#ifdef _KERNEL
EXTERNC int cxiGetTOD(cxiTimeStruc_t *tP);

static inline void cxiInvalidateAttr(cxiNode_t *cnP, int what)
{
  cnP->icValid &= ~what;
  if (what & CXI_IC_PERM)
    cxiInvalidatePerm(cnP);
}

#else /* !_KERNEL */

struct timezone;
EXTERNC int gettimeofday __P ((struct timeval *__tv, struct timezone *__tz));
/* cxiTimeStruc_t should have same size as linux struct timeval.
 * Call LGPL library function and translate microseconds from call
 * to nanoseconds.
 */

EXTERNC inline int cxiGetTOD(cxiTimeStruc_t *tP)
{
  int rc = gettimeofday((struct timeval *)tP, NULL);
  tP->tv_nsec = tP->tv_nsec * 1000;
  return rc;
}

#ifdef TS_RPC_PERF
/** This factor is used in cxiCnvTSC to convert CPU clock cycles to
   nanoseconds.  Since the typical conversion factor is near one (e.g.,
   2.8GHz) and we are using 64-bit integer arithmetic, we have to worry about
   overflow and round off error.  The usual approach is to use multiply first,
   then divide, but this risks overflow if the input cycle count is large.  A
   few seconds after booting the counter will already be more that 32-bits and
   after the system is up a couple months a 64-bit counter has only 10 unused
   bits.  We don't care much about overflow of raw counter values, because
   they are always used to compute intervals.  So the key question is how long
   are the intervals in cycle counts we want to convert to nsec.  A multiplier
   of 1e6, as used by some Linux kernel code (for historical reasons the
   traditional factor is in kHz), which limits intervals to about an hour
   without overflow problems.  On the other hand if the multipler is too small
   conversion accuracy suffers due to round off error.  As a compromise we'll
   use 15 bits here, that supports intervals of a few days.

   For example, the overflow with 1e6 occurs after:
     2**64 / 1e6 / 2.8e9 / 3600.0 = 1.83 hours
   With a 2**15 multiplier we see overflow after:
     2**64 / 2**15 / 2.8e9 / 3600.0 = 55.85 hours
   The conversion error is 1/2**15 => 0.003% or 30ppm, versus 1ppm formerly. */
extern int tscToNsecFactor;

#ifdef __cplusplus
/* get the Time Stamp Counter, i.e. the value in the Time Base Register */
static inline unsigned long
cxiGetTSC(void)
{
#if defined(GPFS_ARCH_X86_64)
  unsigned int low, high;

  __asm__ __volatile__("rdtsc" : "=a" (low), "=d" (high));
  return (low | ((unsigned long)(high) << 32));
#elif defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
  unsigned long val;

  __asm__ __volatile__ ("mftb %0" : "=r" (val));
  return(val);
#else
  return(0);
#endif

}

/** Convert a Time Stamp Counter to nano-seconds.
   Handle overflow condition by returning 0x3FFFF01234567 nsec. */
static inline unsigned long
cxiCnvTSC(unsigned long val)
{
  if (tscToNsecFactor == 0)             // unknown conversion factor
    return 0;
  if (val > (~(UInt64)0 >> 15))         // if conversion will overflow,
    return 0x3FFFF01234567ULL;          // return distinctive max value
  return (val << 15) / tscToNsecFactor;
}
#endif /* __cplusplus */
#endif /* TS_RPC_PERF */

#define cxiSafeGetLongLong(_ptr) (*_ptr)
#define cxiSafeGetLong(_ptr) (*_ptr)
#define cxiSafeGetInt(_ptr) (*_ptr)

/* String functions in user space */
#define cxiStrcpy  strcpy
#define cxiStrncpy strncpy
#define cxiStrcat  strcat
#define cxiStrncat strncat
#define cxiStrrchr strrchr
#define cxiStrchr  strchr
#define cxiStrcmp  strcmp
#define cxiStrncmp strncmp
#ifdef GPFS_LINUX
#define cxiMemcpy  memcpy
#endif
#define cxiStrlen  strlen
#define cxiMemcmp  memcmp
#define cxiMemset  memset

#endif /* _KERNEL */

/* Samba share/delegate flags.  Unlike NFSV4, the interface here is
 * just between our Samba vfs library and ourselves so we can define
 * these to be any values we choose.  */
#define CXI_ACCESS_READ   1
#define CXI_ACCESS_WRITE  2
#define CXI_ACCESS_BOTH   3
#define CXI_DENY_NONE     0
#define CXI_DENY_READ     1
#define CXI_DENY_WRITE    2
#define CXI_DENY_BOTH     3
#define CXI_DENY_DELETE   4
#define CXI_DENY_ALL      7
#define CXI_DELEGATE_NONE  0
#define CXI_DELEGATE_READ  1
#define CXI_DELEGATE_WRITE 2

#define LOOKUP_FLAGS_TO_INTENT(osFlags)                    \
    ((((osFlags) & LOOKUP_OPEN)? GPFS_LOOKUP_OPEN:0) |     \
     (((osFlags) & LOOKUP_CREATE)? GPFS_LOOKUP_CREATE:0))

/* Whatever the values specified in Samba for share, deny, and oplock flags,
 * we have to translate them to our SMB open and oplock flags.
 * Define macros to translate and error check.
 */
#define XLATE_SAMBA_ACCESS(SAMBA_SHARE, SHARE) \
  SHARE = (ALLOW_SHARE_DELETE); \
  if (SAMBA_SHARE == CXI_ACCESS_READ) SHARE |= coRead; \
  else if (SAMBA_SHARE == CXI_ACCESS_WRITE) SHARE |= coWriteM|coWriteA; \
  else if (SAMBA_SHARE == CXI_ACCESS_BOTH) SHARE |= coRead|coWriteM|coWriteA; \
  else if (SAMBA_SHARE != 0) goto xerror;

#define XLATE_SAMBA_DENY(SAMBA_DENY, SHARE) \
  if (SAMBA_DENY & ~CXI_DENY_ALL) goto xerror; \
  else if (SAMBA_DENY == CXI_DENY_DELETE) goto xerror; \
  else if (SAMBA_DENY == CXI_DENY_NONE) SHARE &= ~coDenyAll; \
  if (SAMBA_DENY & CXI_DENY_READ)   SHARE |= coDenyR; \
  if (SAMBA_DENY & CXI_DENY_WRITE)  SHARE |= coDenyWM|coDenyWA; \
  if (SAMBA_DENY & CXI_DENY_DELETE) SHARE &= ~(ALLOW_SHARE_DELETE);

#define XLATE_SAMBA_DELEGATE(SAMBA_DELEGATE, OPLOCK) \
  if (SAMBA_DELEGATE == CXI_DELEGATE_NONE) OPLOCK |= smbOplockNone; \
  else if (SAMBA_DELEGATE == CXI_DELEGATE_READ) OPLOCK |= smbOplockShared; \
  else if (SAMBA_DELEGATE == CXI_DELEGATE_WRITE) OPLOCK |= smbOplockExclusive; \
  else goto xerror;

/* Call Linux-specific F_SETLEASE operation.
   This will register the caller so that it will be notified via SIGIO
   when an OpLock break is required (REVOKE_LEASE is called).
*/
#define CXI_REGISTER_LEASE(FD, LTYPE) \
  fcntl(FD, F_SETLEASE, (LTYPE == CXI_DELEGATE_READ )? F_RDLCK: \
                        (LTYPE == CXI_DELEGATE_WRITE)? F_WRLCK: F_UNLCK)

/* Call Linux-specific F_GETLEASE */
#define CXI_GET_LEASE_HELD(FD, LEASE) \
  LEASE = fcntl(FD, F_GETLEASE, 0); \
  LEASE = (LEASE == F_RDLCK)? CXI_DELEGATE_READ: \
          (LEASE == F_WRLCK)? CXI_DELEGATE_WRITE: \
          (LEASE == F_UNLCK)? CXI_DELEGATE_NONE: LEASE

#if defined(NFS4_VCM)

#define OPEN4_SHARE_ACCESS_READ  0x00000001
#define OPEN4_SHARE_ACCESS_WRITE 0x00000002
#define OPEN4_SHARE_ACCESS_BOTH  0x00000003
#define OPEN4_SHARE_DENY_NONE    0x00000000
#define OPEN4_SHARE_DENY_READ    0x00000010
#define OPEN4_SHARE_DENY_WRITE   0x00000020
#define OPEN4_SHARE_DENY_BOTH    0x00000030
#define OPEN_DELEGATE_NONE       0x00000000
#define OPEN_DELEGATE_READ       0x00000100
#define OPEN_DELEGATE_WRITE      0x00000200

#define CXI_SHARE_ACCESS_READ   OPEN4_SHARE_ACCESS_READ
#define CXI_SHARE_ACCESS_WRITE  OPEN4_SHARE_ACCESS_WRITE
#define CXI_SHARE_ACCESS_BOTH   OPEN4_SHARE_ACCESS_BOTH
#define CXI_SHARE_DENY_NONE     OPEN4_SHARE_DENY_NONE
#define CXI_SHARE_DENY_READ     OPEN4_SHARE_DENY_READ
#define CXI_SHARE_DENY_WRITE    OPEN4_SHARE_DENY_WRITE
#define CXI_SHARE_DENY_BOTH     OPEN4_SHARE_DENY_BOTH
#define CXI_OPEN_DELEGATE_NONE  OPEN_DELEGATE_NONE
#define CXI_OPEN_DELEGATE_READ  OPEN_DELEGATE_READ
#define CXI_OPEN_DELEGATE_WRITE OPEN_DELEGATE_WRITE

/* Whatever the values specified in the NFS4 interface for share, deny, and
 * delegate flags, we have to translate them to our SMB open and oplock flags.
 * Define macros to translate and error check.
 */
#define XLATE_NFS4_ACCESS(NFS4_SHARE, SHARE) \
  if (NFS4_SHARE == CXI_SHARE_ACCESS_READ) SHARE |= coRead; \
  else if (NFS4_SHARE == CXI_SHARE_ACCESS_WRITE) SHARE |= coWriteM|coWriteA; \
  else if (NFS4_SHARE == CXI_SHARE_ACCESS_BOTH) SHARE |= coRead|coWriteM|coWriteA; \
  else if (NFS4_SHARE != 0) goto xerror;

#define XLATE_NFS4_DENY(NFS4_DENY, SHARE) \
  if (NFS4_DENY == CXI_SHARE_DENY_NONE) SHARE &= ~coDenyAll; \
  else if (NFS4_DENY == CXI_SHARE_DENY_READ) SHARE |= coDenyR; \
  else if (NFS4_DENY == CXI_SHARE_DENY_WRITE) SHARE |= coDenyWM|coDenyWA; \
  else if (NFS4_DENY == CXI_SHARE_DENY_BOTH) SHARE |= coDenyR|coDenyWM|coDenyWA; \
  else goto xerror;

#define XLATE_NFS4_DELEGATE(NFS4_DELEGATE, OPLOCK) \
  if (NFS4_DELEGATE == CXI_OPEN_DELEGATE_NONE) OPLOCK |= smbOplockNone; \
  else if (NFS4_DELEGATE == CXI_OPEN_DELEGATE_READ) OPLOCK |= smbOplockShared; \
  else if (NFS4_DELEGATE == CXI_OPEN_DELEGATE_WRITE) OPLOCK |= smbOplockExclusive; \
  else goto xerror;

#endif /* NFS4_VCM */

#ifdef NFS4_VCM
/* VCM definitions */
#define boolean_t Boolean
#define uint16_t UInt16

typedef void * vcm_peerHandle_t;
typedef uint16_t vcm_opRights_t;
typedef UInt64 vcm_revokeTag_t;

/* VCM flags */

/* Flags for vcm_peerRegister() */
#define VCM_PRGY_RTN_OPENS    0x00000001
#define VCM_PRGY_ENF_VREG     0x00000002
#define VCM_PRGY_ENF_VDIR     0x00000004
#define VCM_PRGY_ENF_VLNK     0x00000008

/* Flags for vcm_peerRevoke() */
#define VCM_P_RVK_NOWAIT      0x00000001
#define VCM_P_RVK_FORCE       0x00000002

/* Flags for getOpRights */
#define VCM_P_GR_NOWAIT       0x00000001

/* Flags for returnOpRights */
#define VCM_P_RR_REL_OBJ      0x00000001

/* Flags for vcm_peerCreateReq_t */
#define VCM_P_CREQ_F_CREATE   0x00000001


/* GPFS peer-side utilities */
#define cxiPeerUnregister() (NOOP)
#define cxiGetPeerTag() ((uint64_t)NULL)
#define cxiGetPeerHandle() ((vcm_peerHandle_t)NULL)
#define cxiWatchVCM(nfsP, doClose) (0)
#define cxiCleanupVCM(nfsP) (0)
#define cxiFSCleanupVCM(privVfsP) (0)

#define cxiInitVCM(nfsP) \
{ \
  nfsP->vcmRights = 0; \
  nfsP->vcmRevokeRights = 0; \
  nfsP->vcmRevokeTag = 0; \
}

/* GPFS peer-side interfaces */
#define gpfs_vcm_releaseObjHandle(peerTag, objHandleP) (0)
#define delegateInternal(vP, vinfoP, acc, flags, cb_rtn, cookie, kopP) (0)

/* VCM-side interfaces */
#define vcm_peerRegister(peerInfoP, peerHandleP) (0)
#define vcm_peerUnregister(peerHandle) (0)
#define vcm_peerRevoke(peerHandle, objHandle, peerOpHandle, peerTag, \
                       rights, flags, releObjHandleP) (0) 
#define vcm_peerTest(tc, fid, vfsP, opInfoP) (0)

/* The CXI_OPEN/SHARE values will be set to the VCM Rights 
 * Here some useful comparison macros based on these defines are included. */
#define CXI_DELEGATE          (CXI_OPEN_DELEGATE_READ | CXI_OPEN_DELEGATE_WRITE)
#define CXI_SHARE_ALLOW       (CXI_SHARE_ACCESS_READ | CXI_SHARE_ACCESS_WRITE)
#define CXI_SHARE_DENY        (CXI_SHARE_DENY_READ | CXI_SHARE_DENY_WRITE)
#define CXI_SHARE             (CXI_SHARE_ALLOW | CXI_SHARE_DENY)

#define CXI_IS_DELEGATE_READ(R)  (0 != (R & CXI_OPEN_DELEGATE_READ))
#define CXI_IS_DELEGATE_WRITE(R) (0 != (R & CXI_OPEN_DELEGATE_WRITE))
#define CXI_IS_SHARE_READ(R)     (0 != (R & CXI_SHARE_ACCESS_READ))
#define CXI_IS_SHARE_WRITE(R)    (0 != (R & CXI_SHARE_ACCESS_WRITE))
#define CXI_IS_DENY_READ(R)      (0 != (R & CXI_SHARE_DENY_READ))
#define CXI_IS_DENY_WRITE(R)     (0 != (R & CXI_SHARE_DENY_WRITE))
#define CXI_IS_DELEGATE(R)       (0 != (R & CXI_DELEGATE))
#define CXI_IS_SHARE_ALLOW(R)    (0 != (R & CXI_SHARE_ALLOW))
#define CXI_IS_SHARE_DENY(R)     (0 != (R & CXI_SHARE_DENY))
#define CXI_IS_SHARE(R)          (0 != (R & CXI_SHARE))

#endif /* NFS4_VCM */

EXTERNC int cxiPathToVfsP(void **privVfsPP, char *pathname, void **ndPP, void **gP, Boolean traverseLink);
EXTERNC void cxiPathRel(void * ndP);

#ifdef UIDREMAP
EXTERNC size_t cxiGetUserEnvironmentSize(void);
EXTERNC int cxiGetUserEnvironment(char* buf, size_t len);
#endif

EXTERNC Boolean cxiHasMountHelper();
EXTERNC Boolean cxisReclaim(unsigned int l_flags);
EXTERNC void cxiSetReclaim(unsigned int *l_flags);
EXTERNC void cxiResetReclaim(unsigned int *l_flags);
EXTERNC Boolean cxisCancel(unsigned int l_flags);

EXTERNC int cxiCheckThreadState(cxiThreadId tid);
EXTERNC int cxiMaxIOsize(IntNative blkSize);

#ifdef P_NFS4
EXTERNC int cxiSetFH(int *fhP, int sid);
EXTERNC int cxiRecallLayout(void *vfsP, void *vP, void *p);
EXTERNC int cxiUpdateDevice(void *vfsP, void *p);
EXTERNC int cxiGetDeviceInfo(int nDests, int *ipList, int nDss, int *dsList,
                             void *devidP, void *xdrP);
EXTERNC int cxiGetLayout(int nDests, unsigned int startIndex, cxiVattr_t *vattr,
                         UInt32 myAddr,  UInt32 seqNo, void *args, void *res,
                         void *xdr, UInt32 fsid0, UInt32 fsid1, UInt32 poolId);
EXTERNC void cxiGetDevicePnfsId(void *dev_id, UInt32 myAddr, UInt32 seqNo,
                                UInt32 poolId, UInt32 fsid0, UInt32 fsid1);
EXTERNC int cxiGetDevicePoolId(void *devId);
#endif

#ifdef GPFS_CACHE
EXTERNC int cxiCacheInit(const char *mntPathP, int fsType, Boolean hold, void **vfsPP);
EXTERNC int cxiCacheExit(void *vfsP);
EXTERNC int cxiCacheLookupRoot(void *vfsP, pcacheAttr_t *pattrP);
EXTERNC int cxiCacheLookup(void *vfsP, pcacheAttr_t *pattrP, char *nameP, pcacheAttr_t *cpattrP);
EXTERNC int cxiCacheCreate(void *vfsP, pcacheAttr_t *parentPattrP, char *nameP, int mode,
                           cxiUid_t uid, cxiGid_t gid, cxiDev_t rdev, pcacheAttr_t *pattrP);
EXTERNC int cxiCacheRemove(void *vfsP, pcacheAttr_t *pattrP, char *nameP, int type);
EXTERNC int cxiCacheOpen(void *vfsP, pcacheAttr_t *parentPattrP, const char *nameP, int flags, 
                         int mode, uid_t uid, gid_t gid, 
                         pcacheAttr_t *pattrP, void **filePP, offset_t *fileSizeP);
EXTERNC int cxiCacheClose(void *vfsP, void *fP, pcacheAttr_t *pattrP);
EXTERNC int cxiCacheReaddir(void *vfsP, void *fP, void *fnP, void *argP);
EXTERNC int cxiCacheRead(void *vfsP, void *fP, char *bufP, size_t bufSize,
                         offset_t *offsetP, ssize_t *bytesRead, Boolean user);
EXTERNC int cxiCacheWrite(void *vfsP, void *fP, char *bufP, size_t bufSize,
                          offset_t *offsetP, ssize_t *bytesWritten, Boolean user);
EXTERNC int cxiCacheGetattr(void *vfsP, pcacheAttr_t *pattrP, Boolean force);
EXTERNC int cxiCacheSetattr(void *vfsP, pcacheAttr_t *pattrP, int op, long arg1, long arg2);
EXTERNC int cxiCacheRename(void *vfsP, pcacheAttr_t *sDirPattrP, pcacheAttr_t *sPattrP, char *sNameP,
                           pcacheAttr_t *tDirPattrP, pcacheAttr_t *tPattrP, char *tNameP);
EXTERNC int cxiCacheLink(void *vfsP, pcacheAttr_t *dirPattrP, pcacheAttr_t *pattrP, char *nameP);
EXTERNC int cxiCacheSymlink(void *vfsP, pcacheAttr_t *parentPattrP, char *targetNameP,
                            char *newNameP, pcacheAttr_t *cpattrP);
EXTERNC int cxiCacheReadlink(void *vfsP, pcacheAttr_t *pattrP, char *target);

EXTERNC int cxiCacheOpenState(void *dP, cxiNode_t **cnP, char *nameP);
EXTERNC void cxiMarkOSNodeDirty(void *osNodeP);
EXTERNC void cxiDeleteDCacheEntry(void *den);
EXTERNC int cxiCacheOpenByAttr(void *vfsP, pcacheAttr_t *pattrP, const char *nameP, int flags, int *fdP);
EXTERNC int cxiCacheFadvise(void* fP, int advice, loff_t len);
EXTERNC int cxiCacheUpdateAttrs(pcacheRemoteAttr_t *pattrP);
EXTERNC void cxiCacheKill(void *vfsP);
EXTERNC void cxiCacheSetContext(void *vfsP, Boolean set);
#endif

EXTERNC int cxiInitInodeSecurity(void *dP, void *vP,
                                 char **secattrPrefix, char **secattrSuffix,
                                 void **secattrValue, size_t *secattrValueLen);
EXTERNC void cxiInitInodeSecurityCleanup(char* secattrSuffix, void *secattrValue);
EXTERNC Boolean cxiIsLSMEnabled(void);

#endif  /* _h_cxiSystem_plat */
