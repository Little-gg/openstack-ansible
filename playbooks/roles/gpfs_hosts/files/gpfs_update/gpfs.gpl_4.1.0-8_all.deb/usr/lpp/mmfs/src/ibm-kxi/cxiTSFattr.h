/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)68       1.117  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiTSFattr.h, mmfs, avs_rfks1, rfks1s007a_addw 8/14/14 07:59:40 */

#ifndef _h_cxitsfattr
#define _h_cxitsfattr

#include <gpfs.h>
#include <cxiTypes.h>

#ifndef ID2NAME_DEF_BEGIN
#define ID2NAME_DEF_BEGIN(name)
#define ID2NAME_DEF_END
#endif

ID2NAME_DEF_BEGIN(tsfattrcmd)

/* defines for command parameter in tsfattr() */
#define SET_BUFFERING          10
#define GET_BUFFERING          11
#define LIST_XATTR             12
#define GET_XATTR              13  /* severely deprecated - with PIE, no longer used outside of kernel or daemon */
#define SET_XATTR              14  /* severely deprecated - ditto */
#define GPFS_STATFSPOOL        15
#define GPFS_GETPOOLNAME       16
#define GPFS_QOS_GETSTATS       17  /* get QOS statistics  */
/* #define GET_REPL_FACTORS       20  deprecated -- use gpfs_fcntl */
/* #define SET_REPL_FACTORS       21  deprecated -- use gpfs_fcntl */
#define REMOTE_STAT            22
#define IO_HINTS               24
#define PREALLOCATE_FILE       25
#define GET_ALL_ATTRS          27
#define PUT_ALL_ATTRS          28
#define PUT_ALL_ATTRS_WITH_NAME 29

#define ENC_FILE_REWRAP         30

#define PRIVILEGED_OPERATIONS  31   /* must be privileged user for operations
                                       bigger than PRIVILEGED_OPERATIONS */

#define GET_INODE_BLOCK        32
#define GET_FSET_INODE_BLOCK   33
#define GET_DIR_BLOCK          34
#define SET_DIR_ENTRY          35
#define GPFS_IOPEN             36
#define GPFS_ICLOSE            37
#define GPFS_IREAD             38
#define GPFS_IWRITE            39
#define GPFS_IREAD_SYMLINK     40
#define GPFS_IGET_ATTRS        41
#define GPFS_IPUT_ATTRS        42
#define GPFS_PCACHE_OPEN       43
#define GPFS_SYNC_FS           44
#define GPFS_START_RESTORE     45
#define GPFS_END_RESTORE       46
#define GPFS_FS_RESTORABLE     47
#define GPFS_IGET_FILESET      48
#define GPFS_IGET_STORAGEPOOL  49
#define GPFS_IREADX            50
#define GPFS_IWRITEX           51
#define GPFS_OPEN_FSSNAPHANDLE 52
#define GPFS_OPEN_FSET_SNAPHANDLE   53
#define GET_DIRX_BLOCK         79
#define GPFS_SYNC_FSET         81
#define GPFS_FSET_RESTORABLE   82
#define GPFS_START_FSET_RESTORE 83
#define GPFS_END_FSET_RESTORE   84
#define GPFS_QOS_CNTRL          85  /* various QOS controls */
#define GPFS_IREADX_CLONE_CHILD  86
/* 87 unused */
#define GPFS_PCACHE_GETFS       88
#define ENC_GET_ALGO            89
#define GPFS_PCACHE_REMOTE_CTL  90

/* Defines for 64-bit inode scan with extended attributes */
#define GET_DIR_BLOCK64             54
#define GPFS_IOPEN64                55
#define GPFS_IREAD64                56
#define GPFS_IREAD_SYMLINK64        57
#define GPFS_IGET_ATTRS64           58
#define GPFS_IREADX64               59
#define GPFS_OPEN_FSSNAPHANDLE64    60
#define GET_INODE_XBLOCK            61
#define GET_INODE_XBLOCK64          62
#define SET_DIR_ENTRY64             63
#define GPFS_IPUT_ATTRS64           64
#define GPFS_IWRITE64               65
#define GPFS_IWRITEX64              66
#define GPFS_ICLOSE64               67
#define GPFS_IGET_ATTRSX            68
#define GPFS_IPUT_ATTRSX            69
#define GPFS_IGET_ATTRSX64          70
#define GPFS_IPUT_ATTRSX64          71
#define GPFS_OPEN_ISCANX            72
#define GPFS_STATFS64               73
#define GPFS_OPEN_FSET_SNAPHANDLE64 74
#define GET_FSET_INODE_BLOCK64      75
#define GET_FSET_INODE_XBLOCK       76
#define GET_FSET_INODE_XBLOCK64     77
#define GET_INODE_BLOCK64           78
#define GET_DIRX_BLOCK64            80
#define GPFS_IGET_XATTR64           91
#define GPFS_IGET_XATTR             92

#define GPFS_GET_VAAI_XSTAT         93

/* define TEST_MB_PERF         96  Defined in tsfattrx.h */
/* define KERNEL_LOGGENERIC    97  Defined in tsfattrx.h */
/* define KERNEL_LOGSPECIFIC   98  Defined in tsfattrx.h */
/* define TEST_LOCK_PERF       99  Defined in tsfattrx.h */

ID2NAME_DEF_END

/* String conversions automatically generated from ID2NAME_DEF */
extern const char* tsfattrcmdToString(int id);
#define tsfattrcmd_id2name(i) I2N(tsfattrcmd,i)

/* defines for command parameter in tsfsattr() */

ID2NAME_DEF_BEGIN(tsfsattrcmd)

/*define PRIVILEGED_OPERATIONS  30    must be privileged user for operations
                                      bigger than PRIVILEGED_OPERATIONS */
#define GPFS_FSATTR_HANDLE_VIA_NAME     30  // "HANDLE_VIA_NAME"
#define GPFS_FSATTR_HANDLE_VIA_ID       31  // "HANDLE_VIA_ID"
#define GPFS_FSATTR_PATH_VIA_HANDLE     32  // "PATH_VIA_HANDLE"
#define GPFS_FSATTR_FSNAME_VIA_HANDLE   33  // "FSNAME_VIA_HANDLE"
#define GPFS_FSATTR_SNAPNAME_VIA_HANDLE 34  // "SNAPNAME_VIA_HANDLE"
#define GPFS_FSATTR_RESTORE_FSSNAPID_VIA_HANDLE 35  // "RESTORE_FSSNAPID_VIA_HANDLE"
#define GPFS_FSATTR_GET_SNAPDIRNAME     36  // "GET_SNAPDIRNAME"
#define GPFS_FSET_ATTR_PATH_VIA_HANDLE  45  // "HANDLE_VIA_NAME"
#define GPFS_FSET_ATTR_HANDLE_VIA_NAME  47  // "HANDLE_VIA_NAME"
#define GPFS_FSET_ATTR_HANDLE_VIA_ID    48  // "HANDLE_VIA_ID"
#define GPFS_FSET_ATTR_FSNAME_VIA_HANDLE   50  // "FSNAME_VIA_HANDLE"
#define GPFS_FSET_ATTR_SNAPNAME_VIA_HANDLE 52
#define GPFS_FSET_ATTR_GET_SNAPDIRNAME     54  // "GET_SNAPDIRNAME"

/* Defines for 64-bit inode scan with extended attributes */
#define GPFS_FSATTR_HANDLE64_VIA_NAME     38  // "HANDLE64_VIA_NAME"
#define GPFS_FSATTR_HANDLE64_VIA_ID       39  // "HANDLE64_VIA_ID"
#define GPFS_FSATTR_PATH_VIA_HANDLE64     40  // "PATH_VIA_HANDLE64"
#define GPFS_FSATTR_FSNAME_VIA_HANDLE64   41  // "FSNAME_VIA_HANDLE64"
#define GPFS_FSATTR_SNAPNAME_VIA_HANDLE64 42  // "SNAPNAME_VIA_HANDLE64"
#define GPFS_FSATTR_GET_SNAPDIRNAME64     43  // "GET_SNAPDIRNAME64"
#define GPFS_FSET_ATTR_HANDLE64_VIA_NAME  44  // "FSET_HANDLE64_VIA_NAME"
#define GPFS_FSET_ATTR_PATH_VIA_HANDLE64  46  // "FSET_PATH_VIA_HANDLE64"
#define GPFS_FSET_ATTR_HANDLE64_VIA_ID    49  // "FSET_HANDLE64_VIA_ID"
#define GPFS_FSET_ATTR_FSNAME_VIA_HANDLE64   51 // "FSET_FSNAME_VIA_HANDLE"
#define GPFS_FSET_ATTR_SNAPNAME_VIA_HANDLE64 53 // "FSET_SNAPNAME_VIA_HANDLE64"
#define GPFS_FSET_ATTR_GET_SNAPDIRNAME64     55 // "FSET_GET_SNAPDIRNAME64"

ID2NAME_DEF_END

/* String conversions automatically generated from ID2NAME_DEF */
extern const char* tsfsattrcmdToString(int id);
#define tsfsattrcmd_id2name(i) I2N(tsfsattrcmd,i)

/* Define extended attribute namespaces.
   Note: These must be a superset of the native namespaces.
   Not all EAs may be seen via all native EA api's */
#define GPFS_XATTR_SECURITY_PREFIX "security."
#define GPFS_XATTR_TRUSTED_PREFIX "trusted."
#define GPFS_XATTR_USER_PREFIX "user."
#define GPFS_XATTR_SYSTEM_PREFIX "system."
#define GPFS_XATTR_NAME_ACL_ACCESS      "system.posix_acl_access"
#define GPFS_XATTR_NAME_ACL_DEFAULT     "system.posix_acl_default"
#define GPFS_XATTR_ARCHIVE_PREFIX "archive."
#define GPFS_XATTR_DMAPI_PREFIX "dmapi."
#define GPFS_XATTR_GPFSDMAPI_PREFIX "gpfs.dmapi."
#define GPFS_XATTR_GPFS_PREFIX "gpfs."


/* Structure used to receive additional information regarding
   operation failures. */
typedef struct tsfattrReasonCodeInfo_s
{
  int reason;               /* reason request failed */
  int value1;               /* optional value depending upon reason */
  int value2;               /* optional value depending upon reason */
} tsfattrReasonCodeInfo;


/* Structure used to pass FILE_PREALLOCATION information */
struct filePreallocation
{
  long long offset;        /* in  - offset to start preallocation from */
  long long size;          /* in  - size of preallocation */
  int       flags;         /* in  - write flags */
};

#ifdef GPFS_VAAI
/* Structure used to pass GPFS_GET_VAAI_XSTAT information */
struct fileVaaiXStat
{
  unsigned int level;
  unsigned int rlevel;
  unsigned long long allocated;
  unsigned long long unique;
};
#endif	/* GPFS_VAAI */

#ifdef GPFS_ENC
/* Structure used to pass ENC_FILE_REWRAP  information */
/* This needs to be large enough to fit
      CRYPTO_EA_MAXKMSIDLEN + CRYPTO_EA_MAXKEYIDLEN + 1
   but not including GcryptoDefs.h to avoid over-proliferation of
   encryption headers. */
#define ENC_KEY_ID_MAX_LEN      64

struct encryptionFileRewrap {
  char origKey[ENC_KEY_ID_MAX_LEN + 1];  /* Original Key ID (to be replaced) */
  char newKey[ENC_KEY_ID_MAX_LEN + 1];   /* New Key ID */
};


/* Structure used to pass ENC_GET_ALGO information */

#define ENC_MAX_ENC_EA_LENGTH   4096  /* maximum length of encryption EA.
                                         Similar to
                                         ENC_MAX_ENCRYPTION_ATTR_SIZE */

struct  encryptionGetAlgo
{
  char *xattrValP;                      /* content of gpfs.Encryption */
  int xattrLen;                         /* length of data in xattrVal */
  char *algoTxtP;                       /* string with description of encryption
                                           algorithm */
  int algoTxtSize;                      /* space allocated for algoTxtP */
};

#endif /* GPFS_ENC */

/* Structure used to pass parameters for GET_ALL_ATTRS and PUT_ALL_ATTRS
   functions. For PUT_ALL_ATTRS_WITH_NAME, the attrSizeP points to the
   pathName or NULL. */
struct xattrsparms
{
  int flags;       /* in - flags (must be zero, reserved for future use) */
  void *bufferP;   /* in - address of buffer containing or receiving
                           attribute data */
  int bufferSize;  /* in - size of the buffer (not used by PUT_ALL_ATTRS) */
  int *attrSizeP;  /* in - address where to return actual size of the data
                           (not used by PUT_ALL_ATTRS) */
};

/* Interface structures for gpfsStatFsPool() */
typedef struct
{
  UInt64    f_blocks;     /* total data blocks in pool */
  UInt64    f_bfree;      /* free blocks in pool */
  UInt64    f_bavail;     /* free blocks avail to non-superuser */
  UInt64    f_mblocks;    /* total metadata blocks in pool */
  UInt64    f_mfree;      /* free blocks avail for system metadata */
  int       f_bsize;      /* optimal storage pool block size */
  int       f_files;      /* total file nodes assigned to pool
                             (currently only value -1) */
  UInt32    f_poolid;     /* storage pool id */
  int       f_fsize;      /* fundamental file system block size */
  unsigned int f_usage;   /* data and/or metadata stored in pool */
  int       f_replica;    /* replica */
  int       f_bgf;        /* block group factor */
  int       f_wad;        /* write affinity depth */
  int       f_allowWriteAffinity;   /* allow write affinity depth. 1 means yes */
  int       f_reserved[3];/* Current unused and set to  zero */
} cxiStatFsPool_t;

typedef struct
{
  UInt32 poolId;
  UInt32 options;
  int    nPools;
  int    bufferSize;
  char  *bufferP;
} cxiStatFsPoolArgs_t;

#ifdef QOSIO
/* Interface for gpfs_get_qos_stats */
typedef struct
{
  UInt32 qosid;
  UInt32 poolid;
  UInt32 options;
  UInt32 mqips;
  UInt32 nslots;
  UInt32 bufferSize;
  void* bufferP;
} cxiGetQosStatsArgs_t;

/* Interface for gpfs_qos_control */
typedef struct
{
  UInt32 bufferSize;  /* all commands, options, parameters, and so on are in the buffer ... */
  void* bufferP;      /* ... which must be a sequence of QosCmd subclasses */
} cxiQosControlArgs_t;

#if defined(_KERNEL) && defined(__cplusplus)
extern int gpfsQosGetStats(StripeGroup* sgP, cxiGetQosStatsArgs_t& qosArgs, int& code);
extern int gpfsQosControl(StripeGroup* sgP, cxiQosControlArgs_t& qosArgs, int& code);
#endif

#endif
/* Definitions for GPFS file attribute function */

#ifdef __cplusplus
extern "C"
{
#endif

int GPFS_API
tsfattr(gpfs_file_t fileDesc,  /* Open file descriptor */
        int command,   /* Control function to be performed */
        void *argP,    /* Additional info required by function */
        tsfattrReasonCodeInfo *rCodeP); /* More returned info*/

int GPFS_API
tsfsattr(int command,  /* Control function to be performed */
         void *argP);  /* Additional info required by function */

/* The tsattr call only supports the following commands:
     GET_REPL_FACTORS
 */
int GPFS_API
tsattr(const char *pathname, /* File pathname */
       int command,    /* Control function to be performed */
       void *argP,     /* Additional info required by function */
       tsfattrReasonCodeInfo *rCodeP); /* More returned info*/

/* Define type used to identify a file system. Internally, this is
   actually a DiskUID. Assignments to and from this id must be cast
   as DiskUIDs to generate the correct byte-swapping code. */
typedef struct _gpfs_fs_id
{
  BigEndUInt32 word0;
  BigEndUInt32 word1;
} _gpfs_fs_id_t;

/* Structure used to hold snapshot id max size is 48 see gpfs_snap_id_t in
   gpfs.h. Note that the "_gpfs" prefix is used for an internal definition
   of an externally defined structure. */
#define FSSNAPID_MAGIC 0xD00FF009
#define FSSNAPID_INVALID -1     // Must match SNAPID_INVALID
#define FSET_SNAPID_MAGIC 0xD00FF00A
#define ISCAN_VERSION 1

typedef struct _gpfs_fssnap_id
{
  BigEndInt32 magic;           /* magic number                  */
  BigEndInt32 fmtVersion;      /* version from curFmtVersion    */
  BigEndInt64 snapId;          /* snapshot id                   */
  BigEndInt64 baseSnapId;      /* base id for snapshot          */
  _gpfs_fs_id_t stripeId;      /* FS id assigned at format time */
  _gpfs_fs_id_t baseStripeId;  /* base FS id for snapshot       */
  union
  {
    BigEndInt64 time;            /* time stamp (just second)      */
    BigEndInt64 inodeSpaceInd;
  };
} _gpfs_fssnap_id_t;

/* Structure used to identify file system and snapshot
   Note "_gpfs" is used for the internal version of an externally
   defined type. */
#define FSSNAPHANDLE_MAGIC 0xD00FF021
#define FSETSNAPHANDLE_MAGIC 0xD00FF022
typedef struct _gpfs_fssnap_handle
{
  int  magic;                  /* magic number               */
  int fd;                      /* file descriptor            */
  _gpfs_fssnap_id_t fssnapId;  /* unique fs/snapshot id      */
  cxiIno_t maxIno;           /* maximum inode number       */
  int inodesPMB;               /* inodes per metadata block  */
  int pathNameSize;            /* size of path buffer        */
  char *pathNameP;             /* path buffer                */
  int fsNameSize;              /* size of fsName buffer      */
  char *fsNameP;               /* fsName buffer              */
  int snapNameSize;            /* size of snapName buffer    */
  char *snapNameP;             /* snapName buffer            */
} _gpfs_fssnap_handle_t;

typedef struct _gpfs_fset_snap_handle
{
  int  magic;                        /* magic number               */
  int fd;                            /* file descriptor            */
  _gpfs_fssnap_id_t fssnapId;  /* unique fs/snapshot id      */
  cxiIno_t maxIno;             /* maximum inode number       */
  int inodesPMB;               /* inodes per metadata block  */
  int pathNameSize;            /* size of path buffer        */
  char *pathNameP;             /* path buffer                */
  int fsNameSize;              /* size of fsName buffer      */
  char *fsNameP;               /* fsName buffer              */
  int snapNameSize;            /* size of snapName buffer    */
  char *snapNameP;             /* snapName buffer            */
  int inodeSpaceInd;           /* inode space ind of the scan*/
  int fsetId;                  /* root filesetId of the ispc */
  int fsetNameSize;            /* size of fsetName buffer    */
  char *fsetNameP;             /* fsetName buffer            */
} _gpfs_fset_snap_handle_t;

#ifdef FASTEA
#define FSSNAPHANDLE64_MAGIC 0xD00FF023
/* #MAK# I am bumping magic whenever I change the structure to catch mismatches at runtime */
#define FSETSNAPHANDLE64_MAGIC 0xD00FF024
typedef struct _gpfs_fssnap_handle64
{
  int  magic;                  /* magic number               */
  int fd;                      /* file descriptor            */
  _gpfs_fssnap_id_t fssnapId;  /* unique fs/snapshot id      */
  cxiIno64_t maxIno;           /* maximum inode number       */
  int inodesPMB;               /* inodes per metadata block  */
  int pathNameSize;            /* size of path buffer        */
  int fsNameSize;              /* size of fsName buffer      */
  int snapNameSize;            /* size of snapName buffer    */
  char *pathNameP;             /* path buffer                */
  char *fsNameP;               /* fsName buffer              */
  char *snapNameP;             /* snapName buffer            */
} _gpfs_fssnap_handle64_t;

typedef struct _gpfs_fset_snap_handle64
{
  int  magic;                  /* magic number               */
  int fd;                      /* file descriptor            */
  _gpfs_fssnap_id_t fssnapId;  /* unique fs/snapshot id      */
  cxiIno64_t maxIno;           /* maximum inode number       */
  int inodesPMB;               /* inodes per metadata block  */
  int pathNameSize;            /* size of path buffer        */
  int fsNameSize;              /* size of fsName buffer      */
  int snapNameSize;            /* size of snapName buffer    */
  char *pathNameP;             /* path buffer                */
  char *fsNameP;               /* fsName buffer              */
  char *snapNameP;             /* snapName buffer            */
  int inodeSpaceInd;
  int fsetId;
  int fsetNameSize;            /* size of fsetName buffer    */
  char *fsetNameP;             /* fsetName buffer            */
  UInt64 inodeSpaceMask;       /* copied from StripeGroupDesc so caller can convert/compute ... */
  UInt64 inodeBlockMask;       /* internal/external/inode-space numbers ... */
  Int32  inodesPerInodeBlock;  /* and so on ... See SGDesc.h ext2InternalInNum() & co */
} _gpfs_fset_snap_handle64_t;
#endif

/* Structure used to keep restore session information. */
#define RESTORE_MAGIC 0xD00FF015
#define RESTORE_FSET_MAGIC 0xD00FF016
typedef struct _gpfs_restore
{
  int  magic;                  /* magic number               */
  int  fd;                     /* file descriptor            */
  _gpfs_fssnap_id_t old_fssnapId;  /* id for last snapshot   */
  _gpfs_fssnap_id_t new_fssnapId;  /* id for new snapshot    */
} _gpfs_restore_t;

#define RESTORE_START       0x00000001
#define RESTORE_END         0x00000002
#define RESTORE_ENABLE      0x00000010
#define RESTORE_DISABLE     0x10000000

/* Define a structure used to pass control information
   for the restore start/end code. This structure is
   internal to gpfs and not returned to the users. */
typedef struct gpfs_rcontrol
{
  int  flags;            /* restore flags              */
  Int32 fmtVersion;      /* version from curFmtVersion    */
  Int64 snapId;          /* snapshot id                   */
  _gpfs_fs_id_t stripeId;/* FS id assigned at format time */
  Int64 time;            /* time stamp (just second)      */
} gpfs_rcontrol_t;

typedef struct gpfs_fset_rcontrol
{
  int  flags;            /* restore flags              */
  UInt32 fsetId;         /* fileet id of inode space's root fileset */
  Int32 fmtVersion;      /* version from curFmtVersion    */
  Int64 snapId;          /* snapshot id                   */
  Int64 time;            /* time stamp (just second)      */
} gpfs_fset_rcontrol_t;

/* Structure used to read a block of gpfs_iattr_t with the tsfattr commmand
   GET_INODE_BLOCK. The structure is split into two pieces: one that is
   passed to the kernel on each call and one that is resident in
   the library */

/* Define kernel parms */
typedef struct _gpfs_iscan_kx
{
  UInt32 magic;               /* magic number                   */
  UInt32 nameId;              /* id of fileset/pool             */
  Int64 instanceID;           /* instance identifier            */
  Int64 nextInode;            /* next Inode to read             */
  Int64 termInode;            /* terminate before this ino      */
  _gpfs_fssnap_id_t old_fssnapId;  /* snapId for last snapshot  */
  _gpfs_fssnap_id_t new_fssnapId;  /* snapId for new snapshot   */
  char *bufferP;              /* block of gpfs_iattr_t          */
  char *nameP;                /* pointer to fileset/pool name   */
  Int32 bufferSize;           /* size of buffer                 */
  Int32 lastOffset;           /* offset of last item            */
  Int32 nameLen;              /* length of fileset/pool name    */
  Int32 flag;                 /* do we want to skip unused inodes */
                              /* Also used to pass min EA priority
                                 for iscan_with_xattrs */
} _gpfs_iscan_kx_t;

#define SKIP_UNUSED_INODES_CHECK 0x01
#define SKIP_UNUSED_INODES       0x02

/* Define library only data */
#define ISCAN_CACHE_N_FILESETS  8
#define ISCAN_CACHE_N_DATAPOOLS 8

/* Structure used to read a block of gpfs_iattr_t with the tsfattr commmand
   GET_INODE_BLOCK */
#define ISCAN_MAGIC 0xD00FF005
#define ISCAN_FSET_MAGIC 0xD00FF006
typedef struct _gpfs_iscan
{
  _gpfs_iscan_kx_t kx;         /* kernel parms */

  int  fd;                     /* file descriptor            */
  Int32 offset;                /* offset in buffer           */
  Int64 gixbInode;             /* Inode requested on last GET_INODE_[X]BLOCK[64] */
  struct
  {
    UInt32 id;      /* id of cached fileset name           */
    UInt32 nameLen; /* length of cached fileset name       */
    char   name[CXI_MAXNAMLEN+1];   /* cached fileset name      */
  } fileset[ ISCAN_CACHE_N_FILESETS ];
  struct
  {
    UInt32 id;      /* id of cached storage pool name      */
    UInt32 nameLen; /* length of cached storage pool name */
    char   name[CXI_MAXNAMLEN+1];   /* cached storage pool name */
  } dataPool[ ISCAN_CACHE_N_DATAPOOLS ];

#ifdef FASTEA
  UInt32 reqXAttrLen;           /* length of requested extended attribute
                                   buffer */
  char *reqXAttrBufP;           /* ptr to requested xattr buffer */
  UInt32 reqXAttrPriority;      /* requested EA priority */
#endif
} _gpfs_iscan_t;

typedef struct _gpfs_iscan_fset
{
  _gpfs_iscan_kx_t kx;         /* kernel parms */

  int  fd;                     /* file descriptor            */
  Int32 offset;                /* offset in buffer           */
  Int64 gixbInode;             /* Inode requested on last GET_INODE_[X]BLOCK[64] */
  struct
  {
    UInt32 id;      /* id of cached fileset name           */
    UInt32 nameLen; /* length of cached fileset name       */
    char   name[CXI_MAXNAMLEN+1];   /* cached fileset name      */
  } fileset[ ISCAN_CACHE_N_FILESETS ];
  struct
  {
    UInt32 id;      /* id of cached storage pool name      */
    UInt32 nameLen; /* length of cached storage pool name */
    char   name[CXI_MAXNAMLEN+1];   /* cached storage pool name */
  } dataPool[ ISCAN_CACHE_N_DATAPOOLS ];

#ifdef FASTEA
  UInt32 reqXAttrLen;           /* length of requested extended attribute
                                   buffer */
  char *reqXAttrBufP;           /* ptr to requested xattr buffer */
  UInt32 reqXAttrPriority;      /* requested EA priority */
#endif
} _gpfs_iscan__fset_t;

#define CXI_INVALID_FILESET_ID     ((UInt32) -1) /* cached value */
#define CXI_INVALID_STORAGEPOOL_ID ((UInt32) -1) /*    is invalid */
#define CXI_INVALID_SNAPSHOT_ID    ((Int64) -1)

/* Define internal structure used for block level incremental reads.
   Each call to gpfs_ireadx() returns an array of changes between
   the scanned file and its previous snapshot version. */
typedef struct gpfs_idelta
{
  int   hole;                   /* =0 if data changed in the following range
                                   =1 if a hole was created in that range */
  Int64 startOffset;            /* byte offset to start of change         */
  Int64 endOffset;              /* offset at end of changed region        */
} gpfs_idelta_t;

/* Structure used to pass extended attribute information
   for GET_XATTR and SET_XATTR
   - but not to be used outside of daemon or kernel -
   use PIE/gpfs_fcntl instead */
struct tsxattrs
{
  int appId;              /* application id                   */
  int nattrs;             /* no of attributes to get or set   */
  struct tsxattr *attrs;  /* attributes to get or set         */
};

/* If this is modified, also make corresponding changes to
   tsxattrMB, which is used in mailbox communication */
struct tsxattr
{
  char *keyP;      /* attribute key              */
  int keyLen;      /* key length                 */
  char *valueP;    /* attribute value            */
  int valueLen;    /* length of attribute value  */
};

/* Structure used to pass extended attrbute information for
   get_next_inode_with_xattrs */
typedef struct _gpfs_xattr
{
  int magic;                    /* magic number defined below */
  unsigned int valueLen;        /* Length of binary value */
                                /* Each entry followed by:
                                   null-terminated name padded to double word
                                   then the binary value padded to
                                   double word boundary */

} _gpfs_xattr_t;

typedef struct _gpfs_xhdr
{
  int magic;                    /* magic number defined below */
  unsigned int totalLen;        /* length of hdr + all attributes for file.
                                   hdr is followed by _gpfs_xattr_t's */
} _gpfs_xhdr_t;


#define XATTRHDR_MAGIC 0xD00FF017   /* xattr header */
#define XATTRMORE_MAGIC 0xD00FF007  /* xattr name, value pair with more to follow */
#define XATTRLAST_MAGIC 0xD00FF037  /* xattr last name, value pair */

/* GPFS equivalent of the XATTR_CREATE and XATTR_REPLACE flags for setxattr() */
#define GPFS_XATTR_CREATE   0x00000100
#define GPFS_XATTR_REPLACE  0x00000200
#define GPFS_XATTR_DELETE   0x00000400

/* Structure used to read/write by inode number. */
#define IFILE_MAGIC 0xD00FF011
#define DIRX_BUFFER_SIZE (16*1024)
#define DELTA_BUFFER_SIZE (sizeof(gpfs_idelta_t) * 128)
#define MAX_FILE_OFFSET MAX_INT64

typedef struct _gpfs_ifile
{
  int  magic;                  /* magic number               */
  int  fd;                     /* file descriptor for root   */
  IntNative ino;               /* inode number               */
  int genNo;                   /* inode generation number    */
  Int64 snapId;                /* snapshot ID                */
  int open_flags;              /* open flags                 */
  cxiMode_t mode;              /* mode of file being read    */
  const char *symlinkP;        /* optional symlink           */
  char *bufferP;               /* buffer for read/write      */
  IntNative bufferSize;        /* size of buffer             */
  Int64 offset;                /* offset to read/write from  */
  Int64 count;                 /* length to read/write       */
  int dirCount;                /* number of directory entries*/
  char *dirBufferP;            /* buffer for directory read  */
  IntNative dirBufferSize;     /* size of dir buffer         */
  offset_t dirOffset;          /* offset in directory buffer */
  offset_t lastOffset;         /* offset of last item        */
  struct gpfs_iattr *statxP;   /* optional for open/create   */
  void *vP;                    /* inode/vnode (OS dependent)
                                  NOTE: This value cannot be trusted
                                  between calls to the kernel. */
  int *attrSizeP;              /* ptr to rtnd value for iget_attrs */

  /* Define fields for block-level incremental read/write */
  Int64 prevSnapId;            /* prev snapId                */
  _gpfs_fs_id_t prevStripeId;  /* prev stripeId              */
  int hole;                    /* read/write a hole          */
  int callBlockLevel;          /* if >=0 then call ireadx
                                  if < 0 then call iread     */
  Int64 fileSize;              /* size of file when reading deltas */
  Int64 firstOffset;           /* start of range covered by deltas */
  Int64 nextOffset;            /* in: limit on single ireadx
                                  out: next offset to read   */
  Int64 ispcMask;              /* store the ispc mask for converting
                                  backed up external to internal to
                                  new external inode numbers */
  Int32 fsetId;                /* root filesetId of the ispc */
  Int32 inodeSpaceInd;         /* inode space index */

#ifdef GPFS_VAAI
  int nLink;		       /* inode nlink */
#endif  /* GPFS_VAAI */

} _gpfs_ifile_t;

#ifdef FASTEA
#define IFILE64_MAGIC 0xD00FF017
typedef struct _gpfs_ifile64
{
  int  magic;                  /* magic number               */
  int  fd;                     /* file descriptor for root   */
  Int64 ino;                   /* inode number               */
  Int64 genNo;                 /* inode generation number    */
  Int64 snapId;                /* snapshot ID                */
  int open_flags;              /* open flags                 */
  cxiMode_t mode;              /* mode of file being read    */
  const char *symlinkP;        /* optional symlink           */
  char *bufferP;               /* buffer for read/write      */
  Int32 bufferSize;            /* size of buffer             */
  Int64 offset;                /* offset to read/write from  */
  Int64 count;                 /* length to read/write       */
  int dirCount;                /* number of directory entries*/
  char *dirBufferP;            /* buffer for directory read  */
  Int32 dirBufferSize;         /* size of dir buffer         */
  offset_t dirOffset;          /* offset in directory buffer */
  offset_t lastOffset;         /* offset of last item        */
  struct gpfs_iattr64 *statxP; /* optional for open/create   */
  void *vP;                    /* inode/vnode (OS dependent)
                                  NOTE: This value cannot be trusted
                                  between calls to the kernel. */
  int *attrSizeP;              /* ptr to rtnd value for iget_attrs */

  /* Define fields for block-level incremental read/write */
  Int64 prevSnapId;            /* prev snapId                */
  _gpfs_fs_id_t prevStripeId;  /* prev stripeId              */
  int hole;                    /* read/write a hole. Or use to indicate that a
                                  dir did not exist in the prev snapshot in case
                                  of incremental dir reads */
  int callBlockLevel;          /* if >=0 then call ireadx
                                  if < 0 then call iread     */
  Int64 fileSize;              /* size of file when reading deltas */
  Int64 firstOffset;           /* start of range covered by deltas */
  Int64 nextOffset;            /* in: limit on single ireadx
                                  out: next offset to read   */
  Int64 ispcMask;              /* store the ispc mask for converting
                                  backed up external to internal to
                                  new external inode numbers */
  int fsetId;                  /* root filesetId of the ispc */
  Int32 inodeSpaceInd;         /* inode space index */

#ifdef GPFS_VAAI
  int nLink;		       /* inode nlink */
#endif  /* GPFS_VAAI */

} _gpfs_ifile64_t;

#define IFILE_OPENFLAG_64BIT 0x80000000 /* Internal flag for 64-bit dirs */

#endif

#ifdef __cplusplus
}
#endif

#ifdef GPFS_WINDOWS
#include <kxcalls-ext.h>
#endif



typedef struct MyFillDirXArg
{
  void *kopP;
  void *privVfsP;
  void *old_gnP;
  void *new_gnP;
  void *credP;
  void *fileP;
}MyFillDirXArg;


int myFillDirX(void *fillDirArgP, const char *nameP, int namlen,
               offset_t offset, int snOffset, cxiIno_t ino, void *eP);
int myFillDir(void *fillDirArgP, const char *nameP, int namlen,
              offset_t offset, int snOffset, cxiIno_t ino, void *eP);

/* Operations defined for kxWinOps */
#define WIN_OP_GETATTRS 1
#define WIN_OP_SETATTRS 2
#define WIN_OP_REGISTER_CIFS       3
#define WIN_OP_UNREGISTER_CIFS     4
#define WIN_OP_REGISTER_CIFS_BUF   5
#define WIN_OP_UNREGISTER_CIFS_BUF 6



#endif /* _h_cxitsfattr */
