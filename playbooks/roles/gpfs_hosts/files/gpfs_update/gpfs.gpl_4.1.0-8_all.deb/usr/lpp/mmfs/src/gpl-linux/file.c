/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)95       1.242.1.2  src/avs/fs/mmfs/ts/kernext/gpl-linux/file.c, mmfs, avs_rfks1, rfks1s007a_addw 12/16/14 14:23:38 */
/*
 * File operations
 *
 * Contents:
 *   gpfs_f_llseek
 *   gpfs_f_readdir
 *   gpfs_f_poll
 *   gpfs_f_ioctl
 *   gpfs_f_unlocked_ioctl
 *   gpfs_filemap_open
 *   gpfs_filemap_close
 *   gpfs_filemap_nopage       (in mmap.c)
 *   gpfs_filemap_nopagedone   (in mmap.c)
 *   gpfs_f_mmap
 *   gpfs_f_open
 *   gpfs_f_release
 *   gpfs_f_fsync
 *   gpfs_f_fasync
 *   fsyncInternal
 *   gpfs_f_lock
 *   gpfs_f_flock
 *   rdwrInternal
 *   gpfs_f_read
 *   gpfs_f_dir_read
 *   gpfs_f_write
 *   gpfs_f_readv
 *   gpfs_f_writev
 *   gpfs_f_cleanup
 *   gpfs_f_aio_read
 *   gpfs_f_aio_write
 *   aioComplete
 *
 */
#include <Shark-gpl.h>

#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/stat.h>
#include <linux/fcntl.h>
#ifdef MODULE
#include <linux/module.h>
#endif
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/mman.h>
#include <linux/pagemap.h>
#include <linux/page-flags.h>
#ifdef IS_SYNC_KIOCB_FUNCTION
#include <linux/aio.h>
#endif

#include <linux2gpfs.h>
#ifdef P_NFS4
#include <cxiAclUser.h>
#include <linux/sunrpc/svc.h>
#include <linux/nfsd/nfsfh.h>
#endif
#include <cxiTypes.h>
#include <cxiSystem.h>
#include <cxiMode.h>
#include <cxi2gpfs.h>
#include <cxiVFSStats.h>
#include <cxiCred.h>
#include <cxiIOBuffer.h>
#include <cxiMmap.h>
#include <Trace.h>
#include <verdep.h>


/* prototypes */
static int fsyncInternal(struct file *fP, int datasync );

int gpfs_seek_internal(struct file *fP, int origin, offset_t *offset,
                       offset_t *lenP, offset_t *filesize)
{
  int rc = 0;
  cxiNode_t *cnP;
  struct inode *iP = fP->f_dentry->d_inode;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiVattr_t vattr;
  struct cxiUio_t uio;
  cxiIovec_t tmp_iovec;
#define PCOUNT 4
#define BUFFSIZE (sizeof(uint64_t)*PCOUNT)
  char buf[BUFFSIZE];
  uint64_t *bufP = (uint64_t *)&buf;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  offset_t len = 0;

  ENTER(0);
  TRACE3(TRACE_VNODE, 3, TRCID_LINUXOPS_SEEK_ENTER,
         "gpfs_seek_internal enter: iP 0x%lX what %d offset %ld",
          iP, origin, *offset);

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  gpfs_i_getattr_internal(iP);
  if (*offset >= iP->i_size)
  {
    rc = -ENXIO;
    goto out;
  }
  if (filesize)
    *filesize = iP->i_size;

  tmp_iovec.iov_base = (char *)&buf;/* base memory address */
  tmp_iovec.iov_len = BUFFSIZE;     /* length of transfer for this area */

  uio.uio_resid = BUFFSIZE;        /* length left  */
  uio.uio_iov = &tmp_iovec;        /* ptr to iovec struct array */
  uio.uio_iovcnt = 1;              /* #iovec elements left to be processed */
  uio.uio_iovdcnt = 0;             /* #iovec elements already processed */
  uio.uio_offset = *offset;        /* byte offset in file/dev to read/write*/
  uio.uio_segflg = UIO_SYSSPACE;   /* copy to kernel space */
  uio.uio_fmode = 0;

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto out;

  rc = gpfs_ops.gpfsSeek(privVfsP, NULL, cnP, 0, &uio, eCredP,
                         CXI_RDWROPTS_IREAD);

  putCred(&eCred, &eCredP);

  if(!rc)
  {
    Int64 count = bufP[0];
    Int64 lastOff = bufP[1];
    Int64 start = bufP[2];
    Int64 end = bufP[3];

    TRACE4(TRACE_VNODE, 3, TRCID_LINUXOPS_SEEK_1,
         "gpfs_seek_internal count %ld lastOff 0x%lX start 0x%lX end 0x%lX\n",
          count, lastOff, start, end);

    if (origin == SEEK_DATA) {
      if (count == 0) {         /* no data */
        *offset = iP->i_size;   /* point to eof */
        len = 0;
        rc = -ENXIO;
      }
      else {
        if (*offset < start) {     /* got data */
          len = *offset = start;   /* move offset to start of data */
        }
        else
          len = *offset;
      }
    } else {                    /* SEEK_HOLE */
      if (count != 0) {         /* got data */
        if (*offset >= start)
          *offset = len = end; /* move offset to end of data */
        else
          len = *offset;
      } else
         len = iP->i_size;
    }
    if (lenP)
      *lenP = len;
  }

out:
  TRACE4(TRACE_VNODE, 3, TRCID_LINUXOPS_SEEK_EXIT,
         "gpfs_seek_internal exit: iP 0x%lX rc %d offset %ld len %ld\n",
          iP, rc, *offset, len);

  EXIT(0);
  return rc;
}

/* file_operations */

loff_t
gpfs_f_llseek(struct file *fP, loff_t offset, int origin)
{
  struct inode *iP = fP->f_dentry->d_inode;
  loff_t rc = -EINVAL;
  struct gpfsVfsData_t *privVfsP = NULL;
  loff_t filesize;
  loff_t len;

  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_LLSEEK_ENTER,
         "gpfs_f_llseek enter: fP 0x%lX offset 0x%llX origin %d\n",
         fP, offset, origin);
  /* BKL is held at entry */

  switch (origin)
  {
    case SEEK_SET:
      break;

    case SEEK_END:
      gpfs_i_getattr_internal(iP);
      offset += iP->i_size;
      break;

    case SEEK_CUR:
      offset += fP->f_pos;
      break;

    case SEEK_DATA:
      if (offset < 0)
        goto out;
      rc = gpfs_seek_internal(fP, origin, &offset, &len, &filesize);
      if (rc || (offset > iP->i_size))
      {
        rc = -ENXIO;
        goto out;
      }
      offset = len;
      break;

    case SEEK_HOLE:
      if (offset < 0)
        goto out;
      rc = gpfs_seek_internal(fP, origin, &offset, &len, &filesize);
      if (rc)
      {
        rc = -ENXIO;
        goto out;
      }
      offset = len;
      break;

    default:
        goto out;
  }

  if (offset >= 0)
  {
    rc = offset;
    if (offset != fP->f_pos)
    {
      fP->f_pos = offset;
    }
  }
  else {
    privVfsP = VP_TO_PVP(iP);
    rc = cxiErrorNFS(rc, privVfsP, -EIO);
  }
out:
  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_LLSEEK_EXIT,
         "gpfs_f_llseek exit: fP 0x%lX offset 0x%llX origin %d rc %d rc 0x%llX\n",
         fP, offset, origin, -rc ,rc);
  EXIT(0);
  return rc;
}

/* Save everything we need to make the OS-specific filldir call. */
typedef struct {
  offset_t  offset;
  ino_t     ino;
  int       namelen;
  char      name[1];
} fillDirEntry;

/* gpfs_f_readdir provides a buffer for NFS_fillDir to place entries,
 * and this structure to keep track of its use over successive calls.
 */
typedef struct {
  fillDirEntry   *firstP;  /* first entry */
  fillDirEntry   *endP;    /* buffer end  */
  fillDirEntry   *bufferP; /* current location */
} NFS_fillDirArgs;

/* Return the location of our next filldir entry.  Allow for the size
 * of the fillDirEntry struct plus the namelen.  Round to dblword.
 */
#define NEXT_FILLDIR_ENTRY(eP, len) \
  (fillDirEntry *)((caddr_t)(eP)+(((sizeof(fillDirEntry)+(len)+3)>>2)<<2))

/* Size of our NFS_fillDir buffer. */
#if PAGE_SIZE <= 8192
#define FILLDIR_BUFSIZE PAGE_SIZE
#else
#define FILLDIR_BUFSIZE 8192
#endif

/* For NFS readdir, we provide our own filldir callback so that we can save
 * the records until after we release our locks.  We can then make the real
 * filldir calls without fear they will deadlock when they loopback to the 
 * filesystem for permission checks, etc.
 */
int
NFS_fillDir(void *myArgP, char *nameP, int namelen,
            offset_t offset, const ino_t ino)
{
  NFS_fillDirArgs *argsP = (NFS_fillDirArgs *)myArgP;
  fillDirEntry *entryP = argsP->bufferP;
  fillDirEntry *nextP = NEXT_FILLDIR_ENTRY(entryP, namelen);

  /* If this entry will not fit, report the full condition. */
  if (nextP > argsP->endP)
    return -EINVAL;

  /* Save filldir information to make the real call later */
  entryP->offset = offset;
  entryP->ino = ino;
  entryP->namelen = namelen;
  cxiMemcpy(entryP->name, nameP, namelen+1);

  /* Bump the entry location in arg structure for the next call */
  argsP->bufferP = nextP;

  return 0;
}

#ifdef HAS_READDIR
int
gpfs_f_readdir(struct file *fP, void *direntP, filldir_t filldir)
#else
int
gpfs_f_readdir(struct file *fP, struct dir_context *ctx)
#endif
{
  int rc;
  Boolean klock = false;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  struct inode *iP;
  cxiFillDirArg_t fillDirArg;
  fillDirEntry *fillDirBuf = NULL;
  NFS_fillDirArgs filldirArgs;
  int flags = cxiOpenFlagsXlate(fP->f_flags);
#if !defined(HAS_READDIR)
  filldir_t filldir = ctx->actor;
  void *direntP = (void *)ctx;
#endif
  VFS_STAT_START(readdirCall);
  ENTER(0);
  DBGASSERT(fP != NULL);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_READDIR_ENTER,
         "gpfs_f_readdir enter: fP 0x%lX direntP 0x%lX "
         "filldir 0x%lX pos %lld\n", fP, direntP, filldir, fP->f_pos);
  /* BKL is held at entry */

  /* Quick check for EOF */
  if (fP->f_pos == GPFS_DIR_EOF)
  {
    rc = 0;  // end-of-directory
  }
  else
  {

    iP = fP->f_dentry->d_inode;
    DBGASSERT(iP != NULL);
    cnP = VP_TO_CNP(iP);
    privVfsP = VP_TO_PVP(iP);
    DBGASSERT(privVfsP != NULL);

    /* When called by NFS, wait to make the filldar calls until after
     * we return from gpfsReaddir.  The NFS filldir implementation 
     * includes callbacks (e.g., permission checks) into the filesystem 
     * and these calls may result in getting locks out-of-order and 
     * are therefore subject to deadlock.
     */
    if (cxiIsNFSThread())
    {
      /* Specify a special filldir function where we will save entry 
       * information.  Upon our return from gpfsReaddir, we no longer 
       * hold any locks so we will then go through these saved entries
       * and make the real filldir calls.
       */
      fillDirArg.fnP = (void *)NFS_fillDir;
      fillDirArg.argP = &filldirArgs;

      fillDirBuf = (fillDirEntry *)cxiMallocPinned(FILLDIR_BUFSIZE);
      if (fillDirBuf == NULL)
      {
        rc = ENOMEM;
        goto xerror;
      }

      filldirArgs.firstP = fillDirBuf;
      filldirArgs.endP = (fillDirEntry *)((caddr_t)fillDirBuf + FILLDIR_BUFSIZE);
      filldirArgs.bufferP = filldirArgs.firstP;
    }
    else
    {
      /* Unfortunately we can't use the OS version of the filldir 
       * routine directly.  It has different signatures in varying
       * kernel levels, so we use cxiFillDir() in the portability layer
       * to handle the different signatures.
       */
      fillDirArg.fnP = (void *)filldir;
      fillDirArg.argP = direntP;
    }

    if (KERNEL_LOCKED())
    {
      UNLOCK_KERNEL();
      klock = true;
    }
    flags = flags & FWRITE;
    rc = gpfs_ops.gpfsReaddir(privVfsP, cnP, &fillDirArg, cxiFillDir,
                              &fP->f_pos, vnOp, NULL, fP->f_dentry, flags);

    /* Even if gpfsReaddir reports an error, we want to look
     * to see if there were any entries previously returned.
     */
    if (cxiIsNFSThread() && (filldirArgs.bufferP > filldirArgs.firstP))
    {
      int fillrc;
      fillDirEntry *nextP = filldirArgs.firstP;

      /* Set the real filldir fcn/arg pointers */
      fillDirArg.fnP = (void *)filldir;
      fillDirArg.argP = direntP;

      while(nextP < filldirArgs.bufferP)
      {
        /* Do not overlay any gpfsReadir rc. */
        fillrc = cxiFillDir(&fillDirArg, nextP->name, nextP->namelen,
                            nextP->offset, -1, nextP->ino, NULL);
        if (fillrc < 0)
        {
          rc = 0; /* entry doesn't fit is ok (will resume at offset) */

          /* Reset f_pos based on what we've been able to pass back
           * to NFS.  This is where they will start on the next call.
           */
          fP->f_pos = nextP->offset; /* next offset for nfsd_readdir */

          break;
        }
        nextP = NEXT_FILLDIR_ENTRY(nextP, nextP->namelen);
      }
    }

    if (klock)
      LOCK_KERNEL();
  }

#if !defined(HAS_READDIR)
  ctx->pos = fP->f_pos;
#endif

xerror:
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_READDIR_EXIT,
         "gpfs_f_readdir exit: fP 0x%lX pos %lld code 0 rc %d\n",
         fP, fP->f_pos, rc);

  if (fillDirBuf)
    cxiFreePinned(fillDirBuf);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}

uint
gpfs_f_poll(struct file *fP, struct poll_table_struct *wait)
{
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_POLL,
         "gpfs_f_poll: rc bits POLLERR: fP 0x%lX\n", fP);
  return (uint)0; // ?? which POLL* bits
}


#ifdef HAVE_UNLOCKED_IOCTL
long
gpfs_f_unlocked_ioctl(struct file *fP, uint cmd, unsigned long arg)
{
  struct inode *iP = NULL;
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_UNLOCKED_IOCTL,
         "gpfs_f_ioctl: rc -ENOTTY: iP 0x%lX fP 0x%lX cmd %d\n",
         iP, fP, cmd);
  
  return -ENOTTY; // no one can really explain why this errno, but it is common
}
#endif

int
gpfs_f_ioctl(struct inode *iP, struct file *fP, uint cmd, unsigned long arg)
{
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_IOCTL,
         "gpfs_f_ioctl: rc -ENOTTY: iP 0x%lX fP 0x%lX cmd %d\n",
         iP, fP, cmd);
  return -ENOTTY; // no one can really explain why this errno, but it is common
}

/* called for every child process forked after mmap */
void gpfs_filemap_open(struct vm_area_struct * vma)
{
  int rc = 0;
  Boolean writeAccess = false;
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct file *file = vma->vm_file;
  struct inode *inode = file->f_dentry->d_inode;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct mm_struct *mm = vma->vm_mm;
  long long offset;
  long long length;

  ENTER(0);
  TRACE4(TRACE_VNODE, 2, TRCID_FM_OPEN,
         "gpfs_filemap_open enter: vma 0x%lX inode %lld i_count %d name %s\n",
         vma, inode->i_ino, atomic_read((atomic_t *)&inode->i_count),
         file->f_dentry? file->f_dentry->d_name.name: (const unsigned char*)"");

  TRACE2(TRACE_VNODE, 2, TRCID_FM_OPEN_1,
         "gpfs_filemap_open : mm 0x%lX mm_users %d\n",
         mm, atomic_read(&mm->mm_users));

  cnP = VP_TO_CNP(inode);
  privVfsP = VP_TO_PVP(inode);
  DBGASSERT(privVfsP != NULL);

  if ((vma->vm_flags & VM_SHARED) && (vma->vm_flags & VM_MAYWRITE))
    MMAP_WRITE_ACCESS(writeAccess);

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;
  
  offset = vma->vm_pgoff<<PAGE_SHIFT;
  length = vma->vm_end - vma->vm_start;
  rc = gpfs_ops.gpfsMmap(privVfsP, cnP, (void *)inode, eCredP, 
                         writeAccess,false, offset,length, (void*)file->f_dentry);

  TRACE2(TRACE_VNODE, 2, TRCID_FM_OPEN_EXIT,
         "gpfs_filemap_open exit: vma 0x%lX i_count %d\n",
         vma, atomic_read((atomic_t *)&inode->i_count));
xerror:
  putCred(&eCred, &eCredP);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

  EXIT(0);
}

void gpfs_filemap_close(struct vm_area_struct * vma)
{
  struct file *fP = vma->vm_file;
  struct inode *inode = fP->f_dentry->d_inode;
  int flags, rc;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP = VP_TO_CNP(inode);
  struct mm_struct *mm = vma->vm_mm;

  VFS_STAT_START(unmapCall);
  ENTER(0);

  if ((vma->vm_flags & VM_SHARED) && (vma->vm_flags & VM_MAYWRITE))
    flags = 0;
  else
    flags = CXI_SHM_RDONLY;

  privVfsP = VP_TO_PVP(inode);

  TRACE3(TRACE_VNODE, 2, TRCID_FM_CLOSE_ENTER,
         "gpfs_filemap_close: vma 0x%lX inode 0x%lX i_count %d\n",
         vma, inode, (Int32)atomic_read((atomic_t *)&inode->i_count));
  TRACE3(TRACE_VNODE, 2, TRCID_FM_CLOSE_ENTER1,
         "gpfs_filemap_close: inode %lld, name %s, nrpages %d\n",
         inode->i_ino,
         fP->f_dentry? fP->f_dentry->d_name.name: (const unsigned char*)"",
         inode->i_data.nrpages);
  TRACE2(TRACE_VNODE, 2, TRCID_FM_CLOSE_ENR,
         "gpfs_filemap_close: mm 0x%lX mm_users %d\n",
         mm,atomic_read(&mm->mm_users));

  rc = gpfs_ops.gpfsUnmap(privVfsP, cnP, flags);
  cxiPutOSNode((void *)inode);

  TRACE3(TRACE_VNODE, 2, TRCID_FM_CLOSE,
         "gpfs_filemap_close: vma 0x%lX inode 0x%lX i_count %d\n",
         vma, inode, (Int32)atomic_read((atomic_t *)&inode->i_count));

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

  VFS_STAT_STOP;
  EXIT(0);
}

int
gpfs_f_mmap(struct file *fP, struct vm_area_struct *vma)
{
  int rc;
  int code = 0;
  Boolean heldVnode = false;
  Boolean writeAccess = false;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct inode *iP = fP->f_dentry->d_inode;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiVattr_t vattr;
  struct mm_struct *mm = vma->vm_mm;
  long long offset;
  long long length;

  VFS_STAT_START(map_lloffCall);
  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_MMAP_ENTER,
         "gpfs_f_mmap enter: fP 0x%lX inum %lld vma 0x%1X\n",
         fP, iP->i_ino, vma);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_MMAP_ENTER_A,
         "gpfs_f_mmap: vm_start 0x%lX vm_end 0x%lX, vmpgoff 0x%lX, "
         "vmflags 0x%lX\n",
         vma->vm_start, vma->vm_end, vma->vm_pgoff, vma->vm_flags);
   TRACE4(TRACE_VNODE, 2, TRCID_LINUXOPS_MMAP_ENTER_A1,
          "gpfs_f_mmap: inode %lld i_count %d name %s nrpages %d\n",
          iP->i_ino, atomic_read((atomic_t *)&iP->i_count),
          fP->f_dentry ? fP->f_dentry->d_name.name : (const unsigned char*)"",
          iP->i_data.nrpages);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_MMAP_ENTER_AB,
         "gpfs_f_mmap: mm 0x%lX mm_users %d\n",
         mm,atomic_read(&mm->mm_users));

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  if ((vma->vm_flags & VM_SHARED) && (vma->vm_flags & VM_MAYWRITE))
  {
    MMAP_WRITE_ACCESS(writeAccess);
    if (!writeAccess)
    {
      /* Patch must be applied at this kernel level for mmap write */
      code = 1;
      rc = -EINVAL;
      goto xerror;
    }
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 7;
    rc = -rc;
    goto xerror;
  }

  offset = vma->vm_pgoff<<PAGE_SHIFT;
  length = vma->vm_end - vma->vm_start;

  /* Check for negative offsets & return an error */
  if (offset < 0)
  {
    code = 8;
    rc = -EINVAL;
    goto xerror;
  }

  rc = gpfs_ops.gpfsMmap(privVfsP, cnP, (void *)iP, eCredP,
                         writeAccess, true,offset,length, (void*)fP->f_dentry);
  if (rc != 0)
  {
    code = 2;
    rc = -rc;
    goto xerror;
  }
  
  heldVnode = true;

  if ((vma->vm_flags & VM_SHARED) && (vma->vm_flags & VM_MAYWRITE) &&
      !iP->i_mapping->a_ops->writepage)
  {
    code = 3;
    rc = -EINVAL;
    goto xerror;
  }

  if (!iP->i_sb || !S_ISREG(iP->i_mode))
  {
    code = 4;
    rc = -EACCES;
    goto xerror;
  }

  if (!iP->i_mapping->a_ops->readpage)
  {
    code = 5;
    rc = -ENOEXEC;
    goto xerror;
  }

  /* revalidate linux inode */
  /* This has the effect of calling us back under a lock and
   * setting the inode attributes at the OS level (since this
   * operating system caches this info in the vfs layer)
   */
  rc = gpfs_ops.gpfsGetattr(privVfsP, cnP, &vattr, 0);
  if (rc != 0)
  {
    code = 6;
    rc = -rc;
    goto xerror;
  }

#ifdef UPDATE_ATIME
  UPDATE_ATIME(iP);
#else
#if LINUX_KERNEL_VERSION >= 2061600
#ifdef HAS_F_VFSMNT
  TOUCH_ATIME(fP->f_vfsmnt, fP->f_dentry);
#else
  TOUCH_ATIME(fP->f_path.mnt, fP->f_dentry);
#endif
#else
  update_atime(iP);
#endif
#endif
  vma->vm_ops = &gpfs_vmop;

xerror:
  putCred(&eCred, &eCredP);

  if (rc != 0 && heldVnode)
    cxiPutOSNode((void *)iP); // corresponding hold in gpfsMmap

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_MMAP_EXIT,
         "gpfs_f_mmap exit: rc %d code %d\n", rc, code);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}

int
gpfs_f_open(struct inode *iP, struct file *fP)
{
  int rc = 0;
  int code = 0;
  Boolean gotBKL = false;
  int flags = cxiOpenFlagsXlate(fP->f_flags);
  int iflags = cxiIsSambaThread()? GPFS_OPEN_NO_SMBLOCK: 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  Boolean disableSendfile = false;

  VFS_STAT_START(openCall);
  ENTER(0);
  TRACE7(TRACE_VNODE, 1, TRCID_LINUXOPS_OPEN_ENTER,
         "gpfs_f_open enter: iP 0x%lX fP 0x%lX f_flags 0x%X dP 0x%lX '%s' "
         "flags 0x%X isNFS %d\n", iP, fP, fP->f_flags, fP->f_dentry,
         fP->f_dentry? fP->f_dentry->d_name.name: (const unsigned char*)"",
         flags, cxiIsNFSThread());

  /* BKL is not held at entry, except for NFS calls */
  TraceBKL();
  if (CURRENT_LOCK_DEPTH >= 0)  /* kernel lock is held by me */
  {
    gotBKL = true;
    UNLOCK_KERNEL();
  }

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  /* see comment in gpfs_i_create() on the reason for this code */
  if (cnP->createRaceLoserThreadId &&
      cnP->createRaceLoserThreadId == cxiGetThreadId())
  {
    int fflags = cxiOpenFlagsXlate(fP->f_flags);
    int amode;

    cnP->createRaceLoserThreadId = 0;
    code = EEXIST;

    amode = ((flags & FWRITE ? W_ACC : 0) |
             (flags & FREAD ? R_ACC : 0)  |
             (flags & FTRUNC ? W_ACC : 0));

    TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_OPEN_01,
           "gpfs_f_open fileExist iP 0x%lX cnP 0x%lX fflags 0x%X amode 0x%X\n",
           iP, cnP, fflags, amode);

    /* Check if FEXCL and FCREAT are on and the file exists return EEXIST
     * could not do it at create time because the open flgas are not availble
     * on the create call.
     */
    if ((flags & FEXCL) && (flags & FCREAT))
    {
      rc = EEXIST;
      goto xerror;
    }

    rc = getCred(&eCred, &eCredP);
    if (rc)
      goto xerror;

    rc = gpfs_ops.gpfsAccess(privVfsP, cnP, amode, ACC_SELF, 
                             NULL, NULL, eCredP);
    if (rc)
      goto xerror;
  }

  if (GNP_IS_FILE(cnP) && cxiIsNFSThread())
  {
    int NFSflags;
    int code;

    BEGIN_FAR_CODE;
    /* Linux NFS will not do vget so the clone vnode cannot be created then.
       Need to GetNFS here so the NFS structures will be available. */

#ifdef NFS_CLUSTER_LOCKS //??? temp fix for NFSv4
    fP->f_mode |= FMODE_READ;
#endif

    NFSflags = FWRITE|FREAD;
#ifdef GANESHA
    if (flags & O_DIRECT)
      NFSflags |= O_DIRECT;
#endif
    rc = gpfs_ops.gpfsGetNFS((void *)iP, (void *)fP->f_dentry,
                             (struct MMFSVInfo **)&fP->private_data,
                             &NFSflags);
    if (rc != 0)
    {
      code = ENOSYS; //??EGET_NFS;
      goto xerror;
    }
    DBGASSERT((struct MMFSVInfo *)fP->private_data != NULL);

#ifdef ENABLE_IMMUTABLE_FILES
    if (flags & FWRITE &&
	( (cnP->xinfo & VA_ISIMMUTABLE) || (cnP->xinfo & VA_ISAPPENDONLY)))
    {
      /* disallow write for immutable and appendOnly files from NFS */
      TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_OPEN_IMMUTABLE,
   	     "gpfs_f_open:, flags 0x%lx, xinfo 0x%lx",
	     flags, cnP->xinfo);
      code = EROFS;
      rc = EROFS;
    }
#endif    

    /* Turn off sendfile for NFS */
    disableSendfile = true;

    END_FAR_CODE;
    goto xerror;
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

#ifdef GPFS_CACHE
  if (cxiIsGPFSThread())
    iflags |= GPFS_INTERNAL_CALL;
#endif

  rc = gpfs_ops.gpfsOpen(privVfsP, cnP, fP->f_dentry, flags, iflags, 0,
                         (struct MMFSVInfo **)&fP->private_data, eCredP, NULL);

xerror:
  putCred(&eCred, &eCredP);

#ifdef GPFS_CACHE
  /* If a pcache file is not cached, we do not want to invoke the readpage()
     interface, which will cause us to send per-page requests to the gateway node
     to fetch the data from home. While the file stays incomplete, disable
     sendfile interface */
  if (GNP_IS_FILE(cnP) && (cnP->xinfo & VA_ISINCOMPLETE))
    disableSendfile = true;
#endif

  if (rc == 0 && disableSendfile)
#ifdef REDHAT_RHEL53
    fP->f_op = (struct file_operations *)&gpfs_fops_ext_no_sendfile;
#else
    fP->f_op = &gpfs_fops_no_sendfile;
#endif

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_OPEN_EXIT,
         "gpfs_f_open exit: iP 0x%lX vinfoP 0x%lX sendfile %d code %d rc %d ",
         iP, (struct MMFSVInfo *)fP->private_data, disableSendfile, code, rc);

  VFS_STAT_STOP;

  if (gotBKL)        /* If held kernel lock on entry then reacquire it */
    LOCK_KERNEL();

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

  EXIT(0);
  return (-rc);
}

int
gpfs_f_release(struct inode *iP, struct file *fP)
{
  int rc = 0;
  int flags = cxiOpenFlagsXlate(fP->f_flags);
  struct MMFSVInfo *vinfoP = (struct MMFSVInfo *)fP->private_data;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;

  VFS_STAT_START(closeCall);
  ENTER(0);
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_CLOSE_ENTER,
         "gpfs_f_release enter: iP 0x%lX f_flags 0x%X flags 0x%X vinfoP 0x%lX\n",
         iP, fP->f_flags, flags, vinfoP);
  /* BKL is held if the file was open R/W, otherwise not held */

  /* If nfsd is closing one of its files, schedule it for a delayed close. */
  if (cnP && VP_TO_NFSP(iP) && (cxiIsNFSThread()
#if LINUX_KERNEL_VERSION >= 2063600
      /* workqueue is used to implement nfs laundromat functionality,
         but from 2.6.36 workqueue changed greatly and cxiIsNFSThread()
         no longer holds for nfs laundromat worker thread; since there's
         no good way to know we're on behalf of nfs laundromat workqueue,
         the following checks help us determine if it's nfs thread;
         nfs laundromat only calls into gpfs through gpfs_f_release, so
         cxiIsNFSThread() of other places should be safe, but beware of it */
      || (cxiStrncmp(current->comm, "kworker", 7) == 0 && vinfoP != NULL && ((struct cxiVinfo_t *)vinfoP)->viIsNFS == true)))
#else
      ))
#endif
  {
    DBGASSERT(GNP_IS_FILE(cnP));

    /* On the last NFS release, a watchdog will be set to close the file
       after a delay. */

    rc = gpfs_ops.gpfsReleaseNFS(iP);

    goto xerror;
  }

  rc = gpfs_ops.gpfsClose(privVfsP, cnP, flags, vinfoP, true, NULL);

  fP->private_data = NULL;  // MMFSVInfo was freed

xerror:
  TRACE1(TRACE_VNODE, 1, TRCID_CLOSE_EXIT,
         "gpfs_f_release exit: rc %d", rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}

int
/* struct file *fP, struct dentry *dP, loff_t start, loff_t end, int datasync */
gpfs_f_fsync(FILE_OPS_FSYNC_PARAMETERS)
{
  struct inode *inode = fP->f_mapping->host;
  int rc;

  ENTER(0);
  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_FSYNC_ENTER,
         "gpfs_f_fsync enter: fP 0x%lX datasync %d\n",
         fP, datasync);
  /* Linux doc says BKL is held, but it does not seem to be */

#ifdef LINUX_COMMIT_02c24a82
  rc = filemap_write_and_wait_range(inode->i_mapping, start, end);
  if (!rc)
  {
    /* commit 02c24a8218 pushs i_mutex down into ->fsync() handlers.
       gpfs has no need for holding i_mutex */
    rc = fsyncInternal(fP, datasync);
  }
#else
  rc = fsyncInternal(fP, datasync);
#endif

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_FSYNC_EXIT,
         "gpfs_f_fsync exit: file 0x%lX rc %d\n", fP, rc);

  EXIT(0);
  return (-rc);
}

int
gpfs_f_fasync(int fd, struct file *fP, int on)
{
  int rc;

  ENTER(0);
  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_FASYNC_ENTER,
         "gpfs_f_fasync enter: fd %d fP 0x%lX on %d\n",
         fd, fP, on);
  /* Linux doc says BKL is held, but it does not seem to be */

  rc = fsyncInternal(fP, 0);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_FASYNC_EXIT,
         "gpfs_f_fasync exit: fP 0x%lX rc %d\n", fP, rc);

  EXIT(0);
  return (-rc);
}

static int
fsyncInternal(struct file *fP, int datasync)
{
  int rc = 0;
  cxiNode_t *cnP;
  struct inode *iP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct MMFSVInfo *vinfoP;
  int flags;

  VFS_STAT_START(fsyncCall);
  ENTER(0);
  VFS_INC(fsyncCall);
  /* Creating files via nfs can get us here with a null fP. */
  if (!fP)
    goto xerror;

  vinfoP = (struct MMFSVInfo *)fP->private_data;

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  if (datasync) 
    flags = FDATASYNC;
  else 
    flags = FFILESYNC;
  rc = gpfs_ops.gpfsFsync(privVfsP, vinfoP, cnP, flags, eCredP);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EIO);

xerror:
  putCred(&eCred, &eCredP);

  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}

#ifdef NFS_CLUSTER_LOCKS
void
gpfs_grace(int on_off)
{
  gpfs_ops.gpfsGrace(on_off);
}

/* Linux 2.6.37~3.10.xx use spin-lock to replace the BKL arround
   fops->setlease(). Sleep with this lock hold will cause
   soft-lockup. The following kernel module parameter can be used to
   test it. See D.885791 for details. */
#ifdef DEBUG_SETLEASE
static int setlease_mdelay = 0;
module_param(setlease_mdelay, int, S_IRUGO|S_IWUSR);
#endif	/* DEBUG_SETLEASE */

/*
 * The function used for Linux VFS, with the fix for above issue.
 * arg is lock type F_RDLCK:0 F_WRLCK:1 F_UNLCK:2
*/
int
gpfs_f_set_lease(struct file *fP, long arg, struct file_lock **flPP)
{
  int ret;
  struct inode *inodeP = NULL;

#if defined(HAS_FILE_INODE)
  inodeP = file_inode(fP);
#endif

  /* Release the spin-lock first before we might sleep. */
  UNLOCK_FLOCKS(inodeP);
  ret = __gpfs_f_set_lease(fP, arg, flPP);

  /* Balance the spin-lock, this is safe because we never release it
     on success, which can well protect the returned flPP, see below
     comments on __gpfs_f_set_lease() */
  if (ret)
    LOCK_FLOCKS(inodeP);

  return ret;
}

/*
 * The function as fops->setlease(), used for GPFS internally.
 *
 * For kernel 2.6.37~3.10.xx, this will return with 'file_lock_lock'
 * locked on success and return NOT locked on fail. This behaviour is
 * designed to protect the returned flPP on success.
 *
 * For kernel < 2.6.37, this function needs to be called with BKL and
 * it works just as there is not any locking mechanism.
 *
 * For kernel > 3.10, currently the behaviour should be UNDEFINED
 * because 3.11-rcX is changing the locking mechanism again.
 */
int
__gpfs_f_set_lease(struct file *fP, long arg, struct file_lock **flPP)
{
  int rc = EAGAIN;
  int NFSflags, code = 0;
  int mode, oplockWant = 0;
  int oplockGot, flags;
  void *cb_token, *cookie;
  struct file_lock *flP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct MMFSVInfo *vinfoP = (struct MMFSVInfo *)fP->private_data;
  struct inode *iP = fP->f_dentry->d_inode;
  Boolean isGanesha = false;

//VFS_STAT_START(lockctlCall);
  ENTER(0);

#ifdef GANESHA
  isGanesha = cxiIsGaneshaThread();
#endif

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_LEASE_ENTER,
         "gpfs_f_set_lease: fP 0x%lX iP 0x%lX type %s by %s\n",
          fP, iP, (arg == F_RDLCK) ? "RD" :(arg == F_WRLCK) ? "WR" : "UNLCK",
          (cxiIsNFSThread()) ? "NFS" : isGanesha ? "Ganesha" : "local/samba");

  privVfsP = VP_TO_PVP(fP->f_dentry->d_inode);
  DBGASSERT(privVfsP != NULL);

  flP = *flPP;
  cookie = NULL;
  NFSflags = FREAD;
  mode = FMODE_WRITE;
  flags = RESERVE_NONE;
  oplockGot = smbOplockNone;
  cb_token = iP;

  if (arg == F_UNLCK) {
    cb_token = NULL;
    oplockWant = smbOplockNone;
    flags = RESERVE_DOWNGRADE;
  }
  else if (arg == F_RDLCK)
    oplockWant = smbOplockShared;
  else if (arg == F_WRLCK) {
    oplockWant = smbOplockExclusive;
    NFSflags |= FWRITE;
    mode = FMODE_READ;
  }
  else goto xerror;

  TRACE3(TRACE_VNODE, 3, TRCID_LINUXOPS_LEASE_1,
        "gpfs_f_set_lease: writecount %d d_count %d i_count %d\n",
         atomic_read(&iP->i_writecount), GET_DENTRY_D_COUNT(fP->f_dentry),
         atomic_read(&iP->i_count));

  /* Add this check to avoid getting the lease and than we might have to
     undo it since this check is made later when we call __setlease() */
  if ((arg == F_RDLCK) && (atomic_read(&iP->i_writecount) > 0))
  {
    code = 1;
    goto xerror;
  }
  if ((arg == F_WRLCK)
      && ((GET_DENTRY_D_COUNT(fP->f_dentry) > 1)
      || (atomic_read(&iP->i_count) > 1)))
  {
    code = 3;
    goto xerror;
  }

  if (cxiIsNFSThread())
  {
    rc = gpfs_ops.gpfsGetNFS((void *)iP, NULL, (struct MMFSVInfo **)&vinfoP,
                             &NFSflags);
    if (rc) {
      code = 2;
      goto xerror;
    }
    cnP = VP_TO_CNP(iP);

    rc = getCred(&eCred, &eCredP);
    if (rc)
      goto xerror2;

    rc = gpfs_ops.gpfsOpenNFS(privVfsP, cnP, NFSflags, vinfoP, eCredP);
    if (rc) {
      code = 4;
      goto xerror2;
    }
  }
  rc = gpfs_ops.gpfsReserveDelegation(fP, vinfoP , privVfsP, oplockWant, flags,
				      cb_token, cookie, NULL);
  if (rc) {
    code = 6;
    goto xerror2;
  }

#ifdef DEBUG_SETLEASE
  if (setlease_mdelay)
    msleep(setlease_mdelay);
#endif	/* DEBUG_SETLEASE */

  /* The generic_setlease() must be protected by lock_flocks() */
  LOCK_FLOCKS(iP);
  rc = POSIX_SETLEASE(fP, arg, flPP);
  if (rc)
  {
    /* If error, release the delegation, the spin-lock needs to be
       released before that, just in case there is any sleep. */
    UNLOCK_FLOCKS(iP);
    if (arg != F_UNLCK)
      gpfs_ops.gpfsReserveDelegation(fP, vinfoP , privVfsP, smbOplockNone,
                                     RESERVE_DOWNGRADE, NULL, NULL, NULL);
    if (rc < 0) {
      code = 7;
      rc = -rc;  /* make it positive */
    }
  }
  else
  {   // rc=0
    oplockGot = gpfs_ops.SMBGetOplockStateV(vinfoP);
    if (oplockGot == oplockWant) {
      code = 8;
      goto xerror2;
    }
    else 
    {
      /* Already lost the delegation, be aware that __break_lease()
	 will acquire the spin-lock, we must release it ahead */
      UNLOCK_FLOCKS(iP);
      BREAK_LEASE(iP, FMODE_WRITE);
      code = 10;
      rc = ENOLCK;
    }
  }

xerror2:
  putCred(&eCred, &eCredP);

  if (cxiIsNFSThread())
    gpfs_ops.gpfsReleaseNFS(iP);

xerror:
  TRACE7(TRACE_VNODE, 1, TRCID_LINUXOPS_LEASE_EXIT,
   "gpfs_f_set_lease: fP 0x%lX flP 0x%lX rc %d code %d oplockWant %d oplockGot %d %s",
    fP, flP, rc, code, oplockWant, oplockGot,
    (oplockGot == smbOplockShared) ? "RD" :
    (oplockGot == smbOplockExclusive) ? "WR" : "NONE");

//VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}
#endif

int
gpfs_f_lock(struct file *fP, int cmd, struct file_lock *flP)
{
  int rc = 0;
  int code = 0;
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  eflock_t lckdat;
  UIntPtr localRetryId = 0;
  struct MMFSVInfo *vinfoP = (struct MMFSVInfo *)fP->private_data;
  int(* vfs_callback)(struct file_lock *, struct file_lock *, int) = NULL;

  VFS_STAT_START(lockctlCall);
  ENTER(0);

  /* Linux converts flock64 to flock before calling GPFS lock routine,
     but leaves "cmd" as is. Allow these to go through. */
#if !defined(__64BIT__)
  if (cmd == F_GETLK64) cmd = F_GETLK;
  if (cmd == F_SETLK64) cmd = F_SETLK;
  if (cmd == F_SETLKW64) cmd = F_SETLKW;
#endif

  if ((cmd != F_GETLK) && (cmd != F_SETLK) && (cmd != F_SETLKW)
#ifdef NFS_CLUSTER_LOCKS
      && (cmd != F_CANCELLK)
#endif
     )
  {
    code = 2;
    rc = ENOSYS;
    goto xerror;
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  TRACE9(TRACE_VNODE, 1, TRCID_LINUXOPS_LOCKCTL_ENTER,
        "gpfs_f_lock enter: flP 0x%lX cmd %d pid %d owner 0x%lX fp 0x%lX range 0x%lX:%lX cmd %s type %s",
         flP, cmd, flP->fl_pid, flP->fl_owner, fP, flP->fl_start, flP->fl_end,
         (cmd == F_GETLK) ? "GETLK" : (cmd == F_SETLK) ? "SETLK" : "SETLKW",
         (flP->fl_type == F_RDLCK) ? "RDLCK" :
         (flP->fl_type == F_WRLCK) ? "WRLCK" : "UNLCK");

  TRACE5(TRACE_VNODE, 3, TRCID_LINUXOPS_LOCKCTL_ENTER2,
         "gpfs_f_lock       : pos 0x%lX iP 0x%lX fl_flags 0x%X uid %d gid %d",
         fP->f_pos, fP->f_dentry->d_inode, flP->fl_flags,
         eCredP->principal, eCredP->group);
  TraceBKL();

  cnP = VP_TO_CNP(fP->f_dentry->d_inode);
  privVfsP = VP_TO_PVP(fP->f_dentry->d_inode);
  DBGASSERT(privVfsP != NULL);

#ifdef NFS_CLUSTER_LOCKS
  if (flP->fl_lmops)
  {
    if (flP->fl_lmops->fl_grant &&
       (flP->fl_flags & FL_SLEEP) &&
       (cmd != F_CANCELLK) &&
       flP->fl_type != F_UNLCK)
    {
      vfs_callback = flP->fl_lmops->fl_grant;
      cmd = F_SETLKW;
    }
  }
#ifdef GANESHA
  TRACE2(TRACE_VNODE, 3, TRCID_LINUXOPS_LOCKCTL_ENTER12,
         "gpfs_f_lock: ganesha_tgid %d ganesha_tgid_old %d",
          ganesha_tgid, ganesha_tgid_old);
  /* If unlock is not for last close and owner is NULL keep locks  */
  if (flP->fl_flags & FL_CLOSE && flP->fl_type == F_UNLCK
      && (flP->fl_pid == ganesha_tgid || flP->fl_pid == ganesha_tgid_old)
     )
  {
    flP->fl_lmops = &ganesha_lock_operations;
  }
#endif
#endif

  /* convert file_lock to eflock */
  cxiVFSToFlock((void *)flP, &lckdat);

  lckdat.l_whence = SEEK_SET;

  rc = gpfs_ops.gpfsFcntl(NULL,    // KernelOperation initialized in gpfsFcntl
                          privVfsP,
                          NULL,     // struct vnode *vP or NULL
                                    // advObjP (advisory lock object) is inode
                          fP->f_dentry->d_inode,
                          flP,      // struct file_lock
                          cnP,
                          0,        // offset
                          &lckdat,  // struct cxiFlock_t
                          cmd,
                          vfs_callback, // lockd callback
                          &localRetryId,
                          eCredP,
                          vinfoP);

  /* Even if the daemon is down allow for posix locks cleanup to proceed. */
  if (rc == ESTALE && flP->fl_type == F_UNLCK) {
    code = 6;
    rc = POSIX_LOCK_FILE(fP, flP);
    TRACE3(TRACE_VNODE, 5, TRCID_LINUXOPS_LOCKCTL_DIAG5,
         "gpfs_f_lock: ESTALE rc %d fP 0x%lX, f_dentry 0x%lX",
         rc, fP, fP->f_dentry);
  }
#ifdef HAS_FL_CLOSE
  /* With the introduction of the FL_CLOSE flag, locks_remove_posix
     no longer cleans-up posix_locks following errors from its call
     to the lock file operation.  If called in this path, we must 
     remove them ourselves or posix_locks_flock will BUG when it finds
     the residual posix lock. */

  else if (rc && (flP->fl_type == F_UNLCK) && (flP->fl_flags & FL_CLOSE))
  {
    code = 8;
    rc = POSIX_LOCK_FILE(fP, flP);
    TRACE3(TRACE_VNODE, 5, TRCID_LINUXOPS_LOCKCTL_DIAG3,
         "gpfs_f_lock: rc %d fP 0x%lX, f_dentry 0x%lX",
         rc, fP, fP->f_dentry);
  }
#endif

xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 11, TRCID_LINUXOPS_LOCKCTL_DIAG2,
         "gpfs_f_lock: fP 0x%lX, f_dentry 0x%lX",
         fP, fP->f_dentry);

  VFS_STAT_STOP;

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_LOCKCTL_EXIT,
         "gpfs_f_lock exit: rc %d code %d", rc, code);

  EXIT(0);
#if defined(FILE_LOCK_DEFERRED)
  if (rc == EINPROGRESS) {
    rc = FILE_LOCK_DEFERRED;
    return (rc);
  }
#endif
  if (rc < 0)
    return (rc);
  else
    return (-rc);
}

#ifdef GPFS_FLOCK
/*
 * cmd: F_SETLKW or F_SETLK
 * fl->fl_flags = FL_FLOCK; if sys_flock(), can use other flags for NFSv4
 * fl->fl_start = 0, fl->fl_end = OFFSET_MAX;
 * fl->fl_type =
 *	LOCK_MAND		allow other processes read
 *	or LOCK_MAND&LOCK_RW 	allow other processes read and write
 *	or F_RDLCK		LOCK_SH -- a shared lock.
 *	or F_WRLCK		LOCK_EX -- an exclusive lock.
 *	or F_UNLCK		LOCK_UN -- remove an existing lock.
 *
 *	LOCK_MAND -- a `mandatory' flock. This exists to emulate Windows Share Modes.
 */
int
gpfs_f_flock(struct file *fP, int cmd, struct file_lock *flP)
{
  int rc = 0;
  struct gpfsVfsData_t *privVfsP = NULL;
  int shareWant = 0;
  int flags = 0;
  struct MMFSVInfo *vinfoP = (struct MMFSVInfo *)fP->private_data;
  privVfsP = VP_TO_PVP(fP->f_dentry->d_inode);
  DBGASSERT(privVfsP != NULL);

  VFS_STAT_START(flockCall);
  ENTER(0);

  TRACE5(TRACE_VNODE, 1, TRCID_LINUX_FLOCK_ENTER,
        "gpfs_f_flock: enter fP 0x%lX flP 0x%lX cmd %d flags 0x%X type 0x%X\n",
         fP, flP, cmd, flP->fl_flags, flP->fl_type);

  if ((cmd != F_SETLK) && (cmd != F_SETLKW))
  {
    rc = ENOSYS;
    goto xerror;
  }

  shareWant |= ALLOW_SHARE_DELETE;

  if (flP->fl_flags & FL_FLOCK) {
    /* Translate (and validate) the type arguments to our shareWant */
    if (flP->fl_type & LOCK_MAND) {
       if (flP->fl_type & LOCK_RW)
           shareWant |= coRead|coWriteM|coWriteA;
       else
           shareWant |= coRead|coWriteM|coWriteA|coDenyR;
    }
    else 
    {
      switch (flP->fl_type) 
      {
      case F_RDLCK:               /* LOCK_SH */
        shareWant |= coRead|coDenyWM|coDenyWA;
        break;
      case F_WRLCK:               /* LOCK_EX */
        shareWant |= coRead|coWriteM|coWriteA|coDenyWM|coDenyWA|coDenyR;
        break;
      case F_UNLCK:               /* LOCK_UN */
        flags |= RESERVE_DOWNGRADE;
        shareWant |= 0;
        break;
      default:
        rc = EINVAL;
        goto xerror;
      }
    }
  }
  else 
  {

//??? add code for NFSv4 shares and delegations
    shareWant = coNFS4Share;
    if (!(flP->fl_flags & FL_SLEEP))
      flags |= RESERVE_NOWAIT;

  }
  /* Call to make the reservation */
  rc = gpfs_ops.gpfsReserveShare(fP, vinfoP, privVfsP, flags, shareWant,
                                 NULL, NULL, NULL);

xerror:

 TRACE1(TRACE_VNODE, 1, TRCID_LINUX_FLOCK_EXIT,
         "gpfs_f_flock: exit rc %d\n", rc);

  if (rc)
    rc = cxiErrorNFS(rc, privVfsP, EINVAL);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}
#endif /* GPFS_FLOCK */

ssize_t
rdwrInternal(struct file *fP, cxiRdWr_t op, const struct cxiIovec_t *iovecP,
             unsigned long count, loff_t *offsetP, struct cxiUio_t *uioP,
             int options)
{
  int i, rc;
  Boolean gotBKL = false;
  ssize_t total_len = 0;
  int flags = cxiOpenFlagsXlate(fP->f_flags);
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  struct MMFSVInfo *vinfoP = (struct MMFSVInfo *)fP->private_data;
  struct inode *iP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  ssize_t tmp_len;
  struct cxiPageList_t *plP = NULL;

  ENTER(0);
  DBGASSERT(fP != NULL);
  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  TRACE11(TRACE_VNODE, 1, TRCID_LINUXOPS_RDWRINT_ENTER,
          "gpfs_f_rdwr enter: fP 0x%lX f_flags 0x%X flags 0x%X op %d "
          "iovec 0x%lX count %d offset 0x%llX "
          "dentry 0x%lX private 0x%lX iP 0x%lX name '%s'\n",
          fP, fP->f_flags, flags, op, iovecP, count, *offsetP, fP->f_dentry,
          fP->private_data, fP->f_dentry->d_inode, fP->f_dentry->d_name.name);

  /* BKL is not held at entry, except for NFS calls */
  TraceBKL();
  if (CURRENT_LOCK_DEPTH >= 0)  /* kernel lock is held by me */
  {
    gotBKL = true;
    UNLOCK_KERNEL();
  }

  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  uioP->uio_iov = (struct cxiIovec_t *)iovecP; /* ptr to iovec struct array */
  uioP->uio_iovcnt = count;         /* #iovec elements left to be processed */
  uioP->uio_iovdcnt = 0;            /* #iovec elements already processed    */
  uioP->uio_offset = *offsetP;      /* byte offset in file/dev to read/write*/
  uioP->uio_segflg = UIO_USERSPACE; /* copy to user space                   */
  uioP->uio_fmode = 0;              /* file modes from open file struct     */

  for (i = 0; i < count; i++)
  {
    total_len += iovecP[i].iov_len;
    if (iovecP[i].iov_len > 0 && iovecP[i].iov_base == NULL)
    {
      TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_RDWRINT_VECTOR,
             "gpfs_f_rdwr: iovec[%d]: iov_base 0x%lX  iov_len %d \n",
             i, iovecP[i].iov_base, iovecP[i].iov_len);
      rc = EFAULT;
      goto out;
    }
  }

  uioP->uio_resid = total_len; /* #bytes left in data area */
  uioP->uio_total_len = total_len; /* #bytes of this request */

 /* We should -EINVAL if total length is not >= 0 
  * Be careful here because uio_resid is a unsigned 
  * long not an ssize_t 
  */
  tmp_len = (ssize_t)uioP->uio_resid;
  if ( tmp_len  < 0)
  {
    rc = EINVAL;
    goto out;
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto out;

  DBGASSERT(vinfoP != NULL);

  if ((count == 1) && (((struct cxiVinfo_t*)vinfoP)->viIsDIO) &&
      (current->mm != NULL))
  {
    rc = cxiMapUserBuffer(iovecP, iovecP->iov_len, &plP);
    if (rc != 0)
      goto out;
  }

  if (op == CXI_READ || op == CXI_READ_AIO)
    rc = gpfs_ops.gpfsRead(privVfsP, NULL, cnP, flags, uioP,
                           vinfoP, NULL, NULL, eCredP, plP,
                           options | CXI_RDWROPTS_UIDREMAP |
                           (op == CXI_READ_AIO ? CXI_RDWROPTS_AIO : 0));
  else
  {
    rc = gpfs_ops.gpfsWrite(privVfsP, NULL, cnP, flags, uioP,
                            vinfoP, NULL, NULL, eCredP, plP,
                            CXI_RDWROPTS_UIDREMAP |
                            (op == CXI_WRITE_AIO ? CXI_RDWROPTS_AIO : 0));
    /* If this is a queued AIO, then hold off updating super block dirty bit
       until IO is complete - see aioDoneCallback.  Also, Linux AIO will not
       be done synchronously for NFS threads - see gpfs_f_aio_*. */
    if (rc != EIOCBQUEUED)
    {
#ifdef  HAS_S_DIRT
      iP->i_sb->s_dirt = 1;
#endif

#ifdef GPFS_ASYNC_NFS_WRITE_MARK_INODE_DIRTY
      /* GPFS file system is exported with the sync and wdelay as the default
         options on Linux. The wdelay option allows for multiple write requests
         to be committed to disc with the one operation (fsync) which can improve
         performance, but it depends on GPFS to mark the inode dirty after the
         write. On the other side if no_wdelay is specified each write will be
         committed and without support for the file operation aio_write each
         chunk in the iovec is committed. So if the export option sync is on we
         should also have wdelay on.
      */
      if (cxiIsNFSThread() && !(fP->f_flags & O_SYNC) && !rc)
        mark_inode_dirty_sync(iP);
#endif
    }
  }

out:
  putCred(&eCred, &eCredP);

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_RDWRINT_EXIT,
         "gpfs_f_rdwr exit: fP 0x%lX total_len %ld uio_resid %ld "
         "offset 0x%llX rc %d\n", fP, total_len, uioP->uio_resid,
         uioP->uio_offset, rc);

  if (plP != NULL && rc != EIOCBQUEUED)
    cxiDeallocPageList(plP);

  if (gotBKL)        /* If held kernel lock on entry then reacquire it */
    LOCK_KERNEL();

  if (rc)
  {
    rc = cxiErrorNFS(rc, privVfsP, EIO);

    EXIT(0);
    return (-rc);
  }

  *offsetP = uioP->uio_offset;
  EXIT(0);
  return (total_len - uioP->uio_resid);
}


ssize_t
gpfs_f_read(struct file *fP, char *bufP, size_t count,
            loff_t *offsetP)
{
  ssize_t rc;
  cxiIovec_t tmp_iovec;
  struct cxiUio_t uio;
  VFS_STAT_START(readCall);

  ENTER(0);
  tmp_iovec.iov_base = bufP;    /* base memory address                  */
  tmp_iovec.iov_len = count;    /* length of transfer for this area     */

  rc = rdwrInternal(fP, CXI_READ, &tmp_iovec, 1, offsetP, &uio, 0);

  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}

ssize_t
gpfs_f_dir_read(struct file *fP, char *bufP, size_t count,
                loff_t *offsetP)
{
  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_READ_DIR,
         "gpfs_f_dir_read: fP 0x%lX EISDIR\n", fP);
  return -EISDIR;
}

ssize_t
gpfs_f_write(struct file *fP, const char *bufP, size_t count,
             loff_t *offsetP)
{
  ssize_t rc;
  cxiIovec_t tmp_iovec;
  struct cxiUio_t uio;
  VFS_STAT_START(writeCall);

  ENTER(0);
  tmp_iovec.iov_base = (char *)bufP; /* base memory address              */
  tmp_iovec.iov_len = count;         /* length of transfer for this area */

  rc = rdwrInternal(fP, CXI_WRITE, &tmp_iovec, 1, offsetP, &uio, 0);

  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}


#ifndef KERNEL_HAS_NEW_AIO_FOPS
ssize_t
gpfs_f_readv(struct file *fP, const struct iovec *iovecP,
             unsigned long count, loff_t *offsetP)
{
  int rc;
  struct cxiUio_t uio;
  VFS_STAT_START(readvCall);
  ENTER(0);
  rc = rdwrInternal(fP, CXI_READ, (const struct cxiIovec_t *)iovecP,
                    count, offsetP, &uio, 0);
  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}

ssize_t
gpfs_f_writev(struct file *fP, const struct iovec *iovecP,
              unsigned long count, loff_t *offsetP)
{
  int rc;
  struct cxiUio_t uio;
  VFS_STAT_START(writevCall);
  ENTER(0);
  rc = rdwrInternal(fP, CXI_WRITE, (const struct cxiIovec_t *)iovecP,
                    count, offsetP, &uio, 0);
  VFS_STAT_STOP;
  EXIT(0);
  return rc;
}
#endif

int
gpfs_f_share(struct file *fP, unsigned int share_access, unsigned int share_deny)
{
  int err;
  struct inode *iP;
  struct dentry *dentryP;
  int shareHave, shareWant;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  cxiNode_t *cnP;
  int flags = RESERVE_NONE;
 
  ENTER(0);
  err = 0;
  dentryP = fP? fP->f_dentry: NULL;
  iP = dentryP? dentryP->d_inode: NULL;

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_SHARE_ENTER,
         "gpfs_f_share enter: fP 0x%lX inode %lld (%s) access 0x%X deny 0x%X\n",
         fP, iP? iP->i_ino: INVALID_INODE_NUMBER,
         dentryP? dentryP->d_name.name: (const unsigned char*)"",
         share_access, share_deny);

  if (fP)
    get_file(fP);

  /* Validate the file and obtain privVfsP */
  if (!iP || !(privVfsP = VP_TO_PVP(iP))) {
    err = EBADF;
    goto xerror;
  }

  if ((share_access == 0) && (share_deny == 0))
  {
    /* This type of request can happen after the server recalls a delegation.
     * We reject the request which we recognize since no access/deny flags 
     * are given.  This then causes the client to open the file at the server
     * (no delegation) and continue. */

    TRACE3(TRACE_VNODE, 3, TRCID_LINUXOPS_SHARE_RESET,
           "gpfs_f_share: RESET (fP 0x%lX iP 0x%lX privVfsP 0x%lX)\n",
           fP, iP, iP? VP_TO_PVP(fP->f_dentry->d_inode): NULL);

    goto xerror;
  }

  /* Translate (and validate) the NFS4 share/deny arguments to our shareWant */

  /* setup for the XLATE_NFS4 calls */
  err = EINVAL;
  shareWant = coNFS4Share|ALLOW_SHARE_DELETE;

  XLATE_NFS4_ACCESS(share_access, shareWant);
  XLATE_NFS4_DENY(share_deny, shareWant);

  err = getCred(&eCred, &eCredP);
  if (err)
    goto xerror;

  cnP = VP_TO_CNP(iP);
  /* Call to make the reservation */
  err = gpfs_ops.gpfsReserveShare(fP, fP->private_data, privVfsP, flags,
                                  shareWant, cnP, eCredP, NULL);

xerror:
  putCred(&eCred, &eCredP);

  if (fP) fput(fP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_SHARE_EXIT, 
         "gpfs_f_share exit: rc %d\n", err);
  EXIT(0);
  return err;
}

extern int cleanupFD;

/* gpfs_f_cleanup is a routine that runs when the last mmfsd
   process terminates.  It allows us to do some basic cleanup
   so that the daemon can be restarted nicely. */

int gpfs_f_cleanup(struct inode *iP, struct file *fP)
{
  int rc = 0;

  ENTER(0);
  if (cleanupFD)
  {
    rc = gpfs_ops.gpfsCleanup();
    cleanupFD = 0;
  }
  EXIT(0);
  return rc;
}

/* gpfs_f_direct_IO() is never called. Open currently requires a "value" in
 * gpfs_aops->direct_IO to be successful when O_DIRECT is supplied on the open
 * call. The linux "generic" file routines eventually call this op. We do not use
 * the generic file routines so gpfs_f_direct_IO is never called.
 */
#ifdef DIRECT_IO_HAS_IOV_ITER
ssize_t gpfs_f_direct_IO(int rw, struct kiocb *iocb, struct iov_iter *iterP,
                         loff_t in_offset)
#else
ssize_t gpfs_f_direct_IO(int rw, struct kiocb *iocb, const struct iovec *iovecP,
                         loff_t in_offset, unsigned long count)
#endif
{
  LOGASSERT(!"gpfs_f_direct_IO not supported");
  return 0; /* noreturn */
}


#ifdef P_NFS4
extern int cxisPNFSmds();

#if 0 // not deeded for now
int gpfs_get_deviceiter(struct super_block *sbP, u32 layout_type,
                        struct nfsd4_pnfs_dev_iter_res *iterP)
{
  struct gpfsVfsData_t *privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;

  VFS_STAT_START(pnfsGetDevicelist);
  ENTER(0);
  DBGASSERT(privVfsP != NULL);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_GET_DEVICEITER_ENTER,
         "gpfs_get_devicelist: sbP 0x%lX cook %llu verf %llu\n", sbP,
         iterP->gd_cookie, iterP->gd_verf);

  /* If this is the first invocation, return the only device id
   * (for now at least) and update the cookie.
   * With a single devid, the client will never call getdevicelist
   * more than once, so the verifier can be ignored.
   * Else indicate there are no more devices
   */
  if (iterP->gd_cookie == 0) {
    iterP->gd_devid = cxiGetDeviceId();
    iterP->gd_cookie = 1;  // incr for next invocation
  } else {
    iterP->gd_eof = 1;
  }

xerror:
  TRACE1(TRACE_VNODE, 1, TRCID_GET_DEVICEITER_EXIT,
         "gpfs_get_deviceiter exit: devid %llu\n", iterP->gd_devid);

  VFS_STAT_STOP;
  EXIT(0);
  return (0);
}
#endif

int
gpfs_layout_get(struct inode *iP, struct gpfs_exp_xdr_stream *xdr,
                const struct nfsd4_pnfs_layoutget_arg *args,
                struct nfsd4_pnfs_layoutget_res *res)
{
  int rc = NFS4_OK;
  int code = 0;
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  int open_flags = FREAD;

  VFS_STAT_START(pnfsGetLayout);
  ENTER(0);
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_GET_LAYOUT_ENTER,
         "gpfs_layout_get: iP 0x%lX p 0x%lX\n", iP, args);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 1;
    goto xerror;
  }
  if (args->lg_iomode == x_IOMODE_ANY | args->lg_iomode == x_IOMODE_RW)
    open_flags = FWRITE;

  rc = gpfs_ops.gpfsGetLayout((Int64)iP->i_ino, privVfsP, cnP, (void *)args,
                             (void *)res, (void *)xdr, eCredP, open_flags);

xerror:
  putCred(&eCred, &eCredP);


  TRACE2(TRACE_VNODE, 1, TRCID_GET_LAYOUT_EXIT,
         "gpfs_layout_get exit: code %d rc %d\n", code, rc);

  VFS_STAT_STOP;
  EXIT(0);
  return (rc);
}

/* pNFS: return layout type */
int
gpfs_layout_type(struct super_block *sbP)
{
  int err = 0, res = x_LAYOUT_NFSV4_1_FILES;
  struct gpfsVfsData_t *privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;

  if (!cxisPNFSmds())
  {
    // do we have any ionodes ?
    err = gpfs_ops.gpfsGotIOnodes(privVfsP);
    if (err != 0)
      res = -1;
  }
  TRACE2(TRACE_VNODE, 3, TRCID_LAYOUT_TYPE_EXIT,
         "gpfs_layout_type exit: err %d res %d\n", err, res);

  return res;
}


int
gpfs_layout_return(struct inode *iP, const struct nfsd4_pnfs_layoutreturn_arg *lrp)
{
  int rc = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;

  VFS_STAT_START(pnfsReturnLayout);
  ENTER(0);
  if (!iP) {
     rc = -ENOENT;
     goto xerror;
  }
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_LAYOUT_RET_ENTER,
         "gpfs_layout_return: iP 0x%lX\n", iP);

  rc = gpfs_ops.gpfsLayoutReturn(privVfsP, cnP, (void *)lrp, sizeof(struct nfsd4_pnfs_layoutreturn_arg));

xerror:
  TRACE2(TRACE_VNODE, 1, TRCID_LAYOUT_RET_EXIT,
         "gpfs_layout_return exit: code %d iP 0x%lX\n", rc, iP);

  VFS_STAT_STOP;
  EXIT(0);
  return (-rc);
}

int
gpfs_get_deviceinfo(struct super_block *sbP,
                    struct gpfs_exp_xdr_stream *xdr,
                    u32 layout_type,
                    const struct nfsd4_pnfs_deviceid *devid)
{
  int rc;
  struct gpfsVfsData_t *privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;

  VFS_STAT_START(pnfsGetDeviceinfo);
  ENTER(0);
  DBGASSERT(privVfsP != NULL);

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_GET_DEVICEINFO_ENTER,
         "gpfs_get_deviceinfo: sbP 0x%lX type %u seq %d fd %d fsid 0x%lx",
          sbP, layout_type, devid->device_id2, devid->device_id4,
          devid->devid);

  rc = gpfs_ops.gpfsGetDeviceInfo(privVfsP, (void *)devid, (void *)xdr);

xerror:
  TRACE1(TRACE_VNODE, 1, TRCID_GET_DEVICEINFO_EXIT,
         "gpfs_get_deviceinfo exit: rc %d\n", rc);

  VFS_STAT_STOP;
  EXIT(0);
  return (rc);
}

void gpfs_get_verifier(struct super_block *sbP, u32 *p)
{
  int rc;
  struct gpfsVfsData_t *privVfsP = (struct gpfsVfsData_t *)sbP->s_fs_info;

  ENTER(0);
  DBGASSERT(privVfsP != NULL);

  gpfs_ops.gpfsGetVerifier(privVfsP, p);

  EXIT(0);
  return;
}
#endif

#ifdef KERNEL_HAS_NEW_AIO_FOPS
ssize_t
gpfs_f_aio_read(struct kiocb *kiocbP, const struct iovec *kiovecP,
                unsigned long iov_count, loff_t offset)
#else
ssize_t
gpfs_f_aio_read(struct kiocb *kiocbP, char *bufP, size_t count, loff_t offset)
#endif
{
  ssize_t rc;
#ifdef KERNEL_HAS_NEW_AIO_FOPS
  Boolean freeIOvecNeeded = false;
  unsigned long index;
  /* For performance purpose, we use stack temp iovec to save interlenl
     used iovec if iov_count<=8, or else we do the alloc. */
  cxiIovec_t tmp_iovecList[8];
#else
  cxiIovec_t tmp_iovec;
  unsigned long iov_count = 1;
#endif
  cxiIovec_t *iovecP;
  struct cxiUio_t uio;
  struct cxiUio_t *uioP;
  struct cxiUioAio_t *uioaioP = NULL;
  cxiRdWr_t op;
  VFS_STAT_START(aioReadAsyncCall);

  ENTER(0);

  /* If async request, O_DIRECT, one iovec, and not O_SYNC,
     then attempt async execution. */
  if (!is_sync_kiocb(kiocbP) &&
      kiocbP->ki_filp->f_flags & O_DIRECT &&
#ifdef KERNEL_HAS_NEW_AIO_FOPS
      iov_count == 1 &&
#endif
      !(kiocbP->ki_filp->f_flags & O_SYNC))
  {
    uioaioP = cxiMallocPinned(sizeof(struct cxiUioAio_t));
    if (!uioaioP)
      goto noasync;
    cxiMemset(uioaioP, 0, sizeof(struct cxiUioAio_t));

    uioaioP->uioaio_aio.aio_kiocbP = kiocbP;
#ifdef KERNEL_HAS_NEW_AIO_FOPS
    uioaioP->uioaio_aio.aio_liov.iov_base = (char *)kiovecP->iov_base;
    uioaioP->uioaio_aio.aio_liov.iov_len = kiovecP->iov_len;
#else
    uioaioP->uioaio_aio.aio_liov.iov_base = (char *)bufP;
    uioaioP->uioaio_aio.aio_liov.iov_len = count;
#endif
    op = uioaioP->uioaio_aio.aio_op = CXI_READ_AIO;
    iovecP = &uioaioP->uioaio_aio.aio_liov;
    uioP = &uioaioP->uioaio_uio;
    uioP->uio_uioaio = uioaioP;

    DBGASSERT(!cxiIsNFSThread());   // temp - needs more code review
    DBGASSERT(CURRENT_LOCK_DEPTH < 0); // kernel lock should not be held
  }
  else
  {
noasync:
#ifdef KERNEL_HAS_NEW_AIO_FOPS
    /* gpfs_f_aio_read can be called by AIO and NFS read.
       To AIO read, we need to keep the iov_base and iov_len unchanged,
       because kernel uses them to determine the next retry. We use stack
       temp iovec to save internal used iovec if iov_count<=8, or else
       we do the alloc. */
#ifdef KERNEL_HAS_KI_OPCODE
    if ((kiocbP->ki_opcode == IOCB_CMD_PREADV) ||
        (kiocbP->ki_opcode == IOCB_CMD_PREAD))
#endif /* end of KERNEL_HAS_KI_OPCODE */
    {
      if (iov_count > 8)
      {
        iovecP = cxiMallocPinned(iov_count * sizeof(cxiIovec_t));
        if (!iovecP)
        {
          rc = ENOMEM;
          goto exit;
        }
        freeIOvecNeeded = true;
      }
      else
        iovecP = tmp_iovecList;

      for (index = 0; index < iov_count; index += 1)
      {
        iovecP[index].iov_base = kiovecP[index].iov_base;
        iovecP[index].iov_len = kiovecP[index].iov_len;
      }
    }
#ifdef KERNEL_HAS_KI_OPCODE
    else
      iovecP = (cxiIovec_t*)kiovecP;
#endif /* end of KERNEL_HAS_KI_OPCODE */
#else
    iovecP = &tmp_iovec;
    tmp_iovec.iov_base = (char *)bufP; /* base memory address              */
    tmp_iovec.iov_len = count;         /* length of transfer for this area */
#endif
    uio.uio_uioaio = NULL;
    uioP = &uio;
    op = CXI_READ;
  }

  DBGASSERT(kiocbP->ki_pos == offset);

  rc = rdwrInternal(kiocbP->ki_filp, op, iovecP, iov_count, &kiocbP->ki_pos,
                    uioP, 0);

#ifdef KERNEL_HAS_NEW_AIO_FOPS
exit:
  if (freeIOvecNeeded)
    cxiFreePinned(iovecP);
#endif

  if (rc != -EIOCBQUEUED)
  {
    if (uioaioP)
      cxiFreePinned(uioaioP);
    VFS_STAT_STOPI(aioReadSyncCall);  // aio call executed synchronous
  }
  else
    VFS_STAT_STOP;

  EXIT(0);
  return rc;
}


#ifdef KERNEL_HAS_NEW_AIO_FOPS
ssize_t
gpfs_f_aio_write(struct kiocb *kiocbP, const struct iovec *kiovecP,
                 unsigned long iov_count, loff_t offset)
#else
ssize_t
gpfs_f_aio_write(struct kiocb *kiocbP, const char *bufP, size_t count,
                 loff_t offset)
#endif
{
  ssize_t rc;
#ifdef KERNEL_HAS_NEW_AIO_FOPS
  Boolean freeIOvecNeeded = false;
  unsigned long index;
  /* For performance purpose, we use stack temp iovec to save interlenl
     used iovec if iov_count<=8, or else we do the alloc. */
  cxiIovec_t tmp_iovecList[8];
#else
  cxiIovec_t tmp_iovec;
  unsigned long iov_count = 1;
#endif
  cxiIovec_t *iovecP;
  struct cxiUio_t uio;
  struct cxiUio_t *uioP;
  struct cxiUioAio_t *uioaioP = NULL;
  cxiRdWr_t op;
  VFS_STAT_START(aioWriteAsyncCall);

  ENTER(0);

  /* If async request, O_DIRECT, one iovec, and not O_SYNC,
     then attempt async execution. */
  if (!is_sync_kiocb(kiocbP) &&
      kiocbP->ki_filp->f_flags & O_DIRECT &&
#ifdef KERNEL_HAS_NEW_AIO_FOPS
      iov_count == 1 &&
#endif
      !(kiocbP->ki_filp->f_flags & O_SYNC))
  {
    uioaioP = cxiMallocPinned(sizeof(struct cxiUioAio_t));
    if (!uioaioP)
      goto noasync;
    cxiMemset(uioaioP, 0, sizeof(struct cxiUioAio_t));

    uioaioP->uioaio_aio.aio_kiocbP = kiocbP;
#ifdef KERNEL_HAS_NEW_AIO_FOPS
    uioaioP->uioaio_aio.aio_liov.iov_base = (char *)kiovecP->iov_base;
    uioaioP->uioaio_aio.aio_liov.iov_len = kiovecP->iov_len;
#else
    uioaioP->uioaio_aio.aio_liov.iov_base = (char *)bufP;
    uioaioP->uioaio_aio.aio_liov.iov_len = count;
#endif
    op = uioaioP->uioaio_aio.aio_op = CXI_WRITE_AIO;
    iovecP = &uioaioP->uioaio_aio.aio_liov;
    uioP = &uioaioP->uioaio_uio;
    uioP->uio_uioaio = uioaioP;

    DBGASSERT(!cxiIsNFSThread());   // temp - needs more code review
    DBGASSERT(CURRENT_LOCK_DEPTH < 0); // kernel lock should not be held
  }
  else
  {
noasync:
#ifdef KERNEL_HAS_NEW_AIO_FOPS
    /* gpfs_f_aio_write can be called by AIO and NFS write.
       To AIO write, we need to keep the iov_base and iov_len unchanged,
       because kernel uses them to determine the next retry. We use stack
       temp iovec to save internal used iovec if iov_count<=8, or else
       we do the alloc. */
#ifdef KERNEL_HAS_KI_OPCODE
    if ((kiocbP->ki_opcode == IOCB_CMD_PWRITEV) ||
        (kiocbP->ki_opcode == IOCB_CMD_PWRITE))
#endif /* end of KERNEL_HAS_KI_OPCODE */
    {
      if (iov_count > 8)
      {
        iovecP = cxiMallocPinned(iov_count * sizeof(cxiIovec_t));
        if (!iovecP)
        {
          rc = ENOMEM;
          goto exit;
        }
        freeIOvecNeeded = true;
      }
      else
        iovecP = tmp_iovecList;

      for (index = 0; index < iov_count; index += 1)
      {
        iovecP[index].iov_base = kiovecP[index].iov_base;
        iovecP[index].iov_len = kiovecP[index].iov_len;
      }
    }
#ifdef KERNEL_HAS_KI_OPCODE
    else
      iovecP = (cxiIovec_t*)kiovecP;
#endif /* end of KERNEL_HAS_KI_OPCODE */
#else
    iovecP = &tmp_iovec;
    tmp_iovec.iov_base = (char *)bufP; /* base memory address              */
    tmp_iovec.iov_len = count;         /* length of transfer for this area */
#endif
    uio.uio_uioaio = NULL;
    uioP = &uio;
    op = CXI_WRITE;
  }

  DBGASSERT(kiocbP->ki_pos == offset);
  rc = rdwrInternal(kiocbP->ki_filp, op, iovecP, iov_count, &kiocbP->ki_pos,
                    uioP, 0);

#ifdef KERNEL_HAS_NEW_AIO_FOPS
exit:
  if (freeIOvecNeeded)
    cxiFreePinned(iovecP);
#endif

  if (rc != -EIOCBQUEUED)
  {
    if (uioaioP)
      cxiFreePinned(uioaioP);
    VFS_STAT_STOPI(aioWriteSyncCall);  // aio call executed synchronous
  }
  else
    VFS_STAT_STOP;

  EXIT(0);
  return rc;
}

int aioComplete(struct cxiUioAio_t *uioaioP, size_t bytesProcessed,
                int mbAioErr, Boolean mbAioCallback)
{
  struct cxiUio_t *uioP = &uioaioP->uioaio_uio;
  struct cxiAio_t *aioP = &uioaioP->uioaio_aio;
  struct file *fP;
  struct inode *iP;
  struct MMFSVInfo *vinfoP;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  int flags;
  int rc;
  int op = aioP->aio_op;
  VFS_STAT_START(op == CXI_READ_AIO ? aioReadCompleteCall : aioWriteCompleteCall);

  ENTER(0);

  fP = aioP->aio_kiocbP->ki_filp;
  DBGASSERT(fP != NULL);
  vinfoP = (struct MMFSVInfo *)fP->private_data;
  flags = cxiOpenFlagsXlate(fP->f_flags);
  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  TRACE11(TRACE_VNODE, 1, TRCID_LINUXOPS_AIOCOMPLETE_ENTER,
          "aioComplete enter: fP 0x%lX f_flags 0x%X flags 0x%X op %d "
          "iovec 0x%lX count %d offset 0x%llX "
          "dentry 0x%lX private 0x%lX iP 0x%lX name '%s'\n",
          fP, fP->f_flags, flags, aioP->aio_op, &aioP->aio_liov,
          aioP->aio_liov.iov_len, aioP->aio_kiocbP->ki_pos, fP->f_dentry,
          vinfoP, iP, fP->f_dentry->d_name.name);

  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  rc = gpfs_ops.gpfsLinuxAIOComplete(uioaioP, privVfsP, cnP, vinfoP,
                                     bytesProcessed, mbAioErr, mbAioCallback);

  /* +++ rdwrInternal IO post processing. */
#ifdef  HAS_S_DIRT
  if (op == CXI_WRITE_AIO)
    iP->i_sb->s_dirt = 1;
#endif
  /* +++ gpfs_f_aio_read and gpfs_f_aio_write IO completion post processing. */

  aio_complete(uioaioP->uioaio_aio.aio_kiocbP, rc, 0);

  cxiFreePinned(uioaioP);

  VFS_STAT_STOP;

  EXIT(0);
  return rc;
}

#if LINUX_KERNEL_VERSION >= 2062300
static ssize_t
gpfs_f_splice_read(struct file *fP, loff_t *offsetP,
                     struct pipe_inode_info *pipe, size_t count,
                     unsigned int flags)
{
  struct dentry *dentry = fP->f_path.dentry;
  ssize_t status;

  status = generic_file_splice_read(fP, offsetP, pipe, count, flags);

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_SPLICE_READ,
    "gpfs_f_splice_read: fP 0x%lX flags 0x%X offset 0x%llX count %d rc %d\n",
     fP, flags, *offsetP, count, status);

out:
  return status;
}
#endif

/* Runs when a registered cifs process terminates in order to
   cleanup the cifs tables (both process and thread/data).
*/
int gpfs_f_cleanup_cifs(struct inode *iP, struct file *fP)
{
  return gpfs_ops.gpfsCleanupCifs();
}

/* Function to allocate and deallocate file space. */
long gpfs_f_fallocate(struct file *fP, int mode, loff_t offset, loff_t len)
{
  int rc = 0;
  int code = 0, flags;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct MMFSVInfo *vinfoP;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  struct inode *iP = fP->f_dentry->d_inode;

  ENTER(0);
  TRACE4(TRACE_VNODE, 3, TRCID_LINUXOPS_FILE_FALLOC_ENTER,
         "gpfs_f_fallocate enter: iP 0x%lX mode %d offset %ld len %ld",
          iP, mode, offset, len);

  if (mode & FALLOC_FL_KEEP_SIZE)
  {
    code = 1;
    rc = -EOPNOTSUPP;
    goto xerror;
  }

  vinfoP = (struct MMFSVInfo *)fP->private_data;
  flags = cxiOpenFlagsXlate(fP->f_flags);

  privVfsP = VP_TO_PVP(iP);
  LOGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 3;
    goto xerror;
  }
  if (mode & FALLOC_FL_PUNCH_HOLE)
  {
    rc = gpfs_ops.gpfsFclear(privVfsP, cnP, flags, offset, len, vinfoP,
                             eCredP);
  }
  else if (mode == 0)
  {
     rc = gpfs_ops.gpfsFalloc(privVfsP, cnP, flags, offset, len, mode, vinfoP,
                              eCredP);
  }
  else {
    code = 5;
    rc = -EOPNOTSUPP;
  }

  putCred(&eCred, &eCredP);

xerror:
  TRACE3(TRACE_VNODE, 3, TRCID_LINUXOPS_FILE_FALLOC_EXIT,
         "gpfs_f_fallocate exit: iP 0x%lX rc %d code %d",
          iP, rc, code);

  if (rc > 0)
    rc = -rc;
  EXIT(0);
  return rc;
}


