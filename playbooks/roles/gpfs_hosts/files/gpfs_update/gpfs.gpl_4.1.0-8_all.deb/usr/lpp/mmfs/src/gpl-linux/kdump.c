/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of the author may not be used to endorse or promote products 
 *     derived from this software without specific prior written
 *     permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *************************************************************************** */
/* @(#)64       1.43  src/avs/fs/mmfs/ts/kernext/gpl-linux/kdump.c, mmfs, avs_rfks1, rfks1s007a_addw 8/1/14 15:49:34 */
/* Program to dump kernel memory by address or symbol on a running system.
   Can also get formatted dumps of some kernel data structures.  Invoke
   as 'kdump /var/mmfs/tmp/complete.map.'. */

/*
 * Contents:
 *   Init
 *   CopyString
 *   SymbolHash
 *   LookupSymbolByName
 *   AddUniqueSymbol
 *   AddSymbol
 *   SymbolAddrCompare
 *   SortSymbols
 *   LookupSymbolByAddr
 *   ExactAddrToSymbol
 *   ReadKernelMap
 *   ReadKernel
 *   GetSymbolValue
 *   kMalloc
 *   kFree
 *   kPrintf
 *   kErrPrintf
 *   kAssert
 *   CondFree
 *   DumpMemory
 *   GetHex
 *   PrintCxiNode_t
 *   Usage
 *   DoHelp
 *   main
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <regex.h>
#include <stdarg.h>

#include <cxiTypes.h>

#include <kdump.h>
#include <kdump-kern.h>

/* Symbol storage area.  Each symbol has an address, some flags, and
 * a name.  Symbols are linked into a hash table by name.  Although the
 * symbol array itself is not sorted, the auxiliary array SymsByAddrPP is
 * sorted by address to allow fast binary search by address. 
 */
int NSymbols = 0;
int SymbolTableSorted = 0;

int MaxSymbolsNum = 192 * 1024;
struct Symbol* SymbolAreaP = NULL;
struct Symbol** SymsByAddrPP = NULL;

#define SYM_HASH_BUCKETS 4093
struct Symbol* SymbolHashAnchor[SYM_HASH_BUCKETS];

/* Dwarf area.  Structure sizes and member offset for 
 * dump data formatting.
 */
int NDwarfs = 0;
int MaxDwarfsNum = 192 * 1024;
struct Dwarf *DwarfAreaP = NULL;

#define DWARF_HASH_BUCKETS 4093
struct Dwarf* DwarfHashAnchor[DWARF_HASH_BUCKETS];

/* Handle of /dev/kmem */
int KmemHandle = -1;

/* Bounds of the initial portion of kernel virtual memory.  These are
   initialized to liberal values, then tightened by reading kernel
   variables. */
unsigned long LowKernelAddr = 4096;
unsigned long HighKernelAddr = -1L;

unsigned long HighSymbolAddr = 0;

/* Head of list of vm_struct structs copied from the kernel.  These define
   which areas of kernel virtual memory are legal to access through
   /dev/kmem. */
struct vmStruct* vmListHeadP = NULL;

/* Are we reading a core file or /dev/kmem ? */
int isCore = 0;

/* core file descriptor */
int coreFD = -1;

int savefdout = -1;
int savefdin  = -1;

/* 2.6.5 ppc64/x86_64 /dev/kmem can't read high memory */

#if LINUX_KERNEL_VERSION >= 2060900 \
   || defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE) || defined(GPFS_ARCH_X86_64)
#define USE_KDUMP0
#endif

void
freeSymbolDwarfArea()
{
  struct Dwarf* tmpDwarf = NULL;
  struct Symbol* tmpSymbol = NULL;
  int index = 0;

  if (SymbolAreaP)
  {
    for (index = 0; index < MaxSymbolsNum; index ++)
    {
      tmpSymbol = &SymbolAreaP[index];
      if (tmpSymbol->nameP)
        free(tmpSymbol->nameP);
    }
    free(SymbolAreaP);
  }

  if (DwarfAreaP)
  {
    for (index = 0; index < MaxDwarfsNum; index ++) 
    {
      tmpDwarf = &DwarfAreaP[index];
      if (tmpDwarf->nameP)
        free(tmpDwarf->nameP);
    }
    free(DwarfAreaP);
  }
}

void
cmdpclose(FILE *fp)
{
  if (fp)
  {
    /* reconnect stdout/stdin */
    if (savefdout >= 0)
    {
      fflush(stdout);
      dup2(savefdout, fileno(stdout));

      close(savefdout);
      savefdout = -1;
    }
    if (savefdin >= 0)
    {
      fflush(stdin);
      dup2(savefdin, fileno(stdin));

      close(savefdin);
      savefdin = -1;
    }

    fflush(fp);
    pclose(fp);
    fflush(NULL);
  }
} 
  
FILE *
cmdpopen(char *cmd)
{
  FILE *fp;

  fp = popen(cmd, "w");
  if (fp)
  {
    /* save current connections to stdout/stdin */ 
    savefdout = dup(fileno(stdout));
    savefdin  = dup(fileno(stdin));

    /* close stdout and redirect stdout messages to cmd */
    if (dup2(fileno(fp), fileno(stdout)) < 0)
    {
      perror("cmdpopen: dup2()");
      cmdpclose(fp);
      return NULL;
    }

    /* close stdin and redirect stdin messages to cmd */
    if (dup2(fileno(fp), fileno(stdin)) < 0)
    {
      perror("cmdpopen: dup2()");
      cmdpclose(fp);
      return NULL;   
    }
  }
  return fp;
} 
    
/* Initialize */
void Init()
{
  int i;

  /* Allocate storage for symbols and put one symbol in the 
   * table at address 0 
  */
  SymbolAreaP = (struct Symbol *)malloc(MaxSymbolsNum * sizeof(struct Symbol));
  assert(SymbolAreaP != NULL);

  for (i=0; i < SYM_HASH_BUCKETS ; i++)
    SymbolHashAnchor[i] = NULL;

  DwarfAreaP = (struct Dwarf *)malloc(MaxDwarfsNum * sizeof(struct Dwarf));
  assert(DwarfAreaP != NULL);

  for (i=0; i < DWARF_HASH_BUCKETS ; i++)
    DwarfHashAnchor[i] = NULL;

  AddUniqueSymbol(0, 0, "NULL");

  if (!isCore)
  {
    /* Open /dev/kmem */
#ifdef USE_KDUMP0
    KmemHandle = open("/dev/kdump0", O_RDONLY, 0);
#else
    KmemHandle = open("/dev/kmem", O_RDONLY, 0);
#endif
    if (KmemHandle == -1)
    {
#ifdef USE_KDUMP0
      fprintf(stderr, "Cannot open /dev/kdump0\n");
#else
      fprintf(stderr, "Cannot open /dev/kmem\n");
#endif
      perror("open");
      exit(1);
    }
  }
}

/* Copy a string into the string storage area and return a 
 * pointer to the copy of the string 
 */
static char * 
CopyString(const char* p)
{
  char* newStrP = NULL;
  
  assert(p != NULL);

  newStrP = (char*)malloc(strlen(p) + 1);
  assert(newStrP != NULL);

  strcpy(newStrP, p);

  return newStrP;
}

/* Hash function for symbol table names */
static int 
SymbolHash(const char* nameP)
{
  int i;
  unsigned int hash = 0;
  int len = strlen(nameP);

  for (i=0 ; i<len ; i++)
    hash = (hash << 4) ^ nameP[i];

  return hash % SYM_HASH_BUCKETS;
}

/* Look up symbol by name.  Returns a pointer to the symbol table 
 * entry if a matching name is found, otherwise NULL. 
 */
struct Symbol * 
RESET_KDUMP_REGPARMS LookupSymbolByName(const char* nameP)
{
  struct Symbol* p;
  int h = SymbolHash(nameP);

  p = SymbolHashAnchor[h];
  while (p != NULL)
  {
    if ((p->nameP != NULL) && (strcmp(p->nameP, nameP) == 0))
    {
      DBG(printf("LookupSymbolByName: found '%s' addr 0x%lX\n", 
                 nameP, p->addr));
      return p;
    }
    p = p->hashNextP;
  }
  return NULL;
}

/* Add a symbol to the table.  The symbol name must not already be 
 * present.  Returns the address of the new symbol table entry. 
 */
struct Symbol * 
RESET_KDUMP_REGPARMS AddUniqueSymbol(unsigned long addr, int flags, char* nameP)
{
  struct Symbol* p;
  int h = SymbolHash(nameP);
  int num = 0;
  int i = 0;
  struct Symbol* tmpSymbolAreaP = NULL;
  struct Symbol* tmpSymbolItem = NULL;

  p = SymbolHashAnchor[h];
  while (p != NULL)
  {
    if (strcmp(p->nameP, nameP) == 0)
    {
      fprintf(stderr, "Symbol %s already in table with addr 0x%lX\n"
              "Failed to add symbol at addr 0x%lX\n", nameP, p->addr, addr);
      assert(!"symbol not unique in AddUniqueSymbol");
    }
    p = p->hashNextP;
  }

  if (NSymbols >= MaxSymbolsNum)
  {
    num = MaxSymbolsNum;
    /* increment 1024 items every time */
    MaxSymbolsNum += 1024;
    tmpSymbolAreaP = SymbolAreaP;
    SymbolAreaP = (struct Symbol *)malloc(MaxSymbolsNum * sizeof(struct Symbol));
    assert(SymbolAreaP != NULL);
   
    /* reset SymbolHashAnchor and put all symbols in SymbolAreaP into SymbolHashAnchor */
    for (i=0; i < SYM_HASH_BUCKETS ; i++)
      SymbolHashAnchor[i] = NULL;
    NSymbols = 0;
    for (i=0; i < num; i++)
    {
      tmpSymbolItem = &tmpSymbolAreaP[i];
      AddUniqueSymbol(tmpSymbolItem->addr, tmpSymbolItem->flags, tmpSymbolItem->nameP);
      free(tmpSymbolItem->nameP);
      tmpSymbolItem->nameP = NULL;
    }
    free(tmpSymbolAreaP);
  }

  assert(NSymbols < MaxSymbolsNum);
  p = &SymbolAreaP[NSymbols];
  NSymbols += 1;
  p->addr = addr;
  p->flags = flags;
  p->nameP = CopyString(nameP);
  p->hashNextP = SymbolHashAnchor[h];
  SymbolHashAnchor[h] = p;
  SymbolTableSorted = 0;

  if (addr > HighSymbolAddr)
    HighSymbolAddr = addr;

  return p;
}

/* Add a symbol to the table.  If the symbol name is already present,
 * append the address of the symbol to the symbol name to make it
 * unique.  Returns the address of the new symbol table entry. 
 */
struct Symbol * 
RESET_KDUMP_REGPARMS AddSymbol(unsigned long addr, int flags, char* nameP) 
{
  struct Symbol* p = LookupSymbolByName(nameP);
  char* uniqueNameP;
  int i;

  if (p == NULL)
    return AddUniqueSymbol(addr, flags, nameP);

  uniqueNameP = (char*) malloc(strlen(nameP) + 32);
  assert (uniqueNameP != NULL);
  sprintf(uniqueNameP, "%s.%lX", nameP, addr);
  for (i=1 ; ; i++)
  {
    p = LookupSymbolByName(uniqueNameP);
    if (p == NULL)
      break;
    sprintf(uniqueNameP, "%s.%lX.%d", nameP, addr, i);
  }

  p = AddUniqueSymbol(addr, flags, uniqueNameP);
  free(uniqueNameP);
  return p;
}

/* Dwarf processing.  Creates structure name and member 
   offsets for dump formatting. */
static int
DwarfHash(const char *nameP)
{
  int i;
  unsigned int hash = 0;
  int len = strlen(nameP);

  for (i=0 ; i<len ; i++)
    hash = (hash << 4) ^ nameP[i];

  return hash % DWARF_HASH_BUCKETS;
}

/* Look up a structure definition in the dwarf hash table */
struct Dwarf * 
LookupDwarfByName(const char* nameP)
{
  struct Dwarf* p;
  int h = DwarfHash(nameP);

  p = DwarfHashAnchor[h];
  while (p != NULL)
  {
    if (p->nameP && strcmp(p->nameP, nameP) == 0)
    {
      DBG(printf("LookupDwarfByName: found '%s'\n", nameP));
      return p;
    }
    p = p->hashNextP;
  }
  return NULL;
}

struct Dwarf * 
AllocDwarf(int boff, int blen, char *nameP)
{
  struct Dwarf* p;
  struct Dwarf* tmpDwarf = NULL;
  int num = 0;
  int i = 0;

  assert(NDwarfs < MaxDwarfsNum);
  p = &DwarfAreaP[NDwarfs];
  NDwarfs += 1;

  p->boff = (unsigned short)boff;
  p->blen = (unsigned short)blen;
  p->nameP = CopyString(nameP);
  p->memNextP = NULL;
  p->hashNextP = NULL;

  return p;
}

struct Dwarf *
AddDwarf(struct Dwarf *dwarfP)
{
  struct Dwarf *p;
  int h = DwarfHash(dwarfP->nameP);

  DBG(printf("AddDwarf: name %s\n", dwarfP->nameP));

  p = DwarfHashAnchor[h];
  while (p != NULL)
  {
    if (p->nameP && strcmp(p->nameP, dwarfP->nameP) == 0)
    {
      fprintf(stderr, "Dwarf %s already in table.\n", p->nameP);
      return NULL;
    }
    p = p->hashNextP;
  }

  dwarfP->hashNextP = DwarfHashAnchor[h];
  DwarfHashAnchor[h] = dwarfP;

  return DwarfHashAnchor[h];
}

/* Convert a hex string to a number.  Sets *rcP to 0 if successful, nonzero
   otherwise */
static unsigned long GetHex(const char* argP, int* rcP)
{
  char* p = NULL;
  unsigned long result;

  result = strtoul(argP, &p, 16);
  if (*p != '\0')
    *rcP = 1;
  else
    *rcP = 0;
  DBG(printf("strtoul argP 0x%lX arg '%s' result 0x%lX p 0x%lX *rcP %d\n",
             argP, argP, result, p, *rcP));
  return result;
}


/* Initialize a new dwarf node
   set all pointer to be NULL */
struct DwarfTagNode* GenDwarfNode()
{
  struct DwarfTagNode *typeP = (struct DwarfTagNode*)malloc(
                               sizeof(struct DwarfTagNode));
  assert(typeP != NULL);
  typeP->id = 0;
  typeP->name = NULL;
  typeP->atName = NULL;
  typeP->member = NULL;
  typeP->next = NULL;
  typeP->prev = NULL;
  typeP->size = 0;
  typeP->atType = 0;
  typeP->sizeFlag = -1;
  typeP->offset = -1;

  return typeP;
}

/* remove blank/tab space before and end of string
   return string without blank/tab at the begin and
   end of the input string */
char* AllocString(char* src, int len)
{
  char* ret = NULL;
  int count = 0;

  /* skip blank at the begin */
  for(count = 0; count < len; ++ count)
  {
    if ((src[count] != ' ') &&
      (src[count] != '\t') &&
      (src[count] != '\n'))
      break;
  }
  src = src + count;
  len -= count;

  /* skip blank at the end */
  for(count = len; count > 0; -- count)
  {
    if ((src[count - 1] != ' ') &&
      (src[count - 1] != '\t') &&
      (src[count -1] != '\n'))
      break;
  }
  ret = (char*)malloc(count + 1);
  assert(ret != NULL);
  memcpy(ret, src, count);
  ret[count] = '\0';

  return ret;
}

/* release all dwarf nodes' memory */
void ReleaseNode(struct DwarfTagNode* dwNodePP[],
                struct DwarfTagNode *header)
{
  struct DwarfTagNode *tmp = header;
  struct DwarfTagNode *node = NULL;
  while(tmp != NULL)
  {
    node = tmp->member;
    while(node != NULL)
    {
      tmp->member = node->next;
      free(node->name);
      free(node->atName);
      free(node);
      node = tmp->member;
    }
    node = tmp;
    tmp = tmp->next;
    free(node->name);
    free(node->atName);
    free(node);
  }

  free(dwNodePP);
}


/* find specified dwarf node by dwarf type id */
struct DwarfTagNode* findDwarfTagNode(struct DwarfTagNode* dwNodePP[],
                                     unsigned long id, int numNodes)
{
  unsigned int idMid;
  int low, high, mid;

  low = 0;
  high = numNodes - 1;
  while (low < high)
  {
    mid = (low + high + 1) / 2;
    idMid = dwNodePP[mid]->id;
    if (idMid > id)
      high = mid - 1;
    else
      low = mid;
  }

  return dwNodePP[low];
}

/* find type size by dwarf node id */
unsigned long findSizeField(struct DwarfTagNode* dwNodePP[],
                           int id, int numNodes)
{
  unsigned long ret = 0;
  struct DwarfTagNode* node = findDwarfTagNode(dwNodePP, id, numNodes);

  if (node->sizeFlag ==  1)
  {
    return node->size;
  }
  else if (node->sizeFlag == 0)
  {
    ret = findSizeField(dwNodePP, node->atType, numNodes);
    node->size = ret;
    node->sizeFlag = 1;
    return ret;
  }
  else
  {
    return 0;
  }
}

/* fill type size, once it find explicit size define, backtrace all
   parent node to fill each size field */
void FillSizeField(struct DwarfTagNode* dwNodePP[], int numNodes)
{
  int i = 0;
  struct DwarfTagNode* node = NULL;
  struct DwarfTagNode* member = NULL;
  struct DwarfTagNode* tmp = NULL;

  for (i = 0; i < numNodes; ++i)
  {
    node = dwNodePP[i];

    if (node->sizeFlag == 0)
    {
      node->size = findSizeField(dwNodePP, node->atType, numNodes);
    }

    member = node->member;
    while(member != NULL)
    {
      if (member->sizeFlag == 0)
      {
        tmp = findDwarfTagNode(dwNodePP, member->atType, numNodes);
        /* correct array member size */
        if (tmp->name && strcmp(tmp->name, "DW_TAG_array_type") == 0)
        {
          if (member->next == NULL)
          {
            member->size = node->size - member->offset;
          }
          else
          {
            member->size = member->next->offset - member->offset;
          }
        }
        else
        {
          member->size = findSizeField(dwNodePP, member->atType,
                                      numNodes);
        }
      } /* end of if (member->sizeFlag == 0) */
      member = member->next;
    } /* end of while */
  } /* end of for */
}


/* Init area to store dwarf node, 
   this area will be easy to sort and find */
struct DwarfTagNode** InitDwarfNodeArea(struct DwarfTagNode *header,
                                        int numNodes)
{
  int i = 0;
  struct DwarfTagNode* node = header;
  struct DwarfTagNode** dwNodePP = NULL;

  dwNodePP = (struct DwarfTagNode **)malloc(numNodes *
                                            sizeof(struct DwarfTagNode**));
  assert(dwNodePP != NULL);
  for (i = 0; i < numNodes; i++)
  {
    dwNodePP[i] = node;
    node = node->next;
  }

  return dwNodePP;
}


/* compare two dwarf node, will called by qsort */
static int DwarfTagNodeCompare(const void *prev, const void *next)
{
  struct DwarfTagNode** left = (struct DwarfTagNode**)prev;
  struct DwarfTagNode** right = (struct DwarfTagNode**)next;

  if ((*left)->id > (*right)->id)
  {
    return 1;
  }
  else if ((*left)->id < (*right)->id)
  {
    return -1;
  }
  else
  {
    return 0;
  }
}

void SortDwarfTagNodes(struct DwarfTagNode* dwNodePP[], int numNodes)
{
  qsort((void*)dwNodePP, numNodes, sizeof(struct DwarfTagNode*),
       DwarfTagNodeCompare);
}

/* build internal dwarf structure used in kdump-kernel.c and kdump.c
   so we can re-use the old stab structure and function
   in kdump, we don't need to implement a way to handle node's lookup
   and oragnization */
void BuildInternalDwarf(struct DwarfTagNode* dwNodePP[], int numNodes)
{
  int i = 0;
  struct DwarfTagNode *node = NULL;
  struct DwarfTagNode *member = NULL;
  struct DwarfTagNode *tmpNode = NULL;
  struct Dwarf *dwarfHeadP, *dwarfP, **tailPP;
  struct Dwarf *dwarfHeadPx, *dwarfPx;

  /* scan dwNodePP to set typedef structure */
  for (i = 0; i < numNodes; ++i)
  {
    node = dwNodePP[i];
    if (node->name && (strcmp(node->name, "DW_TAG_typedef") == 0))
    {
      tmpNode = findDwarfTagNode(dwNodePP, node->atType, numNodes);
      if (tmpNode == NULL)
        continue;
      if (tmpNode->atName == NULL)
      {
        tmpNode->atName = AllocString(node->atName, strlen(node->atName) + 1);
      }
    }
  }

  /* scan dwNodePP to add strcture type */
  for (i = 0; i < numNodes; ++i)
  {
    node = dwNodePP[i];
    if (node->name && (strcmp(node->name, "DW_TAG_structure_type") == 0) &&
      (node->atName != NULL) &&
      (node->size > 0))
    {
      DBG(printf("%s %4d\n", node->atName, node->size););

      /* skip duplicated dwarf node info */
      if (LookupDwarfByName(node->atName) != NULL)
        continue;

      /* alloc a dwarf and add it */
      dwarfHeadP = AllocDwarf(node->offset, node->size, node->atName);
      AddDwarf(dwarfHeadP);
      tailPP = &dwarfHeadP->memNextP;
      member = node->member;
      while(member != NULL)
      {
        DBG(printf("%4d %4d  %s\n", member->offset*8, member->size*8,
                  member->atName););
        /* add structure member */
        if (member->atName == NULL)
          dwarfP = AllocDwarf(member->offset * 8, member->size * 8, " ");
        else
          dwarfP = AllocDwarf(member->offset * 8, member->size * 8,
                           member->atName);
        *tailPP = dwarfP;
        tailPP = &dwarfP->memNextP;
        member = member->next;
      } /* end of while */
    } /* end of if */
  } /* end of for */
}


/* Parse a dwarf string line read from the output of "readelf --debug-dump <prog>" */
int ParseDwarfString(char *lineP, regex_t *abbPatP, regex_t *memPatP,
                     regex_t *specNamePatP,
                     int numNodes,
                     struct DwarfTagNode **headPP,
                     struct DwarfTagNode **curNodePP,
                     struct DwarfTagNode **curTypePP)
{
  int rc = 0;
  regmatch_t pmatch[10];
  struct DwarfTagNode *tmpNode = NULL;
  char matched[1024];
  char value[1024];
  char *tmpStr = NULL;
  
  rc = regexec(abbPatP, lineP, 9, pmatch, 0);
  if (rc != REG_NOMATCH)
  {
    /* find a dwarf type group */
    *curNodePP = GenDwarfNode();
    if (*headPP == NULL)
    {
      *headPP = *curNodePP;
    }

    memcpy(matched, lineP + pmatch[2].rm_so,
           pmatch[2].rm_eo - pmatch[2].rm_so);
    matched[pmatch[2].rm_eo - pmatch[2].rm_so] = 0;
    (*curNodePP)->id = GetHex(matched, &rc);
    (*curNodePP)->name = AllocString(lineP + pmatch[4].rm_so,
                                pmatch[4].rm_eo - pmatch[4].rm_so);
    NDwarfs ++;
    if ((*curNodePP)->name && strcmp((*curNodePP)->name, "DW_TAG_member") == 0)
    {
      tmpNode = (*curTypePP)->member;
      if ((*curTypePP)->member == NULL)
      {
        (*curTypePP)->member = *curNodePP;
      }
      else
      {
        while (tmpNode->next != NULL)
        {
          tmpNode = tmpNode->next;
        }
        tmpNode->next = *curNodePP;
        (*curNodePP)->prev = tmpNode;
      }
    }
    else
    {
      numNodes ++;
      if (*curTypePP != NULL)
      {
        (*curTypePP)->next = *curNodePP;
        (*curNodePP)->prev = *curTypePP;
      }
      *curTypePP = *curNodePP;
    }
  }
  else   /* skip to member */
  {
    rc = regexec(memPatP, lineP, 9, pmatch, 0);
    if (rc != REG_NOMATCH)
    {
      memcpy(matched, lineP + pmatch[2].rm_so,
             pmatch[2].rm_eo - pmatch[2].rm_so);
      matched[pmatch[2].rm_eo - pmatch[2].rm_so] = 0;
      memcpy(value, lineP + pmatch[4].rm_so,
             pmatch[4].rm_eo - pmatch[4].rm_so);
      value[pmatch[4].rm_eo - pmatch[4].rm_so] = 0;
      if (strcmp(matched, "DW_AT_name") == 0)
      {
        if ((tmpStr = strstr(lineP + pmatch[4].rm_so, "):")) != NULL)
        {
          rc = regexec(specNamePatP, tmpStr, 9, pmatch, 0);
          if (rc != REG_NOMATCH)
          {
            (*curNodePP)->atName = AllocString(tmpStr + pmatch[1].rm_so,
                                          pmatch[1].rm_eo - pmatch[1].rm_so);
            NDwarfs ++;
          }
        }
        else
        {
          (*curNodePP)->atName = AllocString(lineP + pmatch[4].rm_so,
                                        pmatch[4].rm_eo - pmatch[4].rm_so);
          NDwarfs ++;
        }
      }
      else if (strcmp(matched, "DW_AT_type") == 0)
      {
        (*curNodePP)->atType = GetHex(value, &rc);
        if ((*curNodePP)->sizeFlag == -1)
        {
          (*curNodePP)->sizeFlag = 0;
        }
      }
      else if (strcmp(matched, "DW_AT_byte_size") == 0)
      {
        (*curNodePP)->size = atoi(value);
        (*curNodePP)->sizeFlag = 1;
      }
      else if (strcmp(matched, "DW_AT_data_member_location") == 0)
      {
        memcpy(value, lineP + pmatch[7].rm_so,
               pmatch[7].rm_eo - pmatch[7].rm_so);
        value[pmatch[7].rm_eo - pmatch[7].rm_so] = 0;
        (*curNodePP)->offset = atoi(value);
      }
    } /* end of skip to member */
  }

  return numNodes;
}


/* The kdump program is compiled with -gdwarf-2 and
   -fno-eliminate-unused-debug-type options, so we run readelf
   against it to retrieve all dwarfs info.
   Since kdump-kern.c also includes kernel headers we should
   have dwarfs info for all the relevent kernel structures.  */
int GenerateDwarfs(char *dwarfProg)
{
  int rc = 0;
  int numNodes = 0;
  FILE *fP = NULL;
  regex_t abbPat, memPat, specNamePat;
  struct DwarfTagNode *headP = NULL;
  struct DwarfTagNode *curNodeP = NULL;
  struct DwarfTagNode *curTypeP = NULL;
  struct DwarfTagNode **dwNodePP = NULL;
  size_t len = 0;
  char buff[1024];
  char *lineP = NULL;

  /* pattern list
         abbrevPattern used to find each structure head
         memPattern used to find member for each structure,
         include name, size and offset */
  char abbrevPattern[] = " ([ \t]*<[0-9]+><)"
        "([0-9a-zA-Z]+)"
        "(>:[ \t]*Abbrev Number:[ \t]*[0-9]+[ \t]*\\()"
        "(DW_TAG_[a-zA-Z_]+)(\\))";
  char memPattern[] = "([ \t]*)"
        "(DW_AT_name|DW_AT_type|DW_AT_byte_size|DW_AT_data_member_location)"
        "([ \t]*:[ \t]*[<]*)"
        "([ \t0-9a-zA-Z_:\\.]+)"
        "([>\\(]*)"
        "([ \ta-zA-Z_:]*)"
        "([0-9]*)"
        "([ \\)]*)";
  char specialNamePattern[] = "[ \\(,:0-9a-z]*\\):[ \t]*"
        "([a-zA-Z0-9 _-]+)";
  char secHead[] = "The section .debug_info contains";

  /* compile regexp */
  if ((rc = regcomp(&abbPat, abbrevPattern, REG_EXTENDED)) != 0)
  {
    regerror(rc, &abbPat, buff, sizeof(buff));
    fprintf(stderr, "regcomp failed: %s\n", buff);
    return -1;
  }
  if ((rc = regcomp(&memPat, memPattern, REG_EXTENDED)) != 0)
  {
    regerror(rc, &memPat, buff, sizeof(buff));
    fprintf(stderr, "regcomp failed: %s\n", buff);
    regfree(&abbPat);
    return -1;
  }

  if ((rc = regcomp(&specNamePat, specialNamePattern, REG_EXTENDED)) != 0)
  {
    regerror(rc, &specNamePat, buff, sizeof(buff));
    fprintf(stderr, "regcomp failed: %s\n", buff);
    regfree(&abbPat);
    regfree(&memPat);
    return -1;
  }

  snprintf(buff, sizeof(buff), "/usr/bin/readelf --debug-dump %s", dwarfProg);
  DBG(printf("popen(%s)\n", buff));
  fP = popen(buff, "r");
  if (fP == NULL)
  {
    perror("popen()");
    return -1;
  }

  while (getline(&lineP, &len, fP) != -1)
  {
    if (strncmp(lineP, secHead, sizeof(secHead) - 1) == 0)
    {
      /* got the begin of debug_info section */
      break;
    }
  }
  
  while (getline(&lineP, &len, fP) != -1)
  {
    if ((lineP[0] != ' ') && (lineP[0] != '\t') && (lineP[0] != '\n'))
    {
      /* got the end of debug_info section */
      break;
    }
    numNodes = ParseDwarfString(lineP, &abbPat, &memPat, &specNamePat,
                                numNodes, &headP, &curNodeP, &curTypeP);
  }

  regfree(&abbPat);
  regfree(&memPat);
  regfree(&specNamePat);
  pclose(fP);
  if(lineP)
  {
    free(lineP);
  }

  /* allock more DwarfAreaP if preallocated is not enough */
  if (NDwarfs > MaxDwarfsNum)
  {
    free(DwarfAreaP);
    DwarfAreaP = (struct Dwarf *)malloc(MaxDwarfsNum * sizeof(struct Dwarf));
    assert(DwarfAreaP != NULL);
    MaxDwarfsNum = NDwarfs;
  }
  NDwarfs = 0;

  dwNodePP = (struct DwarfTagNode**)InitDwarfNodeArea(headP, numNodes);
  SortDwarfTagNodes(dwNodePP, numNodes);
  FillSizeField(dwNodePP, numNodes);
  BuildInternalDwarf(dwNodePP, numNodes);
  ReleaseNode(dwNodePP, headP);

  return 0;
}

/* Comparision routine used by SortSymbols.  Compares the addr fields
   of the Symbol objects reachable through the pointers given as arguments. */
static int
SymbolAddrCompare(const void* arg1P, const void* arg2P)
{
  struct Symbol** s1PP = (struct Symbol**) arg1P;
  struct Symbol** s2PP = (struct Symbol**) arg2P;
  unsigned long addr1 = (*s1PP)->addr;
  unsigned long addr2 = (*s2PP)->addr;

  if (addr1 < addr2) return -1;
  if (addr1 > addr2) return 1;

  return 0;
}


/* Build an up-to-date copy of the SymsByAddrPP array and sort it in order
   by the addr fields of the associated symbols */
static void SortSymbols()
{
  int i;

  if (SymbolTableSorted)
    return;

  if (SymsByAddrPP != NULL)
    free(SymsByAddrPP);

  SymsByAddrPP = (struct Symbol**) malloc(NSymbols * sizeof(struct Symbol**));
  assert(SymsByAddrPP != NULL);
  for (i=0 ; i<NSymbols ; i++)
    SymsByAddrPP[i] = &SymbolAreaP[i];

  qsort((void*)SymsByAddrPP, NSymbols, sizeof(struct Symbol*), 
        SymbolAddrCompare);
  SymbolTableSorted = 1;
}


/* Look up symbol by address.  Returns a pointer to the symbol table entry
   with the largest address that is less than or equal to the given
   address.  There will always be a symbol in the table with address 0,
   so this can always return a pointer to some Symbol object. */
struct Symbol* RESET_KDUMP_REGPARMS LookupSymbolByAddr(unsigned long addr)
{
  int low, high, mid;
  unsigned long addrMid;

  SortSymbols();

  /* Binary search */
  low = 0;
  high = NSymbols - 1;
  while (low < high)
  {
    mid = (low+high+1) / 2;
    addrMid = SymsByAddrPP[mid]->addr;
    if (addrMid > addr)
      high = mid - 1;
    else
      low = mid;
  }
  return SymsByAddrPP[low];
}


/* Look up a symbol by address.  If an exact match for the address is
   found, return a pointer to the symbol name, otherwise return a pointer
   to an empty string. */
const char* RESET_KDUMP_REGPARMS ExactAddrToSymbol(unsigned long addr)
{
  static const char* emptyStringP = "";
  struct Symbol* sP;

  if (addr == 0)
    return emptyStringP;
  sP = LookupSymbolByAddr(addr);
  if (sP == NULL)
    return emptyStringP;
  else
    return sP->nameP;
}


/* Read in the map file containing kernel and kernel module symbols */
static void ReadKernelMap(const char* filenameP)
{
  FILE* mapFileP;
  char lineP[4096];
  char* p;
  int len;
  int n;
  unsigned long addr;
  char flagChar;
  int flags;
  char symbolName[4096];

  mapFileP = fopen(filenameP, "r");
  if (mapFileP == NULL)
  {
    fprintf(stderr, "Cannot open kernel map file %s\n", filenameP);
    exit(1);
  }

  for(;;)
  {
    p = fgets(lineP, sizeof(lineP), mapFileP);
    if (p != lineP)
      break;
    len = strlen(lineP);
    if (lineP[len-1] != '\n')
    {
      fprintf(stderr, "Line overflow reading map file: '%s'\n",
              lineP);
      exit(1);
    }
    /* Examples of input lines:
       c0100000 A _text
       c0314030 B vmlist
       c88cc364 T lockStateToString__5LkObjUxPc
     */
    n = sscanf(lineP, "%lX %c %s\n", &addr, &flagChar, symbolName);
    if (n != 3)
    {
      fprintf(stderr, "Parse error in map file: '%s'\n", lineP);
      exit(1);
    }
    DBG(printf("map line: 0x%lX flag '%c' symbol '%s'\n",
               addr, flagChar, symbolName));
    switch (flagChar)
    {
      case 't':
      case 'T':
        flags = FL_TEXT;
        break;

      case 'b':
      case 'B':
        flags = FL_BSS;
        break;

      case 'd':
      case 'D':
        flags = FL_DATA;
        break;

      case 'r':
      case 'R':
        flags = FL_RODATA;
        break;

      case 'A':
        flags = FL_SECTION;
        break;

      case '?':
        flags = FL_KSTRTAB;
        break;

      default:
        flags = 0;
    }
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
    if (addr < 0xC000000000000000)
      addr |= 0xd000000000000000L;
#endif
    AddSymbol(addr, flags, symbolName);
  }
  fclose(mapFileP);
}


/* Read kernel memory after checking the address for validity.  If the address
   is invalid, return -1, otherwise return 0. */
int RESET_KDUMP_REGPARMS ReadKernel(unsigned long addr, void* bufP, int len, int fMap)
{
  long long desiredOffset;
  long long actualOffset;
  int lenRead;
  struct vmStruct* aListP;
  int fd;

  /* check len for validity */
  if (len < 0)
  {
    fprintf(stderr,  "ReadKernel: invalid len %d\n", len); 
    return -1;
  }

  /* Check address for validity */
  if (addr < LowKernelAddr || addr == -1)
  {
    return -1;
  }
  if (addr > HighKernelAddr || isCore)
  {
    aListP = vmListHeadP;
    while (aListP != NULL)
    {
      if (addr >= aListP->startAddr  &&
          addr+len < aListP->startAddr+aListP->areaLen)
      {
        DBG(printf("ReadKernel: addr 0x%lX in range starting at 0x%lX\n",
                   addr, aListP->startAddr));
        goto addrOK;
      }
      aListP = aListP->nextAreaP;
    }
    return -1;
  }

addrOK:
  if (isCore)
  {
    desiredOffset = aListP->file_offset + (addr - aListP->startAddr);
    fd = coreFD;
  }
  else
  {
    desiredOffset = addr - GetOffset(fMap);
    fd = KmemHandle;
  }

  actualOffset = lseek64(fd, desiredOffset, SEEK_SET);
  if (actualOffset != desiredOffset
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
      && actualOffset != (desiredOffset & 0x00000000FFFFFFFFL) )
#else
      )
#endif
  {
    fprintf(stderr, "offset set to 0x%llX instead of 0x%llX\n",
            actualOffset, desiredOffset);
    perror("llseek");
    exit(1);
  }

  lenRead = read(fd, bufP, len);
  if (len == 0)
    return lenRead;
  else
  {
    if (lenRead  != len)
    {
      return -1;
    }
  }
  return 0;
}


/* Read the current value of a kernel symbol.  Returns 0 on success, -1
   on failure. */
int RESET_KDUMP_REGPARMS GetSymbolValue(const char* nameP, void* bufP, int len)
{
  int rc;
  struct Symbol* sP;
  sP = LookupSymbolByName(nameP);
  if ((sP == NULL) || (len == 0))
    return -1;
  rc = ReadKernel(sP->addr, bufP, len, 1);
  DBG(if (len == sizeof(long))
        printf("GetSymbolValue: symbol %s has value 0x%lX\n",
               nameP, *((long*)bufP)));
  return rc;
}


/* Wrapper around malloc so it can be called from modules that include
   kernel files */
void* RESET_KDUMP_REGPARMS kMalloc(int len)
{
  return malloc(len);
}


/* Wrapper around free so it can be called from modules that include
   kernel files */
void kFree(void* p)
{
  free(p);
}

/* Wrapper around free so it can be called from modules that include
   kernel files */
int
RESET_KDUMP_REGPARMS kPrintf(const char *formatP, ...)
{
  int ret = 0;
  va_list ap;

  va_start(ap, formatP);
  ret = vprintf(formatP, ap);
  va_end(ap);

  return ret;
}

/* Wrapper around free so it can be called from modules that include
   kernel files */
int
RESET_KDUMP_REGPARMS kErrPrintf(const char *formatP, ...)
{
  int ret = 0;
  va_list ap;

  va_start(ap, formatP);
  ret = vfprintf(stderr, formatP, ap);
  va_end(ap);
  
  return ret;
}

/* Wrapper around free so it can be called from modules that include
   kernel files */
void
RESET_KDUMP_REGPARMS kAssert(int expression, char *msg, ...)
{
  va_list ap;
  if (! expression)
  {
    va_start(ap, msg);
    vfprintf(stderr, msg, ap);
    va_end(ap);
    fprintf(stderr, "can't continue, exit ...\n");
    exit(1);
  }
}

/* Conditional free.  Free storage if p is not NULL. */
void
RESET_KDUMP_REGPARMS CondFree(void* p)
{
  if (p != NULL)
    free(p);
}


/* Dump a block of memory.  Duplicate lines are supressed. */
void 
RESET_KDUMP_REGPARMS DumpMemory(char* p, int nBytes, unsigned long origin, int dumpFlags)
{
  char* origP;
  union
  {
    unsigned char i1[16];
    unsigned short i2[8];
    unsigned int i4[4];
    unsigned long long int i8[2];
  } buf;
  int row, col, lineLen, oLen;
  char ch;
  Boolean showedDots;
  int i;
  char line[128];

  origP = p;
  if (dumpFlags & DUMPMEM_ROUND)
  {
    p -= origin & 0x00000003;
    nBytes += origP - p;
    origin -= origP - p;
  }
  nBytes = 16 * ((nBytes+15) / 16);

  buf.i1[0] = *p + 1;

  showedDots = false;
  for (row=0 ; row<nBytes/16 ; row++)
  {
    if (memcmp(p, &buf, 16) != 0)
    {
      memcpy(&buf, p, 16);

      /* Dump label of this line.  Save length to indent later lines. */
      lineLen = sprintf(line, "%p: ", (void*)(origin + row*16));
      oLen = lineLen;

      /* Dump 16 bytes in hex, in address order */
      lineLen += sprintf(line+lineLen,
                         "%02x%02x%02x%02x %02x%02x%02x%02x "
                         "%02x%02x%02x%02x %02x%02x%02x%02x  *",
                         buf.i1[0], buf.i1[1], buf.i1[2], buf.i1[3],
                         buf.i1[4], buf.i1[5], buf.i1[6], buf.i1[7],
                         buf.i1[8], buf.i1[9], buf.i1[10], buf.i1[11],
                         buf.i1[12], buf.i1[13], buf.i1[14], buf.i1[15]);

      /* Dump 16 bytes as chars, translating unprintable chars to . */
      for (col=0 ; col<16 ; col++)
      {
        ch = buf.i1[col];
        if (!isalnum (ch)  &&
            !ispunct (ch))
          line[lineLen] = '.';
        else
        {
          line[lineLen] = ch;
          if (ch == '%')
          {
            lineLen += 1;
            line[lineLen] = '%';
          }
        }
        lineLen += 1;
      }
      printf("%s*\n", line);

      /* If requested, dump 16 bytes as 8 shorts */
      if (dumpFlags & DUMPMEM_I2)
      {
        for (i=0 ; i<oLen ; i++)
          line[i] = ' ';
        lineLen = oLen;
        lineLen += sprintf(line+lineLen,
                           "%04x %04x %04x %04x %04x %04x %04x %04x",
                           buf.i2[0], buf.i2[1], buf.i2[2], buf.i2[3],
                           buf.i2[4], buf.i2[5], buf.i2[6], buf.i2[7]);
        printf("%s\n", line);
      }

      /* If requested, dump 16 bytes as 4 ints */
      if (dumpFlags & DUMPMEM_I4)
      {
        for (i=0 ; i<oLen ; i++)
          line[i] = ' ';
        lineLen = oLen;
        lineLen += sprintf(line+lineLen, "%08x %08x %08x %08x",
                           buf.i4[0], buf.i4[1], buf.i4[2], buf.i4[3]);
        printf("%s\n", line);
      }

      /* If requested, dump 16 bytes as 2 long long ints */
      if (dumpFlags & DUMPMEM_I8)
      {
        for (i=0 ; i<oLen ; i++)
          line[i] = ' ';
        lineLen = oLen;
        lineLen += sprintf(line+lineLen, "%016llx  %016llx",
                           buf.i8[0], buf.i8[1]);
        printf("%s\n", line);
      }

      showedDots = false;
    }
    else
    {
      if (!showedDots)
      {
        printf(" ...\n");
        showedDots = true;
      }
    }
    p += 16;
  }

} /* end of DumpMemory */

int
RESET_KDUMP_REGPARMS DumpMemoryCast(unsigned long addr, char *symNameP)
{
  union
  {
    unsigned char  i1[4];
    unsigned short i2[2];
    unsigned int   i4;
  } buf;

  char *p, *kmemP;
  struct Dwarf *dwarfHeadP, *dwarfP;
  int rc, i, kmemLen, maxsym, indent, offchar, len, pos, toCopy, nwords;

  dwarfHeadP = LookupDwarfByName(symNameP);
  if (dwarfHeadP == NULL)
  {
    fprintf(stderr, "Dwarf: %s not found\n", symNameP);
    return -1;
  }

  kmemLen = dwarfHeadP->blen;
  if (kmemLen == 0)
    return -1;
  kmemP = malloc(kmemLen);
  if (kmemP == NULL)
    return -1;
  
  rc = ReadKernel(addr, kmemP, kmemLen, 0);
  if (rc != 0)
  {
    fprintf(stderr, "Error reading from 0x%lX for %d bytes\n", addr, kmemLen);
    goto xerror;
  }

  maxsym = 0;
  for (dwarfP = dwarfHeadP->memNextP; dwarfP != NULL; dwarfP = dwarfP->memNextP)
    if (strlen(dwarfP->nameP) > maxsym)
      maxsym = strlen(dwarfP->nameP);
  if (maxsym > 30)
    maxsym = 30;
  indent = maxsym + 2;

  for (dwarfP = dwarfHeadP->memNextP; dwarfP != NULL; dwarfP = dwarfP->memNextP)
  {
    offchar = dwarfP->boff / 8;
    if (offchar >= kmemLen)
      continue;

    len = (dwarfP->blen + 7) / 8;
    if (offchar + len > kmemLen)
      len = kmemLen - offchar;

    printf(" %s ", dwarfP->nameP);

    pos = strlen(dwarfP->nameP) + 2;
    i = (pos < indent) ? indent - pos
      : (pos - indent) % 9 == 0 ? 0
      : 9 - (pos - indent) % 9;
    printf("%*.0s", i, "");
    pos += i;
    nwords = 0;

    p = kmemP + offchar;
    while (len > 0)
    {
      toCopy = (len > 4) ? 4 : len;

      memcpy(&buf, p, toCopy);
      p += toCopy;
      len -= toCopy;
   
      if (nwords >= 6 || pos > 70)
      {
        printf("\n%*.0s", indent, "");
        pos = indent;
        nwords = 0;
      }

      if (nwords > 0)
        printf(" ");

      if (toCopy == 4)
      {
        printf("%08x", buf.i4);
        pos += 9;
        nwords++;
      }
      else if (toCopy == 2)
      {
        printf("%04x", buf.i2[0]);
      }
      else
      {
        for (i = 0; i < toCopy; i++)
          printf("%02x ", buf.i1[i]);
      }
    }
    printf("\n");
  }

xerror:
  free(kmemP);
  return rc;
}

/* Print a GPFS cxiNode_t.  Parameter may be NULL. */
void 
PrintCxiNode_t(void* parm, unsigned long addr)
{
  cxiNode_t* cP = (cxiNode_t*) parm;

  if (cP == NULL)
  {
    fprintf(stderr, "NULL cxiNode_t\n");
    return;
  }

  printf("cxiNode_t 0x%lX:\n", addr);

  printf("  osNodeP         inode 0x%lX\n", cP->osNodeP);
  printf("  nType           %s\n",
         cP->nType == cxiVNON  ? "cxiVNON" :
         cP->nType == cxiVREG  ? "cxiVREG" :
         cP->nType == cxiVDIR  ? "cxiVDIR" :
         cP->nType == cxiVBLK  ? "cxiVBLK" :
         cP->nType == cxiVCHR  ? "cxiVCHR" :
         cP->nType == cxiVLNK  ? "cxiVLNK" :
         cP->nType == cxiVSOCK ? "cxiVSOCK" :
         cP->nType == cxiVBAD  ? "cxiVBAD" :
         cP->nType == cxiVFIFO ? "cxiVFIFO" :
         cP->nType == cxiVMPC  ? "cxiVMPC" :
         "??");
  printf("  mapReadCount      %d\n", cP->mapReadCount);
  printf("  mapWriteCount     %d\n", cP->mapWriteCount);
  printf("  readCount         %d\n", cP->readCount);
  printf("  icValid           0x%X", cP->icValid);
  if (cP->icValid & CXI_IC_PERM) printf(" CXI_IC_PERM");
  if (cP->icValid & CXI_IC_ATTR) printf(" CXI_IC_ATTR");
  printf("\n");
  printf("  xinfo             0x%X\n", cP->xinfo);
  printf("  nfsP              0x%lX\n", cP->nfsP);
  printf("  ctFlags           %d\n", cP->ctFlags);
}


void
CloseCore()
{
   close(coreFD);
   coreFD = -1;
}

/* check core file is 32bit or 64bit elf format
 * return 0 means 32bit elf core file
 * return 1 means 64 elf core file
 * return -1 means error
 */
int CheckCorefile(char* corefile)
{
  unsigned char coreMaggic[16];
  openCore(corefile);
  readCore(coreMaggic, sizeof(coreMaggic));
  CloseCore();
  if (coreMaggic[4] == 1)
  {
    if (sizeof(unsigned long) != 4)
    {
      printf("\nWarning: corefile is 32bit format, but OS isn't 32bit, ");
      printf("unexpected behaviour may occur!\n\n");
    }
    return 0;
  }
  else if (coreMaggic[4] == 2)
  {
    if (sizeof(unsigned long) != 8)
    {
      printf("\nWarning: corefile is 64bit format, but OS isn't 64bit, ");
      printf("unexpected behaviour may occur!\n\n");
    }
    return 1;
  }
  else
  {
    fprintf(stderr, "Unknown core file type for %s, neither 32bit nor 64bit format\n", corefile);
    exit(1);
  }
}

void RESET_KDUMP_REGPARMS openCore(char* corefile)
{
  coreFD = open(corefile, O_RDONLY, 0);
  if (coreFD == -1)
  {
    fprintf(stderr, "Cannot open kernel core file %s\n", corefile);
    perror("open");
    exit(1);
  }
}

void RESET_KDUMP_REGPARMS readCore(void* bufP, int len)
{
  int lenActual;

  assert(coreFD != -1);
  lenActual = read(coreFD, bufP, len);
  if (len != lenActual)
  {
    fprintf(stderr,
      "Error trying to read %d bytes from core, only %d bytes read\n",
      len, lenActual);
    perror("read");
    exit(1);
  }
}

void RESET_KDUMP_REGPARMS seekCore(off_t pos)
{
  off_t curPos; 
  
  assert(coreFD != -1);

  curPos = lseek(coreFD, pos, SEEK_SET);
  if (curPos != pos)
  {
    fprintf(stderr,
      "Error trying to seek to pos %X in core, current pos %X\n",
      pos, curPos);
    perror("seek");
    exit(1);
  }
}


static void Usage()
{
  fprintf(stderr, "Usage: kdump map-file [corefile]\n");
  exit(1);
}

static void DoHelp()
{
  printf("Commands:\n"
    "  address_space addr  - dump address_space\n"
    "  cxiNode_t addr      - dump cxiNode_t\n"
    "  dentry addr         - dump dcache dentry\n"
    "  dentry_tree addr    - show dcache dentry and all of its descendants\n"
    "  fs addr             - dump fs_struct \n"
    "  inode addr          - dump inode\n"
    "  mm_struct addr      - dump mm_struct\n"
    "  page addr           - dump struct page\n"
    "  super_block [addr]  - dump super_block (if no addr: root superblock)\n"
    "  task pid            - dump task_struct for pid\n"
    "  task_struct addr    - dump task_struct\n"
    "  vfsmount addr       - dump vfsmount struct\n"
    "  vfsmount_list addr  - dump all vfsmount structs starting with addr\n"
    "  vm_area_struct addr - dump vm_area_struct\n"
    "  mem addr len        - dump memory at addr\n"
    "  mem addr dwarf      - dump memory formatted to dwarf struct name\n"
    "  mem symbol len      - dump memory at address of symbol\n"
    "  ps                  - display the list of running processes\n"
    "  btp pid             - display kernel stack traceback for process pid\n"
    "  bta                 - display stack tracebacks for all processes\n"
    "  q                   - quit\n");
}

int main(int argc, char* argvPP[])
{
  struct Symbol* sP;
  char lineP[1024];
  char* p;
  char* cmdP;
  char* arg1P;
  char* arg2P;
  char* arg3P;
  char* arg4P;
  char* arg5P;
  unsigned long addr;
  unsigned long vaddr;
  unsigned long pid;
  int len;
  void* x;
  int rc;
  FILE *outfp = NULL;

  if (argc < 2)
    Usage();

  if (argc == 3)
    ReadKernelCore(argvPP[2], CheckCorefile(argvPP[2]));

  Init();
  ReadKernelMap(argvPP[1]);
  GenerateDwarfs(argvPP[0]);
  KernInit();

  for (;;)
  {
    if (outfp)
    {
      cmdpclose(outfp);
      outfp = NULL;
    }

    printf("> ");
    p = fgets(lineP, sizeof(lineP), stdin);
    if (p == NULL)
      break;

    p = lineP;
    while (isspace(*p)) p += 1;
    if (*p == '\0')
      continue;

    cmdP = strtok(lineP, " \t\n");
    arg1P = strtok(NULL, " \t\n");
    arg2P = strtok(NULL, " \t\n");
    arg3P = strtok(NULL, " \t\n");
    arg4P = strtok(NULL, " \t\n");
    arg5P = strtok(NULL, " \t\n");

    if (arg1P && *arg1P == '|' && arg2P)
    {
      outfp = cmdpopen(arg2P);
      arg1P = arg2P = arg3P = arg4P = arg5P = NULL;
    }
    else if (arg2P && *arg2P == '|' && arg3P)
    {
      outfp = cmdpopen(arg3P);
      arg2P = arg3P = arg4P = arg5P = NULL;
    }
    else if (arg3P && *arg3P == '|' && arg4P)
    {
      outfp = cmdpopen(arg4P);
      arg3P = arg4P = arg5P = NULL;
    }
    else if (arg4P && *arg4P == '|' && arg5P)
    {
      outfp = cmdpopen(arg5P);
      arg4P = arg5P = NULL;
    }

    if (strcmp(cmdP, "?") == 0)
      DoHelp();

    else if (strcmp(cmdP, "q") == 0)
      break;

    else if (strcmp(cmdP, "quit") == 0)
      break;

    else if (strcmp(cmdP, "address_space") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetAddressSpace(addr);
      PrintAddressSpace(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "cxiNode_t") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GenericGet(addr, sizeof(cxiNode_t), 0);
      PrintCxiNode_t(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "dentry") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetDentry(addr);
      PrintDentry(x, addr);
      FreeDentry(x);
    }
    else if (strcmp(cmdP, "dentry_tree") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetDentry(addr);
      PrintDentryTree(x, addr);
      FreeDentry(x);
    }
    else if (strcmp(cmdP, "inode") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetInode(addr);
      PrintInode(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "vfsmount") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetVFSMount(addr);
      PrintVFSMount(x, addr);
      CondFree(x);
    }
#if (LINUX_KERNEL_VERSION < 3030000)
    else if (strcmp(cmdP, "vfsmount_list") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetVFSMount(addr);
      PrintVFSMountList(x, addr);
      CondFree(x);
    }
#endif    
    else if (strcmp(cmdP, "fs") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetFSStruct(addr);
      PrintFSStruct(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "mem") == 0)
    {
      int fMap = 0;
      if (arg1P == NULL || arg2P == NULL)
      {
        DoHelp();
        continue;
      }

      sP = LookupSymbolByName(arg1P);
      if (sP != NULL)
      {
        addr = sP->addr;
        fMap = 1;
      }
      else
      {
        addr = GetHex(arg1P, &rc);
        if (rc != 0)
        {
          fprintf(stderr, "Bad address %s\n", arg1P);
          continue;
        }
      }

      if (isalpha(arg2P[0]))
        DumpMemoryCast(addr, arg2P);
      else
      {
        len = strtol(arg2P, NULL, 0);
        x = malloc(len);
        if (x != NULL)
        {
          rc = ReadKernel(addr, x, len, fMap);
          if (rc != 0)
            fprintf(stderr, "Error reading from 0x%lX for %d bytes\n", 
                    addr, len);
          else
            DumpMemory((char*)x, len, addr, DUMPMEM_I4);
          free(x);
        }
      }
    }
    else if (strcmp(cmdP, "mm_struct") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetMMStruct(addr);
      PrintMMStruct(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "page") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetPage(addr);
      PrintPage(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "task") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      pid = strtoul(arg1P, NULL, 10);
      x = GetTaskStructByPID(pid, &addr);
      if (x != NULL)
      {
        PrintTaskStruct(x, addr);
        CondFree(x);
      }
    }
    else if (strcmp(cmdP, "task_struct") == 0)
    {
      addr = strtoul(arg1P, NULL, 16);
      x = GetTaskStruct(addr);
      PrintTaskStruct(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "super_block") == 0)
    {
      if (arg1P != NULL)
      {
        addr = strtoul(arg1P, NULL, 16);
        x = GetSuperBlock(addr);
      }
      else
        x = GetRootSuperBlock(&addr);
      PrintSuperBlock(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "vm_area_struct") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      addr = strtoul(arg1P, NULL, 16);
      x = GetVMAreaStruct(addr);
      PrintVMAreaStruct(x, addr);
      CondFree(x);
    }
    else if (strcmp(cmdP, "ps") == 0)
    {
      DoPs();
    }
    else if (strcmp(cmdP, "btp") == 0)
    {
      if (arg1P == NULL)
      {
        DoHelp();
        continue;
      }

      pid = atoi(arg1P);
      BacktracePid(pid);
    }
    else if (strcmp(cmdP, "bta") == 0)
    {
      BacktraceAll();
    }
    else
      fprintf(stderr, "Bad command '%s'\n", cmdP);
  }

  freeSymbolDwarfArea();
  return 0;
}
