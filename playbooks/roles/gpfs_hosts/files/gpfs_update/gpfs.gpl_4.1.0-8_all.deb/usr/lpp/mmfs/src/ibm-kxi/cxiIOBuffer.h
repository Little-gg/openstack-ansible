/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)12       1.69  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiIOBuffer.h, mmfs, avs_rfks1, rfks1s007a_addw 7/10/14 10:07:01 */
/*
 * Abstraction of an I/O buffer
 *   struct cxiIOBuffer_t
 *   InitIOBuffer
 *   GetDaemonIOBufferEndAddr
 *
 * Support for buffers that are not contiguous in memory
 *   struct cxiDiscontiguousDirectoryBuffer_t
 *   InitDiscontiguousBuffer
 *   OffsetToPtr
 *   MapContiguousBuffer
 */

#ifndef _h_cxiIOBuffer
#define _h_cxiIOBuffer

#include <cxiTypes.h>
/* Use logging definitions for non portability layer */
#if !defined(GPFS_GPL)
#include <Logger.h>
#endif /* !GPFS_GPL */


/* Abstraction of an I/O buffer.  I/O buffers are contiguous in virtual
   memory from the point of view of the GPFS daemon.  The view of the buffer
   from kernel code is platform-dependent.

   The first operation that must be performed on an I/O buffer must be to
   attach it to kernel memory.  Once this is done, the buffer may be
   accessed indirectly by transferring data between it and buffers in user
   or kernel space.  The buffer may also be mapped so that normal loads and
   stores from the kernel may access the data in the buffer.  In general,
   such a mapping will not be contiguous in the address space of the kernel,
   so the code that accesses the contents of the buffer must be aware of
   page boundaries.  Once all direct and indirect accesses to the buffer are
   complete, it must be detached from kernel memory. */

/* Forward declarations */

/* Result of making a read-only copy of a portion of an I/O buffer */
struct cxiContiguousBuffer_t;

/* Result of mapping a buffer too large to be mapped contiguously */
struct cxiDiscontiguousDirectoryBuffer_t;

/* Handle that describes a cxiIOBuffer_t that has been attached */
struct cxiIOBufferAttachment_t;

struct cxiIOBuffer_t;
struct cxiIORendezvous_t;

/* Type definition for the callback routine used by I/O routines.  The
   first parameter is a pointer to the completed MBDoDiskIOParms.  The
   second parameter indicates whether the I/O request has been assigned
   a rendezvous. */
typedef void (*cxiIODoneIntCallback_t)(void*, Boolean);


/* Entry in a scatter-gather list for physical disk I/O */
typedef struct
{
  /* Number of disk sectors and bytes to transfer to/from this buffer */
  int nSectors;
  int nBytes;

  /* Detail about the buffer referenced by baseEffAddr and xmemDescP.
     Usage is up to the caller. */
  int backBufIdx;
  void* backBufP;

  /* Base address of the buffer to use as the source/target for this
     portion of the I/O.  This is an effective address pointing within
     either the daemon's or the user's (for direct I/O) address space.
     It is used together with *xmemDescP to locate the I/O buffer in
     virtual memory. */
  char* baseEffAddr;

  /* Pointer to the cross memory descriptor of the pinned buffer used
     by this I/O.  The descriptor must be in kernel memory. */
  cxiXmem_t* xmemDescP;
} cxiIOVecEntry;


/* Include platform-specific definitions and possibly define
 * __CXI_BUFFERS_ARE_CONTIGUOUS to affect the definition of
 * cxiDiscontiguousDirectoryBuffer_t below. 
 */
#include <cxiIOBuffer-plat.h>

#include <cxiLinkList.h>

#define BUDDY_NONE  0
#define BUDDY_FIRST 1
#define BUDDY_LAST  255  /* unsigned char max */

#ifndef __cplusplus
/* forward declaration in C for Linux portability layer */
typedef struct Buffer Buffer;
typedef Buffer *BufferXPtr;
#endif

typedef struct cxiMemoryDesc_t cxiMemoryDesc_t;
typedef struct DioMemoryDesc_t DioMemoryDesc_t;

#ifdef GPFS_GPL
/* handle a few shared cxi structures (for swizzling) */
typedef cxiMemoryDesc_t* cxiMemoryDesc_tXPtr;
typedef DioMemoryDesc_t* DioMemoryDesc_tXPtr;
#endif

/* Structure to simulate a scatter gattered
   buffer from a Uio struct */
struct DioMemoryDesc_t
{
  void* vaddr;              /* user space address */
  size_t len;               
  cxiXmem_t xmemDesc;       /* Cross-memory descriptor of vaddr */
#ifdef GPFS_LINUX
  Boolean mapped;           /* cxiMapUserBuffer has been called */
#endif
#ifdef GPFS_AIX
  Boolean segAttached;      /* xmattached */
  Boolean usedXmempin;      /* pinned by xmempin() */
  Boolean pinned;           /* xlate_pin or xmempin-ed */
#endif
};

struct cxiMemoryDesc_t
{
  unsigned short vindex;    /* index in shared seg memMapping array */
  unsigned char  buddyNum;  /* buddies that can be rejoined share a number */
  unsigned char  l2KBlength;/* log base 2 of the length of area in kilobytes */
  unsigned int   offset;    /* offset within the segment - for descriptors
                               on the unpinnedDesc list whose memory has been
                               unpinned due to a reduction in page pool size,
                               the low order bit is set to 1
                               (CXI_DESC_UNPINNED).
                               See also MAX_MEM_MAPPING_KB. */

  /* If C++ would allow me to make a union between inactive and bufP
   * these could be coalesced to make the structure smaller.
   * (something on the inactive list shouldn't have a buffer)
   */
  BufferXPtr myBufP;        /* pointer to owning buffer.  NULL if memory
                               descriptor not associated with a buffer
                               (unassigned or unpinned descriptors). */

  /* list of descriptors on inactive or outsideDesc list */
  DLinkSwizzled_t inactive;

  /* circular doubly linked list of memory siblings */
  DLinkSwizzled_t sibling;

  /* next memory descriptor for scatter buffers */
  cxiMemoryDesc_tXPtr nextP;

  DioMemoryDesc_tXPtr dioDescP;
};
#define CXI_DESC_UNPINNED 0x01

/* Check if this IO buffer is a Dio user buffer. It's better to
   check descP->myBufP->getMemArea() == inDioUserBuffer, however
   this macro need to be accessed in C code */
#define IN_DIO_USER_BUFFER(descP) (((descP) != NULL) ? ((descP)->dioDescP != NULL) \
                                                     : false)

static inline Int64 GETLEN_KB(cxiMemoryDesc_t* descP)
{ 
  DBGASSERT(IN_DIO_USER_BUFFER(descP) == false);
  return 1 << (descP->l2KBlength);
};

#define GETLEN_BYTES(_d) (((_d) != NULL) ? (IN_DIO_USER_BUFFER(_d) ? (_d)->dioDescP->len \
                                                                   : 1 << (10 + (_d)->l2KBlength)) \
                                         : 0)

static inline void 
InitMemoryDesc(struct cxiMemoryDesc_t* mdP)
{
  mdP->vindex = 0;
  mdP->buddyNum = BUDDY_NONE;
  mdP->l2KBlength = 0;
  mdP->offset = 0;
  mdP->myBufP = NULL;
  DLinkInit(&mdP->inactive);
  DLinkInit(&mdP->sibling);
  mdP->nextP = NULL;
  mdP->dioDescP = NULL;
}

/* I/O buffer description

   On AIX, an I/O buffer in the virtual address space of the daemon is
   always pinned, but must be mapped before accessing its contents.  On
   AIX, the kernel mapping will be contiguous, although not necessarily
   at the same addresses as used by the daemon.

   On Linux, an I/O buffer in the virtual address space of the daemon
   is always pinned, but must be mapped before accessing its contents.
   On Linux, pages of the buffer will in general not be contiguous in
   kernel virtual memory.

   On Windows, an I/O buffer in the virtual address space of the daemon is
   always pinned, but must be mapped before accessing its contents.  On
   AIX, the kernel mapping will be contiguous, although not necessarily
   at the same addresses as used by the daemon. */

struct cxiIOBuffer_t
{
  /* Length of buffer in bytes */
  int ioBufLen;

  /* Number of memory descriptors backing this buffer */
  int nDesc;

  /* Pointer to beginning of contiguous buffer in daemon virtual address
     space */
  char* daemonBufP;  

  /* First daemon memory descriptor */
  cxiMemoryDesc_tXPtr hDescP;

  /* Last daemon memory descriptor */
  cxiMemoryDesc_tXPtr tDescP;
};

/* Clear all fields of an cxiIOBuffer_t to default values */
static inline void InitIOBuffer(struct cxiIOBuffer_t* iobP)
{ 
  iobP->ioBufLen = -1; 
  iobP->nDesc = 0;
  iobP->daemonBufP = NULL;
  iobP->hDescP = NULL;
  iobP->tDescP = NULL;
}

/* Return the daemon address of the first byte beyond the end of the
   I/O buffer */
static inline char* GetDaemonIOBufferEndAddr(struct cxiIOBuffer_t* iobP)
{
  LOGASSERT(iobP->nDesc == 1);
  return iobP->daemonBufP + iobP->ioBufLen;
};

#if 0
  /* Pin all the pages of a buffer.  If the buffer is already pinned, just
     increment its pin count.  Returns EOK if successful, other error codes
     if unsuccessful. */
  int pin();

  /* Decrement the pin count on the buffer.  If the count reaches zero,
     unpin the pages of the buffer. */
  void unpin();
#endif

/* Attach an I/O buffer to the kernel's virtual address space.  The
   cxiIOBufferAttachment_t returned in *attachP must be used as a parameter
   of most of the other operations on cxiIOBuffer_t's. */
EXTERNC void cxiAttachIOBuffer(struct cxiIOBuffer_t* iobP,
                               cxiXmem_t* xmemDescP,
                               struct cxiIOBufferAttachment_t* attachP);

/* Detach a buffer from the kernel's virtual address space. */
EXTERNC void cxiDetachIOBuffer(struct cxiIOBuffer_t* iobP,
                               struct cxiIOBufferAttachment_t* attachP);

/* Transfer len bytes beginning at offset bufOffset within I/O buffer *iobP
   to or from a user buffer.  The direction of the transfer is given with
   respect to the I/O buffer.  Returns EOK if successful, other error
   codes if unsuccessful. */
EXTERNC IntRC cxiUXfer(struct cxiIOBuffer_t* iobP, Boolean toIOBuffer,
                       const struct cxiIOBufferAttachment_t* attachP,
                       void* vkopP, int bufOffset, int len,
                       struct cxiUio_t* uioP);
#define CXI_XFER_TO_IOBUFFER true
#define CXI_XFER_FROM_IOBUFFER false

/* Perform cross-memory transfer of len bytes from user memory in current
   task to memory in specified address space.  If toXmem is true then
   copy is from userAddrP to udataP/xmemP, otherwise the opposite. */
EXTERNC IntRC cxiXmemXfer(char *userAddrP, int len, char *udataP,
                          cxiXmem_t* xmemP, Boolean toXmem);

/* Transfer len bytes beginning at offset bufOffset within I/O buffer *iobP
   to or from a contiguous kernel buffer.  The direction of the transfer
   is given with respect to the I/O buffer.  Returns EOK if successful,
   other error codes if unsuccessful. */
EXTERNC IntRC cxiKXfer(struct cxiIOBuffer_t* iobP, Boolean toIOBuffer,
                       const struct cxiIOBufferAttachment_t* attachP,
                       int bufOffset, int len, char* kBufP);
#ifdef ZIP
#ifdef GPFS_LINUX
/* Compress data residing in two contiguous kernel buffers, prefix and inBufP.
   Store the uncompressed data in outBufP.  The caller needs to ensure that the 
   outLen is exactly the same as the size of the uncompress data. */
EXTERNC IntRC 
cxiKUncompress(char* prefix, int prefixLen, char* inBufP, int inLen,
               char* outBufP, int outLen, int* avail_out);
#endif
#endif
#ifdef GPFS_ENC
#ifdef GPFS_LINUX
EXTERNC IntRC cxiKXferXmem(struct cxiIOBuffer_t* iobP,
                           Boolean toIOBuffer,
                           const struct cxiIOBufferAttachment_t* attachDataP,
                           int bufOffset,
                           size_t nBytes,
                           char *userAddrP,
                           cxiXmem_t* xmemP,
                           int* nBytesTransferredP);
#endif /* GPFS_LINUX */
#ifdef GPFS_AIX
EXTERNC IntRC
cxiXmemKXfer(char *userAddrP, struct cxiXmem_t* xmemP, Boolean toIOBuffer,
    struct cxiIOBuffer_t *iobP, const struct cxiIOBufferAttachment_t* attachP,
    int bufOffset, int len);

#endif /* GPFS_AIX */
#endif /* GPFS_ENC */

/* Set len bytes beginning at offset bufOffset within I/O buffer *iobP
   to zero.  Returns EOK if successful, other error codes if unsuccessful. */
EXTERNC IntRC cxiKZero(struct cxiIOBuffer_t* iobP,
                       const struct cxiIOBufferAttachment_t* attachP,
                       int bufOffset, int len);

/* Map an I/O buffer so it can be read and written from kernel code
   running in the context of a user thread.  Depending on the platform,
   the addresses at which the I/O buffer gets mapped may not be
   contiguous.  The details of how the buffer got mapped are handled by
   the cxiDiscontiguousDirectoryBuffer_t object that is filled in by this
   call.  On some platforms, mapping buffers using this call consumes
   scarce resources, so all cxiMapDiscontiguousRW calls should be promptly
   matched by unmapDiscontiguousRW calls as soon as the operation that
   required access to the I/O buffer completes.  Returns EOK if
   successful, other error codes if unsuccessful. */
EXTERNC IntRC cxiMapDiscontiguousRW(struct cxiIOBuffer_t* iobP,
                                    const struct cxiIOBufferAttachment_t* attachP,
                                    struct cxiDiscontiguousDirectoryBuffer_t* discontigP);

/* Unmap an I/O buffer previously mapped */
EXTERNC void cxiUnmapDiscontiguousRW(struct cxiIOBuffer_t* iobP,
                                     struct cxiDiscontiguousDirectoryBuffer_t* discontigP);

/* Return an address in kernel memory that holds a contigous read-only
   copy of a portion of an I/O buffer.  If possible, this will be a
   mapping of the I/O buffer.  If necessary, this routine will allocate a
   new block of kernel memory and copy the requested data to it.  The
   returned cxiContiguousBuffer_t encapsulates what method was used, so
   that unmapContiguousRO can release whatever resources were obtained by
   this call.  Returns EOK if successful, other error codes if
   unsuccessful. */
EXTERNC IntRC cxiMapContiguousRO(struct cxiIOBuffer_t* iobP,
                                 const struct cxiIOBufferAttachment_t* attachP,
                                 int bufOffset, int len,
                                 const char** contigBasePP,
                                 struct cxiContiguousBuffer_t* contigP);

/* Release a mapping or copy obtained with cxiMapContiguousRO */
EXTERNC void cxiUnmapContiguousRO(struct cxiIOBuffer_t* iobP,
                                  struct cxiContiguousBuffer_t* contigP);


/* Maximum size of a directory block.  Must be a multiple of PAGE_SIZE
   except for the case of 64K PAGE_SIZE.  Prior to SG_FORMAT_VERSION_DIR_V2,
   the maximum blocksize was 32K, so add a second definition for use when
   dealing with older filesystems. */
#ifdef DIR_V2
#define MAX_DIRBLOCK_SIZE (256*1024)
#else
#define MAX_DIRBLOCK_SIZE (32*1024)
#endif
#define MAX_DIRBLOCK_SIZE_V1 (32*1024)

/* Page size controlling alignment and unit of relocation for discontiguous
   buffers (must be equal to operating system page size) */
#define DISCONTIG_PAGE_SIZE PAGE_SIZE

/* Description of a buffer that is not necessarily contiguous in memory.
   All buffers managed through this type must begin on page boundaries. */
struct cxiDiscontiguousDirectoryBuffer_t
{
  /* Number of valid bytes in the buffer.  A value of -1 indicates that the
     buffer is not mapped and should not be accessed. */
  int mappedLen;

#ifdef __CXI_BUFFERS_ARE_CONTIGUOUS
  /* Pointer to the contiguous buffer */
  char* dataP;
#else
  /* Number of pages in a maximum size directory block */
#define MAX_PAGES_PER_DIRBLOCK (MAX(MAX_DIRBLOCK_SIZE/DISCONTIG_PAGE_SIZE,1))

  /* Array of pointers to the pages that contain the buffer.  This array
     contains the addresses at which the pages of the buffer can be accessed
     by the thread that called cxiMapDiscontiguousRW. */
  char* userPagePointerArray[MAX_DIRBLOCK_SIZE/4096];

  /* Array of pointers to OS-specific data structures needed to unmap each
     of the pages given by the array of pointers above. */
  void* osPagePointerArray[MAX_DIRBLOCK_SIZE/4096];
#endif  /* __CXI_BUFFERS_ARE_CONTIGUOUS */
};


/* Initialize a cxiDiscontiguousDirectoryBuffer_t */
static inline void 
InitDiscontiguousBuffer(struct cxiDiscontiguousDirectoryBuffer_t* ddbP)
{
  /* Indicate buffer is invalid */
  ddbP->mappedLen = -1;
};


/* Convert an offset into a logical buffer into a pointer to the byte
   at that offset.  The caller is assumed to know the length of the
   object beginning at the returned pointer, and is not supposed to access
   beyond the end of the page in which the pointer points */
static inline char* 
OffsetToPtr(const struct cxiDiscontiguousDirectoryBuffer_t* ddbP, int offset)
{
#ifndef __CXI_BUFFERS_ARE_CONTIGUOUS
  char* pageStartP;
#endif  /* __CXI_BUFFERS_ARE_CONTIGUOUS */
  DBGASSERT(offset >= 0);
  DBGASSERTRC(offset < ddbP->mappedLen, offset, ddbP->mappedLen, 0);
#ifdef __CXI_BUFFERS_ARE_CONTIGUOUS
  return ddbP->dataP+offset;
#else
  pageStartP = ddbP->userPagePointerArray[offset/DISCONTIG_PAGE_SIZE];
  return pageStartP + offset%DISCONTIG_PAGE_SIZE;
#endif  /* __CXI_BUFFERS_ARE_CONTIGUOUS */
};


/* Given a contiguous buffer, set up a mapping as if it was discontiguous */
static inline void 
MapContiguousBuffer(char* bufP, int len,
                    struct cxiDiscontiguousDirectoryBuffer_t* ddbP)
{
  ddbP->mappedLen = len;
#ifdef __CXI_BUFFERS_ARE_CONTIGUOUS
  ddbP->dataP = bufP;
#else
  /* Either we should start on a page boundary or our total buffer
   * should fit within the same page.
   */
  DBGASSERT(((UIntPtr)bufP & (DISCONTIG_PAGE_SIZE-1)) == 0 ||
            ((UIntPtr)bufP & ~(DISCONTIG_PAGE_SIZE-1)) ==
            ((UIntPtr)(bufP + len - 1) & ~(DISCONTIG_PAGE_SIZE-1)));
  DBGASSERT(len <= MAX_PAGES_PER_DIRBLOCK*DISCONTIG_PAGE_SIZE);
  {
    int i;
    for (i=0 ; len>0 ; i++, bufP+=DISCONTIG_PAGE_SIZE, len-=DISCONTIG_PAGE_SIZE)
    {
      ddbP->userPagePointerArray[i] = bufP;
      ddbP->osPagePointerArray[i] = NULL;
    }
  }
#endif  /* __CXI_BUFFERS_ARE_CONTIGUOUS */
};

/* Allocate and free I/O rendezvous objects */
EXTERNC struct cxiIORendezvous_t* cxiAllocIORendezvous();
EXTERNC void cxiFreeIORendezvous(struct cxiIORendezvous_t* renP);
EXTERNC void cxiInitIORendezvous(struct cxiIORendezvous_t* renP);
EXTERNC void cxiTermIORendezvous(struct cxiIORendezvous_t* renP);

/* Wait for the given number of asynchronous I/Os to complete */
EXTERNC Boolean cxiWaitIO(struct cxiIORendezvous_t* renP, int nIOs,
                          int msToWait, void* uioaioP);
EXTERNC void cxiWaitIOInterruptible(struct cxiIORendezvous_t* renP, int nIOs,
                                    int msToWait);

/* Reset an I/O rendezvous to reflect the number of completions that were
   actually processed.  Also reset the target number of completions, to
   reduce the number of calls to wake_up that occur when no thread is
   yet waiting. */
EXTERNC void cxiResetIORendezvous(struct cxiIORendezvous_t* renP,
                                  int nCompletionsSeen);

/* Forcibly awaken threads waiting on an I/O rendezvous.  Used during
   daemon shutdown. */
EXTERNC void cxiAwakenIORendezvous(struct cxiIORendezvous_t* renP);

/* Values for doioState in MBDoDiskIOParms.  Can be ORed together. */

/* I/O has already been submitted, or does not need to be submitted because of
   an error, a quiesced disk, etc. */
#define DOIO_SUBMITTED  0x0001

/* I/O is complete.  No need to wait for it to finish, possibly because it
   was never started. */
#define DOIO_COMPLETE   0x0002

/* I/O has already completed and been cleaned up.  The FIO trace has
   been generated.  If this bit is NOT set upon return from the kernel,
   the I/O must be resubmitted to the kernel, even if DOIO_COMPLETE is
   already set. */
#define DOIO_CLEANED    0x0008

/* How the I/O was executed: local disk, request to NSD server, read
   from local file, etc. */
#define DOIO_NSD        0x0010
#define DOIO_LOCAL_DISK 0x0020
#define DOIO_FILE       0x0040
#define DOIO_VDISK      0x0080

/* I/O started from direct I/O in the kernel */
#define DOIO_DIRECT     0x0100

/* postIO has been called for this I/O */
#define DOIO_POSTIO     0x0200

/* Submit request to NSD server asynchronously (tscSend with callback) */
#define DOIO_NSD_ASYNC  0x0400

/* Partial log sector was accounted for in this MBDoDiskIOParms,
   do not do it again. Useful when nsdAsyncIO encounters a failure and
   resubmits. Indicates whether the particular MBDoDiskIOParms has had its
   iovecs adjusted for the partial log sector.  Examine the values pointed
   to by MBDoDiskIOParms::partialSectorBuffInfoP to see if the partial sector
   adjustment itself has been performed or not yet. */
#define DOIO_PARTIAL_SECTOR_IOVECS_ADJUSTED 0x0800

/* Wait for all I/O's */
#define IO_WAIT_ALL     (-1)

/* Don't time out I/O's */
#define IO_NO_TIMEOUT   (-1)

#endif  /* _h_cxiIOBuffer */
