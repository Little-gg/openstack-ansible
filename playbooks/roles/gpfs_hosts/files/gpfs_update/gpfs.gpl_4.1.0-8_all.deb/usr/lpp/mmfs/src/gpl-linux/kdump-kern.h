/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)63       1.10  src/avs/fs/mmfs/ts/kernext/gpl-linux/kdump-kern.h, mmfs, avs_rfks1, rfks1s007a_addw 3/15/13 13:20:43 */
/* Definitions for kernel piece of program to dump kernel memory */


/* used to disable -mregparm=3 (IMPORTED BY KBUILD OVERHUAL),
   we need to reset regparm=0 in kdump, because kdump kernel-space side
   will call functions defined in user-space side kdump-kern.c, 
   we cann't use registers to pass parameters in function call */
#ifdef KDUMP_NOREGPARMS
#define RESET_KDUMP_REGPARMS __attribute__((regparm(0)))
#else
#define RESET_KDUMP_REGPARMS
#endif

/* Routine to initialize stuff needing access to kernel declarations */
extern void RESET_KDUMP_REGPARMS KernInit();

/* Read routines for various types of kernel objects.  Read the object at the
   given address and copy it into malloc'ed storage.  Return the address of
   the allocated object, or NULL if the object could not be read. */
extern void* RESET_KDUMP_REGPARMS GenericGet(unsigned long addr, int len, int fMap);
extern void* RESET_KDUMP_REGPARMS GetDentry(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetInode(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetVFSMount(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetFSStruct(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetSuperBlock(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetRootSuperBlock(unsigned long * addrP);
extern void* RESET_KDUMP_REGPARMS GetPage(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetAddressSpace(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetVMAreaStruct(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetMMStruct(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetTaskStruct(unsigned long addr);
extern void* RESET_KDUMP_REGPARMS GetTaskStructByPID(unsigned long pid, unsigned long * addrP);

/* Free routines for kernel objects.  Object types not listed here can
   be freed with CondFree. */
extern void RESET_KDUMP_REGPARMS FreeDentry(void* p);

/* Print routines for various types of kernel objects.  Parameter may be NULL. */
extern void RESET_KDUMP_REGPARMS PrintDentry(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintDentryTree(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintInode(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintVFSMount(void* parm, unsigned long addr);
#if (LINUX_KERNEL_VERSION < 3030000)
extern void RESET_KDUMP_REGPARMS PrintVFSMountList(void* parm, unsigned long addr);
#endif
extern void RESET_KDUMP_REGPARMS PrintFSStruct(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintSuperBlock(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintCxiNode_t(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintPage(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintAddressSpace(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintVMAreaStruct(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintMMStruct(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS PrintTaskStruct(void* parm, unsigned long addr);
extern void RESET_KDUMP_REGPARMS DoPs(void);
extern void RESET_KDUMP_REGPARMS BacktracePid(unsigned long pid);
extern void RESET_KDUMP_REGPARMS BacktraceAll();
extern void RESET_KDUMP_REGPARMS ReadKernelCore(char* corefile, int coreType);
