/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)93       1.152.1.78  src/avs/fs/mmfs/ts/kernext/ibm-kxi/cxiTypes.h, mmfs, avs_rfks1, rfks1s007a_addw 8/6/14 09:59:45 */
/*
 * Basic types used throughout GPFS.  Since GPFS shares data between its
 * daemon and its kernel pieces, types must be defined consistently, rather
 * than relying on platform-specific include files.  This file may be
 * included in either C or C++ code.
 *
 */

#ifndef _h_cxiTypes
#define _h_cxiTypes

#ifndef EXTERNC
# ifdef __cplusplus
#   define EXTERNC extern "C"
#   define EXTERNC_BEGIN extern "C" {
#   define EXTERNC_END }
# else
#   define EXTERNC extern
#   define EXTERNC_BEGIN
#   define EXTERNC_END
# endif
#endif

/* Some macros to help catching certain problems at compile time vs at
   run time, to save time on unnecessary recompiles and reboots.  This
   can be accomplished when operating on static data that has known (to
   the compiler) values at compile time, notably complex structure sizes. */

  /* This macro provides a compile time assertion statement. If the assert is 
     false, the compiler should emit an error. */
#if !defined(GPFS_LINUX) || defined(__cplusplus)
# define STATIC_ASSERT(_e) typedef char __static_assert__[(_e)?1:-1]
#else
# define STATIC_ASSERT(_e) \
    EXTERNC void __static_assert_dummy_func(int __static_assert__[][((int)(_e))/((int)(_e))])
#endif

/* This macro could be used to trick the compiler into telling you what is the
   size of a particular data type at compile time.  It takes one argument
   that should be a valid argument for a sizeof operation, and produces
   a compiler error that will have size of the object included in the
   message.  Only to be used during development, has to be disabled for
   the build to work. */
#define TELLSIZEOF(_a) \
  EXTERNC void __static_tellsizeof_dummy_func(int __FoO[][1]); \
  EXTERNC void __static_tellsizeof_dummy_func(int __FoO[][sizeof(_a)]);

/* Macros used on Windows to remove false warnings issued by the Visual Studio 
   static code analyzer. */
#ifndef GPFS_WINDOWS
# define VCWARN(X)
# define VCWARN_ASSERT(X) ((void)0)

# ifdef GPFS_LINUX
#   define VCWARN_NORETURN __attribute__ ((noreturn))
# else
#   define VCWARN_NORETURN
# endif

# define VCWARN_SUPPRESS(X)
# define VCWARN_PUSH(X)
# define VCWARN_POP
# define VCWARN_CONST(X) (X)
#endif

/* Types to use when the number of bits in a word is important.  Use these
   instead of long, short, int, etc. for portability */
typedef char                   Int8;
typedef short                  Int16;
typedef int                    Int32;
typedef long long              Int64;
typedef unsigned char          UInt8;
typedef unsigned short         UInt16;
typedef unsigned int           UInt32;
typedef unsigned long long     UInt64;
typedef unsigned char          UChar;
typedef float                  Float32;
typedef double                 Float64;

/* These types replace previous uses of 'long'. On AIX and Linux, int is always
   32 bits and long matches the machine architecture: 32 or 64 bits. On Windows
   with the Visual C++ compiler, both int and long are always 32 bits. */
#ifdef __64BIT__
# ifdef GPFS_WINDOWS
    typedef Int64              IntNative;
    typedef UInt64             UIntNative;
# else
    typedef signed long        IntNative;
    typedef unsigned long      UIntNative;
# endif
#else
  typedef Int32                IntNative;
  typedef UInt32               UIntNative;
#endif

typedef IntNative              Ptrdiff;

/* Use these instead of Int or UInt for padding in structures that are sent
   in RPCs.  These types will not be byte-swapped when sent between nodes
   having different endian value. */
typedef short                  Pad16;
typedef int                    Pad32;

/* Use these for fields send in RPCs that should not be byte-swapped */
typedef int                    Opaque32;
typedef unsigned long long     Opaque64;

/* Use this as the return type for functions that return a local
   system errno value, to make it clear that the function is called from
   outside of GPFS and does not return a GPFS Errno. */
typedef int                    IntRC;

#define INODENUM_MAX32  0x7FFFFFFEU       /* 2^31-1, 2^28-1 in practice */
#define INODENUM_MAX32E 0xFFFFFFFEU       /* 2^32-1 in theory */
#define INODENUM_MAX64  0x7FFFFFFFFFFFFFFEULL /* 2^63-1 */

#define INODENUM_MAX 0x7FFFFFFFFFFFFFFEULL /* 2^63-1 */

/* INODE64: ! inode number was up to 31 bit but will be up to 48 bit */
typedef Int64 InodeNumber;
typedef Int64 InodeCount;
/** @attention This *MUST* be passed an object of type InodeNumber, InodeCount
   or another type whose size is 32 bits with INODE64_PREP off and 64 bits when
   it is on.  This is *NOT* a general purpose "do the right thing" function for
   inode numbers.  Normally, you just want a (Int64) cast. */
/*#define INUM64CAST(x) (x)*/

#define INVALID_INODE_NUMBER    ((InodeNumber)-1)
#define INVALID_INODE_NUMBER32  ((Int32)-1)
/* XXX -- See also INODENUM_ROOTDIR_SNAPNAP (-3) defined in fs/FSDisk.h. */

typedef Int32 InodeNumber32;
typedef Int64 InodeNumber64;
typedef Int32 InodeCount32;
typedef Int64 InodeCount64;
typedef Int32 RelInodeNumber;  /* Can a relative inode num be negative? */
typedef Int32 RelInodeCount;   /* Count of Relative inodes */

#define MAX_UINT64 ((UInt64)(0xFFFFFFFFFFFFFFFFuLL))
#define MAX_INT64  ((Int64)(0x7FFFFFFFFFFFFFFFLL))
#define MIN_INT64  ((Int64)(0x8000000000000000LL))
#define MAX_UINT32 ((UInt32)0xFFFFFFFF)
#define MAX_INT32  ((Int32)0x7FFFFFFF)
#define MIN_INT32  ((Int32)0x80000000)
#define MAX_UINT16 ((UInt16)0xFFFF)
#define MAX_INT16  ((Int16)0x7FFF)
#define MIN_INT16  ((Int16)0x8000)

/* Macros to fetch the high and low 32 bits of an Int64 */
#define High32(_i) ((Int32) (((UInt64)(_i))>>32))
#define Low32(_i) ((UInt32) (((UInt64)(_i))&0xFFFFFFFF))

/* Macro to cast two 32 bit values to one 64 bit value */
#define Cast32To64(_high1, _low2) ((UInt64)(_high1) << 32 | (UInt64)(_low2))

/* Use types to safely allow integer to ptr assignment and vice-versa;
   defined for maximum portability (instead of using intptr_t/uintptr_t) */
typedef IntNative              IntPtr;
typedef UIntNative             UIntPtr;


/* Define macros to typecast a pointer in a failsafe manner */
#define INTPTR(_p)             ((IntPtr)(_p))
#define UINTPTR(_p)            ((UIntPtr)(_p))

/* Conversion macros for pointers and 32-bit integers */
/* Use when intentionally converting to/from 32-bit integers
   and pointers so that useless compiler warnings are suppressed. */
#define PTR_TO_INT32(_p)       ((Int32)(IntPtr)(_p))
#define PTR_TO_UINT32(_p)      ((UInt32)(UIntPtr)(_p))
#define INT32_TO_PTR(_i)       ((void *)(IntPtr)(_i))
#define UINT32_TO_PTR(_i)      ((void *)(UIntPtr)(_i))
#define PTR_TO_INT64(_p)       ((Int64)(IntPtr)(_p))
#define PTR_TO_UINT64(_p)      ((UInt64)(UIntPtr)(_p))
#define UINT64_TO_PTR(_i)      ((void *)(UIntPtr)(_i))

/* Lockword type for mutexes */
typedef UIntNative             lockWord_t;

/* Boolean type */
typedef unsigned int Boolean;
typedef char cBoolean;
#define false 0
#define FALSE 0
#define true  1
#define TRUE  1
STATIC_ASSERT(FALSE == (int)(0 != 0));
STATIC_ASSERT(TRUE == (int)(0 == 0));

/* Command parameters given to gpfsSetattr() */
#ifndef V_MODE         /* set mode */
#define V_MODE  0x01
#endif
#ifndef V_OWN          /* set owner */
#define V_OWN   0x02
#endif
#ifndef V_UTIME        /* set atime and mtime */
#define V_UTIME 0x04
#endif
#ifndef V_STIME        /* set atime, mtime, and ctime */
#define V_STIME 0x08
#endif
#ifndef V_NTIME        /* set atime, mtime, and ctime to now */
#define V_NTIME 0x10
#endif
#ifndef V_SIZE         /* set file size */
#define V_SIZE  0x20
#endif

#define CXIDEVNONE (cxiDev_t)(-1U)

/* AIX SHM_RDONLY sys/shm.h */
#define CXI_SHM_RDONLY 010000

/* Make sure null pointer definition is always available */
#ifndef NULL
#define NULL 0
#endif

#ifdef GPFS_SOLARIS
/* This is essentially the same as /usr/include/stddef.h and sys/sysmacros.h */
/* But the args, of course, are in reverse order */
#define OFFSET_OF(_field, _struct) ((char*)&((_struct *)0)->_field - (char*)0)
#else  /* GPFS_SOLARIS */
/* Macro to compute the offset of a field within a structure */
#if defined(__GNUC__) && (__GNUC__ >= 3) || (__GNUC__ >= 4)
/* gcc 3.x: avoid warning msg "invalid offsetof from non-POD type: ..."  */
#define OFFSET_OF(_field, _struct) \
  (Int32) ( (unsigned long)&((_struct *)16)->_field - (unsigned long)16 )
#else
#define OFFSET_OF(_field, _struct) ( (Ptrdiff) ( &((_struct *)0)->_field ) )
#endif
#endif /* GPFS_SOLARIS */


/* L1/L2 cache line size for various architectures */
#ifndef CACHE_LINE_SIZE

#if defined(GPFS_ARCH_X86_64)
/* All recent Intel (Pentium 4, Xeon, Core 2) and AMD (Athlon 64, Opteron)
   processors have a 64 byte L1 & L2 cache line size.
   ?? On Intel, the optional "adjacent cache line prefetch" feature makes
      the L2 cache behave more like a 128 byte cache line size; can be
      enabled/disabled via BIOS or changing MSR bits at runtime.  If enabled
      (default?), using 128 byte alignment might be better. */
#ifdef GPFS_WINDOWS
#define CACHE_LINE_SIZE 128
#else
#define CACHE_LINE_SIZE 64
#endif

#elif defined(GPFS_ARCH_POWER) || defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
/* Power 4, Power 5, and PowerPC G5 have a 128 byte L1 & L2 cache line size */
#define CACHE_LINE_SIZE 128

#elif defined(GPFS_ARCH_SPARC_V9)
/* UltraSparc IV has L2 cache line size of 128 bytes */
#define CACHE_LINE_SIZE 128

#else
/* Unknown architecture; pick something plausible */
#define CACHE_LINE_SIZE 64
#endif

#endif /* CACHE_LINE_SIZE undefined */

/* Compiler directive to align a structure on cache line boundaries */
#if CACHE_LINE_SIZE == 0
#define __CACHE_LINE_ALIGNED__
#elif defined(__GNUC__)
#define __CACHE_LINE_ALIGNED__  __attribute__ ((aligned (CACHE_LINE_SIZE)))
#else
#define __CACHE_LINE_ALIGNED__
#endif


/* Identifier of a thread.  Always 32 bits, even if native thread IDs are
   longer on some platforms.  The value cxiNoThread denotes an invalid
   thread ID. */
typedef Int32                  cxiThreadId;
#define cxiNoThread            0

#if (defined(GPFS_AIX) || defined(GPFS_SOLARIS))&& defined(__64BIT__)
typedef Int64                  cxiPid_t;
#else
typedef Int32                  cxiPid_t;
#endif
typedef Int64                  cxiPid64_t;
typedef Int32                  cxiPid32_t;
typedef Int32                  cxiKey_t;

#if defined(GPFS_SOLARIS)
/* See solaris/cxiTypes-plat.h for the Solaris definitions of these */
#else
/* Needed since mode_t is short in linux kernel */
typedef UInt32                 cxiMode_t;
typedef UInt32                 cxiUid_t;
typedef UInt64                 cxiUid64_t;
typedef UInt32                 cxiGid_t;
typedef UInt64                 cxiGid64_t;
typedef UInt64                 cxiIno_t;    /* gpfs inode number */
typedef UInt64                 cxiIno64_t;    /* gpfs inode number */
#endif

/* Original AIX sizes for dev_t.  Special device files continue to
 * record their major/minor numbers as 32 bits on disk.
 */
typedef UInt32                 cxiDev32_t;

typedef UInt32                 cxiTime32_t; /* seconds time type */
typedef UInt32                 cxiNSec32_t; /* nanoseconds time type */
typedef UIntNative             cxiSize_t;
typedef Int64                  cxiTime64_t; /* seconds time type.  Signed
                                               because NFSv4 uses signed
                                               64 bit times. */

/* cxiHandle is an int type file descriptor on UNIX. On Windows, it is a
   void* HANDLE type. It is used to store the handle to an opened device.
   cxiHandle is not used as a general file descriptor type.
   This definition needs to remain compatible with gpfs_file_t defined
   in gpfs.h. */
#ifdef GPFS_WINDOWS
  typedef void* cxiHandle;
#else
  typedef int cxiHandle;
#endif
/* Classic -1 definition for an invalid file descriptor, but also works for void* types */
#define CXI_INVALID_HANDLE ((cxiHandle)(~0))

/* For secvm, we send bytes offset of file through structure buf when we call
   I/O strategy routine. Secvm just cares about user data I/O. For other I/Os 
   for metadata, such as indBlock, LL file, we can set fileOffset to 
   CXI_INVALID_FILEOFFSET */
#define CXI_INVALID_FILEOFFSET ((Int64)-1)

/* Socket types */
#ifndef USE_WINSOCK
  typedef int Sock;
  typedef struct pollfd PollFd;
  typedef struct pollfd PollSock;

  /* Values to use in place of -1, STDOUT_FILENO, and STDERR_FILENO */
  #define INVALID_SOCK (-1)
  #define STDIN_SOCK (STDIN_FILENO)
  #define STDOUT_SOCK (STDOUT_FILENO)
  #define STDERR_SOCK (STDERR_FILENO)

  /* Type coercion functions */
  #define SockToInt(s) ((int)(s))
  #define IntToSock(i) ((Sock)(i))
#endif

/* pthread_t on Windows is a structure but an integer on Unix.
   This definition allows a portable way to get the integer tid. */
#ifdef GPFS_WINDOWS
  #define PThreadToInt(T) (pthread_getw32threadid_np(T))
#else
  #define PThreadToInt(T) (T)
#endif

/* File system type within cxiStatfs_t */
typedef struct cxiFsid_t
{
  UIntNative val[2];
} cxiFsid_t;

/* Interface structure for gpfsStatfs() */
typedef struct cxiStatfs_t
{
  UInt64    f_blocks;     /* total data blocks in file system */
  UInt64    f_bfree;      /* free block in fs */
  UInt64    f_bavail;     /* free blocks avail to non-superuser */
  int       f_bsize;      /* optimal file system block size */
  InodeCount f_files;     /* total file nodes in file system */
  InodeCount f_ffree;     /* free file nodes in fs */
  cxiFsid_t f_fsid;       /* file system id */
  int       f_fsize;      /* fundamental file system block size */
  int       f_sector_size;/* logical disk sector size */
  char      f_fname[32];  /* file system name (usually mount pt.) */
  char      f_fpack[32];  /* file system pack name */
  int       f_name_max;   /* maximum component name length for posix */
} cxiStatfs_t;

typedef struct getdents_callback_s {
  char *name;              /* name that was found. It already points to a
                              buffer NAME_MAX+1 is size */
  unsigned long ino;       /* the inum we are looking for */
  int found;               /* inode matched? */
  int sequence;            /* sequence counter */
  UInt64 pos;              /* offset */
} getdents_callback_t;


/* l_caller values */
#define L_CALLER_NULL 0
#define L_CALLER_LOCKD 1

/* Advisory record locking interface structure */
typedef long long cxiOff64_t;
typedef struct cxiFlock_t
{
  short           l_type;
  short           l_whence;
  unsigned int    l_sysid;
  cxiPid_t        l_pid;
#ifdef GPFS_AIX
  int             l_vfs;
#else
  int             l_caller;
#endif
  cxiOff64_t      l_start;
  cxiOff64_t      l_len;
  void *          l_owner;
  void *          l_file;
  void *          l_lmops;
  unsigned int    l_flags;
#ifdef GPFS_WINDOWS
  void *          l_fop;
  UInt32          l_key;
  UInt32          l_wop;
#endif /* GPFS_WINDOWS */
#ifdef GPFS_SOLARIS
  void *          flkCallback;
  int             flag;
  Boolean         pxfsBlocked;
#endif /* GPFS_SOLARIS */
} cxiFlock_t;

/* flock l_type constants are OS dependent.  When sending F_GETLK
 * results between nodes, they must be mapped to generic constants
 * and then back to OS-specific values by the receiving node.
 */
#define GENERIC_F_RDLCK 1
#define GENERIC_F_WRLCK 2
#define GENERIC_F_UNLCK 3

#define L_TYPE_OUT(lt) \
  ((lt) == F_RDLCK)? GENERIC_F_RDLCK: \
  ((lt) == F_WRLCK)? GENERIC_F_WRLCK: \
  ((lt) == F_UNLCK)? GENERIC_F_UNLCK: lt; \

#define L_TYPE_IN(lt) \
  ((lt) == GENERIC_F_RDLCK)? F_RDLCK: \
  ((lt) == GENERIC_F_WRLCK)? F_WRLCK: \
  ((lt) == GENERIC_F_UNLCK)? F_UNLCK: lt; \

#ifdef GPFS_AIX
#define cxiFlock2Common( cxiCommonP, cxiP )           \
{                                                     \
  (cxiCommonP)->l_type = L_TYPE_OUT((cxiP)->l_type);  \
  (cxiCommonP)->l_whence = (cxiP)->l_whence;          \
  (cxiCommonP)->l_sysid = (cxiP)->l_sysid;            \
  (cxiCommonP)->l_pid = (cxiPid64_t)(cxiP)->l_pid;    \
  (cxiCommonP)->l_vfs = (cxiP)->l_vfs;                \
  (cxiCommonP)->l_start = (cxiP)->l_start;            \
  (cxiCommonP)->l_len = (cxiP)->l_len;                \
  (cxiCommonP)->l_owner = (UInt64)(cxiP)->l_owner;    \
};
#define cxiCommon2Flock( cxiP, cxiCommonP )           \
{                                                     \
  (cxiP)->l_type = L_TYPE_IN((cxiCommonP)->l_type);   \
  (cxiP)->l_whence = (cxiCommonP)->l_whence;          \
  (cxiP)->l_sysid = (cxiCommonP)->l_sysid;            \
  (cxiP)->l_pid = (cxiPid_t)(cxiCommonP)->l_pid;      \
  (cxiP)->l_vfs = (cxiCommonP)->l_vfs;                \
  (cxiP)->l_start = (cxiCommonP)->l_start;            \
  (cxiP)->l_len = (cxiCommonP)->l_len;                \
  (cxiP)->l_owner = (void *)(cxiCommonP)->l_owner;    \
};
#else
#define cxiFlock2Common( cxiCommonP, cxiP )           \
{                                                     \
  (cxiCommonP)->l_type = L_TYPE_OUT((cxiP)->l_type);  \
  (cxiCommonP)->l_whence = (cxiP)->l_whence;          \
  (cxiCommonP)->l_sysid = (cxiP)->l_sysid;            \
  (cxiCommonP)->l_pid = (cxiPid64_t)(cxiP)->l_pid;    \
  (cxiCommonP)->l_caller = (cxiP)->l_caller;          \
  (cxiCommonP)->l_start = (cxiP)->l_start;            \
  (cxiCommonP)->l_len = (cxiP)->l_len;                \
  (cxiCommonP)->l_owner = PTR_TO_UINT64((cxiP)->l_owner);    \
};
#define cxiCommon2Flock( cxiP, cxiCommonP )           \
{                                                     \
  (cxiP)->l_type = L_TYPE_IN((cxiCommonP)->l_type);   \
  (cxiP)->l_whence = (cxiCommonP)->l_whence;          \
  (cxiP)->l_sysid = (cxiCommonP)->l_sysid;            \
  (cxiP)->l_pid = (cxiPid_t)(cxiCommonP)->l_pid;      \
  (cxiP)->l_caller = (cxiCommonP)->l_caller;          \
  (cxiP)->l_start = (cxiCommonP)->l_start;            \
  (cxiP)->l_len = (cxiCommonP)->l_len;                \
  (cxiP)->l_owner = (void *)(UIntPtr)(cxiCommonP)->l_owner;    \
};
#endif        /* GPFS_AIX */

typedef enum cxiTrace_t
{
  cxiTraceNFS = 0,     /* trace linux nfs activity via printk */
  cxiTraceNFSoff = 1   /* stop  tracing of linux nfs activity */
} cxiTrace_t;


/* DMAPI operation context
   Changes to this enum must also be reflected in reqDmLockTable. */
typedef enum cxiContext_t
{
  unknownOp = 0,        /* invalid or unknown operation type */
  vnOp = 1,             /* vnode operation */
  reservedFileOp = 2,   /* quota operation (quota check, asyncRecovery) */
  generalOp = 3,        /* general (not vnop) operation */
  iscanOp = 4,          /* inode scan operation */
  pcacheOp = 5,         /* pcache operation */
  ganeshaOp = 6,        /* Ganesha operation */

  /* must place all non-dm contexts above this line */
  /* must place dmOp context on next line, and all other dm contexts after it */
  dmOp = 7,             /* non-file-related DM operation */
  dmOpWithToken = 8,    /* File-related DM operation with a DM token */
  dmOpWithoutToken = 9, /* File-related DM operation without a token */
  dmOpInvalidToken = 10, /* File-related DM operation with an invalid token */
  dmOpAccessControl = 11,/* DM operation that upgrade/downgrade/releases access rights */
  dmOpAccessAcquire = 12 /* DM Operation that acquires access rights */
} cxiContext_t;

#define CXI_DEV_BSIZE  512     /* DEV_BSIZE AIX sys/dir.h */
#define CXI_MAXNAMLEN  255     /* MAXNAMLEN AIX sys/dir.h */
#define CXI_MAXPATHLEN 1024    /* MAXPATHLEN AIX sys/param.h */
#define CXI_PATH_MAX   1023    /* PATH_MAX AIX sys/limits.h */
#define CXI_ATTR_MAX   (64*1024) /* ATTR_MAX_VALUELEN attr/attributes.h */

/* This macro verifies if a given operation context is one of DMAPI contexts */
#define IS_DM_CONTEXT(opContext) ((opContext < dmOp) ? false : true)
#define IS_PCACHE_CONTEXT(opContext)  (opContext == pcacheOp)

/* Operations supported by gpfsReadWrite */
typedef enum cxiRdWr_t
{
  CXI_READ, CXI_WRITE, CXI_READ_NO_MOVE,
  CXI_WRITE_NO_MOVE, CXI_READ_AIO, CXI_WRITE_AIO
} cxiRdWr_t;

/* gpfsRead and gpfsWrite options */
#define CXI_RDWROPTS_NONE       (0x00000000)
#define CXI_RDWROPTS_IREAD      (0x00000001)
#define CXI_RDWROPTS_ROWRITE    (0x00000002)
#define CXI_RDWROPTS_UIDREMAP   (0x00000004)
#define CXI_RDWROPTS_AIO        (0x00000008)
#define CXI_RDWROPTS_SKIP_HOLES (0x00000010)

/* Forward declarations */
struct gpfsVfsData_t;
struct ext_cred_t;

/* Macros to convert integers of various sizes from big endian to little
   endian or vice versa.  Do not use these directly; use either the ByteSwapxx
   routines defined in cxiTypes-plat.h or the BigEndToCPUxx/CPUToBigEndxx
   macros instead. */
#define _ByteSwap16(d) \
        ((UInt16)((((UInt16)(d) >> 8) & 0x00FFU) | \
                  (((UInt16)(d) << 8) & 0xFF00U)))

#define _ByteSwap32(d) \
        ((UInt32)((((UInt32)(d) >> 24) & 0x000000FFU) | \
                  (((UInt32)(d) >>  8) & 0x0000FF00U) | \
                  (((UInt32)(d) <<  8) & 0x00FF0000U) | \
                  (((UInt32)(d) << 24) & 0xFF000000U)))

#define _ByteSwap64(d) \
        ((UInt64)((((UInt64)(d) >> 56) & 0x00000000000000FFULL) | \
                  (((UInt64)(d) >> 40) & 0x000000000000FF00ULL) | \
                  (((UInt64)(d) >> 24) & 0x0000000000FF0000ULL) | \
                  (((UInt64)(d) >>  8) & 0x00000000FF000000ULL) | \
                  (((UInt64)(d) <<  8) & 0x000000FF00000000ULL) | \
                  (((UInt64)(d) << 24) & 0x0000FF0000000000ULL) | \
                  (((UInt64)(d) << 40) & 0x00FF000000000000ULL) | \
                  (((UInt64)(d) << 56) & 0xFF00000000000000ULL)))


/* Based on the AIX definition */
typedef struct cxiIovec_t
{
  char     *iov_base;
  cxiSize_t iov_len;
} cxiIovec_t;

/* Include platform specific types */
#include <cxiTypes-plat.h>


#ifdef __cplusplus

/* Declare classes for other-endian (big-endian or little-endian) integers
   of various sizes.  Each class provides operator= and integer cast
   operators, so the compiler will insert code to do conversions
   automatically when evaluating expressions involving alternate-endian
   integers.  When passing an OtherEndIntxx as a value parameter to a
   function without a prototype for its arguments, be sure to explicitly
   cast to the corresponding native arithmetic type.  Otherwise, passing
   the class instance by value will result in the wrong byte order in
   the called routine.  This most often occurs with printf and related
   functions.  Notice that the code generated by TRACEn macros already
   contains such an explicit cast, so no case is needed in the source
   code. */

  class OtherEndInt16
  {
  private:
    Int16 val16;

  public:
    operator Int16() const
      { return ByteSwap16(val16); }
    OtherEndInt16 operator=(Int16 newVal16)
      { val16 = ByteSwap16(newVal16); return *this; }
    bool operator==(OtherEndInt16 rhs) const
      { return val16 == rhs.val16; }
    bool operator!=(OtherEndInt16 rhs) const
      { return val16 != rhs.val16; }
    OtherEndInt16 operator+=(Int16 inc)
      { val16 = ByteSwap16(ByteSwap16(val16)+inc); return *this; }
    OtherEndInt16 operator-=(Int16 inc)
      { val16 = ByteSwap16(ByteSwap16(val16)-inc); return *this; }
    OtherEndInt16 operator&=(Int16 mask)
      { val16 &= ByteSwap16(mask); return *this; }
    OtherEndInt16 operator|=(Int16 mask)
      { val16 |= ByteSwap16(mask); return *this; }
  };

  class OtherEndUInt16
  {
  private:
    UInt16 uval16;

  public:
    operator UInt16() const
      { return ByteSwap16(uval16); }
    OtherEndUInt16 operator=(UInt16 newVal16)
      { uval16 = ByteSwap16(newVal16); return *this; }
    bool operator==(OtherEndUInt16 rhs) const
      { return uval16 == rhs.uval16; }
    bool operator!=(OtherEndUInt16 rhs) const
      { return uval16 != rhs.uval16; }
    OtherEndUInt16 operator+=(UInt16 inc)
      { uval16 = ByteSwap16(ByteSwap16(uval16)+inc); return *this; }
    OtherEndUInt16 operator-=(UInt16 inc)
      { uval16 = ByteSwap16(ByteSwap16(uval16)-inc); return *this; }
    OtherEndUInt16 operator&=(UInt16 mask)
      { uval16 &= ByteSwap16(mask); return *this; }
    OtherEndUInt16 operator|=(UInt16 mask)
      { uval16 |= ByteSwap16(mask); return *this; }
  };

  class OtherEndInt32
  {
  private:
    Int32 val32;

  public:
    operator Int32() const
      { return ByteSwap32(val32); }
    OtherEndInt32 operator=(Int32 newVal32)
      { val32 = ByteSwap32(newVal32); return *this; }
    bool operator==(OtherEndInt32 rhs) const
      { return val32 == rhs.val32; }
    bool operator!=(OtherEndInt32 rhs) const
      { return val32 != rhs.val32; }
    OtherEndInt32 operator+=(Int32 inc)
      { val32 = ByteSwap32(ByteSwap32(val32)+inc); return *this; }
    OtherEndInt32 operator-=(Int32 inc)
      { val32 = ByteSwap32(ByteSwap32(val32)-inc); return *this; }
  };

  class OtherEndUInt32
  {
  private:
    UInt32 uval32;

  public:
    operator UInt32() const
      { return ByteSwap32(uval32); }
    OtherEndUInt32 operator=(UInt32 newVal32)
      { uval32 = ByteSwap32(newVal32); return *this; }
    bool operator==(OtherEndUInt32 rhs) const
      { return uval32 == rhs.uval32; }
    bool operator!=(OtherEndUInt32 rhs) const
      { return uval32 != rhs.uval32; }
    OtherEndUInt32 operator+=(UInt32 inc)
      { uval32 = ByteSwap32(ByteSwap32(uval32)+inc); return *this; }
    OtherEndUInt32 operator-=(UInt32 inc)
      { uval32 = ByteSwap32(ByteSwap32(uval32)-inc); return *this; }
    OtherEndUInt32 operator&=(UInt32 mask)
      { uval32 &= ByteSwap32(mask); return *this; }
    OtherEndUInt32 operator|=(UInt32 mask)
      { uval32 |= ByteSwap32(mask); return *this; }
    OtherEndUInt32 operator^=(UInt32 mask)
      { uval32 ^= ByteSwap32(mask); return *this; }
  };

  class OtherEndInt64
  {
  private:
    Int64 val64;

  public:
    operator Int64() const
      { return ByteSwap64(val64); }
    OtherEndInt64 operator=(Int64 newVal64)
      { val64 = ByteSwap64(newVal64); return *this; }
    bool operator==(OtherEndInt64 rhs) const
      { return val64 == rhs.val64; }
    bool operator!=(OtherEndInt64 rhs) const
      { return val64 != rhs.val64; }
    OtherEndInt64 operator+=(Int64 inc)
      { val64 = ByteSwap64(ByteSwap64(val64)+inc); return *this; }
    OtherEndInt64 operator-=(Int64 inc)
      { val64 = ByteSwap64(ByteSwap64(val64)-inc); return *this; }
  };

  class OtherEndUInt64
  {
  private:
    UInt64 uval64;

  public:
    operator UInt64() const
      { return ByteSwap64(uval64); }
    OtherEndUInt64 operator=(UInt64 newVal64)
      { uval64 = ByteSwap64(newVal64); return *this; }
    bool operator==(OtherEndUInt64 rhs) const
      { return uval64 == rhs.uval64; }
    bool operator!=(OtherEndUInt64 rhs) const
      { return uval64 != rhs.uval64; }
    OtherEndUInt64 operator+=(UInt64 inc)
      { uval64 = ByteSwap64(ByteSwap64(uval64)+inc); return *this; }
    OtherEndUInt64 operator-=(UInt64 inc)
      { uval64 = ByteSwap64(ByteSwap64(uval64)-inc); return *this; }
  };

  #ifdef GPFS_LITTLE_ENDIAN

    typedef OtherEndInt16  BigEndInt16;
    typedef OtherEndUInt16 BigEndUInt16;
    typedef OtherEndInt32  BigEndInt32;
    typedef OtherEndUInt32 BigEndUInt32;
    typedef OtherEndInt64  BigEndInt64;
    typedef OtherEndUInt64 BigEndUInt64;

    typedef Int16  LittleEndInt16;
    typedef UInt16 LittleEndUInt16;
    typedef Int32  LittleEndInt32;
    typedef UInt32 LittleEndUInt32;
    typedef Int64  LittleEndInt64;
    typedef UInt64 LittleEndUInt64;

  #else /* GPFS_LITTLE_ENDIAN */

    typedef Int16  BigEndInt16;
    typedef UInt16 BigEndUInt16;
    typedef Int32  BigEndInt32;
    typedef UInt32 BigEndUInt32;
    typedef Int64  BigEndInt64;
    typedef UInt64 BigEndUInt64;

    typedef OtherEndInt16  LittleEndInt16;
    typedef OtherEndUInt16 LittleEndUInt16;
    typedef OtherEndInt32  LittleEndInt32;
    typedef OtherEndUInt32 LittleEndUInt32;
    typedef OtherEndInt64  LittleEndInt64;
    typedef OtherEndUInt64 LittleEndUInt64;

  #endif /* GPFS_LITTLE_ENDIAN */


  /* Big endian IEEE 754 floating point types. */

  #ifndef _KERNEL

    #ifndef GPFS_IEEE754_FLOAT
    #include <stdlib.h>
    #include <math.h>
    #endif

    #ifdef  GW_WIN
    #define isnan(x)    _isnan(x)
    #define isinf(x)    ((int)(!_finite(x) && !_isnan(x)))

    // from SUA math.h
    static __inline double getInf()
    {
      double dbl;
      int *p=(int*)&dbl;
      *p=0x00000000;
      *(p+1)=0x7ff00000;
      return dbl;
    }

    static __inline double getNAN()
    {
      double dbl;
      int *p=(int*)&dbl;
      *p=0x00000000;
      *(p+1)=0x7fff0000;
      return dbl;
    }
    #define INFINITY        getInf()
    #define NAN             getNAN()

    #endif  /* GW_WIN */

    template <typename bigEndUIntType, typename uIntType, typename floatType,
              int totalBits, int exponentBits> class BigEndIEEE754
    {
    private:
      bigEndUIntType bigEndUInt;

    public:
      operator floatType() const
        { return IEEE754ToFloat((uIntType)bigEndUInt); }
      BigEndIEEE754& operator =(floatType rhs)
        { bigEndUInt = floatToIEEE754(rhs); return *this; }
      bool operator ==(BigEndIEEE754 rhs) const
        { return bigEndUInt == rhs.bigEndUInt; }
      bool operator !=(BigEndIEEE754 rhs) const
        { return bigEndUInt != rhs.bigEndUInt; }
      bigEndUIntType& operator +=(floatType rhs)
      {
        bigEndUInt = floatToIEEE754(IEEE754ToFloat((uIntType)bigEndUInt) + rhs);
        return *this;
      }
      bigEndUIntType& operator -=(floatType rhs)
      {
        bigEndUInt = floatToIEEE754(IEEE754ToFloat((uIntType)bigEndUInt) - rhs);
        return *this;
      }

    private:
    #ifdef GPFS_IEEE754_FLOAT
      /* Simple conversion functions for architectures that use IEEE 754
         floating point format natively. */

      /* Convert IEEE754 to native float. */
      static floatType IEEE754ToFloat(uIntType uValue)
      {
        STATIC_ASSERT(sizeof(floatType) == sizeof(uIntType));
        floatType result;

        *reinterpret_cast<uIntType *>(&result) = uValue;
        return result;
      }

      /* Convert native float to IEEE754. */
      static uIntType floatToIEEE754(floatType fValue)
      {
        STATIC_ASSERT(sizeof(floatType) == sizeof(uIntType));
        uIntType result;

        result = *reinterpret_cast<uIntType *>(&fValue);
        return result;
      }

    #else  /* GPFS_IEEE754_FLOAT */
      /* Generic conversion functions that work on architectures that do
         not use IEEE 754 floating point format natively. */

      enum {
        /* number of stored bits in the mantissa (not including implied bits) */
        mantissaBits = totalBits - exponentBits - 1,

        /* position of the exponent field from lsb */
        exponentShift = mantissaBits,

        /* maximum biased value that can be stored in the exponent field */
        exponentMax = ~(~0U << exponentBits),

        /* exponent bias */
        bias = (1 << (exponentBits - 1)) - 1,

        /* minimum unbiased exponent value */
        emin = 1 - bias,

        /* maximum unbiased exponent value */
        emax = bias,
      };

      /*!Return a bit mask for the sign bit. */
      static uIntType getSignMask()
        { return (uIntType)1U << (totalBits - 1); }

      /*!Return a bit mask for the exponent field. */
      static uIntType getExponentMask()
        { return ~(~(uIntType)0U << exponentBits) << exponentShift; }

      /*!Return a bit mask for the mantissa field. */
      static uIntType getMantissaMask()
        { return ~(~(uIntType)0U << mantissaBits); }

      /*!Return a mask containing the implied "1" bit before the mantissa field. */
      static uIntType getImpliedOne()
        { return (uIntType)1U << mantissaBits; }

      /*!Return a mask containing the non-zero "payload" for nan values.
         We are using the intel/AMD "quiet nan" convention of a 1 in the
         most significant mantissa bit. */
      static uIntType getNanPayload()
        { return (uIntType)1U << (mantissaBits - 1); }

      /* Convert IEEE754 format to native float. */
      static floatType IEEE754ToFloat(uIntType uValue)
      {
        STATIC_ASSERT(totalBits == 8 * sizeof(uIntType));

        /* Split into sign, exponent and mantissa fields. */
        int sign = (uValue & getSignMask()) ? -1 : 1;
        int exponent = (int)((uValue & getExponentMask()) >> exponentShift) - bias;
        uIntType mantissa = uValue & getMantissaMask();

        /* Handle special cases. */
        switch (exponent)
        {
          case emin-1:
            /* +/- zero */
            if (mantissa == 0)
              return sign > 0 ? 0.0 : -0.0; /* -0.0 may be the same as 0.0 */

            /* denormalized float */
            return ldexp((double)sign * (double)mantissa, emin - mantissaBits);

          case emax+1:
            /* +/- infinity */
            if (mantissa == 0)
              return sign > 0 ? strtof("+inf", NULL) : strtof("-inf", NULL);

            /* "nan" (not a number)  Note that there are different kinds of
               nan's, but their representations are not well standardized --
               we return the most generic nan.  On some architectures, this
               may return zero. */
            return strtof("nan", NULL);

          default:
            break;
        }

        /* normalized float */
        mantissa |= getImpliedOne();
        return ldexp((double)sign * (double)mantissa, exponent - mantissaBits);
      }

      /* Convert a native float to IEEE754 format. */
      static uIntType floatToIEEE754(floatType fValue)
      {
        STATIC_ASSERT(totalBits == 8 * sizeof(uIntType));

        int sign = 1;
        int exponent = 0;
        int shift = mantissaBits;
        uIntType result = 0;

        /* positive zero */
        if (fValue == +0.0)
          return 0;

        /* negative zero (if actually different) */
        if (fValue == -0.0)
          return getSignMask();

        /* positive infinity */
        if (isinf(fValue) > 0)
          return getExponentMask();

        /* negative infinity */
        if (isinf(fValue) < 0)
          return getSignMask() | getExponentMask();

        /* not a number */
        if (isnan(fValue))
          return getExponentMask() | getNanPayload();

        /* Separate the floating point value into a normalized mantissa and
           exponent.  The mantissa will initially be in the range +/-(0..1).
           Adjust the result so that the most significant bit is left of
           the decimal point, i.e. so that 1.0 is represented as 1.0 *
           2^0 instead of 0.5 * 2^1. */
        fValue = frexp(fValue, &exponent);
        fValue *= 2.0;
        exponent -= 1;

        /* Separate the sign. */
        if (fValue < 0.0)
        {
          fValue *= -1.0;
          sign    = -1;
        }

        /* If the exponent is larger than emax, encode infinity. */
        if (exponent > emax)
          return (sign < 0 ? getSignMask() : 0) | getExponentMask();

        /* If the exponent is less than emin, adjust the shift value
           to create a denormalized mantissa. */
        if (exponent < emin)
        {
          shift -= (emin - exponent);
          exponent = emin - 1;
        }

        /* Load the mantissa, masking the implied 1 bit (if present). */
        result = (uIntType)floor(fValue * ldexp(1.0, shift));
        result &= getMantissaMask();

        /* Bias and load the exponent. */
        result |= (uIntType)(exponent + bias) << exponentShift;

        /* Load the sign bit. */
        if (sign < 0)
          result |= getSignMask();

        return result;
      }
    #endif /* GPFS_IEEE754_FLOAT */
    };

    /* BigEndFloat32 */
    typedef BigEndIEEE754<BigEndUInt32, UInt32, Float32, 32,  8> BigEndFloat32;

    /* BigEndFloat64 */
    typedef BigEndIEEE754<BigEndUInt64, UInt64, Float64, 64, 11> BigEndFloat64;

  #endif /* _KERNEL */

  /* Endian Independent Class that transforms two back to back BigEndUInt16
   * variables into a single virtual BigEndUInt32 class.
   *
   * Why do this? Because on disk we have two back to back BigEndUInt16 fields
   * and the first was assigned to hold the nlink value prior to GPFS V3.3,
   * so we had a 16 bit nlink field, but for V3.3 we wanted to expand the nlink
   * to 32 bits so we want to use the second BigEndUInt16 field to be our high
   * order (MS16B) 16 bits. The class uses the existing BigEndUInt16 class.
   */
  class MixEndUInt32
  {
  private:
    BigEndUInt16 vlow;
    BigEndUInt16 vhigh;

  public:

    /* Don't use constructor/destructor in product as it causes problems */
    /* MixEndUInt32(){uval32=0;} */
    /* ~MixEndUInt32(){} */

    operator UInt32() const
    {
      UInt32 tlow  = (UInt16)vlow;
      UInt32 thigh = (UInt16)vhigh;
      return (UInt32)(tlow | thigh<<16);
    }

    MixEndUInt32 operator=(MixEndUInt32 nval32)
    {
      vlow  = nval32.vlow;
      vhigh = nval32.vhigh;
      return *this;
    }

    MixEndUInt32 operator=(UInt32 nval32)
    {
      vlow  = (UInt16)(nval32);
      vhigh = (UInt16)(nval32>>16);
      return *this;
    }

    MixEndUInt32 operator=(Int32 nval32)
    {
      vlow  = (UInt16)(nval32);
      vhigh = (UInt16)(nval32>>16);
      return *this;
    }

    bool operator==(MixEndUInt32 rhs) const
    {
      return ((vhigh == rhs.vhigh) && (vlow == rhs.vlow));
    }

    bool operator!=(MixEndUInt32 rhs) const
    {
      return ((vhigh != rhs.vhigh) || (vlow != rhs.vlow));
    }

    bool operator==(UInt32 rhs) const
    {
      BigEndUInt16 rlow;
      BigEndUInt16 rhigh;
      rlow  = (UInt16)(rhs);
      rhigh = (UInt16)(rhs>>16);
      return ((vhigh == rhigh) && (vlow == rlow));
    }

    bool operator!=(UInt32 rhs) const
    {
      BigEndUInt16 rlow;
      BigEndUInt16 rhigh;
      rlow  = (UInt16)(rhs);
      rhigh = (UInt16)(rhs>>16);
      return ((vhigh != rhigh) || (vlow != rlow));
    }

    bool operator==(Int32 rhs) const
    {
      BigEndUInt16 rlow;
      BigEndUInt16 rhigh;
      rlow  = (UInt16)(rhs);
      rhigh = (UInt16)(rhs>>16);
      return ((vhigh == rhigh) && (vlow == rlow));
    }

    bool operator!=(Int32 rhs) const
    {
      BigEndUInt16 rlow;
      BigEndUInt16 rhigh;
      rlow  = (UInt16)(rhs);
      rhigh = (UInt16)(rhs>>16);
      return ((vhigh != rhigh) || (vlow != rlow));
    }

    MixEndUInt32 operator+=(MixEndUInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 += n32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator+=(UInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 += nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator+=(Int32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 += nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator+(const MixEndUInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 += n32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator+(const UInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 += nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator+(const Int32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 += nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator-=(MixEndUInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 -= n32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator-=(UInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 -= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator-=(Int32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 -= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator-(const MixEndUInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 -= n32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator-(const UInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32  = (UInt32)*this;
      u32 -= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator-(const Int32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 -= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator&=(MixEndUInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 &= n32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator&=(UInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 &= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator&=(Int32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 &= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator&(const MixEndUInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 &= n32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator&(const UInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 &= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator&(const Int32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 &= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator|=(MixEndUInt32 nval32)
    { UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 |= n32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator|=(UInt32 nval32)
    { UInt32 u32 = (UInt32)*this;
      u32 |= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator|=(Int32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 |= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator|(const MixEndUInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 |= n32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator|(const UInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 |= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator|(const Int32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 |= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator^=(MixEndUInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 ^= n32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator^=(UInt32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 ^= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator^=(Int32 nval32)
    {
      UInt32 u32 = (UInt32)*this;
      u32 ^= nval32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 operator^(const MixEndUInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      UInt32 n32 = (UInt32)nval32;
      u32 ^= n32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator^(const UInt32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 ^= nval32;
      mu32 = u32;
      return mu32;
    }

    MixEndUInt32 operator^(const Int32 nval32) const
    {
      MixEndUInt32 mu32;
      UInt32 u32 = (UInt32)*this;
      u32 ^= nval32;
      mu32 = u32;
      return mu32;
    }

    /* prefix versions */
    MixEndUInt32 & operator++ ()
    {
      UInt32 u32 = (UInt32)*this;
      ++u32;
      *this = u32;
      return *this;
    }

    MixEndUInt32 & operator-- ()
    {
      UInt32 u32 = (UInt32)*this;
      --u32;
      *this = u32;
      return *this;
    }

    /* postfix versions */
    MixEndUInt32 operator++ (int)
    {
      UInt32 u32  = (UInt32)*this;
      MixEndUInt32 result = *this;
      ++u32;
      *this = u32;
      return result;
    }

    MixEndUInt32 operator-- (int)
    {
      UInt32 u32  = (UInt32)*this;
      MixEndUInt32 result = *this;
      --u32;
      *this = u32;
      return result;
    }
  };

#else /* not __cplusplus */

  /* FIXME: This is sloppy */

  typedef Int16  BigEndInt16;
  typedef UInt16 BigEndUInt16;
  typedef Int32  BigEndInt32;
  typedef UInt32 BigEndUInt32;
  typedef Int64  BigEndInt64;
  typedef UInt64 BigEndUInt64;

#endif /* __cplusplus */

/* Physical attributes of a Disk. */
struct cxiDiskInfo_t
{
  /* Size in bytes of a logical block as defined by SCSI, i.e. what
     is meant by a logical block address (LBA) in a disk command.
     See the description of the read capacity 16 command in the SCSI
     Block Commands 3 (SBC-3) standard.  If the logical block size is
     not a multiple of 512, then GPFS cannot use the disk and the fields
     below that are in units of sectors are undefined. */
  UInt32 logicalBlockSize;

  /* Size in bytes of a physical block on the storage medium -- must
     be a multiple of logicalBlockSize. */
  UInt32 physicalBlockSize;

  /* Total capacity of the device/partition in GPFS sectors. */
  UInt64 totalSectors;

  /* For partitioned device, offset in GPFS sectors of the partition
     from the beginning of the disk.  Zero for whole disk devices. */
  UInt64 deviceOffsetSector;

  /* Offset in GPFS sectors from the beginning of the disk to the
     first optimal storage boundary.  This is Linux's alignment_offset
     or SCSI's first aligned logical block -- usually zero. */
  UInt32 alignmentSectors;
};

/* Common nfs file handle structure: use this bad boy as the nfs file handle */
/* Only used when inode number of file or parent exceeds 32 bits */
typedef struct nfsFileHandleCommon_t
{
  UInt32 flags;  /* nfs file handle flag fields */ 
  UInt32 hash;   /* Hash of the file dentry name */
  UInt64 inode;  /* InodeNumber for file */
  UInt32 sid;    /* Snapshot id for file */
  UInt32 gen;    /* File generation number for file */
  UInt64 pinode; /* InodeNumber for parent file */
  UInt32 psid;   /* Snapshot id for parent file */
  UInt32 pgen;   /* File generation number for parent file */
}
nfsFileHandleCommon_t;
#define MAX_FH_INT 10
#define MAX_FH_SIZE (MAX_FH_INT*4)

/* Small nfs file handle used internally to do file lookups */
/* inode, sid, gen may be for parent or file and second inode will then be the
   other, file or parent */
typedef struct smallNfsFileHandleCommon_t
{
  UInt64 inode;  /* InodeNumber for file */
  UInt32 sid;    /* Snapshot id for file */
  UInt32 gen;    /* File generation number for file */
  UInt64 inode2; /* InodeNumber for second file, either parent or child */
} 
smallNfsFileHandleCommon_t;

/* Macros to be used when switching data from big endian to
 * the endian-ness of the CPU
 */
#ifdef GPFS_LITTLE_ENDIAN
#define BigEndToCPU16(d)  ByteSwap16(d)
#define BigEndToCPU32(d)  ByteSwap32(d)
#define BigEndToCPU64(d)  ByteSwap64(d)
#define CPUToBigEnd16(d)  ByteSwap16(d)
#define CPUToBigEnd32(d)  ByteSwap32(d)
#define CPUToBigEnd64(d)  ByteSwap64(d)
#else
#define BigEndToCPU16(d)  (d)
#define BigEndToCPU32(d)  (d)
#define BigEndToCPU64(d)  (d)
#define CPUToBigEnd16(d)  (d)
#define CPUToBigEnd32(d)  (d)
#define CPUToBigEnd64(d)  (d)
#endif

/* Macros to get the endian-ness and word size of this CPU */
#ifdef GPFS_LITTLE_ENDIAN
#define NodeBigEndian false
#else
#define NodeBigEndian true
#endif

typedef enum {
  OSTYPE_AIX,
  OSTYPE_LINUX,
  OSTYPE_WINDOWS,
  OSTYPE_SOLARIS,
  OSTYPE_UNKNOWN
} OSType;

#define ostypeToStr(T) \
  (((T) == OSTYPE_AIX)      ? "AIX"     : \
   ((T) == OSTYPE_LINUX )   ? "Linux"   : \
   ((T) == OSTYPE_SOLARIS ) ? "Solaris" : \
   ((T) == OSTYPE_WINDOWS ) ? "Windows" : \
                              "unknown")

#define ostypeToStrShort(T) \
  (((T) == OSTYPE_AIX)      ? "AIX" : \
   ((T) == OSTYPE_LINUX )   ? "Lnx" : \
   ((T) == OSTYPE_SOLARIS ) ? "Sol" : \
   ((T) == OSTYPE_WINDOWS ) ? "Win" : \
                              "unk")

#define ostypeFromStr(S) \
  (!strcmp(S, "AIX")        ? OSTYPE_AIX     : \
   !strcmp(S, "Linux")      ? OSTYPE_LINUX   : \
   !strcmp(S, "Solaris")    ? OSTYPE_SOLARIS   : \
   !strcmp(S, "Windows")    ? OSTYPE_WINDOWS   : \
                              OSTYPE_UNKNOWN)

#if defined(GPFS_AIX)
#define NodeOperatingSystem OSTYPE_AIX
#elif defined(GPFS_LINUX)
#define NodeOperatingSystem OSTYPE_LINUX
#elif defined(GPFS_SOLARIS)
#define NodeOperatingSystem OSTYPE_SOLARIS
#elif defined(GPFS_WINDOWS)
#define NodeOperatingSystem OSTYPE_WINDOWS
#endif

#ifdef __cplusplus
static const bool IsAIX = NodeOperatingSystem == OSTYPE_AIX;
static const bool IsLinux = NodeOperatingSystem == OSTYPE_LINUX;
static const bool IsWindows = NodeOperatingSystem == OSTYPE_WINDOWS;
#endif

#ifdef __64BIT__
#define NodeWordSize 64
#else
#define NodeWordSize 32
#endif

/* Retrieve the file type from the mode and translate it to cxiNodeType_t */
#define CXIMODE_TO_NODETYPE(M) (modeToNodeType[((M) & S_IFMT) >> 12])

/* Invariant size time structure. */
typedef struct cxiTimeStruc32_t
{
  cxiTime32_t tv_sec;   /* seconds */
  cxiNSec32_t tv_nsec;  /* nanoseconds */
} cxiTimeStruc32_t;

/* May be 32/64 bit specific depending on how OS defines
 * cxiTime_t (cxiTypes-plat.h).  On AIX cxiTime_t (time_t) is
 * an int32long64 and cxiNSec_t (suseconds_t) is a signed int.
 * Nanoseconds can always be represented within 32 bits, however
 * on linux it's a long int, which would change size for 64bits.
 */
typedef struct cxiTimeStruc_t
{
  cxiTime_t tv_sec;    /* seconds */
  cxiNSec_t tv_nsec;   /* nanoseconds */
} cxiTimeStruc_t;

#define GETATTR_EXACT      0x00000001
#define GETATTR_NFS        0x00000002
#define GETATTR_COMPACT_OK 0x00000004
#define GETATTR_EXTENDED   0x00000008
#define GETATTR_LITE       0x00000010
/* unused                  0x00000020 */
#define GETATTR_ATIMEXATTR 0x00000040
#define GETATTR_REVALIDATE 0x00000080
#define GETATTR_PERM_OK    0x00000100 /* READ_ATTR permission approved */

/* nlink32: va_nlink was increased from 16 to 32 bits */ 
/*          generation number increased from 32 to 64 bits */
/* INODE64: inode number increasing from 32 to 64 bits */
/* Structure is no longer identical to struct vattr on AIX, do not memcpy! */
/* Cleanup: some fields changed to use fixed variable sizes */
typedef struct cxiVattr_t
{
  UInt32         va_type;       /* vnode type */
  cxiMode_t      va_mode;       /* access mode */
  cxiUid_t       va_uid;        /* owner uid */
  cxiGid_t       va_gid;        /* owner gid */
  union
  {
    cxiDev_t    _va_dev;        /* id of device containing file */
    IntNative   _va_fsid;       /* fs id (dev for now) */
  } _vattr_union;
  cxiIno64_t     va_ino;        /* file (serial) inode number */
  UInt32         va_nlink;      /* number of links */
  UInt16         va_flags;      /* Flags, see below for define */
  UInt32         va_mask;       /* Initial attribute mask */
  cxiOff64_t     va_size;       /* file size in bytes */
  UInt32         va_blocksize;  /* preferred blocksize for io */
  UInt64         va_blocks;     /* number of 512-byte blocks held by file */

  /* The following three fields use the 32/64 bit dependent
   * cxiTimeStruc_t since the AIX vattr structure defines these
   * with timestruc_t which has time_t field.
   */
  cxiTimeStruc_t va_atime;      /* time of last access */
  cxiTimeStruc_t va_mtime;      /* time of last data modification */
  cxiTimeStruc_t va_ctime;      /* time of last status change */
  cxiDev_t       va_rdev;       /* id of device */

  /* Fields added for compatability with the fullstat structure */
  UInt32         va_chan;       /* unused (channel on AIX) */
  cxiSize_t      va_xinfo;      /* Extended info field (defined below)
                                   (AIX: cxiSize_t va_aclsiz (size of ACL)) */
  UInt64         va_gen;        /* inode generation number */
} cxiVattr_t;

#ifdef __cplusplus
/* Extended attributes: stuff from cxiVattr_t plus more exotic attrs */
struct cxiVattrExt_t : public cxiVattr_t
{
  cxiTimeStruc_t va_creationTime;
  UInt32 va_winAttrs;
};
#endif /* __cplusplus */

#ifdef GPFS_CACHE
#define PCACHE_FHSIZE_V1 128  /* pre 4.1TL2 */
#define PCACHE_FHSIZE_V2 64   /* 4.1TL2 and later */

#ifdef GPFS_CACHE_ASYNC
#define PCACHE_FHSIZE   PCACHE_FHSIZE_V2
#else
#define PCACHE_FHSIZE   PCACHE_FHSIZE_V1
#endif

/* Supported NFS types */
typedef enum
{
  PCACHE_NFS_KNFS = 0,
  PCACHE_NFS_GANESHA
} PcacheNFSType;

/* Supported filesystem backends */
typedef enum
{
  PCACHE_VFS_NFS  = 0,  /* Default is nfs */
  PCACHE_VFS_CIFS,
  PCACHE_VFS_EXT3,
  PCACHE_VFS_GPFS,
  PCACHE_VFS_LUSTRE,
  PCACHE_NUM_VFS        /* last value is number of VFS */
} PcacheFsType;

#define PcacheFsTypeToString(T) \
  (((T) == PCACHE_VFS_NFS)   ? "nfs"     : \
   ((T) == PCACHE_VFS_CIFS)  ? "cifs"    : \
   ((T) == PCACHE_VFS_EXT3)  ? "ext3"    : \
   ((T) == PCACHE_VFS_GPFS)  ? "gpfs"    : \
   ((T) == PCACHE_VFS_LUSTRE)? "lustre"  : \
                               "unknown")

typedef struct cxiFH_t
{
  UInt16  size;
  UChar   data[PCACHE_FHSIZE];
} cxiFH_t;

/* File handle structure that encodes the GPFS fileId */
typedef struct pcacheFileHandle_t
{
  BigEndUInt64 inodeNum;  /* 64-bit inode number */
  BigEndUInt64 snapId;    /* 64-bit snapshot id */
  BigEndUInt32 genNum;    /* 32-bit generation number */
  BigEndUInt32 filesetId; /* 32-bit fileset id */
} pcacheFileHandle_t;
  
typedef struct pcacheAttr
{
  cxiMode_t       pa_mode;
  cxiUid_t        pa_uid;
  cxiGid_t        pa_gid;
  cxiIno_t        pa_ino;
  cxiDev_t        pa_rdev;
  cxiOff64_t      pa_size;
  UInt32          pa_nlink;
  cxiTimeStruc_t  pa_ctime;
  cxiTimeStruc_t  pa_mtime;
  cxiTimeStruc_t  pa_atime;
  UInt16          pa_version;
  cxiFH_t         pa_fh;
} pcacheAttr_t;

typedef enum
{
  PCACHE_RCMD_GET_MOUNTINFO,
  PCACHE_RCMD_GET_HASH,
  PCACHE_RCMD_SET_ATTRS,
  PCACHE_RCMD_SET_XATTRS,
  PCACHE_RCMD_SET_EXATTRS,
  PCACHE_RCMD_GET_LASTSNAPNAME,
  PCACHE_RCMD_GET_SNAPDIFF,
  PCACHE_RCMD_MK_SECONDARY,
  PCACHE_RCMD_UPDATE_ATTRS,
}pcacheRcmd_t;

typedef struct pcacheRemoteAttr
{
  pcacheRcmd_t cmd;
  UInt16 fsType;
  UInt16 nfsType;
  UInt32 nfsReadSize;
  UInt32 hashValue;
  UInt32 filesetId;
  UInt64 inodeNum;
  UInt64 dirInodeNum;
  UInt64 remoteInodeNum;
  char fileName[CXI_MAXPATHLEN];
  void *xattrBufP;
  pcacheAttr_t attr;
}pcacheRemoteAttr_t;

#endif /* GPFS_CACHE */

/* Define bit flags for the extended information field */
#define VA_XPERM 0x0001         /* file has extended ACL */
#define VA_XVOL  0x0002         /* dir entry was generated and is volatile */
#define VA_HASXATTR 0x0004      /* file has extended attributes */
#define VA_ISIMMUTABLE 0x0008   /* file is immutable */
#define VA_ISAPPENDONLY 0x0010  /* file is appendOnly */
#define VA_ISINCOMPLETE 0x0020  /* pcache file is not data cached */

/* Start of the range used to generate unique inode numbers for snapshot
   link directories, when running on an old file system for which we have
   not yet created the range of additional reserved inode numbers, which
   would normally be used for this puropose (see makeExternalInodeNum and
   isSnapRootDireExternalIno). */
#define SNAPROOTDIR_EXT_INO_BASE 0x00000000FFFF0000ULL

#ifdef va_dev
#undef va_dev
#endif
#ifdef va_fsid
#undef va_fsid
#endif
#define va_dev   _vattr_union._va_dev
#define va_fsid  _vattr_union._va_fsid

/* Windows attribute bits */
#define GPFS_VA_WINATTR_ARCHIVE              0x0001
#define GPFS_VA_WINATTR_COMPRESSED           0x0002
#define GPFS_VA_WINATTR_DEVICE               0x0004
#define GPFS_VA_WINATTR_DIRECTORY            0x0008
#define GPFS_VA_WINATTR_ENCRYPTED            0x0010
#define GPFS_VA_WINATTR_HIDDEN               0x0020
#define GPFS_VA_WINATTR_NORMAL               0x0040
#define GPFS_VA_WINATTR_NOT_CONTENT_INDEXED  0x0080
#define GPFS_VA_WINATTR_OFFLINE              0x0100
#define GPFS_VA_WINATTR_READONLY             0x0200
#define GPFS_VA_WINATTR_REPARSE_POINT        0x0400
#define GPFS_VA_WINATTR_SPARSE_FILE          0x0800
#define GPFS_VA_WINATTR_SYSTEM               0x1000
#define GPFS_VA_WINATTR_TEMPORARY            0x2000
#define GPFS_VA_WINATTR_HAS_STREAMS          0x4000
#define GPFS_VA_WINATTR_MASK_ALL             0x7fff

/* gpfs_set_winattrs APIs treat the offline bit as R/O (and possibly others in the future */
#define GPFS_VA_WINATTR_MASK_SETATTR_API (GPFS_VA_WINATTR_MASK_ALL & ~GPFS_VA_WINATTR_OFFLINE)


/* Information passed via Windows FILE_BASIC_INFORMATION struct */
typedef struct cxiWinBasicInfo_t
{
  UInt32 flags;
  cxiTimeStruc_t atime;
  cxiTimeStruc_t mtime;
  cxiTimeStruc_t ctime;
  cxiTimeStruc_t creationTime;

  /* Attribute bits */
  UInt32 attrs;
} cxiWinBasicInfo_t;

#define GPFS_WININFO_SET_ATIME         0x01
#define GPFS_WININFO_SET_MTIME         0x02
#define GPFS_WININFO_SET_CTIME         0x04
#define GPFS_WININFO_SET_CREATION_TIME 0x08
#define GPFS_WININFO_SET_ATTRS         0x10
#define GPFS_WININFO_SUPPRESS_IMPLICIT 0x20

/* INODE64: ! logRecTag needs to go to 64 bits */
typedef struct cxiErrorLogEntry_t
{
  short logErrorType;       /* One of the values #defined below */

  /*   Fields common for all types of errors   */
  UInt32 logRecTag;         /* Tag to associate related log entries */
  const char *componentName;/* Name of the malfunctioning component */
  const char *componentID;
  const char *buildBranch;

  /*  Fields used by logMoreInfo, logGenIF, logShutdownIF    */
  const char *strFileName;  /* File in which the error occurred */
  UInt32 srcLineNumber;     /* Line on which the error occurred */
  Int32 retCode;            /* return code value */
  Int32 reasonCode;         /* reason code value */
  const char *dataStr;      /* Data dump string */
  const char *failingExpr;  /* Expression that evaluates to false */

  /*   Fields used by LOGSPECIFIC   */
  UInt32 logTemplID;        /* Error log template ID (used in AIX only) */
  const char *formatStr;    /* printf-style format string */
  void *varargPtrPtr;       /* Pointer to the variable argument list
                               (will be casted to va_list *)           */

  char *kernData;           /* Used for copying the logRecData field of the logging
                               kernel mailbox   */
  int kernDataLength;       /* = logRecDataLen */

  const char *moduleVersion;/* Used only for logging from external progsams */
} cxiErrorLogEntry_t;

#ifdef SMB_LOCKS
/* Enumeration used to specify whether a file will be read or written. */
enum AccessMode
{
  opAccessNone  = 0,
  opAccessRead  = 1,
  opAccessWrite = 2
};

/* types of oplocks granted to Samba */
enum OplockMode
{
  smbOplockNone  = 0,
  smbOplockShared  = 1,
  smbOplockExclusive = 2
};

/* Check whether oplock olm is in conflict with lock access am:
   A conflict exists if one of the two is for write/exlucisve and the
   other one is at least for read/shared. */
#define oplockAccessConflict(olm, am) ((int)(olm) + (int)(am) > 2)
#endif

/* Types of dentry operations tables that can be requested. */
typedef enum DentryOpTableTypes
{
  DOpNormal,
  DOpOnlyValidIfSamba,
  DOpInvalidIfSamba,
  DOpValidate
#ifdef GPFS_CACHE
  , DOpPCache
#endif
} DentryOpTableTypes;

#define LOG_ERR_SPECIFIC    0x1
#define LOG_ERR_GENERIC     0x2
#define LOG_ERR_MOREINFO    0x3
#define LOG_ERR_SHUTDOWN    0x4
#define LOG_ERR_TRACEBACK   0x5
#define LOG_ERR_SPECIFIC_KERN  0x6


/* Common part of information about an open file */
typedef struct cxiVinfo_t
{
  cBoolean viInUse;      /* True if VInfo is in use by an open file */
  cBoolean disconnected; /* True if the daemon died or a forced unmount or
                            SG panic occurred since the file was opened */
  cBoolean viIsNFS;      /* True if this cxiVinfo_t is embedded inside a
                            struct NFSData */
  cBoolean rwPageDone;   /* True if paging requests received */
  cBoolean viIsDIO;      /* True if the instance was opened for DIO */
} cxiVinfo_t;

#ifdef _KERNEL
#ifdef __cplusplus
extern "C" {
#endif
/* Function pointer for main routine of a kernel process */
typedef void (*cxiKProcFunc_t)(void *argP);
#ifdef __cplusplus
}
#endif

/* Interface structure to cxiStartKProc() and cxiStopKProc() */
typedef struct cxiKProcData_t
{
  cxiPid_t pid;        /* proc pid (returned) */

  /* protects startStopEvent and kprocEvent transitions */
  cxiBlockingMutex_t lock;

  /* kproc can sleep here */
  cxiWaitEvent_t kprocEvent;

  /* start or stop request should sleep here waiting on pid transition */
  cxiWaitEvent_t startStopEvent; 

  int priority;        /* process priority of kproc */
  int kprocFlags;      /* flags to pass to kernel thread creation routine */
  Boolean terminate;   /* terminate proc when true */
  cxiKProcFunc_t func; /* proc function */
  void *fargP;         /* proc function arguments */
  const char *nameP;   /* proc name */
  char *systemP;       /* any system data structure associated with process */
} cxiKProcData_t;

#define KPROC_FAILED_PID      -1
#define KPROC_UNASSIGNED_PID  -2
#define KPROC_RUNNING(KP)     ((KP)->pid > 0)
#endif /* _KERNEL */


/* Callback function to return directory entries.
   Called by readddir for each directory entry to be returned to the user.
   Should return zero if the entry still fits in the user's buffer;
   otherwise a negative value should be returned.  The 'offset' parameter
   is the logical offset of the current entry, i.e., a seekdir to that
   offset followed by a readdir will return the same directory entry again. */
typedef int (*cxiFillDir_t)(void *argP, const char *nameP, int namelen,
                            offset_t offset, int snOffset, cxiIno_t ino,
                            void *eP);

#define GPFS_DIR_EOF 0x7FFFFFFF


/* Macros to do multiplication, division, and modulo by numbers that
   are probably powers of two.  Depending on which define is set, the
   operations can be performed using the built-in operators /, *, and %,
   or using shifts and masks.  The _shift parameter of the macros should
   be log base 2 of _divisor or _multiplier, or 0 if _divisor or
   _multiplier is not a power of 2.  If POW2_COND_SHIFT is defined, the
   generated code will test _shift for 0, then do either a shift or the
   general operation.  If POW2_FORCE_SHIFT is defined, the generated
   code will always use shifts.  This requires that the subblock size of
   the file system actually be a power of 2.  If neither POW2_COND_SHIFT
   nor POW2_FORCE_SHIFT are defined, the generated code will use the
   general operations (/, *, or %). */
#if defined(POW2_FORCE_SHIFT)
# define MULT_OR_SHIFT(_multiplicand, _multiplier, _shift)   \
     ((_multiplicand)<<(_shift))
# define DIV_OR_SHIFT(_dividend, _divisor, _shift)           \
     ((_dividend)>>(_shift))
# define MOD_OR_MASK(_dividend, _divisor, _shift)            \
     ((_dividend) & ((1<<(_shift)) - 1))
#elif defined(POW2_COND_SHIFT)
# define MULT_OR_SHIFT(_multiplicand, _multiplier, _shift)   \
   ( ((_shift)!=0) ?                                         \
       (_multiplicand) << (_shift) :                         \
       ((_multiplicand)*(_multiplier)) )
# define DIV_OR_SHIFT(_dividend, _divisor, _shift)           \
   ( ((_shift)!=0) ?                                         \
       (_dividend) >> (_shift) :                             \
       ((_dividend)/(_divisor)) )
# define MOD_OR_MASK(_dividend, _divisor, _shift)            \
   ( ((_shift)!=0) ?                                         \
       (_dividend) & ((1<<(_shift)) - 1) :                   \
       ((_dividend)%(_divisor)) )
#else
# define MULT_OR_SHIFT(_multiplicand, _multiplier, _shift)   \
     ((_multiplicand)*(_multiplier))
# define DIV_OR_SHIFT(_dividend, _divisor, _shift)           \
     ((_dividend)/(_divisor))
# define MOD_OR_MASK(_dividend, _divisor, _shift)            \
     ((_dividend)%(_divisor))
#endif

/* Memory copy macros that use memcpy when aligned data accesses
   are necessary, and standard pointer typecast copying otherwise. */
#ifdef ALIGNED_DATA_ACCESS
#define MCPY(DEST, SRC, TYPE)  memcpy((void*) DEST, (void*) SRC, sizeof(TYPE));
#define MCPY_SRCVAR(DEST, SRCVAR, TYPE)  memcpy((void*) DEST, (void*) &SRCVAR, sizeof(TYPE));
#define MCPY_DESTVAR(DESTVAR, SRC, TYPE)  memcpy((void*) &DESTVAR, (void*) SRC, sizeof(TYPE));
#define MCPY_VAR(DEST, SRC, TYPE)  memcpy((void*) &DEST, (void*) &SRC, sizeof(TYPE));
#else
#define MCPY(DEST, SRC, TYPE)  *((TYPE *)DEST) = *((TYPE *)SRC);
#define MCPY_SRCVAR(DEST, SRCVAR, TYPE)  *((TYPE *)DEST) = SRCVAR;
#define MCPY_DESTVAR(DESTVAR, SRC, TYPE) DESTVAR = *((TYPE *)SRC);
#define MCPY_VAR(DEST, SRC, TYPE) DEST = SRC;
#endif /* ALIGNED_DATA_ACCESS */

/* Flag values for cxiNode_t::icValid:
   Indicates whether inode attributes cached in the osNode (struct inode
   in Linux) are known to be valid. */
#define CXI_IC_PERM   0x00000001  /* permission related inode fields (owner,
                                     mode, acl, etc) are valid */
#define CXI_IC_ATTR   0x00000002  /* other inode fields are valid */

/* combinations of bits defined above: */
#define CXI_IC_STAT   0x00000003  /* what needs to be valid for stat() */
#define CXI_IC_ALL    0x00000003  /* OR of all flags above */

typedef Int32 DiskNum_t;
typedef Int64 SectorNum_t;
typedef Int32 SectorNumHigh_t;
typedef UInt32 SectorNumLow_t;
typedef Int64 BlkNum_t;
#define DiskSizeInit MAX_INT64

#ifndef INODENUM_ROOTDIR_FILE
/* Definition needed in portability layer */
#define INODENUM_ROOTDIR_FILE 3
#else /* See fs/FSDisk.h. */
#endif

/* g++ implicitly expects a new() operator to throw an exception rather than
   return NULL if memory allocation fails, and GPFS code never throws any
   exceptions.  Therefore, if memory allocation fails, g++-generated code 
   would proceed to call the object constructor, with "this" set to NULL, 
   which will quickly cause SIGSEGV/kernel exception.  Defining new() with 
   an empty throw() clause causes g++ to check for NULL returned by NULL and 
   skip the constructor call, thus giving our code a chance for handling the 
   allocation failure gracefully. */
#ifdef GPFS_LINUX
#define THROWEMPTY throw()
#else
#define THROWEMPTY 
#endif

#ifdef LIGHT_WEIGHT_EVENT
#include <gpfs_lweTypes.h>
#endif

#if defined(GPFS_AIX) || defined(GPFS_LINUX) || defined(GPFS_SOLARIS)
#define GPFS_THREAD_SPEC __thread
#else
#if defined(GPFS_WINDOWS)
#define GPFS_THREAD_SPEC __declspec(thread) 
#endif
#endif

#define CXI_CONTAINER_OF(ptr,type,member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

/* Define CXI_INLINE to the inline keyword if C++ or C99. */
#if defined(__cplusplus) || \
    (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L)
#define CXI_INLINE  inline
#else
#define CXI_INLINE  /*empty*/
#endif

#endif  /* _h_cxiTypes */
