/***************************************************************************
 *
 * Copyright (C) 2001 International Business Machines
 * All rights reserved.
 *
 * This file is part of the GPFS mmfslinux kernel module.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer. 
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution. 
 *  3. The name of International Business Machines may not be used to endorse 
 *     or promote products derived from this software without specific prior 
 *     written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Alternatively, provided that this notice is retained in full, this
 * software may be distributed under the terms of the GNU General
 * Public License ("GPL") as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version,
 * in which case the provisions of the GPL apply INSTEAD OF those given above.
 *
 ****************************************************************************/
/* @(#)39       1.295.1.5  src/avs/fs/mmfs/ts/kernext/gpl-linux/kx.c, mmfs, avs_rfks1, rfks1s008a 3/29/15 08:29:10 */

#include <Shark-gpl.h>

#ifdef MODULE
#include <linux/module.h>
#endif
#include <linux/string.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/dcache.h>
#include <linux/file.h>
#include <linux/stat.h>
#include <linux/personality.h>
#include <linux/fcntl.h>
#ifdef GANESHA
#if LINUX_KERNEL_VERSION >= 2063200
  #include <linux/ratelimit.h>
#endif
#if LINUX_KERNEL_VERSION >= 2062600
  #include <linux/fdtable.h>
#endif
#include <linux/sunrpc/svc.h>
#include <linux/nfsd/nfsfh.h>
#include <linux/sunrpc/cache.h>
#include <linux/nfsd/export.h>
#include <linux/fsnotify.h>
#include <linux/quotaops.h>
#include <linux/highuid.h>
#endif
#if (defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)) && defined(TS_RPC_PERF)
#include <asm/time.h>
#endif
#include <gpfs_fcntl.h>
#include <gpfs_nfs.h>

#ifndef GPFS_ARCH_X86_64
/* grab stuff for madvise */
#define __KERNEL_SYSCALLS__
#endif
#include <linux/unistd.h>
#include <linux/mman.h>

#include <verdep.h>
#include <cxiSystem.h>
#include <cxi2gpfs.h>
#include <cxiCred.h>

#include <linux2gpfs.h>
#include <Trace.h>
#include <cxiMode.h>
#include <cxiTSFattr.h>
#include <cxiVFSStats.h>

#define MAX_NLINK16 65535

#define _SYS_STAT_H
#include <cxiTypes.h>

extern void incompleteAioListRemove(struct cxiUioAio_t *uioaioP);

#define E_HOLE 238

#ifdef API_32BIT

/* Equivalent structure for stat64 at 32-bit user level (for API remapping) */
/* gcc doesn't align double words with i386/ia32 like it does for ia64, so
 * we need to adjust for this. */
/* Ideally we would include a header file with this definition (ia32.h) instead
   of defining it ourselves, but this typically breaks things
   (such as with x86_64). */
typedef struct stat64_user32 {
  UInt64 st_dev;
  UInt32 __pad1;
  UInt32 __st_ino;
  UInt32 st_mode;
  UInt32 st_nlink;
  UInt32 st_uid;
  UInt32 st_gid;
  UInt64 st_rdev;
  UInt32 __pad2;
  UInt32 st_size_lower;     /* break up st_size to avoid extra padding */
  UInt32 st_size_upper;     /* w/ little Endian ordering */
  UInt32 st_blksize;
  UInt64 st_blocks;
  UInt32 st_atime;
  UInt32 __unused1;
  UInt32 st_mtime;
  UInt32 __unused2;
  UInt32 st_ctime;
  UInt32 __unused3;
  UInt64 st_ino;
} stat64_user32;
#endif /* API_32BIT */

/* check if inode belongs to GPFS */
#define GPFS_TYPE(IP) (!(IP) ? false : \
                        (!(IP->i_sb) ? false : \
                          (!(IP->i_sb->s_type) ? false : \
                            !strcmp(IP->i_sb->s_type->name, "gpfs"))))

int
kxPoll(void* fdListP, int nFDs, int timeoutMS)
{
  return -ENOSYS;
}

int cleanupFD = 0;

#ifdef API_32BIT
static void
vstat32(cxiVattr_t *vattrp, struct stat64_user32 *statbuf)
{
  ENTER(0);
  memset(statbuf, 0, sizeof(struct stat64_user32));

  statbuf->st_dev         = vattrp->va_dev;
  statbuf->st_ino         = vattrp->va_ino;
  statbuf->st_mode        = vattrp->va_mode;
  statbuf->st_nlink       = vattrp->va_nlink;
  statbuf->st_uid         = vattrp->va_uid;
  statbuf->st_gid         = vattrp->va_gid;
  statbuf->st_rdev        = vattrp->va_rdev;
  statbuf->st_size_upper  = High32(vattrp->va_size);
  statbuf->st_size_lower  = Low32(vattrp->va_size);
  statbuf->st_atime       = vattrp->va_atime.tv_sec;
  statbuf->st_mtime       = vattrp->va_mtime.tv_sec;
  statbuf->st_ctime       = vattrp->va_ctime.tv_sec;
  statbuf->st_blksize     = vattrp->va_blocksize;
  statbuf->st_blocks      = vattrp->va_blocks;
  /* STAT64_HAS_BROKEN_ST_INO is set on i386 ... */
  statbuf->__st_ino       = vattrp->va_ino;
  EXIT(0);
}
#endif /* API_32BIT */

void static
vstat(cxiVattr_t *vattrp, struct stat64 *statbuf)
{
  ENTER(0);
  memset(statbuf, 0, sizeof(struct stat64));

  statbuf->st_dev         = vattrp->va_dev;
  statbuf->st_ino         = vattrp->va_ino;
  statbuf->st_mode        = vattrp->va_mode;
  /* Make sure we do a best effort to convert nlink to fit the field */
  statbuf->st_nlink = vattrp->va_nlink;
  if (sizeof(statbuf->st_nlink) == 2)
    statbuf->st_nlink = MIN(vattrp->va_nlink, MAX_NLINK16);
  statbuf->st_uid         = vattrp->va_uid;
  statbuf->st_gid         = vattrp->va_gid;
  statbuf->st_rdev        = vattrp->va_rdev;
  statbuf->st_size        = vattrp->va_size;
  statbuf->st_atime       = vattrp->va_atime.tv_sec;
  statbuf->st_mtime       = vattrp->va_mtime.tv_sec;
  statbuf->st_ctime       = vattrp->va_ctime.tv_sec;
#ifdef STAT_HAVE_NSEC
  statbuf->st_atime_nsec  = vattrp->va_atime.tv_nsec;
  statbuf->st_mtime_nsec  = vattrp->va_mtime.tv_nsec;
  statbuf->st_ctime_nsec  = vattrp->va_ctime.tv_nsec;
#else
  statbuf->st_atime_nsec  = 0;
  statbuf->st_mtime_nsec  = 0;
  statbuf->st_ctime_nsec  = 0;
#endif
  statbuf->st_blksize     = vattrp->va_blocksize;
  statbuf->st_blocks      = vattrp->va_blocks;

#ifdef STAT64_HAS_BROKEN_ST_INO
  /* Linux has 2 struct stat64 definitions:
      1) /usr/include/asm/stat.h
      2) /usr/include/bits/stat.h
     Of course, they differ
      1) st_dev & st_rdev is 2 bytes in (1) and 8 bytes in (2),
         but the 2 definitions overlap.
      2) st_ino is 8 bytes in (1) and 4 bytes in (2)
         and they are in different places!
    Fortunately, (1) defines an ifdef telling us to assign st_ino
    to a second variable which just happens to exactly match the
    definition in (2). */
  statbuf->__st_ino       = vattrp->va_ino;
#endif
  EXIT(0);
}

#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
void static
vstat_ppc64(cxiVattr_t *vattrp, struct stat *statbuf)
{
  ENTER(0);
  memset(statbuf, 0, sizeof(struct stat));
                                                                                
  statbuf->st_dev         = vattrp->va_dev;
  statbuf->st_ino         = vattrp->va_ino;
  statbuf->st_mode        = vattrp->va_mode;
  /* Make sure we do a best effort to convert nlink to fit the field */
  statbuf->st_nlink = vattrp->va_nlink;
  if (sizeof(statbuf->st_nlink) == 2)
    statbuf->st_nlink = MIN(vattrp->va_nlink, MAX_NLINK16);
  statbuf->st_uid         = vattrp->va_uid;
  statbuf->st_gid         = vattrp->va_gid;
  statbuf->st_rdev        = vattrp->va_rdev;
  statbuf->st_size        = vattrp->va_size;
  statbuf->st_atime       = vattrp->va_atime.tv_sec;
  statbuf->st_mtime       = vattrp->va_mtime.tv_sec;
  statbuf->st_ctime       = vattrp->va_ctime.tv_sec;
#ifdef STAT_HAVE_NSEC
  statbuf->st_atime_nsec  = vattrp->va_atime.tv_nsec;
  statbuf->st_mtime_nsec  = vattrp->va_mtime.tv_nsec;
  statbuf->st_ctime_nsec  = vattrp->va_ctime.tv_nsec;
#else
  statbuf->st_atime_nsec  = 0;
  statbuf->st_mtime_nsec  = 0;
  statbuf->st_ctime_nsec  = 0;
#endif
  statbuf->st_blksize     = vattrp->va_blocksize;
  statbuf->st_blocks      = vattrp->va_blocks;
  EXIT(0);
}
#endif /* GPFS_ARCH_PPC64 || GPFS_ARCH_PPC64_LE */

#define LITEMASK_EXACT_ATIME(m)   (0  != ((m) & 0x10))
#define LITEMASK_SET_EXACT(m)     (m) |= 0x77
#define LITEMASK_SET_NORMAL(m)    (m)  = 0x67

/* a call to return exact file status information
 * using the file's pathname;
 */
int
tsstat(const char *pathname, struct stat64 *statP, 
       unsigned int *litemaskP, unsigned int statFlags)
{
  struct gpfsVfsData_t *privVfsP;
  cxiNode_t *cnP;
  int code = 0;
  int rc = 0;
  struct nameidata nd;
  struct inode *iP;
  Boolean relePath = false;
  cxiVattr_t vattr;
  int flags = 0;
  unsigned int litemask = 0;
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
  struct stat statbuf;
#else
  struct stat64 statbuf;
#endif
#ifdef API_32BIT
  stat64_user32 statbuf32;
#endif

  ENTER(0);
  if (pathname == NULL || statP == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }

  if (statFlags & GPFS_NOFOLLOW)
    rc = USER_LPATH(pathname, &nd);
  else
    rc = USER_PATH(pathname, &nd);

  if (rc)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }
  relePath = true;

  iP = NDP_TO_IP(&nd);
  DBGASSERT(iP != NULL);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_TSSTAT_ENTER,
         "tsstat enter: iP 0x%lX statP 0x%lX\n", iP, statP);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  rc = cxiCopyIn((char *)litemaskP, (char *)&litemask, sizeof(unsigned int));
  if (rc)
  {
    code = 6;
    goto xerror;
  }

  /* Based on litemask, set either GETATTR_EXACT, GETATTR_LITE, or ZERO */
  if (LITEMASK_EXACT_ATIME(litemask))
  {
    /* Accurate atime required exact stat */
    flags = GETATTR_EXACT;
    LITEMASK_SET_EXACT(litemask);
  }
  else if (0 == litemask)
  {
    /* No attrs must be exact.  This is statlite. */
    flags = GETATTR_LITE;
  }
  else
  {
    /* Normal stat (atime need not be accurate) */
    flags = 0;
    litemask = 0x67;
    LITEMASK_SET_NORMAL(litemask);
  }

  rc = gpfs_ops.gpfsGetattr(privVfsP, cnP, &vattr, flags);

  vattr.va_rdev = cxiDev32ToDev(vattr.va_rdev);

  if (rc == 0)
  {
#ifdef API_32BIT
    /* Need to remap? */
    if (cxiIS64U((char *)statP))
    {
      vstat(&vattr, &statbuf);

      rc = cxiCopyOut((char *)&statbuf, (char *)statP, sizeof(struct stat64));
    }
    else
    {
      /* Need to remap for 32-bit API call */
      vstat32(&vattr, &statbuf32);

      rc = cxiCopyOut((char *)&statbuf32, (char *)statP,
                      sizeof(struct stat64_user32));
    }
#else

#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
    /* On ppc64, struct stat64 layout is different for a 64-bit user app and
       kernel, and we can't use it for copying data out.  However, struct stat
       has the same layout in kernel and 64-bit userspace, and is identical
       to struct stat64 in 64-bit userspace, so we use it for copyout. */
    vstat_ppc64(&vattr, &statbuf);
#else
    vstat(&vattr, &statbuf);
#endif
    rc = cxiCopyOut((char *)&statbuf, (char *)statP, sizeof(statbuf));

#endif /* API_32BIT */
    if (rc != 0)
    {
      code = 5;
      goto xerror;
    }

    /* return litemask */
    rc = cxiCopyOut((char *)&litemask, (char *)litemaskP, sizeof(unsigned int));
    if (rc)
    {
      code = 7;
      goto xerror;
    }
  }

xerror:
  if (relePath)
    PATH_PUT(&nd);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_TSSTAT_EXIT,
         "tsstat exit: code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}

int
tsfstat(int fileDesc, struct stat64 *statP)
{
  struct gpfsVfsData_t *privVfsP;
  cxiNode_t *cnP;
  struct file *fP = NULL;
  struct inode *iP;
  int code = 0;
  int rc;
  Boolean releFile = false;
  cxiVattr_t vattr;
#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
  struct stat statbuf;
#else
  struct stat64 statbuf;
#endif
#ifdef API_32BIT
  struct stat64_user32 statbuf32;
#endif /* API_32BIT */

  ENTER(0);
  if (statP == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }

  fP = fget(fileDesc);
  if (!fP)
  {
    code = 2;
    rc = EBADF;
    goto xerror;
  }
  releFile = true;

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_TSFSTAT_ENTER,
         "tsfstat enter: fd %d fP 0x%lX iP 0x%lX statP 0x%lX\n",
         fileDesc, fP, iP, statP);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  rc = gpfs_ops.gpfsGetattr(privVfsP, cnP, &vattr, GETATTR_EXACT);
  vattr.va_rdev = cxiDev32ToDev(vattr.va_rdev);

  if (rc == 0)
  {
#ifdef API_32BIT
    /* Need to remap? */
    if (cxiIS64U((char *)statP))
    {
      vstat(&vattr, &statbuf);

      rc = cxiCopyOut((char *)&statbuf, (char *)statP, sizeof(struct stat64));
    }
    else
    {
      /* Need to remap for 32-bit API call */
      vstat32(&vattr, &statbuf32);

      rc = cxiCopyOut((char *)&statbuf32, (char *)statP,
                      sizeof(struct stat64_user32));
    }
#else

#if defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)
    /* On ppc64, struct stat64 layout is different for a 64-bit user app and
       kernel, and we can't use it for copying data out.  However, struct stat
       has the same layout in kernel and 64-bit userspace, and is identical
       to struct stat64 in 64-bit userspace, so we use it for copyout. */
    vstat_ppc64(&vattr, &statbuf);
#else
    vstat(&vattr, &statbuf);
#endif
    rc = cxiCopyOut((char *)&statbuf, (char *)statP, sizeof(statbuf));

#endif /* API_32BIT */
    if (rc != 0)
    {
      code = 5;
      goto xerror;
    }
  }

xerror:
  if (releFile)
    fput(fP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_TSFSTAT_EXIT,
         "tsfstat exit: code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}

int
tsfattr(int fileDesc, int command, void *argP,
        tsfattrReasonCodeInfo *rCodeP)
{
  struct gpfsVfsData_t *privVfsP;
  cxiNode_t *cnP;
  struct MMFSVInfo *vinfoP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct file *fP = NULL;
  struct inode *iP;
  int reason = 0;
  int code = 0;
  int flags;
  int rc;
  Boolean releFile = false;
    
  VFS_STAT_START(tsfattrCall);
  ENTER(0);

#ifdef SMB_LOCKS_TEST
  /* hack to test setSMBOplock via tsfattr call */
  if (command == 999)
  {
    int args[2];
    int oplockGranted;
    struct file *fP = NULL;
    /*??KernelOperation kop;*/

    rc = cxiCopyIn((char *)argP, (char *)args, sizeof(args));
    if (rc)
      return -rc;

    /* Obtain the file pointer from the descriptor */
    fP = fget(fileDesc);
    if (!fP)
      return -EBADF;

    /*??rc = (int)kop.kBegin(privVfsP, CHECK_UNMOUNTED, pudNone, generalOp);*/
    rc = setSMBOplock(fP, fP->private_data, args[0], args[1],
                      (void *)0xdeadbeef, &oplockGranted, false);

    fput(fP);

    if (rc)
      return -rc;
    return oplockGranted;
  }
#endif

  /* if rCodeP was specified then immediately reset reason field */
  if (rCodeP != NULL)
  {
    rc = cxiCopyOut((char*)&reason, (char*)&(rCodeP->reason), sizeof(reason));
    if (rc != 0)
    {
      code = 1;
      goto xerror;
    }
  }

  fP = fget(fileDesc);
  if (!fP)
  {
    code = 2;
    rc = EBADF;
    goto xerror;
  }
  releFile = true;

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  flags = cxiOpenFlagsXlate(fP->f_flags);

  TRACE9(TRACE_VNODE, 1, TRCID_LINUXOPS_TSFATTR_ENTER,
         "tsfattr enter: fd %d fP 0x%lX name %s f_flags 0x%X flags 0x%X "
         "iP 0x%lX command %d argP 0x%lX rCodeP 0x%lX",
         fileDesc, fP, fP->f_dentry->d_name.name, fP->f_flags, flags, iP, 
         command, argP, rCodeP);

  switch (iP->i_mode & S_IFMT)
  {
    case S_IFREG:
    case S_IFDIR:
      vinfoP = (struct MMFSVInfo *)fP->private_data;
      break;

    case S_IFLNK:
    case S_IFBLK:
    case S_IFCHR:
    case S_IFIFO:
    case S_IFSOCK:
      /* At the moment we do have have any file ops enabled for the
       * special files on Linux, and thus we don't have an OpenFile object 
       * or vinfoP stored in fP.  This means that a special file can't
       * have e.g. ACLs associated with it.  Fixing this properly will 
       * require a redesign of our LFS interface.  For now, just fix the 
       * kernel panic caused by invalid vinfoP. */
      vinfoP = NULL;
      if ((command != REMOTE_STAT) &&   // UIDREMAP
          (command != GET_XATTR) &&     // GPFS_LINUX
          (command != SET_XATTR))       // GPFS_LINUX
      {
        code = 5;
        rc = ENOSYS;
        goto xerror;
      }
      break;
  }

  if (!GPFS_TYPE(iP))
  {
    /* This file is not in GPFS filesystem, so fill in the error
       reason in the argument structure's errReason field, which will
       be returned to user's stderr finally. */   
    if (argP != NULL)
    {
      struct { gpfsFcntlHeader_t hdr; genericStruct_t gnc; } a;
      rc = cxiCopyIn((char *)argP, (char *)&a, sizeof(a));
      if (rc != 0)
      {
        code = 7;
        goto xerror;
      }
      if (a.gnc.structLen + sizeof(gpfsFcntlHeader_t) <= a.hdr.totalLength)
      { 
        int errVal = GPFS_FCNTL_ERR_NOT_GPFS_FILE, errOffset = -1;
        if (a.gnc.structType == GPFS_FCNTL_SET_REPLICATION)
          errOffset = OFFSET_OF(errReason, gpfsSetReplication_t);
        else if (a.gnc.structType == GPFS_FCNTL_SET_STORAGEPOOL)
          errOffset = OFFSET_OF(errReason, gpfsSetStoragePool_t);
        else if (a.gnc.structType == GPFS_FCNTL_RESTRIPE_DATA)
          errOffset = OFFSET_OF(errReason, gpfsRestripeData_t);
        else if (a.gnc.structType == GPFS_FCNTL_RESTRIPE_RANGE)
          errOffset = OFFSET_OF(errReason, gpfsRestripeData_t);
        if (errOffset >= 0)
          cxiCopyOut((char *)&errVal, (char *)argP +
                     sizeof(gpfsFcntlHeader_t) + errOffset, sizeof(int));
      }
    }
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 6;
    goto xerror;
  }

  rc = gpfs_ops.gpfsFattr(privVfsP, cnP, vinfoP, flags, command, argP,
                          rCodeP, eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (releFile)
    fput(fP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_TSFATTR_EXIT,
         "tsfattr exit: code %d rc %d\n", code, rc);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
tsfsattr(int command, void *argP)
{
  int rc;

  VFS_STAT_START(tsfattrCall);
  ENTER(0);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_TSFSATTR_ENTER,
        "tsfsattr enter: command %s\n",tsfsattrcmd_id2name(command));

  rc = gpfs_ops.gpfsFsAttr(command, argP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUXOPS_TSFSATTR_EXIT,
         "tsfsattr exit: rc %d\n", rc);

  VFS_STAT_STOP;
  EXIT(0);
  return -rc;
}

int
tsattr(const char *pathname, int command, void *argP,
       tsfattrReasonCodeInfo *rCodeP)
{
  struct gpfsVfsData_t *privVfsP;
  cxiNode_t *cnP;
  int code = 0;
  int rc = 0;
  int reason = 0;       /* local reason code for resetting caller's */
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct nameidata nd;
  struct inode *iP;
  Boolean relePath = false;


  /* if rCodeP was specified then immediately reset reason field */
  ENTER(0);
  if (rCodeP != NULL)
  {
    rc = cxiCopyOut((char*)&reason, (char*)&(rCodeP->reason), sizeof(reason));
    if (rc != 0)
    {
      code = 1;
      goto xerror;
    }
  }

  rc = USER_PATH(pathname, &nd);
  if (rc)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }
  relePath = true;

  iP = NDP_TO_IP(&nd);
  DBGASSERT(iP != NULL);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUXOPS_TSATTR_ENTER,
         "tsattr enter: iP 0x%lX command %d argP 0x%lX rCodeP 0x%lX\n",
         iP, command, argP, rCodeP);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 5;
    goto xerror;
  }

  rc = gpfs_ops.gpfsFattr(privVfsP, cnP, NULL, 0, command, argP, rCodeP,
                          eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_TSATTR_EXIT,
         "tsattr exit: code %d rc %d\n", code, rc);

  EXIT(0);
  return -rc;
}

int
kxGetACL(const char *pathname, int flags, void *aclP)
{
  int rc = 0;
  int code = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct nameidata nd;
  struct inode *iP;
  Boolean relePath = false;

  /* Verify input exists */
  ENTER(0);
  if (pathname == NULL || aclP == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }

  rc = USER_PATH(pathname, &nd);
  if (rc)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }
  relePath = true;

  iP = NDP_TO_IP(&nd);
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }

  cnP = VP_TO_CNP(iP);

  /* Retrieve the ACL data */
  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 5;
    goto xerror;
  }

  rc = gpfs_ops.gpfsGetAcl(privVfsP, cnP, flags, aclP, eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_KXGETACL_EXIT,
         "kxGetACL exit: code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}

int
kxPutACL(const char *pathname, int flags, void *aclP)
{
  int rc = 0;
  int code = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct nameidata nd;
  struct inode *iP;
  Boolean relePath = false;

  /* Verify input exists */
  ENTER(0);
  if (pathname == NULL || aclP == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }

  rc = USER_PATH(pathname, &nd);
  if (rc)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }
  relePath = true;

  iP = NDP_TO_IP(&nd);
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }

  cnP = VP_TO_CNP(iP);

  /* Put the ACL data */
  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 5;
    goto xerror;
  }

  rc = gpfs_ops.gpfsPutAcl(privVfsP, cnP, flags, aclP, eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_KXPUTACL_EXIT,
         "kxPutACL exit: code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}

/* aclP points struct ACL consists of header information (length, type, etc.)*/
int
vfs_getacl(struct dentry *dentry, void *aclP)
{
  int rc = 0;
  int code = 0;
  cxiNode_t *cnP;
    struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct inode *iP;
  Boolean relePath = false;

  /* Verify input exists */
  ENTER(0);
  if (aclP == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }
  iP = dentry->d_inode;
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }
  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  /* Retrieve the ACL data */
  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 5;
    goto xerror;
  }
  rc = gpfs_ops.gpfsGetAcl(privVfsP, cnP, GPFS_GETACL_STRUCT, aclP, eCredP);
  rc = cxiErrorNFS(rc, privVfsP, rc);

xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_VFS_GETACL_EXIT,
         "vfs_getacl exit: code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}

int
vfs_setacl(struct dentry *dentry, void *aclP)
{
  int rc = 0;
  int code = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct inode *iP;
  Boolean relePath = false;

  /* Verify input exists */
  ENTER(0);
  if (aclP == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }
  iP = dentry->d_inode;
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }
  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  /* Retrieve the ACL data */
  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 5;
    goto xerror;
  }
  rc = gpfs_ops.gpfsPutAcl(privVfsP, cnP, GPFS_PUTACL_STRUCT, aclP, eCredP);
  rc = cxiErrorNFS(rc, privVfsP, rc);

xerror:
  putCred(&eCred, &eCredP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_VFS_SETACL_EXIT,
         "vfs_setacl exit: code %d rc %d\n", code, rc);
  EXIT(0);
  return -rc;
}


#if !defined(GPFS_ARCH_X86_64) 
/* madvise is handled as a kernel extension / ioctl call until support
   is provided by glibc */
#if LINUX_KERNEL_VERSION >= 2061900
/* needs a fix */
#else
static inline _syscall3(int,madvise,void*,addr,size_t,len,int,advice);
#endif
#endif

int
kxMadvise(void* addr, size_t len, int advice)
{
#if defined(GPFS_ARCH_X86_64) 
  /* kxMadvise should never be called since glibc has madvice */
  return -ENOSYS;
#else
#if LINUX_KERNEL_VERSION >= 2061900
  /* needs a fix */
  return -ENOSYS;
#else
  return madvise(addr, len, advice);
#endif
#endif
}

/* Get the kernel thread ID. */
cxiThreadId
kxGetThreadID()
{
  return (cxiThreadId)current->pid;
}

#ifdef FILESETMAPPING_API
int kxGetFilesetId(const char *pathname, const char *name, int *idP)
{
  int rc = 0;
  int code = 0;
  struct nameidata nd;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  struct inode *iP;
  Boolean relePath = false;

  ENTER(0);

  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_GETFILESETID_ENT,
         "kxGetFilesetId: enter pathname 0x%x, name 0x%x, euid %d\n",
          pathname, name, FROM_KUID(CRED(current, euid)));

  /* Verify input exists */
  if (pathname == NULL || name == NULL)
  {
    code = 1;
    rc = EINVAL;
    goto xerror;
  }

  rc = USER_PATH(pathname, &nd);

  if (rc)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }

  relePath = true;

  iP = NDP_TO_IP(&nd);
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 5;
    goto xerror;
  }

  rc = gpfs_ops.gpfsGetFilesetId(privVfsP, name, idP, eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_GETFILESETID_EXIT,
         "kxGetFilesetId: exit: code %d, rc %d\n",
         code, rc);

  EXIT(0);

  return -rc;
}
#endif /* FILESETMAPPING_API */


int kxQuotactl(const char *pathname, int cmd, int qid, void *bufferP)
{
  int rc = 0;
  int code = 0;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  struct nameidata nd;
  struct inode *iP;
  Boolean relePath = false;
  size_t len;
  static char kpathname[CXI_MAXPATHLEN+1];

  ENTER(0);

  TRACE6(TRACE_VNODE, 2, TRCID_LINUXOPS_TSQUOTACTL_K,
         "kxQuotactl: cmd 0x%x, qid %d, path 0x%x, euid %d fsuid %d fsgid %d\n",
         cmd, qid, pathname, FROM_KUID(CRED(current, euid)), FROM_KUID(CRED(current, fsuid)), 
         FROM_KGID(CRED(current, fsgid)));

  /* Verify input exists */
  if (pathname == NULL)
  {
    code = 1; // EBUF_ERROR
    rc = EINVAL;
    goto xerror;
  }

  rc = cxiCopyInstr(pathname, kpathname, CXI_MAXPATHLEN, &len);
  if (rc)
  {
    rc = -rc;
    code = 6;
    goto xerror;
  }

  TRACE1(TRACE_VNODE, 2, TRCID_LINUXOPS_TSQUOTACTL_K1,
       "kxQuotactl at [1]: path \"%s\"\n", kpathname);

  rc = USER_PATH(pathname, &nd);

  TRACE1(TRACE_VNODE, 2, TRCID_LINUXOPS_TSQUOTACTL_K2,
        "kxQuotactl at [2] user_path_walk rc %d\n",
         rc);

  if (rc)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }

  relePath = true;

  iP = NDP_TO_IP(&nd);
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }

  cnP = VP_TO_CNP(iP);
 
  rc = getCred(&eCred, &eCredP);

  TRACE4(TRACE_VNODE, 2, TRCID_LINUXOPS_TSQUOTACTL_K6,
         "kxQuotactl: gpfs_ops.gpfsQuotactl, cmd 0x%x, qid %d, eCredP 0x%x, bufferP 0x%x\n",
         cmd, qid, eCredP, bufferP);

  if (rc)
  {
    code = 5;
    goto xerror;
  }

  TRACE3(TRACE_VNODE, 2, TRCID_LINUXOPS_TSQUOTACTL_K8,
        "kxQuotactl: ecredP principal %d group %d num_groups %d\n",
        eCredP->principal, eCredP->group, eCredP->num_groups);

  rc = gpfs_ops.gpfsQuotactl(privVfsP, cmd, qid, bufferP, eCredP, cnP);

  TRACE1(TRACE_VNODE, 2, TRCID_LINUXOPS_TSQUOTACTL_K7,
         "kxQuotactl: gpfs_ops.gpfsQuotactl rc %d\n", rc);
xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  TRACE3(TRACE_VNODE, 1, TRCID_LINUXOPS_TSQUOTACTL_EXIT,
         "kxQuotactl exit: code %d rc %d, pathname 0x%x\n", 
         code, rc, pathname);

  EXIT(0);

  return -rc;
}

#ifdef SMB_LOCKS
/* Exchange control between Samba, GPFS */
int
setSMBOpenLockControl(void *kopP, void *vP, void *infoP, int command, int lockmode)
{
  struct inode *iP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct MMFSVInfo *vinfoP;
  struct file *fP = (struct file *)vP;
  int rc = EINVAL;

  ENTER(0);

  TRACE2(TRACE_VNODE, 9, TRCID_SMBOPENLOCKCONTROL_ENTERL,
         "setSMBOpenLockControl entry - command %d, mode 0x%x",
         command, lockmode);

  vinfoP = (struct MMFSVInfo *)fP->private_data;

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  if (!GPFS_TYPE(iP))
  {
    rc = 0;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);

  rc = gpfs_ops.SMBOpenLockControl(kopP, command, lockmode, iP->i_ino, vinfoP,
                                   privVfsP);

xerror:

  TRACE1(TRACE_VNODE, 1, TRCID_SMBOPENLOCKCONTROL_EXITL,
         "setSMBOpLockControl exit: rc %d\n", rc);

  EXIT(0);
  return (rc);
}

#include <oplock.h>
#include <asm/uaccess.h>
int
setSMBOplock(void *vP, void *infoP, int accessWant, int oplockWant,
             void *breakArgP, int *oplockGrantedP, Boolean isAsync)
{
  struct file *filp = (struct file *)vP;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  struct MMFSVInfo *vinfoP;
  struct file *fP;
  struct inode *iP;
  int reason = 0;
  int code = 0;
  int flags;
  int rc;
  Boolean releFile = false;

  /* get file pointer and inode */
  ENTER(0);
  fP = filp;
  if (!fP)
  {
    code = 2;
    rc = EBADF;
    goto xerror;
  }

  get_file(fP);

  releFile = true;

  vinfoP = (struct MMFSVInfo *)fP->private_data;

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_SETSMBOPLOCK_E,
         "setSMBOplock enter: fP 0x%lX acc %d oplock %d argP 0x%lX async %d\n",
         fP, accessWant, oplockWant, breakArgP, isAsync);

  if (!GPFS_TYPE(iP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(iP);

  rc = gpfs_ops.gpfsSetSMBOplock(privVfsP, cnP, vinfoP, accessWant, oplockWant,
                                 breakArgP, oplockGrantedP, isAsync);

xerror:
  if (releFile)
    fput(fP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUXOPS_SETSMBOPLOCK_X,
         "setSMBOplock exit: granted %d rc %d", *oplockGrantedP, rc);

  EXIT(0);
  return rc;
}

/* Share/Delegate interface for Samba */
int
kxGetShare(int fd, unsigned int share, unsigned int deny)
{
  int rc;
  struct file *fP = NULL;
  struct inode *iP;
  struct MMFSVInfo *vinfoP;
  struct gpfsVfsData_t *privVfsP = NULL;
  int shareWant;

  ENTER(0);

  fP = fget(fd);
  if (!fP || !fP->f_dentry || !fP->f_dentry->d_inode)
  {
    rc = EINVAL;
    goto xerror;
  }

  vinfoP = (struct MMFSVInfo *)fP->private_data;

  if (!vinfoP)
  {
    rc = EBADF;
    goto xerror;
  }

  iP = fP->f_dentry->d_inode;
  if (!iP || !(privVfsP = VP_TO_PVP(iP)))
  {
    rc = EBADF;
    goto xerror;
  }

  if (!GPFS_TYPE(iP))
  {
    rc = 0;
    goto xerror;
  }

  /* We do not have file ops for special files on Linux, so the vinfoP
   * on these will not be valid. */

  if (!S_ISREG(iP->i_mode) && !S_ISDIR(iP->i_mode))
  {
    rc = EBADF;
    goto xerror;
  }

  TRACE6(TRACE_VNODE, 1, TRCID_LINUX_SHARE_ENTER,
         "kxGetShare: enter fd %d fP 0x%lX inode %lld infoP 0x%lX access 0x%X "
         "deny 0x%X\n", fd, fP, iP->i_ino, vinfoP, share, deny);

  /* Translate (and validate) the Samba share/deny arguments to our shareWant */

  rc = EINVAL; /* setup for XLATE_SAMBA_ACCESS/DENY */

  XLATE_SAMBA_ACCESS(share, shareWant);
  XLATE_SAMBA_DENY(deny, shareWant);

  /* Call to make the reservation */
  if ((share != 0) || (deny != 0))
    rc = gpfs_ops.gpfsReserveShare(fP, vinfoP, privVfsP, 0, shareWant, 
				   NULL, NULL, NULL);
  else
    rc = 0;

  /* give back any pre-existing rights */
  if ((rc == 0) && (0 != (coMask & ~shareWant)))
    rc = gpfs_ops.gpfsReserveShare(fP, vinfoP, privVfsP, RESERVE_DOWNGRADE, 
                                   coMask & ~shareWant, NULL, NULL, NULL);
xerror:
  if (fP)
    fput(fP);

  TRACE1(TRACE_VNODE, 1, TRCID_LINUX_SHARE_EXIT,
         "kxGetShare: exit rc %d\n", rc);

  EXIT(0);
  return -rc;
}

int
kxGetDelegation(int fd, unsigned int delegate_access,
                void *cb_token, void *cookie)
{
  int rc = 0;
  int code = 0;
  int flags = 0;
  struct file *fP = NULL;
  struct inode *iP;
  struct MMFSVInfo *vinfoP;
  struct gpfsVfsData_t *privVfsP = NULL;
  int oplockWant;

  ENTER(0);

#ifdef CLUSTER_LEASES
  // Linux fcntl_setlease will call the fs to get the lease
  goto xerror;
#endif

#if 0
  /* As long as Samba write leases are not as strict as NFSv4 write
     delegations (are not required to be revoked on stat) we can
     allow them.
  */
  if (delegate_access == CXI_DELEGATE_WRITE)
  {
    rc = EOPNOTSUPP;
    goto xerror;
  }
#endif

  fP = fget(fd);
  if (!fP || !fP->f_dentry || !fP->f_dentry->d_inode)
  {
    rc = EINVAL;
    goto xerror;
  }

  vinfoP = (struct MMFSVInfo *)fP->private_data;

  if (!vinfoP)
  {
    rc = EBADF;
    goto xerror;
  }

  iP = fP->f_dentry->d_inode;
  if (!iP || !(privVfsP = VP_TO_PVP(iP)))
  {
    rc = EBADF;
    goto xerror;
  }

  if (!GPFS_TYPE(iP))
  {
    rc = 0;
    goto xerror;
  }

  /* We do not have file ops for special files on Linux, so the vinfoP
   * on these will not be valid. */

  if (!S_ISREG(iP->i_mode) && !S_ISDIR(iP->i_mode))
  {
    rc = EBADF;
    goto xerror;
  }

  TRACE5(TRACE_VNODE, 1, TRCID_DELEGATE_ENTER,
         "kxGetDelegation: enter fd %d fP 0x%lX inode %lld vinfoP 0x%lX "
         "delegate 0x%x\n", fd, fP, iP->i_ino, vinfoP, delegate_access);

  /* Translate (and validate) the Samba delegate argument to our oplock flags */

  /* setup for XLATE_SAMBA_DELEGATE */
  rc = EINVAL;
  oplockWant = 0;

  if (delegate_access == CXI_DELEGATE_NONE)
    flags = RESERVE_DOWNGRADE;

  XLATE_SAMBA_DELEGATE(delegate_access, oplockWant);

  rc = gpfs_ops.gpfsReserveDelegation(fP, vinfoP, privVfsP, oplockWant, 
                                      flags, iP, NULL, NULL);

xerror:
  if (fP)
    fput(fP);

  TRACE1(TRACE_VNODE, 1, TRCID_DELEGATE_EXIT,
         "kxGetDelegation: exit rc %d\n", rc);

  EXIT(0);
  return -rc;
}
#endif

int kxWinOps(int fd, const char * pathname, int op, int flags, void *genArg1)
{
  int rc = 0;
  int code = 0;
  int crc;
  struct file *fP = NULL;
  struct inode *iP = NULL;
  struct nameidata nd;
  /* struct MMFSVInfo *vinfoP; */
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP = NULL;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  cxiWinBasicInfo_t info;
  Boolean relePath = false;

  ENTER(0);

  if ((!genArg1) &&
      ((op == WIN_OP_GETATTRS) || 
       (op == WIN_OP_SETATTRS) ||
       (op == WIN_OP_REGISTER_CIFS_BUF)))
  {
    code = 2;
    rc = EINVAL;
    goto xerror;
  }

  if ((op == WIN_OP_GETATTRS) || (op == WIN_OP_SETATTRS))
  {
    if (pathname)
    {
      rc = USER_PATH(pathname, &nd);
      if (rc)
      {
        rc = -rc;
        code = 3;
        goto xerror;
      }
      relePath = true;

      iP = NDP_TO_IP(&nd);
      DBGASSERT(iP != NULL);
    }
    else
    {
      fP = fget(fd);
      if (!fP || !fP->f_dentry || !fP->f_dentry->d_inode)
      {
        code = 4;
        rc = EINVAL;
        goto xerror;
      }

      /* vinfoP = (struct MMFSVInfo *)fP->private_data;
       *
       * Note: if vinfoP is needed in the future, be sure to guard against
       * NULL and also invalid values in the case of special files (see
       * kxGetShare, kxGetDelegation, kxFtrunc for example). 
       */

      iP = fP->f_dentry->d_inode;
    }

    if (!iP || !(privVfsP = VP_TO_PVP(iP)))
    {
      code = 5;
      rc = EBADF;
      goto xerror;
    }

    if (!GPFS_TYPE(iP))
    {
      code = 6;
      rc = EBADF;
      goto xerror;
    }

    cnP = VP_TO_CNP(iP);
  }

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  TRACE6(TRACE_VNODE, 1, TRCID_LINUX_SAMBA_OP_ENTER,
         "kxWinOps: enter op %d fd %d fP 0x%lX inode %lld flags 0x%X "
         "arg1 0x%X\n", op, fd, fP, iP? iP->i_ino: 0, flags, genArg1);

  rc = gpfs_ops.gpfsWinOps(op, flags, genArg1, privVfsP, cnP, &info, eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  if (fP)
    fput(fP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUX_SAMBA_OP_EXIT, 
         "kxWinOps: exit rc %d code %d\n", rc, code);

  EXIT(0);
  return -rc;
}

/* called from umount helper before calling umount system call  */

#define UMOUNT_BEGIN 0
#define UMOUNT_END 1
int kxUMount(int type, char *pathname, int force, int *ret_err)
{
    int rc = 0;
    int dmrc = 0;
    int code = 0;
    size_t len;
    struct cxiNode_t  *cnP = NULL;
    struct gpfsVfsData_t *privVfsP = NULL;
    void       *ndP = NULL;
    Boolean doDMEvents = false;
    char *kxnode = NULL;
    char *bufP = NULL;

    ENTER(0);

    bufP = (char *)cxiMallocUnpinned(CXI_MAXPATHLEN+1);
    if (bufP == NULL)
    {
      /* Unable to allocate kernel space for the name */
      code = 2;
      rc = ENOMEM;
      goto exit;
    }
    kxnode = bufP;
    cxiMemset(kxnode, 0, CXI_MAXPATHLEN+1);

    rc = cxiCopyInstr(pathname, kxnode, CXI_MAXPATHLEN, &len);
    LOGASSERT(rc == 0);
    TRACE4(TRACE_VNODE, 1, TRCID_KXUMOUNT_ENT,
         "kxUMount: enter type %d path %s force %d  ret_err %d\n",
          type,kxnode,force,*ret_err);
    
    rc = cxiPathToVfsP((void **)&privVfsP,pathname, &ndP, (void **)&cnP, true);
    if (rc)
    {
      code = 1;
      goto exit;
    }         
    
    /* Generate PREUNMOUNT event for normal mounts. For force unmount
           it is generated from gpfs_s_umount_begin.
           umount helper calls with UMOUNT_BEGIN before calling umount
           system call.
    */

    if ( type == UMOUNT_BEGIN && !force)
    {
       dmrc = gpfs_ops.gpfsDmUnmountEvent(true,force,privVfsP,cnP,
                                        &doDMEvents, NULL, NULL, NULL, 0);
       if (doDMEvents )
         *ret_err = 1;
       else
         *ret_err = 0;
    }

        /* 
          umount helper calls with UMOUNT_END if umount system call fails.
    */

    if ( type == UMOUNT_END )
       dmrc = gpfs_ops.gpfsDmUnmountEvent(false,force,privVfsP,cnP,
                                     &doDMEvents, NULL, NULL, NULL, *ret_err);

exit:
    if (ndP)
      cxiPathRel(ndP);

    if (bufP)
      cxiFreeUnpinned(bufP);

    TRACE4(TRACE_VNODE, 1, TRCID_KXUMOUNT_EXT,
         "kxUMount: exit dmrc %d  ret_err %d rc %d code %d\n",
          dmrc,*ret_err,rc,code);
     EXIT(0);
     return rc;
}

int kxGetRealFileName(int fd, const char *pathname, char * realFileNameP, int *lenP)
{
  int rc = 0;
  struct file *fP = NULL;
  struct inode *diP = NULL;
  struct inode *iP = NULL;
  struct dentry *dentryP = NULL;
  cxiNode_t *cnDirP = NULL;
  cxiNode_t *cnFileP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;
  int nameLength = 0;
  int inputLen = 0;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  int code = 0;
  size_t len = 0;
  struct nameidata nd;
  Boolean relePath = false;
  char *dirPathName = NULL;
  char *filenameP = NULL;
  char *cP = NULL;
  char *curNameP = NULL;
  char *bufP = NULL;
  Boolean isCaseSensitive = false;
  int supportSambaLookup = false;

  /* Check if we are configured for case-insensitive samba lookkups. */
  supportSambaLookup = gpfs_ops.gpfsSupportSambaLookup();
  if (supportSambaLookup < 0)
  {
    rc = -(supportSambaLookup);
    code = 16;
    goto xerror;
  }

  /* Normally, we do case-insensitive lookups.
     The exception is for samba (when properly configured). */

  isCaseSensitive = (!cxiIsSambaThread() || !supportSambaLookup);

  bufP = (char *)cxiMallocUnpinned(CXI_MAXPATHLEN+1);
  if (bufP == NULL)
  {
    /* Unable to allocate kernel space for the name */
    code = 1;
    rc = ENOMEM;
    goto xerror;
  }
  curNameP = bufP;
  cxiMemset(curNameP, 0, CXI_MAXPATHLEN+1);

  ENTER(0);
  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 15;
    goto xerror;
  }

  rc = cxiCopyIn((char *)lenP, (char *)&inputLen, sizeof(int));
  if (rc)
  {
    code = 3;
    goto xerror;
  }

  /* Pathnamne was given, so lookup the file without an open. */
  if (pathname)
  {
    rc = cxiCopyInstr(pathname, curNameP, CXI_MAXPATHLEN, &len);
    if (rc != 0)
    {
      code = 4;
      goto xerror;
    }

    nameLength = (int)len;

    TRACE2(TRACE_VNODE, 1, TRCIDGETREALNAME1,
           "kxGetRealFileName: file %s buffer len = %d", curNameP, inputLen);

    /* Check to see if length of user provided buffer is large enogh to hold actual name */
    if (len  > inputLen)
    {
      code = 5;
      rc = ENOSPC;
      goto xerror;
    }

    /* set filenameP to the last component of the path (the file), leaving
       keepng dirPathName pointing to the parent directory. */

    dirPathName = curNameP;
    cP = cxiStrchr(curNameP, '/');
    if (!cP)
    {
      code = 6;
      rc = EINVAL;
      goto xerror;
    }

    while (cP)
    {
      filenameP = cP;
      curNameP ++;
      cP = cxiStrchr(curNameP, '/');
    }
    *filenameP = '\0';

    /* Previous path components must have previously been translated, so we
       can lookup the parent directory name. */

    rc = PATH_LOOKUP(dirPathName, LOOKUP_FOLLOW | LOOKUP_DIRECTORY, &nd);
    if (rc)
    {
      /* Parent directory not valid */
      rc = -rc;
      code = 7;
      goto xerror;
    }
    relePath = true;

    diP = NDP_TO_IP(&nd);
    if (!diP || !(privVfsP = VP_TO_PVP(diP)))
    {
      code = 8;
      rc = EBADF;
      goto xerror;
    }

    if (!GPFS_TYPE(diP))
    {
      /* Parent directory is not GPFS */
      code = 9;
      rc = EBADF;
      goto xerror;
    }

    cnDirP = VP_TO_CNP(diP);

    if (!cnDirP)
    {
      code = 10;
      rc = EBADF;
      goto xerror;
    }

    nameLength = len -(cxiStrlen(dirPathName)); /* remaing in buffer (filename only) */

    *filenameP = '/';
    filenameP++;

    rc = gpfs_ops.gpfsLookupRealName(cnDirP, filenameP, privVfsP, eCredP, filenameP, &nameLength);

#if 1
    /* gpfsLookupRealName returned the translated filename on top of the input
       name part of the full pathname and nameLength of this name part only.
       Return the full translated pathname and its length to our caller. */
    nameLength = (int)len;
    curNameP = dirPathName;
#else
    /* Return the filename only (not the entire path) and its length. */
    curNameP = filenameP;
#endif
  }

  else /* file descriptor case */
  {
   fP = fget(fd);
    if (!fP || !fP->f_dentry || !fP->f_dentry->d_inode ||
        !fP->f_dentry->d_parent || !fP->f_dentry->d_parent->d_inode )
    {
      code = 11;
      rc = EINVAL;
      goto xerror;
    }

    iP = fP->f_dentry->d_inode;
    /* This dentry will have an hold so not calling dget on this */
    dentryP = fP->f_dentry;
    diP = fP->f_dentry->d_parent->d_inode;

    if (!GPFS_TYPE(iP))
    {
      code = 12;
      rc = EBADF;
      goto xerror;
    }
  
    if (!iP || !(privVfsP = VP_TO_PVP(iP)))
    {
      rc = EBADF;
      goto xerror;
    }

    cnDirP  = VP_TO_CNP(diP);
    cnFileP = VP_TO_CNP(iP);
    if (!cnDirP || !cnFileP)
    {
      code = 13;
      rc = EBADF;
      goto xerror;
    }

    nameLength = cxiStrlen(dentryP->d_name.name) + 1;

    /* Check to see if length of user provided buffer is large enogh to hold actual name */
    if (nameLength > inputLen)
    {
      code = 14;
      rc = ENOSPC;
      goto xerror;
    }

    TRACE2(TRACE_VNODE, 1, TRCIDGETREALNAME2,
           "kxGetRealFileName:  dentryName: %s, namelen = %d\n",
           dentryP->d_name.name, nameLength);


    /* If this is a root dir get its name from dentry itself. No need to perform
       lookup */
    if (iP && iP->i_ino == INODENUM_ROOTDIR_FILE)
    {
      cxiStrcpy(curNameP, dentryP->d_name.name);
      goto xerror;
    }
    /* SAMBA can force GPFS on Linux to do a caseinsensitive lookup.
     * In that case, name of file stored in dcache may not be actual filename.
     * To get real file name, pass on the FileUID so that after name lookup
     * FileUID can be matched to get real file name. This lookup does not create
     * negative dcache entry if name not found. It also does not perform
     * relookup in case rename has happened on other node. Since fget has already
     * an hold on dentry so we can be sure of it not going away.
     */
  
    rc = gpfs_ops.gpfsLookupFileWithFileId (cnDirP,
                                            dentryP->d_name.name,
                                            isCaseSensitive,
                                            privVfsP,
                                            eCredP,
                                            cnFileP,
                                            curNameP,
                                            &nameLength);
    }

xerror:
  putCred(&eCred, &eCredP);

  if (rc == 0)
    cxiCopyOut(curNameP, realFileNameP, nameLength+1);

  if (rc == 0 || rc == ENOSPC)
    cxiCopyOut((char *)&nameLength, (char *)lenP, sizeof(int));

  if (relePath)
    PATH_PUT(&nd);

  if (fP)
    fput(fP);

  if (bufP)
    cxiFreeUnpinned(bufP);

  TRACE3(TRACE_VNODE, 1, TRCIDGETREALNAME3,
         "kxGetRealFileName:  actualnamelen= %d, rc= %d, code=%d\n",
          nameLength, rc, code);

  EXIT(0);
  return -rc;
}

#ifdef CLONE_FILE
/* Create a clone copy of a file */
int kxCloneFile(CloneOp clop, const char *sourcePathP, const char *destPathP)
{
  int rc = 0;
  int code = 0;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct nameidata sourceNd, destNd;
  struct inode *sourceIP, *destIP;
  cxiNode_t *cnP, *cnDirP = NULL;
  char *bufP = NULL, *nameP = NULL;
  const char *dirNameP;
  size_t len = 0;
  mm_segment_t oldfs;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  Boolean relePath = false, relePath2 = false;

  ENTER(0);

  rc = USER_PATH(sourcePathP, &sourceNd);
  if (rc != 0)
  {
    rc = -rc;
    code = 2;
    goto xerror;
  }
  relePath = true;

  sourceIP = NDP_TO_IP(&sourceNd);
  DBGASSERT(sourceIP != NULL);

  if (!GPFS_TYPE(sourceIP))
  {
    code = 3;
    rc = EINVAL;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(sourceIP);
  if (privVfsP == NULL)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  cnP = VP_TO_CNP(sourceIP);

  rc = getCred(&eCred, &eCredP);
  if (rc != 0)
  {
    code = 5;
    goto xerror;
  }

  if (clop == coCopy || destPathP != NULL)
  {
    /* Split the destination file name from directory */
    bufP = (char *)cxiMallocUnpinned(CXI_MAXPATHLEN+1);
    if (bufP == NULL)
    {
      code = 6;
      rc = ENOMEM;
      goto xerror;
    }
    rc = cxiCopyInstr(destPathP, bufP, CXI_MAXPATHLEN, &len);
    if (rc != 0)
    {
      rc = -rc;
      code = 7;
      goto xerror;
    }
    if (len == 0)
    {
      code = 8;
      rc = EINVAL;
      goto xerror;
    }
    if (bufP[len-1] == '/')
    {
      code = 9;
      rc = EINVAL;
      goto xerror;
    }
    nameP = cxiStrrchr(bufP, '/');
    if (nameP == NULL)
    {
      nameP = bufP;
      dirNameP = ".";
    }
    else
    {
      *nameP++ = '\0';
      dirNameP = bufP;
    }

    /* Look up the parent directory*/
    oldfs = get_fs();
    set_fs(get_ds());
    rc = USER_PATH(dirNameP, &destNd);
    set_fs(oldfs);
    if (rc != 0)
    {
      rc = -rc;
      code = 10;
      goto xerror;
    }
    relePath2 = true;

    destIP = NDP_TO_IP(&destNd);
    DBGASSERT(destIP != NULL);

    if (destIP->i_op->lookup == NULL)
    {
      code = 11;
      rc = ENOTDIR;
      goto xerror;
    }
    if (!GPFS_TYPE(destIP))
    {
      code = 12;
      rc = EINVAL;
      goto xerror;
    }
    if (VP_TO_PVP(destIP) != privVfsP)
    {
      code = 13;
      rc = EXDEV;
      goto xerror;
    }
    cnDirP = VP_TO_CNP(destIP);
  }
  rc = gpfs_ops.gpfsCloneFile(privVfsP, clop, cnP, cnDirP, NULL, nameP,
                              IS_CASE_SENSITIVE(), current->fs->umask,
                              eCredP);

xerror:
  putCred(&eCred, &eCredP);
  if (relePath)
    PATH_PUT(&sourceNd);
  if (relePath2)
    PATH_PUT(&destNd);
  if (bufP != NULL)
    cxiFreeUnpinned(bufP);

  TRACE2(TRACE_VNODE, 1, TRCID_KXCLONEFILE_EXIT, 
         "kxCloneFile exit: rc %d code %d", rc, code);

  EXIT(0);
  return -rc;
}

/* Copy blocks from clone parent to child, or split clone child from parent */
int kxDeclone(DecloneOp dcop, int fd, int ancLimit, UInt32 nBlocksHi,
              UInt32 nBlocksLo, Int64 *offsetP)
{
  int rc = 0;
  int code = 0;
  struct file *fP = NULL;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  struct dentry *dentryP = NULL;
  struct inode *iP = NULL;
  cxiNode_t *cnFileP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;
  Int64 nBlocks = Cast32To64(nBlocksHi, nBlocksLo), offset = 0;

  ENTER(0);

  rc = getCred(&eCred, &eCredP);
  if (rc != 0)
  {
    code = 1;
    goto xerror;
  }

  if (dcop == dcCopy && offsetP == NULL)
  {
    code = 2;
    rc = EINVAL;
    goto xerror;
  }

  if (offsetP != NULL)
  {
    rc = cxiCopyIn((char *)offsetP, (char *)&offset, sizeof(Int64));
    if (rc != 0)
    {
      code = 3;
      goto xerror;
    }
  }

  fP = fget(fd);
  if (fP == NULL || fP->f_dentry == NULL)
  {
    code = 4;
    rc = EBADF;
    goto xerror;
  }

  dentryP = fP->f_dentry;
  if (dentryP->d_inode == NULL)
  {
    code = 5;
    rc = ENOENT;
    goto xerror;
  }
  iP = dentryP->d_inode;

  if (!GPFS_TYPE(iP))
  {
    code = 6;
    rc = EBADF;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 7;
    rc = EBADF;
    goto xerror;
  }

  cnFileP = VP_TO_CNP(iP);
  if (cnFileP == NULL)
  {
    code = 8;
    rc = EBADF;
    goto xerror;
  }

  rc = gpfs_ops.gpfsDeclone(privVfsP, dcop, cnFileP, ancLimit, nBlocks,
                            NULL, eCredP, &offset);
  if (rc != 0)
  {
    code = 9;
    goto xerror;
  }

  if (offsetP != NULL)
  {
    rc = cxiCopyOut((char *)&offset, (char *)offsetP, sizeof(Int64));
    if (rc != 0)
    {
      code = 10;
      goto xerror;
    }
  }

xerror:
  putCred(&eCred, &eCredP);
  if (fP)
    fput(fP);

  TRACE3(TRACE_VNODE, 1, TRCID_DECLONE,
         "kxDeclone exit: fd %d rc %d code %d", fd, rc, code);
  EXIT(0);
  return -rc;
}
#endif /* CLONE_FILE */


int kxFtruncate(int fd, offset_t length)
{
  int rc = 0;
  int code = 0;
  int flags = FWRITE;
  struct file *fP = NULL;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  struct MMFSVInfo *vinfoP;
  struct dentry *dentryP = NULL;
  struct dentry *parent_dentryP = NULL;
  struct inode *iP = NULL;
  struct inode *diP = NULL;
  cxiNode_t *cnFileP = NULL;
  struct gpfsVfsData_t *privVfsP = NULL;


  ENTER(0);

  TRACE2(TRACE_VNODE, 1, TRCIDFTRUNCATE1,
         "kxFtruncate enter:  fd %d, length %lld\n",
          fd, length);

  rc = getCred(&eCred, &eCredP);
  if (rc)
  {
    code = 1;
    goto xerror;
  }

  if (length < 0)
  {
    code = 2;
    rc = EINVAL;
    goto xerror;
  }

  fP = fget(fd);
  if (!fP || !fP->f_dentry || !fP->f_dentry->d_parent )
  {
    code = 3;
    rc = EBADF;
    goto xerror;
  }

  dentryP = fP->f_dentry;
  parent_dentryP = dentryP->d_parent;

  if (!dentryP->d_inode || !parent_dentryP->d_inode)
  {
    code = 4;
    rc = ENOENT;
    goto xerror;
  }
  iP = dentryP->d_inode;
  diP = parent_dentryP->d_inode;

  vinfoP = (struct MMFSVInfo *)fP->private_data;

  if (!vinfoP)
  {
    code = 9;
    rc = EBADF;
    goto xerror;
  }

  if (!GPFS_TYPE(iP))
  {
    code = 5;
    rc = EBADF;
    goto xerror;
  }

  privVfsP = VP_TO_PVP(iP);
  if (!privVfsP)
  {
    code = 6;
    rc = EBADF;
    goto xerror;
  }

  cnFileP = VP_TO_CNP(iP);
  if (!cnFileP)
  {
    code = 7;
    rc = EBADF;
    goto xerror;
  }

  /* We do not have file ops for special files on Linux, so the vinfoP
   * on these will not be valid. */

  if (!S_ISREG(iP->i_mode) && !S_ISDIR(iP->i_mode))
  {
    code = 10;
    rc = EBADF;
    goto xerror;
  }

  TRACE2(TRACE_VNODE, 1, TRCIDFTRUNCATE2,
         "kxFtruncate:  iP=0x%lX, diP= 0x%lX\n",
          iP, diP);

  rc = gpfs_ops.gpfsFtrunc(privVfsP, cnFileP, flags, length, vinfoP, eCredP, true);

  if (rc != 0)
  {
    code = 8;
    goto xerror;
  }

xerror:
  putCred(&eCred, &eCredP);

  if (fP)
    fput(fP);

  TRACE3(TRACE_VNODE, 1, TRCIDFTRUNCATE3,
         "kxFtruncate exit:  fd %d, rc %d, code %d\n",
          fd, rc, code);

  EXIT(0);
  return -rc;
}

int kxSetTimes(int fd, char *pathname, int flags, void *times)
{
  int rc = 0;
  int code = 0;
  int crc;
  struct file *fP = NULL;
  struct inode *iP;
  struct nameidata nd;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  ext_cred_t  eCred;
  ext_cred_t *eCredP = &eCred;
  Boolean relePath = false;

  ENTER(0);

  TRACE4(TRACE_VNODE, 1, TRCID_LINUX_SETTIMES_ENTER,
         "kxSetTimes: enter fd %d pathname 0x%x flags %d times 0x%X\n",
	 fd, pathname, flags, times);

  if (!times)
  {
    code = 2;
    rc = EINVAL;
    goto xerror;
  }

  if (pathname)
  {
    rc = USER_PATH(pathname, &nd);
    if (rc)
    {
      rc = -rc;
      code = 3;
      goto xerror;
    }
    relePath = true;

    iP = NDP_TO_IP(&nd);
    DBGASSERT(iP != NULL);
  }
  else
  {
    fP = fget(fd);
    if (!fP || !fP->f_dentry || !fP->f_dentry->d_inode)
    {
      code = 4;
      rc = EINVAL;
      goto xerror;
    }

    iP = fP->f_dentry->d_inode;
  }

  if (!iP || !(privVfsP = VP_TO_PVP(iP)))
  {
    code = 5;
    rc = EBADF;
    goto xerror;
  }

  if (!GPFS_TYPE(iP))
  {
    code = 6;
    rc = EBADF;
    goto xerror;
  }

  cnP = VP_TO_CNP(iP);

  rc = getCred(&eCred, &eCredP);
  if (rc)
    goto xerror;

  TRACE5(TRACE_VNODE, 1, TRCID_LINUX_SETTIMES_ENTER2,
         "kxSetTimes: enter fd %d fP 0x%lX inode %lld flags 0x%X arg1 0x%X\n",
	 fd, fP, iP->i_ino, flags, times);

  rc = gpfs_ops.gpfsSetTimes(flags, times, privVfsP, cnP, eCredP);

xerror:
  putCred(&eCred, &eCredP);

  if (relePath)
    PATH_PUT(&nd);

  if (fP)
    fput(fP);

  TRACE2(TRACE_VNODE, 1, TRCID_LINUX_SETTIMES_EXIT,
         "kxSetTimes: exit rc %d code %d\n", rc, code);

  EXIT(0);
  return -rc;
}


#ifdef GANESHA

#define MAX_STR 290

#if (LINUX_KERNEL_VERSION >= 2062400)
struct dentry *
gpfs_fh_to_dentry(struct super_block *sbP, struct fid *fid,
                  int len, int fhtype);
#endif

#if (LINUX_KERNEL_VERSION >= 2062500)
#define USER_WALK_PATH user_path_at
#define ND_DENTRY(nd) nd.path.dentry
#define PWDMNT pwd.mnt
#define FSUID current_fsuid()
#define FGET(fd, fput_needed) fget(fd)
#define FPUT(fp, fput_needed) fput(fp)
#else
#define USER_WALK_PATH __user_walk_fd
#define ND_DENTRY(nd) nd.dentry
#define PWDMNT pwdmnt
#define FSUID current->fsuid
#if defined(REDHAT_AS_LINUX)
#define FGET(fd, fput_needed) fget_light(fd, &fput_needed)
#define FPUT(fp, fput_needed) fput_light(fp, fput_needed)
#else
#define FGET(fd, fput_needed) fget(fd)
#define FPUT(fp, fput_needed) fput(fp)
#endif
#endif

#define FH_HDR_SIZE (sizeof(struct gpfs_file_handle)-OPENHANDLE_HANDLE_LEN)

struct handle_svc_export
{
  struct cache_head h;
  struct auth_domain *ex_client;
  int ex_flags;
};

typedef union {
  struct open_arg         oarg;
  struct open_share_arg   osarg;
  struct share_reserve_arg sarg;
  struct link_arg         linkarg;
  struct stat_name_arg    snarg;
  struct create_name_arg  crarg;
  struct link_fh_arg      lnarg;
  struct rename_fh_arg    rnarg;
  struct name_handle_arg  harg;
  struct get_handle_arg   gharg;
  struct readlink_arg     readlinkarg;
  struct readlink_fh_arg  rlfharg;
  struct stat_arg         statarg;
  struct deviceinfo_arg   darg;
  struct layoutget_arg    yarg;
  struct layoutreturn_arg zarg;
  struct dsread_arg       rarg;
  struct dswrite_arg      warg;
  struct read_arg        frarg;
  struct write_arg       fwarg;
  struct xstat_access_arg xarg;
  struct xstat_arg        carg;
  struct callback_arg     barg;
  struct set_get_lock_arg larg;
  struct layoutcommit_arg targ;
  struct fsync_arg        farg;
  struct statfs_arg       sfarg;
  struct close_file_arg   cfarg;
  struct grace_period_arg gparg;
  struct trace_arg        trarg;
  struct fadvise_arg      faarg;
  struct fseek_arg        fsarg;
  struct quotactl_arg     qarg;
  struct alloc_arg        aarg;
  struct fs_loc_arg       flarg;
} all_args;

void *
getPrivVfsP(void *vfsP)
{
  struct super_block *sbP = (struct super_block *)vfsP;

  /* Do some sanity checking */
  if (sbP->s_magic != GPFS_SUPER_MAGIC)
  {
#if (LINUX_KERNEL_VERSION >= 2063200)
    static DEFINE_RATELIMIT_STATE(rs, 10 * HZ, 1);
    if (__ratelimit(&rs))
#endif
      printk(GPFS_NOTICE "GPFS: Bad super block pointer %p\n", sbP);

    return NULL;                    			
  }
  return sbP->s_fs_info;
}

#define MY_ACC_MODE(x) ("\000\004\002\006"[(x)&O_ACCMODE])

static int vfs_dentry_acceptable(void *context, struct dentry *dentry)
{
  return 1;
}

int posix2glock(struct glock *glock, struct file_lock *plock);

static inline ssize_t
pnfs_rdwr(struct dentry *dentry, struct MMFSVInfo *vinfoP, int f_flags,
         ext_cred_t *eCredP, cxiRdWr_t op, const struct cxiIovec_t *iovecP,
         unsigned long count, loff_t *offsetP, struct cxiUio_t *uioP,
         int opt)
{
  int i, rc;
  ssize_t total_len = 0;
  int flags = cxiOpenFlagsXlate(f_flags);
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  struct inode *iP;
  ssize_t tmp_len;
  struct cxiPageList_t *plP = NULL;
  int options = 0;

  iP = dentry->d_inode;

  TRACE10(TRACE_VNODE, 1, TRCID_LINUXOPS_RDWRPNFS_ENTER,
          "pnfs_rdwr enter: vinfoP 0x%lX f_flags 0x%X flags 0x%X op %d "
          "iovec 0x%lX count %d offset 0x%llX "
          "dentry 0x%lX iP 0x%lX name '%s'\n",
          vinfoP, f_flags, flags, op, iovecP, count, *offsetP, dentry,
          dentry->d_inode, dentry->d_name.name);

  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);
  cnP = VP_TO_CNP(iP);

  uioP->uio_iov = (struct cxiIovec_t *)iovecP; /* ptr to iovec struct array */
  uioP->uio_iovcnt = count;         /* #iovec elements left to be processed */
  uioP->uio_iovdcnt = 0;            /* #iovec elements already processed    */
  uioP->uio_offset = *offsetP;      /* byte offset in file/dev to read/write*/
  uioP->uio_segflg = UIO_USERSPACE; /* copy to user space                   */
  uioP->uio_fmode = 0;              /* file modes from open file struct     */

  for (i = 0; i < count; i++)
    total_len += iovecP[i].iov_len;

  uioP->uio_resid = total_len; /* #bytes left in data area */

 /* We should -EINVAL if total length is not >= 0
  * Be careful here because uio_resid is a unsigned
  * long not an ssize_t
  */
  tmp_len = (ssize_t)uioP->uio_resid;
  if ( tmp_len  < 0)
  {
    rc = EINVAL;
    goto out;
  }
  DBGASSERT(vinfoP != NULL);

  if ((count == 1) && (((struct cxiVinfo_t*)vinfoP)->viIsDIO) &&
      (current->mm != NULL))
  {
    rc = cxiMapUserBuffer(iovecP, iovecP->iov_len, &plP);
    if (rc != 0)
      goto out;
  }
  if (op == CXI_READ || op == CXI_READ_AIO) {
    options = CXI_RDWROPTS_UIDREMAP |
              (op == CXI_READ_AIO ? CXI_RDWROPTS_AIO : 0);
    
    if (opt & IO_SKIP_HOLE)
      options |= CXI_RDWROPTS_SKIP_HOLES;
    
    rc = gpfs_ops.gpfsRead(privVfsP, NULL, cnP, flags, uioP,
                           vinfoP, NULL, NULL, eCredP, plP, options);
    if (rc == E_HOLE && opt & IO_SKIP_HOLE)
    {
      rc = ENODATA;
      *offsetP = iP->i_size;
    }
  }
  else
  {
    options = CXI_RDWROPTS_UIDREMAP |
              (op == CXI_WRITE_AIO ? CXI_RDWROPTS_AIO : 0);

    if (opt & IO_SKIP_HOLE)
      rc = gpfs_ops.gpfsFclear(privVfsP, cnP, flags, uioP->uio_offset,
                               total_len, vinfoP, eCredP);
    else
      rc = gpfs_ops.gpfsWrite(privVfsP, NULL, cnP, flags, uioP,
                              vinfoP, NULL, NULL, eCredP, plP, options);

      /* If this is a queued AIO, then hold off updating super block dirty bit
       until IO is complete - see aioDoneCallback.  Also, Linux AIO will not
       be done synchronously for NFS threads - see gpfs_f_aio_*. */
    if (rc != EIOCBQUEUED)
    {
#ifdef  HAS_S_DIRT
      iP->i_sb->s_dirt = 1;
#endif

#ifdef GPFS_ASYNC_NFS_WRITE_MARK_INODE_DIRTY
      /* GPFS file system is exported with the sync and wdelay as the default
         options on Linux. The wdelay option allows for multiple write requests
         to be committed to disc with the one operation (fsync) which can improve
         performance, but it depends on GPFS to mark the inode dirty after the
         write. On the other side if no_wdelay is specified each write will be
         committed and without support for the file operation aio_write each
         chunk in the iovec is committed. So if the export option sync is on we
         should also have wdelay on.
      */
      if (cxiIsNFSThread() && !(fP->f_flags & O_SYNC) && !rc)
        mark_inode_dirty_sync(iP);
#endif
    }
  }

out:

  TRACE5(TRACE_VNODE, 1, TRCID_LINUXOPS_RDWRPNFS_EXIT,
         "pnfs_rdwr exit: iP 0x%lX total_len %ld uio_resid %ld "
         "offset 0x%llX rc %d\n", iP, total_len, uioP->uio_resid,
         uioP->uio_offset, rc);

  if (plP != NULL && rc != EIOCBQUEUED)
    cxiDeallocPageList(plP);

  if (rc)
  {
    rc = cxiErrorNFS(rc, privVfsP, EIO);

    EXIT(0);
    return (-rc);
  }
  *offsetP = uioP->uio_offset;
  return (total_len - uioP->uio_resid);
}



static int ganesha_grant_deferred(struct file_lock *fl, struct file_lock *conf,
                                  int result)
{
  int rc = -ENOENT;
  int reason;
  struct glock glock;
  struct flock *flock = &glock.flock;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct file *fP;

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_GRANT_LOCK,
         "ganesha_grant_deferred: fl 0x%lX conf 0x%lX result %d",
          fl, conf, result);

  if (result == EAGAIN || result == EBUSY)
    reason = INODE_LOCK_AGAIN;
  else
    reason = INODE_LOCK_GRANTED;

  if (!result || result == EAGAIN || result == EBUSY)
  {
    fP = fl->fl_file;
    DBGASSERT(fP != NULL);
    cnP = VP_TO_CNP(fP->f_dentry->d_inode);
    privVfsP = VP_TO_PVP(fP->f_dentry->d_inode);
    DBGASSERT(privVfsP != NULL);
    rc = posix2glock(&glock, fl);

    TRACE6(TRACE_VNODE, 3, TRCID_LINUX_GRANT_LOCK_06,
        "ganesha_grant_deferred: rc %d lock pid %d type %d start %lld len %lld lock_owner 0x%lX",
         rc, flock->l_pid, flock->l_type, flock->l_start,
         flock->l_len, glock.lock_owner);

    if (!rc)
      rc = gpfs_ops.gpfsGaneshaLock(privVfsP, cnP, &glock, fl, reason);

    if (rc) {
      if (reason == INODE_LOCK_GRANTED) {  /* too late, free the lock */
        fl->fl_type = F_UNLCK;
        rc = POSIX_LOCK_FILE(fP, fl);
      }
      TRACE2(TRACE_VNODE, 1, TRCID_LINUX_GRANT_LOCK_08,
        "ganesha_grant_deferred: rc %d reason %d", rc, reason);
    }
  }
  return rc;
}

static void ganesha_break_deleg(struct file_lock *fl)
{
  int rc = -ENOENT;
  int reason;
  struct glock glock;
  struct flock *flock = &glock.flock;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct file *fP;

  reason = BREAK_DELEGATION;

  fP = fl->fl_file;
  DBGASSERT(fP != NULL);
  cnP = VP_TO_CNP(fP->f_dentry->d_inode);
  privVfsP = VP_TO_PVP(fP->f_dentry->d_inode);
  DBGASSERT(privVfsP != NULL);
  rc = posix2glock(&glock, fl);

  TRACE6(TRACE_VNODE, 3, TRCID_LINUX_BREAK_LOCK_06,
      "ganesha_break_deleg: rc %d lock pid %d type %d start %lld len %lld lock_owner 0x%lX",
       rc, flock->l_pid, flock->l_type, flock->l_start,
       flock->l_len, glock.lock_owner);

  if (!rc)
    rc = gpfs_ops.gpfsGaneshaLock(privVfsP, cnP, &glock, fl, reason);

return;
}

static int ganesha_change_deleg(struct file_lock **fl, int arg)
{
  int rc = 0;

  if (arg & F_UNLCK)
    rc = lease_modify(fl, arg);

  else if (arg & F_WRLCK)
    rc = -EAGAIN;

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_CHANGE_LOCK,
         "ganesha_change_deleg: fl 0x%lX arg %d rc %d",
          fl, arg, rc);

  return rc;
}

static void ganesha_notify_deferred(struct file_lock *fl)
{
  struct file *filp = NULL;
  int rc;

  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_NOTIFY_LOCK,
         "ganesha_notify_deferred: fl 0x%lX filp 0x%lX", fl, filp);

  rc = ganesha_grant_deferred(fl, NULL, EAGAIN);

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_NOTIFY_LOCK_2,
         "ganesha_notify_deferred: rc %d fl 0x%lX filp 0x%lX", rc, fl, filp);

  return;
}

static int ganesha_same_owner(struct file_lock *fl1, struct file_lock *fl2)
{
  TRACE6(TRACE_VNODE, 5, TRCID_LINUX_SAMET_LOCK_06,
         "ganesha_same_owner flags %x:%x pid %d:%d owner 0x%lX:0x%lX",
          fl1->fl_flags, fl2->fl_flags, fl1->fl_pid, fl2->fl_pid,
          fl1->fl_owner, fl2->fl_owner);

#ifdef HAS_FL_CLOSE
  if (fl1->fl_flags & FL_CLOSE)
    return fl1->fl_pid == fl2->fl_pid;
  else
    return fl1->fl_owner == fl2->fl_owner && fl1->fl_pid == fl2->fl_pid;
#endif
  return fl1->fl_owner == fl2->fl_owner;
}

struct lock_manager_operations ganesha_lock_operations = {
	.fl_compare_owner = ganesha_same_owner,
	.fl_notify = ganesha_notify_deferred,
#ifdef NFS_CLUSTER_LOCKS
	.fl_grant = ganesha_grant_deferred,
        .fl_break = ganesha_break_deleg,
        .fl_change = ganesha_change_deleg,
#if LINUX_KERNEL_VERSION < 2063800
	.fl_mylease = ganesha_same_owner,
#endif
#endif
};

int ganesha_tgid_old = 0;
int ganesha_tgid = 0;

static int check_type(struct file_lock *flock, int type)
{
  switch (type)
  {
    case F_WRLCK:
    case F_RDLCK:
    case F_UNLCK:
      flock->fl_type = type;
      break;

    default:
      return -EINVAL;
  }
  return 0;
}

static int glock2posix(struct file *fP, struct file_lock *plock, struct glock *g)
{
  off_t first, last;
  int retval = 0;
  int code = 0;

  switch (g->flock.l_whence)
  {
    case SEEK_SET:
      first = 0;
      break;
    case SEEK_CUR:
      first = fP->f_pos;
      break;
    default:
     {
       code = 1;
       retval = -EINVAL;
       goto out;
     }
  }
  first += g->flock.l_start;
  if (first < 0)
  {
    code = 3;
    retval = -EINVAL;
    goto out;
  }
  plock->fl_end = OFFSET_MAX;
  if (g->flock.l_len > 0)
  {
    last = first + g->flock.l_len - 1;
    plock->fl_end = last;
  }
  else if (g->flock.l_len < 0)
  {
    last = first - 1;
    plock->fl_end = last;
    first += g->flock.l_len;
    if (first < 0)
    {
      code = 5;
      retval = -EINVAL;
      goto out;
    }
  }
  plock->fl_start = first;	
  if (plock->fl_end < plock->fl_start)
  {
    code = 7;
    retval = -EOVERFLOW;
    goto out;
  }
  plock->fl_owner = g->lock_owner+1;  // make sure it is not a valid address.

  plock->fl_pid = cxiGetProcessId();
  plock->fl_file = fP;
  plock->fl_flags = FL_POSIX;
  plock->fl_ops = NULL;
  plock->fl_lmops = &ganesha_lock_operations;

  retval = check_type(plock, g->flock.l_type);

out:
  TRACE2(TRACE_VNODE, 1, TRCID_LINUX_GLOCK_TO_POSIX,
         "glock2posix: retval %d code %d", retval, code);

  return retval;
}

int posix2glock(struct glock *glock, struct file_lock *plock)
{
  glock->flock.l_start = plock->fl_start;
  glock->flock.l_len = plock->fl_end == OFFSET_MAX?0:plock->fl_end-plock->fl_start + 1;
  glock->flock.l_whence = 0;
  glock->flock.l_pid = plock->fl_pid;
  glock->flock.l_type = plock->fl_type;
  glock->lock_owner = (void *)(((long)plock->fl_owner >> 1) << 1); // make even
  return 0;
}

int
gpfs_wait_inode_update(struct super_block *sbP,
                       struct gpfs_file_handle __user *ufh, void __user *statbuf,
                       struct glock __user *glock, int __user *reasonP,
                       int __user *flagsP,
                       struct nfsd4_pnfs_deviceid __user *devId,
                       uint32_t __user *expire_interval, int fd)
{
  struct gpfsVfsData_t *privVfsP = NULL;
  struct gpfs_file_handle fh;
  struct nfsd4_pnfs_deviceid dev_id;
  uint32_t nodeAddr;
  uint32_t devIDseqNo;
  int retval = 0;
  int len = 0;
  int reason = 0;
  int code = 0;
  unsigned int *fhP;
  cxiVattr_t vattr;
  struct glock tglock;
  struct stat tmp;
  uint32_t expire_attr = 0;
  uint32_t poolId;

  if (copy_from_user(&fh, ufh, FH_HDR_SIZE))
  {
    code = 1;
    retval = EFAULT;
    goto err_out;
  }
  len = fh.handle_size;

  TRACE4(TRACE_VNODE, 1, TRCID_LINUX_GABESHA_INODE_01,
         "gpfs_wait_inode_update: ganesha_tgid %d gid %d len %d sbP 0x%lX",
         ganesha_tgid, FROM_KGID(CRED(current, gid)), len, sbP);

  privVfsP = (struct gpfsVfsData_t *)getPrivVfsP(sbP);
  if (privVfsP == NULL)
  {
    retval == EFAULT;
    code = 2;
    goto err_out;
  }

retry:
  retval = gpfs_ops.gpfsGaneshaUpdate(privVfsP, (int *)&fh.f_handle, &len,
                                      &vattr, &tglock, &reason, &nodeAddr,
                                      &devIDseqNo, &expire_attr, ganesha_tgid,
                                      &poolId);
  if (retval)
  {
    if (retval == EAGAIN)
      goto retry;
    code = 3;
    goto err_out;
  }
  fh.handle_type = len >> 2;
  fh.handle_size = len;
  if (len == (MAX_FH_INT << 2))
    fh.handle_key_size = 24;  // 40 - 16 don't include parent info
  else
    fh.handle_key_size = 12;  // 32 bit inode

  fh.handle_key_size = FH_HDR_SIZE + fh.handle_key_size;

  gpfs_ops.gpfsGetFSID(privVfsP, (int *)&fh.handle_fsid, NULL, NULL);

  if (copy_to_user(ufh, &fh, FH_HDR_SIZE+len))
  {
    code = 5;
    retval = EFAULT;
    goto err_out;
  }
  if (copy_to_user(reasonP, &reason, sizeof(int)))
  {
    code = 7;
    retval = EFAULT;
    goto err_out;
  }
  fhP = (int *)&fh.f_handle;

  TRACE8(TRACE_VNODE, 3, TRCID_ENCODE_FH_1,
         "gpfs_wait_inode_update len %d: %08x %08x %08x %08x %08x %08x %08x",
          len, fhP[0],fhP[1],fhP[2],fhP[3],fhP[4],fhP[5],fhP[6]);

  tmp.st_ino = vattr.va_ino;

  if (reason == INODE_INVALIDATE)
  {
    code = 11;
  }
  if (reason == INODE_UPDATE)
  {
    if (expire_interval) {

      TRACE1(TRACE_VNODE, 3, TRCID_EXPIRE_1,
         "gpfs_wait_inode_update expire_attr %d", expire_attr);

      if (copy_to_user(expire_interval, &expire_attr, sizeof(int)))
      {
        code = 4;
        retval = EFAULT;
        goto err_out;
      }
    }
    if (copy_to_user(flagsP, &vattr.va_flags, sizeof(int)))
    {
      code = 12;
      retval = EFAULT;
      goto err_out;
    }
    tmp.st_size = (Int64)vattr.va_size;
    tmp.st_blksize = vattr.va_blocksize;
    tmp.st_blocks = vattr.va_blocks;
    tmp.st_mode = vattr.va_mode;
    tmp.st_uid = vattr.va_uid;
    tmp.st_gid = vattr.va_gid;

    tmp.st_nlink = (Int64)vattr.va_nlink;
    tmp.st_atime = vattr.va_atime.tv_sec;
    tmp.st_mtime = vattr.va_mtime.tv_sec;
    tmp.st_ctime = vattr.va_ctime.tv_sec;
#ifdef STAT_HAVE_NSEC
    tmp.st_atime_nsec = vattr.va_atime.tv_nsec;
    tmp.st_mtime_nsec = vattr.va_mtime.tv_nsec;
    tmp.st_ctime_nsec = vattr.va_ctime.tv_nsec;
#endif
    code = 13;
  }
  if (reason == INODE_LOCK_GRANTED || reason == INODE_LOCK_AGAIN)
  {
     TRACE5(TRACE_VNODE, 3, TRCID_LINUX_GABESHA_INODE_06,
          "gpfs_wait_inode_update: lock pid %d type %d start %lld len %lld lock_owner0x%lX",
           tglock.flock.l_pid, tglock.flock.l_type, tglock.flock.l_start,
           tglock.flock.l_len, tglock.lock_owner);
    if (copy_to_user(glock, &tglock, sizeof(struct glock)))
    {
      code = 17;
      retval = EFAULT;
      goto err_out;
    }
    if (reason == INODE_LOCK_AGAIN)
    {
      code = 19;
      goto err_out;
    }
  }
  if (reason == LAYOUT_NOTIFY_DEVICEID)
  {
#ifdef P_NFS4
    cxiGetDevicePnfsId(&dev_id, nodeAddr, devIDseqNo, poolId,
                       fh.handle_fsid[0], fh.handle_fsid[1]);

    TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_GET_DEVID,
         "gpfs_wait_inode_update: fsal_id %d seq %d fd %d fsid 0x%lx",
          dev_id.fsal_id, dev_id.device_id2,
          dev_id.device_id4, dev_id.devid);

    if (copy_to_user(devId, &dev_id, sizeof(struct nfsd4_pnfs_deviceid)))
    {
      code = 23;
      retval = EFAULT;
      goto err_out;
    }
#endif
  }
  if (copy_to_user(statbuf, &tmp, sizeof(tmp)))
  {
    code = 25;
    retval = EFAULT;
    goto err_out;
  }

err_out:

  TRACE7(TRACE_VNODE, 3, TRCID_LINUX_GABESHA_INODE_04,
     "gpfs_wait_inode_update:  retval %d reason %d ino %lld nlink %lld code %d len %d key size %d",
      retval, reason, tmp.st_ino, tmp.st_nlink, code, len, fh.handle_key_size);

  if (retval != 0)
  {
    if (retval == EINTR || retval == EFAULT || retval == ESTALE)
      retval = EUNATCH;

    TRACE3(TRACE_VNODE, 1, TRCID_LINUX_GABESHA_INODE_07,
       "gpfs_wait_inode_update:  retval %d reason %d code %d",
        retval, reason, code);
  }
  return (-retval);
}

int
gpfs_wait_update(struct super_block *sbP, int *reasonP)
{
  struct gpfsVfsData_t *privVfsP = NULL;
  int retval = 0;
  int reason = 0;
  int code = 0;

  if (copy_from_user(&reason, reasonP, sizeof(int)))
  {
    retval = -EFAULT;
    goto err_out;
  }

  TRACE4(TRACE_VNODE, 1, TRCID_LINUX_GABESHA_UPDATE_01,
         "gpfs_wait_update: ganesha_tgid %d gid %d sbP 0x%lX reason %d",
         ganesha_tgid, FROM_KGID(CRED(current, gid)), sbP, reason);

  privVfsP = (struct gpfsVfsData_t *)getPrivVfsP(sbP);
  if (privVfsP == NULL)
  {
    retval == EFAULT;
    code = 2;
    goto err_out;
  }

  retval = gpfs_ops.gpfsGaneshaThread(privVfsP, &reason, NULL, 0);
  if (retval)
  {
    if (retval == ESTALE || retval == -ESTALE)
      retval = EUNATCH;
    code = 3;
    goto err_out;
  }
  if (copy_to_user(reasonP, &reason, sizeof(int)))
  {
    code = 7;
    retval = EFAULT;
    goto err_out;
  }

err_out:
  TRACE3(TRACE_VNODE, 1, TRCID_LINUX_GABESHA_UPDATE_03,
     "gpfs_wait_update:  retval %d reason %d code %d",
      retval, reason, code);

  return (-retval);
}

static int dentry_to_handle(struct dentry *dentry,
                            struct gpfs_file_handle __user *ufh)
{
  struct gpfsVfsData_t *privVfsP = NULL;
  int retval;
  int handle_size = 0;
  struct gpfs_file_handle fh;
  const struct export_operations *exop = dentry->d_sb->s_export_op;

  privVfsP = (struct gpfsVfsData_t *)getPrivVfsP(dentry->d_sb);

  if (copy_from_user(&fh, ufh, FH_HDR_SIZE))
  {
    retval = -EFAULT;
    goto err_out;
  }
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_NAME_TO_HANDLE_IN,
         "dentry_to_handle: handle_size %d key_size %d",
          fh.handle_size, fh.handle_key_size);

  if (fh.handle_size > OPENHANDLE_HANDLE_LEN)
  {
    retval = -EINVAL;
    goto err_out;
  }
  handle_size = fh.handle_size >> 2;
  /* we ask for a non connected handle */
#ifdef NEW_ENCODE_FH
  retval = gpfs_encode_fh(dentry->d_inode, (int *)&fh.f_handle, &handle_size, NULL);
#else
  retval = gpfs_encode_fh(dentry, (int *)&fh.f_handle, &handle_size, 0);
#endif
  /* convert handle size to bytes */
  handle_size = handle_size << 2;
  fh.handle_size = handle_size;
  if (handle_size == (MAX_FH_INT << 2))
    fh.handle_key_size = 24;  // 40 - 16 don't include parent info
  else
    fh.handle_key_size = 12;  // 32 bit inode

  fh.handle_key_size = FH_HDR_SIZE + fh.handle_key_size;

  if (retval == 255)
    retval = -ENOSPC;
  else
  {
    gpfs_ops.gpfsGetFSID(privVfsP, (int *)&fh.handle_fsid, NULL, NULL);
    fh.handle_type = retval;
    retval = 0;
    if (copy_to_user(ufh, &fh, FH_HDR_SIZE+handle_size))
    {
      retval = -EFAULT;
      goto out;
    }
  }
  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_NAME_TO_HANDLE_OUT,
         "dentry_to_handle: exit retval %d handle_size %d key_size %d",
          retval, fh.handle_size, fh.handle_key_size);

  goto out;

err_out:
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_NAME_TO_HANDLE_EXIT,
         "dentry_to_handle: exit retval %d handle_size %d",
          retval, fh.handle_size);
out:
  return retval;
}

int name_to_handle_at(int dfd, const char __user *name,
                       struct gpfs_file_handle __user *handle, int flag)
{
  int follow = 0;
  int ret = -EINVAL;
  int code = 0;
  struct nameidata nd;
  struct file *file = NULL;

#if LINUX_KERNEL_VERSION < 2061800 || defined(SUSE_SLES10SP2) || defined(SUSE_SLES11) || defined(UBUNTU_LINUX)
  ret = -ENOENT; //??? fix for old SLES
  code = 2;
  goto err_out;
#else
  if ((flag & ~AT_SYMLINK_FOLLOW) != 0)
  {
    code = 4;
    goto err_out;\
  }
#endif

  if (name == NULL && dfd != AT_FDCWD)
  {
    file = fget(dfd);

    if (file)
      ND_PATH(nd).dentry = file->f_dentry;
    else
    {
      code = 6;
      ret = -EBADF;
      goto err_out;
    }
  }
  else
  {
#if LINUX_KERNEL_VERSION < 2061800 || defined(SUSE_SLES10SP2) || defined(SUSE_SLES11) || defined(UBUNTU_LINUX)
    ret = -ENOENT; //??? fix for old SLES
    code = 8;
    goto err_out;
#else
    follow = (flag & AT_SYMLINK_FOLLOW) ? LOOKUP_FOLLOW : 0;
#endif
    if (name == NULL)
    {
      code = 10;
      ret = -ENOENT;
      goto err_out;
    }
    ret = USER_WALK_PATH(dfd, name, follow, &ND_PATH(nd));
    if (ret)
    {
      code = 12;
      goto err_out;
    }
  }
  ret = dentry_to_handle(ND_DENTRY(nd), handle);
  if (file)
    fput(file);
  else
    PATH_PUT(&nd);

err_out:

  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_AT_EXIT,
         "name_to_handle_at: exit ret %d code %d dfd %d follow %d",
          ret, code, dfd, follow);

  return ret;
}

static struct vfsmount *get_vfsmount_from_fd(int fd)
{
  struct vfsmount *mnt;

  if (fd == AT_FDCWD)
  {
    struct fs_struct *fs = current->fs;

    FS_STRUCT_LOCK(&fs->lock);
    mnt = fs->PWDMNT;
    mntget(mnt);
    FS_STRUCT_UNLOCK(&fs->lock);
  }
  else
  {
    struct file *filep;
    int fput_needed;

    filep = FGET(fd, fput_needed);
    if (!filep)
      return ERR_PTR(-EBADF);
#ifdef HAS_F_VFSMNT
    mnt = filep->f_vfsmnt;
#else
    mnt = filep->f_path.mnt;
#endif
    mntget(mnt);

    FPUT(filep, fput_needed);
  }

#if (LINUX_KERNEL_VERSION >= 2063200)
  if (getPrivVfsP(mnt->mnt_sb) == NULL)
  {
    mntput(mnt);
    mnt = ERR_PTR(-EBADF);
  }
#endif
  return mnt;
}

struct dentry *
ganesha_fh_to_dentry(struct super_block *sbP, struct fid *fid,
                  int len, int fhtype, int needRevalidate);

static struct dentry *
getDentryFromFH(struct super_block *sbP, struct gpfs_file_handle *handle,
                int needRevalidate)
{
  int handle_size;
  struct dentry *dentry;
  struct handle_svc_export svc;

  /* change the handle size to multiple of sizeof(u32) */
  handle_size = handle->handle_size >> 2;

#if (LINUX_KERNEL_VERSION >= 2062400)
  dentry = ganesha_fh_to_dentry(sbP, (struct fid *) handle->f_handle,
                             handle_size, handle->handle_type, needRevalidate);
#else
  /*
   * GPFS overload acceptable callback. To make GPFS return
   * 1 set svc->ex_flags
   */
  memset(&svc, 0, sizeof(svc));
  svc.ex_flags = NFSEXP_NOSUBTREECHECK;

  dentry = gpfs_decode_fh(sbP, (__u32 *) handle->f_handle,
                          handle_size, handle->handle_type,
                          vfs_dentry_acceptable, (void *)&svc);
#endif
  return dentry;
}

static struct dentry *handle_to_dentry(int mountdirfd,
                         struct gpfs_file_handle *handle,
                         struct vfsmount **mntp, int needRevalidate)
{
  long retval;
  int code = 0;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct handle_svc_export svc;

  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    code = 2;
    retval = PTR_ERR(mnt);
    goto out_err;
  }
  dentry = getDentryFromFH(mnt->mnt_sb, handle, needRevalidate);
  if (IS_ERR(dentry))
  {
    code = 4;
    retval = PTR_ERR(dentry);
    goto out_mnt;
  }
  if (!dentry)
  {
    code = 6;
    retval = -ESTALE;
    goto out_mnt;
  }
  *mntp = mnt;
  return dentry;

out_mnt:
  mntput(mnt);
out_err:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_TO_DENTRY_EXIT,
         "handle_to_dentry: exit err %ld retval %lx code %d",
          ERR_PTR(retval), retval, code);

  return ERR_PTR(retval);
}

int suidRemove(struct dentry *dentry)
{
  mode_t i_mode = dentry->d_inode->i_mode;
  int kill_attr = 0;

  if (i_mode & S_ISUID)
    kill_attr = ATTR_KILL_SUID;

  if ((i_mode & S_ISGID) && (i_mode & S_IXGRP))
    kill_attr |= ATTR_KILL_SGID;

  if (kill_attr && !capable(CAP_FSETID))
    return kill_attr;

  return 0;
}

int truncate_it(struct dentry *dentry, loff_t len, unsigned int attr_time)
{
  int rc;
  struct iattr attrs;

  if (len < 0)
    return -EINVAL;

  attrs.ia_size = len;
  attrs.ia_valid = ATTR_SIZE | attr_time;

  attrs.ia_valid |= suidRemove(dentry);

  INODE_LOCK(dentry->d_inode);
#if defined(SUSE_SLES10SP2) || defined(SUSE_SLES11) || defined(UBUNTU_LINUX)
  rc = -ENOENT; //??? fix for old SLES
#else
  rc = NOTIFY_CHANGE(dentry, &attrs);
#endif
  INODE_UNLOCK(dentry->d_inode);

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_TRUNCATE_EXIT,
         "truncate_it: exit rc %d inode %lld len %lld",
          rc, dentry->d_inode->i_ino, len);

  return rc;
}

int check_permission(struct inode *inode, int mask, unsigned int flags)
{
  int submask;
  umode_t i_mode = inode->i_mode;

  if (mask & MAY_WRITE)
  {
    if (IS_RDONLY(inode) && (S_ISREG(i_mode) || S_ISDIR(i_mode) || S_ISLNK(i_mode)))
      return -EROFS;

    if (IS_IMMUTABLE(inode))
      return -EACCES;
  }

  if ((mask & MAY_EXEC) && S_ISREG(i_mode) && !(i_mode & S_IXUGO))
    return -EACCES;

  submask = mask & ~MAY_APPEND;
#ifdef IN_KERNEL_CHANGE_NOT_SUPP

  /* FIXME! we don't have nameidata for handle lookup. So not sure how
   * we can check for inode->permissions. We already limit the call
   * to CAP_DAC_OVERRIDE. So we should be able to skip the ACL check.
   * But we also skip security_inode_permission below.
   */

  if (inode->i_op && inode->i_op->permission)
    retval = inode->i_op->permission(inode, submask, nd);
  else
    retval = LINUX_GENERIC_PERMISSION(inode, submask, flags, NULL);
  if (retval)
    return retval;

  return security_inode_permission(inode, mask, nd);
#else
  return LINUX_GENERIC_PERMISSION(inode, submask, flags, NULL);
#endif
}

static int may_handle_open(struct dentry *dentry, int open_flag)
{
  int acc_mode;
  int error;
  int code = 0;
  struct inode *inode = dentry->d_inode;

  if ((open_flag + 1) & O_ACCMODE)
    open_flag++;

  acc_mode = MY_ACC_MODE(open_flag);

  if (open_flag & O_TRUNC)
    acc_mode |= MAY_WRITE;

  if (open_flag & O_APPEND)
    acc_mode |= MAY_APPEND;

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_MAY_HANDLE_OPEN,
         "may_handle_open: enter inode %lld acc_mode 0x%X open_flag 0x%X",
          inode->i_ino, acc_mode, open_flag);

  if (S_ISDIR(inode->i_mode) && (acc_mode & MAY_WRITE))
  {
    error = -EISDIR;
    code = 3;
    goto out;
  }
  error = check_permission(inode, acc_mode, open_flag);
  if (error)
  {
    code = 5;
    goto out;
  }

  if (S_ISFIFO(inode->i_mode) || S_ISSOCK(inode->i_mode))
  {
    open_flag &= ~O_TRUNC;
  }
  else if (S_ISBLK(inode->i_mode) || S_ISCHR(inode->i_mode))
  {
#ifdef IN_KERNEL_CHANGE_NOT_SUPP
    if (nd->mnt->mnt_flags & MNT_NODEV)
    {
      error = -EACCES;
      code = 7;
      goto out;
    }
#endif
    open_flag &= ~O_TRUNC;
  }
  else if (IS_RDONLY(inode) && (acc_mode & MAY_WRITE))
  {
    error = -EROFS;
    code = 9;
    goto out;
  }
  if (IS_APPEND(inode))
  {
    if ((open_flag & FMODE_WRITE) && !(open_flag & O_APPEND))
    {
      error = -EPERM;
      code = 11;
      goto out;
    }
    if (open_flag & O_TRUNC)
    {
      error = -EPERM;
      code = 13;
      goto out;
    }
  }
  if (open_flag & O_NOATIME)
    if (!UID_EQ(FSUID, inode->i_uid) && !capable(CAP_FOWNER))
    {
      error = -EPERM;
      code = 15;
      goto out;
    }

  if (S_ISREG(inode->i_mode))
  {
    error = break_lease(inode, open_flag | O_NONBLOCK);
    if (error)
    {
      code = 17;
      goto out;
    }
  }
  if (open_flag & O_TRUNC)
  {
    error = get_write_access(inode);
    if (error)
    {
      code = 19;
      goto out;
    }

#ifdef IN_KERNEL_CHANGE_NOT_SUPP
    error = locks_verify_locked(inode);
#endif
    if (!error)
    {
      error = truncate_it(dentry, 0, ATTR_MTIME | ATTR_CTIME);
    }
    put_write_access(inode);
    if (error)
    {
      code = 21;
      goto out;
    }
  }
  error = 0;

out:
  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_MAY_HANDLE_OPEN_EXIT,
         "may_handle_open: exit inode %lld error %d code %d",
          inode->i_ino, error, code);

  return error;
}

static struct dentry *
dentry_by_handle(int mountdirfd, struct gpfs_file_handle __user *ufh)
{
  int retval = 0;
  struct dentry *dentry = NULL;
  struct vfsmount *mnt = NULL;
  struct gpfs_file_handle fh;

  if (copy_from_user(&fh, ufh, FH_HDR_SIZE))
    return ERR_PTR(-EFAULT);

  if ((fh.handle_size > OPENHANDLE_HANDLE_LEN) || (fh.handle_size <= 0))
    return ERR_PTR(-EINVAL);

  /* copy the full handle */
  if (copy_from_user(&fh, ufh, FH_HDR_SIZE + fh.handle_size))
    return ERR_PTR(-EFAULT);

  dentry = handle_to_dentry(mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
    return dentry;

  mntput(mnt);

  return dentry;
}

int do_sys_open_by_handle(int mountdirfd, struct gpfs_file_handle __user *ufh,
                          int open_flag, int share_access, int share_deny)
{
  int fd = 0;
  int retval = 0;
  struct file *filp;
  struct dentry *dentry;
  struct vfsmount *mnt = NULL;
  struct gpfs_file_handle fh;

  /* can't use O_CREATE with open_by_handle */
  if (open_flag & O_CREAT)
  {
    retval = -EINVAL;
    goto out;
  }
  if (copy_from_user(&fh, ufh, FH_HDR_SIZE))
  {
    retval = -EFAULT;
    goto out;
  }
  if ((fh.handle_size > OPENHANDLE_HANDLE_LEN) || (fh.handle_size <= 0))
  {
    retval = -EINVAL;
    goto out;
  }
  /* copy the full handle */
  if (copy_from_user(&fh, ufh, FH_HDR_SIZE + fh.handle_size))
  {
    retval = -EFAULT;
    goto out;
  }
  dentry = handle_to_dentry(mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out;
  }

  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_OPEN_5,
        "do_sys_open_by_handle: in  i_ino %lld writecount %d i_count %d open_flag 0x%X\n",
         dentry->d_inode->i_ino, atomic_read(&dentry->d_inode->i_writecount),
         atomic_read(&dentry->d_inode->i_count), open_flag);

  retval = may_handle_open(dentry, open_flag);
  if (retval)
    goto out_dentry;

  fd = get_unused_fd();
  if (fd < 0)
  {
    retval = fd;
    goto out_dentry;
  }
  DENTRY_OPEN(filp, dentry, mnt, open_flag);
  if (IS_ERR(filp))
  {
    put_unused_fd(fd);
    retval = PTR_ERR(filp);
  }
  else
  {
    retval = fd;
    fd_install(fd, filp);
  }
  if (retval > 0)
  {
    int err = 0;

#if (LINUX_KERNEL_VERSION >= 3100000) && defined(CONFIG_IMA)
    TRACE8(TRACE_VNODE, 3, TRCID_GANESHA_OPEN_7,
        "do_sys_open_by_handle: i_ino %lld writecount %d readcount %d i_count %d open_flag 0x%X mode0 x%X fP 0x%lX f_count %lld\n",
         dentry->d_inode->i_ino, atomic_read(&dentry->d_inode->i_writecount),
         atomic_read(&dentry->d_inode->i_readcount),
         atomic_read(&dentry->d_inode->i_count), open_flag, filp->f_mode, filp,
         atomic_long_read(&filp->f_count));
#else
    TRACE7(TRACE_VNODE, 3, TRCID_GANESHA_OPEN_7_1,
        "do_sys_open_by_handle: i_ino %lld writecount %d i_count %d open_flag 0x%X mode0 x%X fP 0x%lX f_count %lld\n",
         dentry->d_inode->i_ino, atomic_read(&dentry->d_inode->i_writecount),
         atomic_read(&dentry->d_inode->i_count), open_flag, filp->f_mode, filp,
         atomic_long_read(&filp->f_count));
#endif

    if ((share_access == 0) && (share_deny == 0))  /* no shares */
#if LINUX_KERNEL_VERSION >= 3100000
      goto out_dentry;
#else
      goto out;
#endif
    err = gpfs_f_share(filp, share_access, share_deny);

    TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_DO_SYS_OPEN_SHARE,
         "do_sys_open_by_handle: fd %d err %d share_access %d share_deny %d",
          fd, err, share_access, share_deny);

    if (err)
    {
      fput(filp);
      retval = -(err);
      goto out_dentry;
    }
  }
#if LINUX_KERNEL_VERSION >= 3100000
  goto out_dentry;
#else
  goto out;
#endif

out_dentry:
  dput(dentry);
  mntput(mnt);

out:
  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_DO_SYS_OPEN_EXIT,
         "do_sys_open_by_handle: exit retval %d mountdirfd %d fd %d",
          retval, mountdirfd, fd);

  return retval;
}

int open_by_handle(int mountdirfd, struct gpfs_file_handle __user *handle,
                   int flags, int share_access, int share_deny)
{
  int ret;

  if (force_o_largefile())
    flags |= O_LARGEFILE;

  ret = do_sys_open_by_handle(mountdirfd, handle, flags,
                              share_access, share_deny);
  return ret;
}

/* get/set lock or delegation */

int set_lock(int mountdirfd, struct glock __user *l, Boolean set_delegation)
{
  struct file_lock *flock = NULL;
  struct file_lock *old_fl = NULL;
  struct glock glock;
  struct file *filep = NULL;
  struct file *f;
  struct inode *iP = NULL;
  int fput_needed = 0;
  int error = 0;
  int code = 0;
  struct inode *inodeP = NULL;

  TRACE2(TRACE_VNODE, 3, TRCID_LINUXOPS_SET_DELEG_IN,
        "set_lock: dirfd %d set_delegation %d",
         mountdirfd, set_delegation);

#ifndef NFS_CLUSTER_LOCKS
   code = 2;
   error = -ENOLCK;
   goto out;
#endif
  if (copy_from_user(&glock, l, sizeof(glock)))
  {
    code = 3;
    error = -EFAULT;
    goto out;
  }
  filep = FGET(glock.lfd, fput_needed);
  if (!filep)
  {
    code = 5;
    error = -EBADF;
    goto out;
  }
  flock = LOCK_ALLOC_LOCK();
  if (flock == NULL)
  {
    code = 7;
    error = -ENOMEM;
    goto out_fd;
  }
  old_fl = flock;

  TRACE6(TRACE_VNODE, 3, TRCID_SET_LOCK_1,
         "set_lock: fl 0x%lX dfd %d lfd %d cmd %d owner 0x%lX type %d",
          flock, mountdirfd, glock.lfd, glock.cmd, glock.lock_owner,
          glock.flock.l_type);

  locks_init_lock(flock);
  error = glock2posix(filep, flock, &glock);
  if (error)
  {
    code = 9;
    error = -EBADF;
    goto out_fd;
  }
  if (set_delegation)
  {
    flock->fl_flags = FL_LEASE;
    if (flock->fl_type != F_RDLCK && flock->fl_type != F_WRLCK && flock->fl_type != F_UNLCK)
    {
      code = 11;
      error = -ENOLCK;
      goto out_fd;
    }

#if defined(HAS_FILE_INODE)
    inodeP = file_inode(filep);
#endif

    /* For BKL version, we need to LOCK_KERNEL(), but for spin-lock
       version, __gpfs_f_set_lease() will handle it. */
    LOCK_KERNEL();
#ifdef NFS_CLUSTER_LOCKS
    error = __gpfs_f_set_lease(filep, flock->fl_type, &flock);
#endif
    if (error == 0)   /* 0 means we got the delegation, keep flock */
    {
      /* If the flock returned is the same as the one we allocated, we
	 don't free it. Here, we can access flock because we have BKL
	 or spin-lock held, release it after the access. */
      if (flock->fl_type != F_UNLCK && flock == old_fl)
        old_fl = NULL;
      UNLOCK_KERNEL();
      UNLOCK_FLOCKS(inodeP);
      code = 21;
      goto out_fd;

    }
    else
    {
      /* On error, __gpfs_f_set_lease() won't hold any spin-lock, so
	 here we only handle BKL. */
      UNLOCK_KERNEL();
      code = 23;
      goto out_fd;
    }
  }
  else
  {
    if (glock.cmd == F_SETLKW)
      flock->fl_flags |= FL_SLEEP;
#ifdef NFS_CLUSTER_LOCKS
    if (glock.cmd == GPFS_F_CANCELLK)
      glock.cmd = F_CANCELLK;
#endif

    error = -EBADF;
    switch (glock.flock.l_type)
    {
      case F_RDLCK:
        if (!(filep->f_mode & FMODE_READ))
        {
          code = 33;
          goto out_fd;
        }
        break;
      case F_WRLCK:
        if (!(filep->f_mode & FMODE_WRITE))
        {
          code = 35;
          goto out_fd;
        }
        break;
      case F_UNLCK:
        break;
      default:
        code = 37;
        error = -EINVAL;
        goto out_fd;
    }
    error = gpfs_f_lock(filep, glock.cmd, flock);
    if (error == 1)   /* 1 means we will get callback, keep flock */
      old_fl = NULL;
#ifdef NFS_CLUSTER_LOCKS
      else if (error < 0 && glock.cmd == GPFS_F_CANCELLK)
      {
        error = 0;
        code = 39;
      }
#endif
  }
out_fd:

  if (old_fl)
    LOCK_FREE_LOCK(old_fl);

  FPUT(filep, fput_needed);

out:

  TRACE7(TRACE_VNODE, 3, TRCID_SET_LOCK_EXIT_1,
   "set_lock: exit dfd %d lfd %d cmd %d old_fl 0x%lX fl 0x%lX error %d code %d",
    mountdirfd, glock.lfd, glock.cmd, old_fl, flock, error, code);

  return error;
}

int get_lock(int mountdirfd, struct glock __user *l)
{
  struct file_lock file_lock;
  struct glock glock;
  struct file *filep = NULL;
  int fput_needed = 0;
  int error = 0;
  int code = 0;

  if (copy_from_user(&glock, l, sizeof(glock)))
  {
    code = 3;
    error = -EFAULT;
    goto out;
  }
  TRACE4(TRACE_VNODE, 3, TRCID_GET_LOCK_1,
         "get_lock: dfd %d lfd %d cmd %d lock_owner 0x%lX",
          mountdirfd, glock.lfd, glock.cmd, glock.lock_owner);

  filep = FGET(glock.lfd, fput_needed);
  if (!filep)
  {
    code = 5;
    error = -EBADF;
    goto out;
  }
  if ((glock.flock.l_type != F_RDLCK) && (glock.flock.l_type != F_WRLCK))
  {
    code = 7;
    error = -EINVAL;
    goto out_fd;
  }
  locks_init_lock(&file_lock);
  error = glock2posix(filep, &file_lock, &glock);
  if (error)
  {
    code = 9;
    goto out_fd;
  }
  error = gpfs_f_lock(filep, glock.cmd, &file_lock);
  if (error)
  {
    code = 11;
    goto out_fd;
  }
  glock.flock.l_type = file_lock.fl_type;
  if (file_lock.fl_type != F_UNLCK)
  {
    error = posix2glock(&glock, &file_lock);
    if (error)
    {
      code = 13;
      goto out_fd;
    }
  }
  if (copy_to_user(l, &glock, sizeof(glock)))
  {
    code = 15;
    error = -EFAULT;
    goto out_fd;
  }
out_fd:
  FPUT(filep, fput_needed);

out:
  TRACE6(TRACE_VNODE, 3, TRCID_GET_LOCK_EXIT_1,
        "get_lock: exit dfd %d lfd %d cmd %d lock_owner 0x%lX error %d code %d",
         mountdirfd, glock.lfd, glock.cmd, glock.lock_owner, error, code);

  return error;
}

int readlink_by_fh(int mountdirfd, struct gpfs_file_handle __user *fh,
                   char __user *buf, int buffsize)
{
  int error = 0;
  int code = 0;
  struct inode *inode;
  struct dentry *dentry = NULL;

  dentry = dentry_by_handle(mountdirfd, fh);
  if (IS_ERR(dentry))
  {
    code = 2;
    error = PTR_ERR(dentry);
    goto exit;
  }
  inode = dentry->d_inode;
  error = -EINVAL;

  if (inode && inode->i_op && inode->i_op->readlink)
  {
    code = 4;
    error = inode->i_op->readlink(dentry, buf, buffsize);
  }
  dput(dentry);

exit:

  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_READLINK_FH_EXIT,
         "readlink_by_fh: exit error %d code %d", error, code);

  return error;
}

static int get_kernel_handle(struct gpfs_file_handle __user *ufh,
                             struct gpfs_file_handle __user *fh)
{
  int error = 0;
  int code = 0;
  struct gpfs_file_handle fhandle;

  if (copy_from_user(&fhandle, ufh, FH_HDR_SIZE))
  {
    code = 2;
    error = -EFAULT;
    goto out;
  }
  if ((fhandle.handle_size > OPENHANDLE_HANDLE_LEN) || (fhandle.handle_size <= 0))
  {
    code = 4;
    error = -EINVAL;
    goto out;
  }
  /* copy the full handle */
  if (copy_from_user(fh, ufh, FH_HDR_SIZE + fhandle.handle_size))
  {
    code = 8;
    error = -EFAULT;
    goto out;
  }

out:
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_GET_KERNEL_HANDLE_EXIT,
          "get_kernel_handle: exit error %d code %d", error, code);

  return error;
}

int get_inode_update(int mountdirfd, struct gpfs_file_handle __user *handle,
                     void __user *buf, struct glock __user *glock, int *reasonP,
                     int *flagsP, struct nfsd4_pnfs_deviceid *devId,
                     uint32_t *expire_interval)

{
  int retval = 0;
  struct vfsmount *mnt = NULL;

  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    retval = PTR_ERR(mnt);
    goto out_err;
  }
  retval = gpfs_wait_inode_update(mnt->mnt_sb, handle, buf, glock, reasonP,
                                  flagsP, devId, expire_interval, mountdirfd);
  mntput(mnt);

out_err:
  return retval;
}

int thread_update(int mountdirfd, int *reasonP)

{
  int retval = 0;
  struct vfsmount *mnt = NULL;

  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    retval = PTR_ERR(mnt);
    goto out_err;
  }
  retval = gpfs_wait_update(mnt->mnt_sb, reasonP);
  mntput(mnt);

out_err:
  return retval;
}

static int link_by_fh(int mountdirfd, struct gpfs_file_handle __user *dir_fh,
                struct gpfs_file_handle __user *dst_fh,
                const char __user *newname, int len)
{
  void *name = NULL;
  int error = 0;
  int code = 0;
  struct dentry *new_dentry = NULL;
  struct dentry *dir_dentry = NULL;
  struct dentry *dst_dentry = NULL;
  struct vfsmount *mnt = NULL;

  name = GPFS_GETNAME(newname);
  if ((name == NULL) || IS_ERR(name))
  {
    code = 2;
    error = -EFAULT;
    goto exit;
  }
  dst_dentry = dentry_by_handle(mountdirfd, dst_fh);
  if (IS_ERR(dst_dentry))
  {
    code = 4;
    error = PTR_ERR(dst_dentry);
    goto put_name;
  }
  /* dst_dentry is what we link to and it must not be directory */
  if ((dst_dentry->d_inode->i_mode & S_IFMT) == S_IFDIR)
  {
    code = 5;
    error = -EPERM;
    goto put_dst_dentry;
  }
  dir_dentry = dentry_by_handle(mountdirfd, dir_fh);
  if (IS_ERR(dir_dentry))
  {
    code = 6;
    error = PTR_ERR(dir_dentry);
    goto put_dst_dentry;
  }
  /* dir_entry where we add the link must be a directory */
  if ((dir_dentry->d_inode->i_mode & S_IFMT) != S_IFDIR)
  {
    code = 7;
    error = -EPERM;
    goto put_dir_dentry;
  }
  INODE_LOCK_NESTED(dir_dentry->d_inode, I_MUTEX_PARENT);
  new_dentry = LOOKUP_ONE_LEN(name, dir_dentry, len);
  if (IS_ERR(new_dentry))
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 8;
    error = PTR_ERR(new_dentry);
    goto put_dir_dentry;
  }
  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 10;
    error = PTR_ERR(mnt);
    goto put_new_dentry;
  }
  if (S_ISREG(dst_dentry->d_inode->i_mode))
  {
    error = break_lease(dst_dentry->d_inode, O_WRONLY | O_NONBLOCK);
    if (error)
      code = 17;
  }
  if (!error)
    error = VFS_LINK(mnt, dst_dentry, dir_dentry->d_inode, new_dentry);
  INODE_UNLOCK(dir_dentry->d_inode);
  mntput(mnt);

put_new_dentry:
  dput(new_dentry);

put_dir_dentry:
  dput(dir_dentry);

put_dst_dentry:
  dput(dst_dentry);

put_name:
  GPFS_PUTNAME(name);

exit:
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_LINK_FH_EXIT,
         "link_by_fh: exit error %d code %d", error, code);

  return error;
}

static int rename_by_fh(int mountdirfd, struct gpfs_file_handle __user *old_fh,
                       const char __user *old_name, int old_len,
                       struct gpfs_file_handle __user *new_fh,
                       const char __user *new_name, int new_len)
{
  void *newname = NULL;
  void *oldname = NULL;
  int error = 0;
  int code = 0;
  struct vfsmount *mnt = NULL;
  struct dentry *new_dentry = NULL;
  struct dentry *old_dentry = NULL;
  struct dentry *lock_dentry = NULL;
  struct dentry *newdentry = NULL;
  struct dentry *olddentry = NULL;

  oldname = GPFS_GETNAME(old_name);
  if ((oldname == NULL) || IS_ERR(oldname))
  {
    code = 2;
    error = -EFAULT;
    goto exit;
  }
  newname = GPFS_GETNAME(new_name);
  if ((newname == NULL) || IS_ERR(newname))
  {
    code = 4;
    error = -EFAULT;
    goto put_oldname;
  }
  old_dentry = dentry_by_handle(mountdirfd, old_fh);
  if (IS_ERR(old_dentry))
  {
    code = 6;
    error = PTR_ERR(old_dentry);
    goto put_newname;
  }
  new_dentry = dentry_by_handle(mountdirfd, new_fh);
  if (IS_ERR(new_dentry))
  {
    code = 8;
    error = PTR_ERR(new_dentry);
    goto put_old_dentry;
  }
  
  if (new_dentry->d_inode == old_dentry->d_inode) {
    INODE_LOCK_NESTED(new_dentry->d_inode, I_MUTEX_PARENT);
    lock_dentry = NULL;
    code = 29;
    TRACE4(TRACE_VNODE, 1, TRCID_GANESHA_RENAME_FH_12,
         "rename_by_fh: same inode %lld new %p old %p code %d",
         new_dentry->d_inode->i_ino, new_dentry, old_dentry, code);
  }
  else
    lock_dentry = lock_rename(new_dentry, old_dentry);

  if ((!S_ISDIR(new_dentry->d_inode->i_mode)) ||
      (!S_ISDIR(old_dentry->d_inode->i_mode)))
  {
    code = 9;
    error = -ENOENT;
    goto put_new_dentry;
  }
  olddentry = LOOKUP_ONE_LEN(oldname, old_dentry, old_len);
  if (IS_ERR(olddentry))
  {
    code = 10;
    error = PTR_ERR(olddentry);
    goto put_new_dentry;
  }
  if (!olddentry->d_inode)
  {
    code = 12;
    error = -ENOENT;
    goto put_olddentry;
  }
  if (olddentry == lock_dentry)
  {
    code = 13;
    error = -EINVAL;
    goto put_olddentry;
  }
  newdentry = LOOKUP_ONE_LEN(newname, new_dentry, new_len);
  if (IS_ERR(newdentry))
  {
    code = 14;
    error = PTR_ERR(newdentry);
    goto put_olddentry;
  }
  if (newdentry == lock_dentry)
  {
    code = 16;
    error = -ENOTEMPTY;
    goto put_newdentry;
  }
  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    code = 31;
    error = PTR_ERR(mnt);
    goto put_newdentry;
  }
  if (S_ISREG(olddentry->d_inode->i_mode))
  {
    error = break_lease(olddentry->d_inode, O_WRONLY | O_NONBLOCK);
    if (error) {
      code = 17;
      goto put_mnt;
    }
  }
  if (newdentry->d_inode && S_ISREG(newdentry->d_inode->i_mode))
  {
    error = break_lease(newdentry->d_inode, O_WRONLY | O_NONBLOCK);
    if (error) {
      code = 19;
      goto put_mnt;
    }
  }
  error = VFS_RENAME(mnt, old_dentry->d_inode, olddentry,
                     new_dentry->d_inode, newdentry);
put_mnt:
  mntput(mnt);

put_newdentry:
  dput(newdentry);

put_olddentry:
  dput(olddentry);

put_new_dentry:
  if (new_dentry->d_inode == old_dentry->d_inode) {
    INODE_UNLOCK(new_dentry->d_inode);
  }
  else
    unlock_rename(new_dentry, old_dentry);

  dput(new_dentry);

put_old_dentry:
  dput(old_dentry);

put_newname:
  GPFS_PUTNAME(newname);

put_oldname:
  GPFS_PUTNAME(oldname);

exit:
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_RENAME_FH_EXIT,
         "rename_by_fh: exit error %d code %d", error, code);

  return error;
}

/* If this is a close for Ganesha that wants to keep the locks than close_owner is NULL.
   If Ganesha will not use this option we can take it out and just call close(fd)
   from Ganesha directly */
static int close_file(struct close_file_arg *arg)
{
  int retval = 0;
  fl_owner_t owner;
  struct file *fP;
  struct inode *iP;
  struct MMFSVInfo *vinfoP;
  int fput_needed;
  cxiNode_t *cnP;
  struct files_struct *files;
  struct gpfsVfsData_t *privVfsP = NULL;
#if LINUX_KERNEL_VERSION >= 2062600
  struct fdtable *fdp;
#endif

  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_CLOSE_FILE,
        "close_file: dirfd %d fd %d flags 0x%X lock_owner 0x%lX",
         arg->mountdirfd, arg->close_fd, arg->close_flags, arg->close_owner);

  files = current->files;
  spin_lock(&files->file_lock);
#if LINUX_KERNEL_VERSION >= 2062600
  fdp = files_fdtable(files);
#endif
  fP = FGET(arg->close_fd, fput_needed);
  if (!fP)
  {
    spin_unlock(&files->file_lock);
    retval = -EBADF;
    goto out;
  }

#if (LINUX_KERNEL_VERSION >= 3100000) && defined(CONFIG_IMA)
  TRACE7(TRACE_VNODE, 3, TRCID_GANESHA_CLOSE_21,
        "close_file: i_ino %lld writecount %d readcount %d i_count %d f_count %lld mode 0x%X fP 0x%lX",
         fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_writecount),
         atomic_read(&fP->f_dentry->d_inode->i_readcount),
         atomic_read(&fP->f_dentry->d_inode->i_count),
         atomic_long_read(&fP->f_count),
         fP->f_mode, fP);
#else
  TRACE6(TRACE_VNODE, 3, TRCID_GANESHA_CLOSE_23,
        "close_file: i_ino %lld writecount %d i_count %d f_count %lld mode 0x%X fP 0x%lX",
         fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_writecount),
         atomic_read(&fP->f_dentry->d_inode->i_count),
         atomic_long_read(&fP->f_count),
         fP->f_mode, fP);
#endif
  /* When close_owner is NULL we set owner to current->files, this owner will not match
     any Ganesha owner and will keep the locks. All Ganesha owners have an odd address+1*/
  if (arg->close_owner != NULL)
    owner = arg->close_owner+1;  // make sure it is not a valid address.
  else
    owner = current->files;

#if LINUX_KERNEL_VERSION >= 2062600
  rcu_assign_pointer(fdp->fd[arg->close_fd], NULL);
#endif
  spin_unlock(&files->file_lock);
  put_unused_fd(arg->close_fd);

  retval = filp_close(fP, owner);

#if (LINUX_KERNEL_VERSION >= 3100000) && defined(CONFIG_IMA)
  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_CLOSE_25,
        "close_file:  i_ino %lld read count %d mode 0x%X\n, f_count %lld",
         fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_readcount), fP->f_mode,
         atomic_long_read(&fP->f_count));
#else
  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_CLOSE_27,
        "close_file: i_ino %lld mode 0x%X f_count %lld",
         fP->f_dentry->d_inode->i_ino, fP->f_mode,
         atomic_long_read(&fP->f_count));
#endif
  FPUT(fP, fput_needed);

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_CLOSE_FILE_EXIT,
        "close_file: fd %d flags 0x%X retval %d",
         arg->close_fd, arg->close_flags, retval);
out:
  return retval;
}

/* If this is a reopen for Ganesha that wants to keep the locks. */
static int reopen_file(struct open_share_arg *arg)
{
  int retval = 0;
#if LINUX_KERNEL_VERSION >= 2063200
  int code = 0;
  int decit = 0;
  fl_owner_t owner;
  struct file *fP;
  struct inode *iP;
  struct MMFSVInfo *vinfoP;
  int fput_needed;
  cxiNode_t *cnP;
  struct files_struct *files;
  struct gpfsVfsData_t *privVfsP = NULL;
  fmode_t save_mode;
  int save_flags;

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_REOPEN_FILE,
        "reopen_file: dirfd %d fd %d flags 0x%X",
         arg->mountdirfd, arg->openfd, arg->flags);

  if (!(arg->flags & (O_RDWR|O_WRONLY|O_SYNC)) && arg->flags != O_RDONLY)
  {
    code = 2;
    retval = -EACCES;
    goto out;
  }

  files = current->files;
  spin_lock(&files->file_lock);
  fP = FGET(arg->openfd, fput_needed);
  if (!fP)
  {
    spin_unlock(&files->file_lock);
    code = 4;
    retval = -EBADF;
    goto out;
  }
  spin_unlock(&files->file_lock);

  if ((fP->f_mode & (FMODE_READ | FMODE_WRITE)) == FMODE_READ)
    decit = 1;

#if (LINUX_KERNEL_VERSION >= 3100000) && defined(CONFIG_IMA)
  TRACE8(TRACE_VNODE, 3, TRCID_REOPEN_31,
        "reopen_file: in decit %d i_ino %lld writecount %d readcount %d i_count %d mode 0x%X fP 0x%lX f_count %lld",
         decit, fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_writecount),
         atomic_read(&fP->f_dentry->d_inode->i_readcount),
         atomic_read(&fP->f_dentry->d_inode->i_count), fP->f_mode, fP,
         atomic_long_read(&fP->f_count));
#else
  TRACE7(TRACE_VNODE, 3, TRCID_REOPEN_36,
        "reopen_file: in decit %d i_ino %lld writecount %d i_count %d mode 0x%X fP 0x%lX f_count %lld",
         decit, fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_writecount),
         atomic_read(&fP->f_dentry->d_inode->i_count), fP->f_mode, fP,
         atomic_long_read(&fP->f_count));
#endif

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 6;
    retval = -EBADF;
    goto out_err;
  }
  cnP = VP_TO_CNP(iP);
  if (cnP == NULL)
  {
    code = 8;
    retval = -EBADF;
    goto out_err;
  }

  retval = may_handle_open(fP->f_dentry, arg->flags);
  if (retval)
  {
    code = 9;
    goto out_err;
  }
  /* Save old vinfo */
  vinfoP = (struct MMFSVInfo *)fP->private_data;
  fP->private_data = NULL;
  save_mode = fP->f_mode;
  save_flags = fP->f_flags;

  if (arg->flags & O_SYNC)
  {
    fP->f_mode |= FSYNC;
    arg->flags &= ~O_SYNC;
  }
  else
    fP->f_mode &= ~FSYNC;

  if (arg->flags & (O_RDWR|O_WRONLY))
  {
    fP->f_flags |= FREAD | FWRITE;
    /* if it was not in write mode increament i_writecount */
    if (!(fP->f_mode & FMODE_WRITE))
    {
      allow_write_access(fP);
#if LINUX_KERNEL_VERSION >= 3100000
      mnt_want_write(fP->f_path.mnt);
#endif
      fP->f_mode |= FMODE_WRITE;
    }
    if (arg->flags & O_RDWR)
      fP->f_mode |= FMODE_READ;
  }
  else
  {
    /* if it was in write mode deccreament i_writecount */
    if (fP->f_mode & FMODE_WRITE)
    {
      put_write_access(iP);
#if LINUX_KERNEL_VERSION >= 3100000
      mnt_drop_write_file(fP);
#if defined(HAS_FILE_RELEASE_WRITE)
      file_release_write(fP);
#endif
#endif
    }
    fP->f_flags |= FREAD;
    fP->f_flags &= ~FWRITE;
    fP->f_mode |= FMODE_READ;
    fP->f_mode &= ~FMODE_WRITE;
  }
  retval = gpfs_f_open(iP, fP);
  if (!retval && vinfoP) {
    retval = gpfs_ops.gpfsClose(privVfsP, cnP, 0, vinfoP, false, NULL);
    retval = cxiErrorNFS(retval, privVfsP, retval);
  }
  else
  {
    code = 10;
    fP->private_data = vinfoP;
    fP->f_mode = save_mode;
    fP->f_flags= save_flags;
  }
  TRACE5(TRACE_VNODE, 3, TRCID_REOPEN_33,
        "reopen_file: out  i_ino %lld writecount %d i_count %d mode 0x%X fP 0x%lX\n",
         fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_writecount),
         atomic_read(&fP->f_dentry->d_inode->i_count), fP->f_mode, fP);

out_err:
#if LINUX_KERNEL_VERSION >= 3100000
  if (((fP->f_mode & (FMODE_READ | FMODE_WRITE)) == FMODE_READ) && !decit)
  {
    decit = 1;
    i_readcount_inc(fP->f_dentry->d_inode);
  }
#if defined(CONFIG_IMA)
  TRACE5(TRACE_VNODE, 3, TRCID_GANESHA_REOPEN_FILE_5,
        "reopen_file: decit %d  i_ino %lld readcount %d mode 0x%X f_count %lld",
         decit, fP->f_dentry->d_inode->i_ino,
         atomic_read(&fP->f_dentry->d_inode->i_readcount), fP->f_mode,
         atomic_long_read(&fP->f_count));
#endif
#endif

  FPUT(fP, fput_needed);

out:

  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_REOPEN_FILE_EXIT,
        "reopen_file: fd %d flags 0x%X retval %d code %d",
         arg->openfd, arg->flags, retval, code);

#endif
  return retval;
}

static int fadvise_file(struct fadvise_arg *arg)
{
  int retval = 0;
  int code = 0;
  fl_owner_t owner;
  struct file *fP;
  struct inode *iP;
  int fput_needed;
  cxiNode_t *cnP;
  struct files_struct *files;
  struct gpfsVfsData_t *privVfsP = NULL;
  uint32_t hints = 0;

  if (copy_from_user(&hints, arg->hints, sizeof(hints)))
  {
    retval = -EFAULT;
    code = 2;
    goto out;
  }
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_FADVISE_FILE,
        "fadvise_file: dirfd %d fd %d", arg->mountdirfd, arg->openfd);

  files = current->files;
  spin_lock(&files->file_lock);
  fP = FGET(arg->openfd, fput_needed);
  if (!fP)
  {
    spin_unlock(&files->file_lock);
    code = 4;
    retval = -EBADF;
    goto out;
  }
  spin_unlock(&files->file_lock);

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 6;
    retval = -EBADF;
    goto out_err;
  }
  cnP = VP_TO_CNP(iP);
  if (cnP == NULL)
  {
    code = 8;
    retval = -EBADF;
    goto out_err;
  }

//???  retval = gpfs_f_hints();
  hints = 0; //??? for now hints are not supported

  if (copy_to_user(arg->hints, &hints, sizeof(hints)))
  {
    code = 12;
    retval = -EFAULT;
  }

out_err:
  FPUT(fP, fput_needed);

out:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_FADVISE_FILE_EXIT,
        "fadvise_file: fd %d retval %d code %d",
         arg->openfd, retval, code);

  return retval;
}

static int fseek_file(struct fseek_arg *arg)
{
  int retval = 0;
  int code = 0;
  fl_owner_t owner;
  struct file *fP;
  struct inode *iP;
  int fput_needed;
  cxiNode_t *cnP;
  struct files_struct *files;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct gpfs_io_info io_info;
  loff_t rc = -EINVAL;
  loff_t filesize = 0;

  if (copy_from_user(&io_info, arg->info, sizeof(struct gpfs_io_info)))
  {
    retval = -EFAULT;
    code = 2;
    goto out;
  }
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_FSEEK_FILE,
        "fseek_file: dirfd %d fd %d", arg->mountdirfd, arg->openfd);

  files = current->files;
  spin_lock(&files->file_lock);
  fP = FGET(arg->openfd, fput_needed);
  if (!fP)
  {
    spin_unlock(&files->file_lock);
    code = 4;
    retval = -EBADF;
    goto out;
  }
  spin_unlock(&files->file_lock);

  iP = fP->f_dentry->d_inode;
  DBGASSERT(iP != NULL);

  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    code = 6;
    retval = -EBADF;
    goto out_err;
  }
  cnP = VP_TO_CNP(iP);
  if (cnP == NULL)
  {
    code = 8;
    retval = -EBADF;
    goto out_err;
  }

  rc = gpfs_seek_internal(fP, io_info.io_what,  &(io_info.io_offset),
                          &io_info.io_len, &filesize);
  if (rc < 0)
  {
    code = 10;
    retval = rc;
    goto out_err;
  }
  if (io_info.io_offset == filesize)
    io_info.io_eof = TRUE;
  else
    io_info.io_eof = FALSE;

  if (io_info.io_what == SEEK_DATA)
    io_info.io_alloc = TRUE;
  else   /* SEEK_HOLE */
    io_info.io_alloc = FALSE;

  if (copy_to_user(arg->info, &io_info, sizeof(struct gpfs_io_info)))
  {
    code = 12;
    retval = -EFAULT;
  }

out_err:
  FPUT(fP, fput_needed);

out:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_FSEEK_FILE_EXIT,
        "fseek_file: fd %d retval %d code %d",
         arg->openfd, retval, code);

  return retval;
}

int get_attr_expire(struct dentry *dentryP, uint32_t *expire_interval)
{
  int retcode;
  int retval = 0;
  int retinter = 0;
  struct inode *iP = dentryP->d_inode;
  cxiNode_t *cnP;
  struct gpfsVfsData_t *privVfsP = NULL;

  if (iP == NULL)
    return retval;


  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
    return retval;

  cnP = VP_TO_CNP(iP);
  if (cnP == NULL)
    return retval;

#ifdef GPFS_CACHE
  /* Must revalidate periodically for pcache files */
  if (!TestCtFlag(cnP, revalidateNeeded))
    retval = 0;
  else
  {
    retcode = gpfs_ops.gpfsRevalidateInterval(privVfsP, cnP, &retinter);
    if (!retcode && retinter > 0)
    {
      if (expire_interval)
        *expire_interval = retinter; /* the interval in seconds */
      retval = XATTR_NO_CACHE;
    }
    retcode = cxiErrorNFS(retcode, privVfsP, retcode);
  }
#endif

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_CACHE_INODE,
        "get_attr_expire: retval %d retinter %d expire_interval %lX",
         retval, retinter, expire_interval);

  return retval;
}

static int cp_new_statfs(cxiStatfs_t *stats, struct statfs __user *statbuf)
{
  struct statfs tmp;

  tmp.f_type = 0;
  tmp.f_bsize = stats->f_bsize;
  tmp.f_blocks = stats->f_blocks;
  tmp.f_bfree = stats->f_bfree;
  tmp.f_bavail = stats->f_bavail;
  tmp.f_files = stats->f_files;
  tmp.f_ffree = stats->f_ffree;
  tmp.f_fsid.val[0] = 0;
  tmp.f_fsid.val[1] = 0;
  tmp.f_namelen = 0;
  tmp.f_frsize = stats->f_bsize;

  return copy_to_user(statbuf, &tmp, sizeof(tmp)) ? -EFAULT : 0;
}

static int cp_new_stat(struct kstat *stat, struct stat __user *statbuf)
{
  struct stat tmp;

  if (!new_valid_dev(stat->dev) || !new_valid_dev(stat->rdev))
    return -EOVERFLOW;

  tmp.st_dev = new_encode_dev(stat->dev);
  tmp.st_ino = stat->ino;
  if (sizeof(tmp.st_ino) < sizeof(stat->ino) && tmp.st_ino != stat->ino)
    return -EOVERFLOW;

  tmp.st_mode = stat->mode;
  tmp.st_nlink = stat->nlink;
  if (tmp.st_nlink != stat->nlink)
    return -EOVERFLOW;

  SET_UID(tmp.st_uid, FROM_KUID_MUNGED(stat->uid));
  SET_GID(tmp.st_gid, FROM_KGID_MUNGED(stat->gid));
  tmp.st_rdev = new_encode_dev(stat->rdev);
  tmp.st_size = stat->size;
  tmp.st_atime = stat->atime.tv_sec;
  tmp.st_mtime = stat->mtime.tv_sec;
  tmp.st_ctime = stat->ctime.tv_sec;
#ifdef STAT_HAVE_NSEC
  tmp.st_atime_nsec = stat->atime.tv_nsec;
  tmp.st_mtime_nsec = stat->mtime.tv_nsec;
  tmp.st_ctime_nsec = stat->ctime.tv_nsec;
#endif
  tmp.st_blocks = stat->blocks;
  tmp.st_blksize = stat->blksize;
  return copy_to_user(statbuf, &tmp,sizeof(tmp)) ? -EFAULT : 0;
}

static int stat_by_name(int mountdirfd, struct gpfs_file_handle __user *dir_fh,
                const char __user *newname, int len,
                struct stat __user *buf)
{
  void *name = NULL;
  int error = 0;
  int code = 0;
  struct dentry *new_dentry = NULL;
  struct dentry *dir_dentry = NULL;
  struct vfsmount *mnt = NULL;
  struct kstat stat;

  name = GPFS_GETNAME(newname);
  if ((name == NULL) || IS_ERR(name))
  {
    code = 2;
    error = -EFAULT;
    goto exit;
  }
  dir_dentry = dentry_by_handle(mountdirfd, dir_fh);
  if (IS_ERR(dir_dentry))
  {
    code = 4;
    error = PTR_ERR(dir_dentry);
    goto put_name;
  }
  INODE_LOCK(dir_dentry->d_inode);
  new_dentry = LOOKUP_ONE_LEN(name, dir_dentry, len);
  INODE_UNLOCK(dir_dentry->d_inode);
  if (IS_ERR(new_dentry))
  {
    code = 6;
    error = PTR_ERR(new_dentry);
    goto put_dir_dentry;
  }
  if (new_dentry->d_inode == NULL)
  {
    code = 8;
    error = -ENOENT;
    goto put_new_dentry;
  }
  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    code = 10;
    error = PTR_ERR(mnt);
    goto put_new_dentry;
  }
  VFS_GETATTR(error, mnt, new_dentry, &stat);
  if (error)
    goto put_mnt;

  error = cp_new_stat(&stat, buf);

put_mnt:
  mntput(mnt);

put_new_dentry:
  dput(new_dentry);

put_dir_dentry:
  dput(dir_dentry);

put_name:
  GPFS_PUTNAME(name);

exit:
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_STAT_BY_NAME_EXIT,
         "stat_by_name: exit error %d code %d", error, code);

  return error;
}

static int unlink_by_name(int mountdirfd, struct gpfs_file_handle __user *dir_fh,
                const char __user *newname, int len,
                struct stat __user *buf)
{
  void *name = NULL;
  int error = 0;
  int code = 0;
  struct dentry *new_dentry = NULL;
  struct dentry *dir_dentry = NULL;
  struct vfsmount *mnt = NULL;
  struct kstat stat;

  name = GPFS_GETNAME(newname);
  if ((name == NULL) || IS_ERR(name))
  {
    code = 2;
    error = -EFAULT;
    goto exit;
  }
  dir_dentry = dentry_by_handle(mountdirfd, dir_fh);
  if (IS_ERR(dir_dentry))
  {
    code = 4;
    error = PTR_ERR(dir_dentry);
    goto put_name;
  }
  INODE_LOCK_NESTED(dir_dentry->d_inode, I_MUTEX_PARENT);
  if (!S_ISDIR(dir_dentry->d_inode->i_mode))
  {
    code = 5;
    error = -ENOENT;
    goto put_dir_dentry;
  }
  new_dentry = LOOKUP_ONE_LEN(name, dir_dentry, len);
  if (IS_ERR(new_dentry))
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 6;
    error = PTR_ERR(new_dentry);
    goto put_dir_dentry;
  }
  if (new_dentry->d_inode == NULL)
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 8;
    error = -ENOENT;
    goto put_new_dentry;
  }
  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 10;
    error = PTR_ERR(mnt);
    goto put_new_dentry;
  }
  if (S_ISREG(new_dentry->d_inode->i_mode))
  {
    error = break_lease(new_dentry->d_inode, O_WRONLY | O_NONBLOCK);
    if (error) {
      INODE_UNLOCK(dir_dentry->d_inode);
      code = 17;
      goto put_mnt;
    }
  }
  if ((new_dentry->d_inode->i_mode & S_IFMT) != S_IFDIR)
    error = VFS_UNLINK(mnt, dir_dentry->d_inode, new_dentry);
  else
    error = VFS_RMDIR(mnt, dir_dentry->d_inode, new_dentry);

  INODE_UNLOCK(dir_dentry->d_inode);
  if (error)
    goto put_mnt;

  VFS_GETATTR(error, mnt, dir_dentry, &stat);
  if (error)
    goto put_mnt;

  error = cp_new_stat(&stat, buf);

put_mnt:
  mntput(mnt);

put_new_dentry:
  dput(new_dentry);

put_dir_dentry:
  dput(dir_dentry);

put_name:
  GPFS_PUTNAME(name);

exit:
  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_UNLINK_BY_NAME_EXIT,
         "unlink_by_name: exit error %d code %d", error, code);

  return error;
}

static int set_xattr(struct dentry *dentry, struct stat *buf, int attr_changed)
{
  struct stat tmp;
  int retval = 0;
  struct iattr iattr;
  struct iattr *iattrP = &iattr;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct gpfs_timestruc now;

  if (copy_from_user((void *)&tmp, buf, sizeof(struct stat)))
  {
    retval = -EFAULT;
    return retval;
  }
  iattrP->ia_valid = 0;
  if (attr_changed & XATTR_MODE)
  {
    iattrP->ia_valid |= ATTR_MODE;
    iattrP->ia_mode = tmp.st_mode;
  }
  if (attr_changed & XATTR_UID)
  {
    iattrP->ia_valid |= ATTR_UID;
    iattrP->ia_uid = MAKE_KUID(tmp.st_uid);
  }
  if (attr_changed & XATTR_GID)
  {
    iattrP->ia_valid |= ATTR_GID;
    iattrP->ia_gid = MAKE_KGID(tmp.st_gid);
  }
  if (attr_changed & XATTR_SIZE)
  {
    iattrP->ia_valid |= ATTR_SIZE;
    iattrP->ia_size = tmp.st_size;
  }
  if (attr_changed & XATTR_ATIME)
  {
    iattrP->ia_valid |= ATTR_ATIME;
    if (attr_changed & XATTR_ATIME_NOW)
    {
       gpfs_ops.gpfsGetTime(&now);
       iattrP->ia_atime.tv_sec = (uint32_t)now.tv_sec;
#ifdef STAT_HAVE_NSEC
       iattrP->ia_atime.tv_nsec = now.tv_sec;
#else
       iattrP->ia_atime.tv_nsec = 0;
#endif
    }
    else
    {
      iattrP->ia_atime.tv_sec = tmp.st_atime;
#ifdef STAT_HAVE_NSEC
      iattrP->ia_atime.tv_nsec = tmp.st_atime_nsec;
#else
      iattrP->ia_atime.tv_nsec = 0;
#endif
    }
  }
  if (attr_changed & XATTR_CTIME)
  {
    iattrP->ia_valid |= ATTR_CTIME;
    iattrP->ia_ctime.tv_sec = tmp.st_ctime;
#ifdef STAT_HAVE_NSEC
    iattrP->ia_ctime.tv_nsec = tmp.st_ctime_nsec;
#else
    iattrP->ia_ctime.tv_nsec = 0;
#endif
  }
  if (attr_changed & XATTR_MTIME)
  {
    iattrP->ia_valid |= ATTR_MTIME;
    if (attr_changed & XATTR_MTIME_NOW)
    {
       gpfs_ops.gpfsGetTime(&now);
       iattrP->ia_mtime.tv_sec = (uint32_t)now.tv_sec;
#ifdef STAT_HAVE_NSEC
       iattrP->ia_mtime.tv_nsec = now.tv_sec;
#else
       iattrP->ia_mtime.tv_nsec = 0;
#endif
    }
    else
    {
      iattrP->ia_mtime.tv_sec = tmp.st_mtime;
#ifdef STAT_HAVE_NSEC
      iattrP->ia_mtime.tv_nsec = tmp.st_mtime_nsec;
#else
      iattrP->ia_mtime.tv_nsec = 0;
#endif
    }
  }
  if (attr_changed & XATTR_ATIME_SET)
    iattrP->ia_valid |= ATTR_ATIME_SET;
  if (attr_changed & XATTR_MTIME_SET)
    iattrP->ia_valid |= ATTR_MTIME_SET;

#ifdef NFSv42
  if (attr_changed & XATTR_SPACE_RESERVED)
    retval = gpfs_i_fallocate(dentry->d_inode, 0, 0, tmp.st_size);
#endif

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_SET_ATTR,
         "set_xattr: retval %d attr_changed 0x%X iattrP->ia_valid 0x%X",
          retval, attr_changed, iattrP->ia_valid);

  if (S_ISREG(dentry->d_inode->i_mode))
    retval = break_lease(dentry->d_inode, O_WRONLY | O_NONBLOCK);

  if (retval == 0)
    retval = gpfs_i_setattr(dentry, iattrP);

  if (retval == -ESTALE) {
    privVfsP = VP_TO_PVP(dentry->d_inode);
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);
  }
  return retval;
}

static int create_by_name(int mountdirfd, struct gpfs_file_handle __user *dir_fh,
                int mode, u_int32_t dev, const char __user *newname, int len,
                struct gpfs_file_handle __user *new_fh, struct stat __user *buf,
                int attr_valid, int attr_changed, struct gpfs_acl __user *acl)
{
  void *name = NULL;
  int error = 0;
  int code = 0;
  struct dentry *new_dentry = NULL;
  struct dentry *dir_dentry = NULL;
  struct vfsmount *mnt = NULL;
  struct kstat stat;

  name = GPFS_GETNAME(newname);
  if ((name == NULL) || IS_ERR(name))
  {
    code = 2;
    error = -EFAULT;
    goto exit;
  }
  dir_dentry = dentry_by_handle(mountdirfd, dir_fh);
  if (IS_ERR(dir_dentry))
  {
    code = 4;
    error = PTR_ERR(dir_dentry);
    goto put_name;
  }
  INODE_LOCK_NESTED(dir_dentry->d_inode, I_MUTEX_PARENT);
  new_dentry = LOOKUP_ONE_LEN(name, dir_dentry, len);
  if (IS_ERR(new_dentry))
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 6;
    error = PTR_ERR(new_dentry);
    goto put_dir_dentry;
  }
  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    INODE_UNLOCK(dir_dentry->d_inode);
    code = 10;
    error = PTR_ERR(mnt);
    goto put_new_dentry;
  }
  if (S_ISREG(mode))
#ifdef NEW_VFS_CREATE
    error = vfs_create(dir_dentry->d_inode, new_dentry, mode, 0);
#else
    error = vfs_create(dir_dentry->d_inode, new_dentry, mode, NULL);
#endif
  else if (S_ISDIR(mode))
    error = VFS_MKDIR(mnt, dir_dentry->d_inode, new_dentry, mode);
  else if (S_ISCHR(mode) | S_ISBLK(mode) | S_ISFIFO(mode) | S_ISSOCK(mode))
    error = VFS_MKNOD(mnt, dir_dentry->d_inode, new_dentry, mode, dev);
  else
    error = -EINVAL;

  INODE_UNLOCK(dir_dentry->d_inode);
  if (error)
  {
    code = 12;
    goto put_mnt;
  }
  error = dentry_to_handle(new_dentry, new_fh);
  if (error)
  {
    code = 13;
    goto put_mnt;
  }
  if (buf != NULL && (attr_valid & XATTR_STAT))
  {
    error = set_xattr(new_dentry, buf, attr_changed);
    if (error)
    {
      code = 14;
      goto put_mnt;
    }
  }
  if (acl != NULL && (attr_valid & XATTR_ACL))
  {
    error = vfs_getacl(new_dentry, acl);
    if (error)
    {
      code = 15;
      goto put_mnt;
    }
  }
  if (buf != NULL)
  {
    VFS_GETATTR(error, mnt, new_dentry, &stat);
    if (error)
    {
      code = 16;
      goto put_mnt;
    }
    error = cp_new_stat(&stat, buf);
  }
  if (acl != NULL)
    error = vfs_getacl(new_dentry, acl);

put_mnt:
  mntput(mnt);

put_new_dentry:
  dput(new_dentry);

put_dir_dentry:
  dput(dir_dentry);

put_name:
  GPFS_PUTNAME(name);

exit:
  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_CREATE_BY_NAME_EXIT,
         "create_by_name: exit error %d code %d mode x%X dev x%X",
          error, code, mode, dev);

  return error;
}

static int get_handle(int mountdirfd, struct gpfs_file_handle __user *dir_fh,
                     struct gpfs_file_handle __user *out_fh,
                     const char __user *newname, int len)
{
  void *name = NULL;
  int error = 0;
  int code = 0;
  struct dentry *new_dentry = NULL;
  struct dentry *dir_dentry = NULL;

  name = GPFS_GETNAME(newname);
  if ((name == NULL) || IS_ERR(name))
  {
    code = 2;
    error = -EFAULT;
    goto exit;
  }
  dir_dentry = dentry_by_handle(mountdirfd, dir_fh);
  if (IS_ERR(dir_dentry))
  {
    code = 4;
    error = PTR_ERR(dir_dentry);
    goto put_name;
  }
  INODE_LOCK(dir_dentry->d_inode);
  new_dentry = LOOKUP_ONE_LEN(name, dir_dentry, len);
  INODE_UNLOCK(dir_dentry->d_inode);
  if (IS_ERR(new_dentry))
  {
    code = 6;
    error = PTR_ERR(new_dentry);
    goto put_dir_dentry;
  }
  if (new_dentry->d_inode == NULL)
  {
    code = 8;
    error = -ENOENT;
    goto put_new_dentry;
  }
  error = dentry_to_handle(new_dentry, out_fh);

put_new_dentry:
  dput(new_dentry);

put_dir_dentry:
  dput(dir_dentry);

put_name:
  GPFS_PUTNAME(name);

exit:
  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_GET_FH_EXIT,
         "get_handle: exit error %d code %d len %d", error, code, len);

  return error;
}

/*
 * if the directory's sticky bit set
 * then reset the fsid.
 */
static Boolean
is_sticky_bit_set(struct kstat *stat, struct fsal_fsid *fsid)
{
  if (stat->mode & (S_IXUSR|S_IXGRP|S_IXOTH))
    return false;

  if (!(stat->mode & S_ISVTX))
    return false;

  /* Must return a different fsid, should be set in the FSAL */
  fsid->major = 1;
  fsid->minor = 2;

  TRACE1(TRACE_VNODE, 3, TRCID_GANESHA_IS_STICKY,
        "is_sticky_bit_set: yes on %ld", stat->ino);

  return true;
}

long get_fs_locations(struct fs_loc_arg *args, struct fs_loc_arg __user *uargs)
{
  int retval;
  int code = 0;
  int len;
  ssize_t attrSize;
  struct gpfs_file_handle fh;
  struct vfsmount *mnt = NULL;
  struct dentry *dentry;

  retval = get_kernel_handle(args->handle, &fh);
  if (retval)
  {
    code = 2;
    goto exit;
  }
  dentry = handle_to_dentry(args->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    code = 4;
    retval = PTR_ERR(dentry);
    goto exit;
  }
  args->fs_path_len = gpfs_i_getxattr(dentry, "user.ref-path", args->fs_path,
                                      args->fs_path_len);
  if (args->fs_path_len < 1)
  {
    code = 6;
    retval = -EINVAL;
    goto out_mnt;
  }
  args->fs_root_len = gpfs_i_getxattr(dentry, "user.ref-root", args->fs_root,
                                      args->fs_root_len);
  if (args->fs_root_len < 1)
  {
    code = 8;
    retval = -EINVAL;
    goto out_mnt;
  }
  args->fs_server_len = gpfs_i_getxattr(dentry, "user.ref-server", args->fs_server,
                                        args->fs_server_len);
  if (args->fs_server_len < 1)
  {
    code = 10;
    retval = -EINVAL;
    goto out_mnt;
  }

  if (copy_to_user(uargs, args, sizeof(struct fs_loc_arg)))
    retval = -EFAULT;

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_GET_FSLOC,
         "get_fs_locations: path %d root %d server %d",
          args->fs_path_len, args->fs_root_len, args->fs_server_len);

out_mnt:
  dput(dentry);
  mntput(mnt);

exit:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_GET_FSLOC_EXIT,
         "get_fs_locations: exit mountdirfd %d retval %d code %d",
          args->mountdirfd, retval, code);

  return retval;

}

long get_acl_by_handle(struct xstat_arg *args, int __user *attr_valid)
{
  struct kstat stat;
  int retval = 0;
  int error = 0;
  int cache_flag = 0;
  struct dentry *dentry;
  struct vfsmount *mnt = NULL;
  struct gpfs_file_handle fh;
  struct fsal_fsid fsid;
  struct gpfsVfsData_t *privVfsP = NULL;
  uint32_t expire_interval = 0; /* Use Ganesha setting */
  cxiNode_t *cnP;

  retval = get_kernel_handle(args->handle, &fh);
  if (retval)
    return retval;

  dentry = handle_to_dentry(args->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_handle;
  }
  if (args->acl != NULL && (args->attr_valid & XATTR_ACL))
    error = vfs_getacl(dentry, args->acl);
  if (args->buf != NULL && (args->attr_valid & XATTR_STAT))
  {
    VFS_GETATTR(retval, mnt, dentry, &stat);
    if (retval)
      goto out_mnt;
    retval = cp_new_stat(&stat, args->buf);
    if (retval)
      goto out_mnt;

    if (args->attr_valid & XATTR_EXPIRE)
    {
      cache_flag = get_attr_expire(dentry, &expire_interval);
      if (copy_to_user(attr_valid, &cache_flag, sizeof(int)))
      {
        error = -EFAULT;
        goto out_mnt;
      }
      if (copy_to_user(args->expire_attr, &expire_interval, sizeof(uint64_t)))
      {
        error = -EFAULT;
        goto out_mnt;
      }
    }
    else /* old interface, will not have expire_attr */
    {
      cache_flag = get_attr_expire(dentry, NULL);
      if (copy_to_user(attr_valid, &cache_flag, sizeof(int)))
      {
        error = -EFAULT;
        goto out_mnt;
      }
    }
  }
  if (args->fsid != NULL && (args->attr_valid & XATTR_FSID))
  {
    if (!(is_sticky_bit_set(&stat, &fsid)))
    {
      cnP = VP_TO_CNP(dentry->d_inode);
      privVfsP = VP_TO_PVP(dentry->d_inode);
      gpfs_ops.gpfsGetFSID(privVfsP, (int *)&fsid.major, cnP, (int *)&fsid.minor);
    }
    if (copy_to_user(args->fsid, &fsid, sizeof(fsid)))
    {
      error = -EFAULT;
      goto out_mnt;
    }
  }

out_mnt:
  dput(dentry);
  mntput(mnt);
  if (!retval)
    retval = error;
out_handle:
  return retval;
}

long set_acl_by_handle(struct xstat_arg *args)
{
  int retval = 0;
  int code = 0;
  struct dentry *dentry;
  struct vfsmount *mnt = NULL;
  struct gpfs_file_handle fh;

  retval = get_kernel_handle(args->handle, &fh);
  if (retval)
    return retval;

  dentry = handle_to_dentry(args->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    code = 2;
    goto out_handle;
  }
  if (args->acl != NULL && (args->attr_valid & XATTR_ACL))
  {
    retval = vfs_setacl(dentry, args->acl);
    if (retval)
    {
      code = 4;
      goto out_mnt;
    }
  }
  if (args->buf != NULL && (args->attr_valid & XATTR_STAT))
  {
    retval = set_xattr(dentry, args->buf, args->attr_changed);
    if (retval)
    {
      code = 10;
      goto out_mnt;
    }
  }

out_mnt:
  dput(dentry);
  mntput(mnt);

out_handle:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_SET_ACL_EXIT,
         "set_acl_by_handle: exit mountdirfd %d retval %d code %d",
          args->mountdirfd, retval, code);

  return retval;
}

long set_grace_period(int mountdirfd, int grace_sec)
{
  struct gpfsVfsData_t *privVfsP = NULL;
  struct vfsmount *mnt;
  int retval = 0;

  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    retval = PTR_ERR(mnt);
    goto out_err;
  }
  privVfsP = (struct gpfsVfsData_t *)mnt->mnt_sb->s_fs_info;

  retval = gpfs_ops.gpfsGaneshaGrace(privVfsP, grace_sec);
  mntput(mnt);

  if (retval == -ESTALE)
    retval = -EUNATCH;

out_err:
  return retval;
}

long access_by_handle(int mountdirfd, struct gpfs_file_handle __user *uhandle,
                      struct xstat_cred_t __user *cred, int posix_mode,
                      int access, int *supp)
{
  int i, retval = 0;
  struct dentry *dentry;
  struct vfsmount *mnt = NULL;
  struct gpfs_file_handle fh;
  struct xstat_cred_t uCred;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  cxiNode_t *cnP;
  struct inode *iP;
  int supported;

  retval = get_kernel_handle(uhandle, &fh);
  if (retval)
    return retval;

  dentry = handle_to_dentry(mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_handle;
  }
  iP = dentry->d_inode;
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);

  if (access)        /* call permission check only if got access mode */
  {
    if (copy_from_user((void *)&uCred, cred, sizeof(uCred)))
    {
      retval = -EFAULT;
      goto out_mnt;
    }
    retval = getCred(&eCred, &eCredP);
    if (retval)
    {
      retval = -ENOMEM;
      goto out_mnt;
    }
    eCredP->principal = uCred.principal;
    eCredP->group = uCred.group;
    eCredP->capabilities = 0;
    eCredP->num_groups = uCred.num_groups;
    if (eCredP->num_groups > ECRED_NGROUPS)
    {
      putCred(&eCred, &eCredP);
      retval = -EINVAL;
      goto out_mnt;
    }
    for(i = 0; i < ECRED_NGROUPS; i++)
      eCredP->eGroups[i] = uCred.eGroups[i];

    retval = gpfs_ops.gpfsAccess(privVfsP, cnP, posix_mode, ACC_SELF,
                                 &access, NULL, eCredP);
    putCred(&eCred, &eCredP);

    if (retval)
      retval = cxiErrorNFS(retval, privVfsP, -EACCES);

  }
  supported = 0;
  if (copy_to_user(supp, &supported, sizeof(int)))
  {
    retval = -EFAULT;
    goto out_mnt;
  }

out_mnt:
  dput(dentry);
  mntput(mnt);

out_handle:
  return retval;
}

int set_share_reserve(struct share_reserve_arg *sarg)
{
  int retval = 0;

  TRACE4(TRACE_VNODE, 3, TRCID_LINUXOPS_SHARE_RESERVE_IN,
        "set_share_reserve: dirfd %d fd %d access 0x%X deny 0x%X",
         sarg->mountdirfd, sarg->openfd, sarg->share_access, sarg->share_deny);

  retval = kxGetShare(sarg->openfd, sarg->share_access, sarg->share_deny);

  TRACE3(TRACE_VNODE, 3, TRCID_LINUXOPS_SHARE_RESERVE_EXIT,
         "set_share_reserve exit: retval %d -retval %d fd %d",
          retval, -(retval), sarg->openfd);

  if (retval == ESTALE || retval == -ESTALE)
  {
    struct gpfsVfsData_t *privVfsP = NULL;
    struct file *fP = NULL;

    fP = fget(sarg->openfd);
    if (fP && fP->f_dentry && fP->f_dentry->d_inode)
      privVfsP = VP_TO_PVP(fP->f_dentry->d_inode);

    retval = cxiErrorNFS(retval, privVfsP, -ENOENT);
    if (fP)
      fput(fP);
  }

  return retval;
}

static int handle_layout_commit(struct layoutcommit_arg *targ)
{
  int retval = 0;
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct inode *iP = NULL;

  retval = get_kernel_handle(targ->handle, &fh);
  if (retval)
    goto out_err;

  dentry = handle_to_dentry(targ->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_err;
  }
  iP = dentry->d_inode;
  DBGASSERT(iP != NULL);

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  retval = getCred(&eCred, &eCredP);
  if (retval)
    goto out_mnt;

  retval = gpfs_ops.gpfsFsync(privVfsP, NULL, cnP, FFILESYNC, eCredP);
  putCred(&eCred, &eCredP);

  retval = cxiErrorNFS(retval, privVfsP, retval);

out_mnt:
  dput(dentry);
  mntput(mnt);

out_err:

  TRACE1(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_LAYOUT_COMMIT_EXIT,
         "handle_layout_commit: exit retval %d",
          retval);

  return retval;
}

static int handle_fsync(struct fsync_arg *farg)
{
  int retval = 0;
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct inode *iP = NULL;
  int flags = FFILESYNC;
  uint32_t verifier[2];
  uint32_t *verifierP = (uint32_t *)&verifier;

  retval = get_kernel_handle(farg->handle, &fh);
  if (retval)
    goto out_err;

  dentry = handle_to_dentry(farg->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_err;
  }
  iP = dentry->d_inode;
  DBGASSERT(iP != NULL);

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  retval = getCred(&eCred, &eCredP);
  if (retval)
    goto out_mnt;

  retval = gpfs_ops.gpfsFsyncRange(privVfsP, cnP, flags, farg->offset,
                                   farg->length, eCredP);
  putCred(&eCred, &eCredP);
  if (retval) {
    retval = cxiErrorNFS(retval, privVfsP, retval);
    goto out_mnt;
  }
  gpfs_ops.gpfsGetVerifier(privVfsP, verifierP);
  if (copy_to_user(farg->verifier4, verifierP, sizeof(verifier)))
    retval = -EFAULT;

out_mnt:
  dput(dentry);
  mntput(mnt);

out_err:

  TRACE1(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_FSYNC_EXIT,
         "handle_fsync: exit retval %d", retval);

  return retval;
}


static int handle_statfs(struct statfs_arg *sfarg)
{
  int retval = 0;
  cxiNode_t *cnP;
  cxiStatfs_t statfs;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct inode *iP = NULL;

  retval = get_kernel_handle(sfarg->handle, &fh);
  if (retval)
    goto out_err;

  dentry = handle_to_dentry(sfarg->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_err;
  }
  iP = dentry->d_inode;
  DBGASSERT(iP != NULL);

  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);

  retval = gpfs_ops.gpfsStatfs(privVfsP, &statfs, cnP, NULL);
  if (retval) {
    retval = cxiErrorNFS(retval, privVfsP, retval);
    goto out_mnt;
  }
  retval = cp_new_statfs(&statfs, sfarg->buf);

out_mnt:
  dput(dentry);
  mntput(mnt);

out_err:

  TRACE1(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_STATFS_EXIT,
         "handle_statfs: exit retval %d", retval);

  return retval;
}


static int handle_layout_type(int mountdirfd, struct gpfs_file_handle *handle)
{
  int retval = 0;
  struct vfsmount *mnt;

  mnt = get_vfsmount_from_fd(mountdirfd);
  if (IS_ERR(mnt))
  {
    retval = PTR_ERR(mnt);
    goto out_err;
  }
#ifdef P_NFS4
  retval = gpfs_layout_type(mnt->mnt_sb);
#else
  retval = 0;
#endif
  mntput(mnt);
  if (retval == ESTALE || retval == -ESTALE)
    retval = -EUNATCH;

out_err:

  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_LAYOUT_TYPE_EXIT,
         "handle_layout_type: exit mountdirfd %d retval %d",
          mountdirfd, retval);

  return retval;
}

static int handle_get_layout(struct layoutget_arg *yarg)
{
  int retval = 0;
  struct gpfs_file_handle __user *uhandle = yarg->handle;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct inode *iP = NULL;
  struct nfsd4_pnfs_layoutget_res res;
  struct pnfs_filelayout_layout file_layout;
  unsigned int *fhP;
  uint32_t mdsAddr = 0;

  retval = get_kernel_handle(uhandle, &fh);
  if (retval)
    goto out_err;

  dentry = handle_to_dentry(yarg->fd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_err;
  }
  iP = dentry->d_inode;
#ifdef P_NFS4
  fhP = (int *)&(fh.f_handle);

  retval = gpfs_layout_get(iP, (void *)yarg->xdr, &yarg->args,
                               (struct nfsd4_pnfs_layoutget_res *)&file_layout);
  if (retval == 0)
  {
    mdsAddr = file_layout.device_id.device_id4;
    fhP[6] = mdsAddr;
    file_layout.device_id.device_id4 = yarg->fd;

    TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_GET_LAYOUT_RET,
         "handle_get_layout: mdsAddr 0x%x seq %d fd %d fsid 0x%lx",
          mdsAddr, file_layout.device_id.device_id2,
          file_layout.device_id.device_id4,
          file_layout.device_id.devid);

    /* copy the full handle back */
    if (copy_to_user(uhandle, &fh, FH_HDR_SIZE + fh.handle_size))
    {
      retval = -EFAULT;
      goto out_mnt;
    }
    if (copy_to_user(yarg->file_layout, &file_layout, sizeof(file_layout)))
    {
      retval = -EFAULT;
      goto out_mnt;
    }
  }
  else if (retval == ESTALE || retval == -ESTALE)
    retval = -EUNATCH;

#else
  retval = -ENOSYS;
#endif

out_mnt:
  dput(dentry);
  mntput(mnt);

out_err:

  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_GET_LAYOUT_EXIT,
         "handle_get_layout: exit fd %d retval %d",
          yarg->fd, retval);

  return retval;
}

static int handle_return_layout(struct layoutreturn_arg *zarg)
{
  int retval = 0;
  struct gpfs_file_handle __user *uhandle = zarg->handle;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct nfsd4_pnfs_layoutreturn_arg lr;
  struct inode *iP = NULL;

  retval = get_kernel_handle(uhandle, &fh);
  if (retval)
    goto out_err;

  dentry = handle_to_dentry(zarg->mountdirfd, &fh, &mnt, true);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    goto out_err;
  }
  iP = dentry->d_inode;
#ifdef P_NFS4
  retval = gpfs_layout_return(iP, &zarg->args);
#else
  retval = -ENOSYS;
#endif
  if (retval == ESTALE || retval == -ESTALE)
    retval = -EUNATCH;

out_mnt:
  dput(dentry);
  mntput(mnt);

out_err:

  TRACE2(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_RETURN_LAYOUT_EXIT,
         "handle_return_layout: exit mountdirfd %d retval %d",
          zarg->mountdirfd, retval);

  return retval;
}

static int handle_read(struct read_arg *rarg)
{
  int code = 0, retval = 0;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct file *filp;
  int fput_needed;
  uint64_t offset = rarg->offset;
  cxiIovec_t tmp_iovec;
  struct cxiUio_t uio;
  int options = 0;

  if (rarg->fd < 3)
  {
    code = 3;
    retval = -EBADF;
    goto out;
  }
  filp = FGET(rarg->fd, fput_needed);
  if (!filp)
  {
    code = 5;
    retval = -EBADF;
    goto out;
  }
  if (!(filp->f_mode & FMODE_READ))
  {
    code = 7;
    retval = -EBADF;

    FPUT(filp, fput_needed);
    goto out;
  }

  tmp_iovec.iov_base = rarg->bufP;    /* base memory address                  */
  tmp_iovec.iov_len = rarg->length;   /* length of transfer for this area     */
  if (rarg->options & IO_SKIP_HOLE)
    options = CXI_RDWROPTS_SKIP_HOLES;

  retval = rdwrInternal(filp, CXI_READ, &tmp_iovec, 1, &offset, &uio, options);

  if (retval == -E_HOLE && rarg->options & IO_SKIP_HOLE)
    retval = -ENODATA;
  else if (retval == -ESTALE) {
    privVfsP = VP_TO_PVP(filp->f_dentry->d_inode);
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);
  }

  FPUT(filp, fput_needed);

out:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_READ_EXIT,
         "handle_read: exit fd %d retval %d code %d", rarg->fd, retval, code);

  return retval;
}

static Boolean forceOSyncWrites = false;

static int handle_write(struct write_arg *warg)
{
  int code =0, retval = 0;
  struct file *filp;
  int fput_needed;
  uint64_t offset = warg->offset;
  int sync = 0;
  struct gpfsVfsData_t *privVfsP = NULL;

  if (warg->fd < 3)
  {
    code = 3;
    retval = -EBADF;
    goto out;
  }
  filp = FGET(warg->fd, fput_needed);
  if (!filp)
  {
    code = 5;
    retval = -EBADF;
    goto out;
  }
  if (!(filp->f_mode & FMODE_WRITE))
  {
    code = 7;
    retval = -EBADF;

    FPUT(filp, fput_needed);
    goto out;
  }
  if (warg->stability_wanted || forceOSyncWrites)
  {
    filp->f_flags |= O_DSYNC;
    sync = true;
  }
  retval = vfs_write(filp, warg->bufP, warg->length, &offset);

  FPUT(filp, fput_needed);

  if (retval > 0 && sync)
  {
    if (copy_to_user(warg->stability_got, &sync, sizeof(int)))
    {
      retval = -EFAULT;
      code = 9;
    }
  }
  else if (retval == -ESTALE) {
    privVfsP = VP_TO_PVP(filp->f_dentry->d_inode);
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);
  }
out:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_WRITE_EXIT,
         "handle_write: exit fd %d retval %d code %d", warg->fd, retval, code);

  return retval;
}

static int handle_allocate(struct alloc_arg *aarg)
{
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct MMFSVInfo *vinfoP = NULL;
  int mode = 0, code = 0, retval = 0;
  struct file *filp;
  int fput_needed;
  cxiNode_t *cnP;
  struct inode *iP = NULL;
  int flags = FWRITE;

  if (aarg->fd < 3)
  {
    code = 3;
    retval = -EBADF;
    goto out;
  }
  filp = FGET(aarg->fd, fput_needed);
  if (!filp)
  {
    code = 5;
    retval = -EBADF;
    goto out;
  }
  if (!(filp->f_mode & FMODE_WRITE))
  {
    code = 7;
    retval = -EBADF;
    goto out_put;
  }
  iP = filp->f_dentry->d_inode;
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL || cnP == NULL)
  {
    retval = -EIO;
    code = 9;
    goto out_put;
  }
  vinfoP = (struct MMFSVInfo *)filp->private_data;
  if (vinfoP == NULL)
  {
    code = 11;
    goto out_put;
  }
  retval = getCred(&eCred, &eCredP);
  if (retval)
  {
    code = 13;
    goto out_put;
  }
  if (aarg->options & IO_ALLOCATE)
    mode = 0;
  /* SFSClear can not deallocate space but still use it for deallocate */
  else if ((aarg->offset <= iP->i_size) && (aarg->options & IO_DEALLOCATE))
    mode = FALLOC_FL_PUNCH_HOLE;
  else {
    code = 14;
    retval = -EOPNOTSUPP;
    goto out_cred;
  }
  retval = gpfs_f_fallocate(filp, mode, aarg->offset, aarg->length);
  if (retval == -ESTALE)
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);

out_cred:
  putCred(&eCred, &eCredP);

out_put:
  FPUT(filp, fput_needed);

out:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_CLEAR_EXIT,
         "handle_clear: exit fd %d retval %d code %d", aarg->fd, retval, code);

  return retval;
}

#define PNFS_IO

static int handle_dsread(struct dsread_arg *rarg)
{
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct MMFSVInfo *vinfoP = NULL;
  int retval = 0;
  int code = 0;
  int open_flag;
  struct gpfs_file_handle __user *uhandle = rarg->handle;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct inode *iP = NULL;
  struct file *filp = NULL;
  uint64_t offset = rarg->offset;
  int mdsAddr = 0;
  unsigned int *fhP;
  cxiIovec_t tmp_iovec;
  struct cxiUio_t uio;

#ifdef P_NFS4
  retval = get_kernel_handle(uhandle, &fh);
  if (retval)
  {
    code = 2;
    goto out;
  }
  fhP = (int *)&(fh.f_handle);
  mdsAddr = fhP[6];

  dentry = handle_to_dentry(rarg->mountdirfd, &fh, &mnt, false);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    code = 4;
    goto out;
  }
  retval = getCred(&eCred, &eCredP);
  if (retval)
  {
    code = 6;
    goto out_dentry;
  }
#if 0 //??? direct IO conflicts with exclusive-share token
  open_flag = O_RDONLY | O_DIRECT;
#else
  open_flag = O_RDONLY;
#endif

#ifdef PNFS_IO
  iP = dentry->d_inode;
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    retval = -EIO;
    code = 8;
    goto out_cred;
  }
  retval = gpfs_ops.gpfsGetOpenState(privVfsP, &vinfoP, cnP, mdsAddr, NULL,
                                     0, eCredP);
  if (retval || vinfoP == NULL)
  {
    retval = -EIO;
    code = 10;
    goto out_cred;
  }
  tmp_iovec.iov_base = rarg->bufP;    /* base memory address                  */
  tmp_iovec.iov_len = rarg->length;   /* length of transfer for this area     */

  retval = pnfs_rdwr(dentry, vinfoP, open_flag, eCredP, CXI_READ,
                     &tmp_iovec, 1, &offset, &uio, rarg->options);

  /* if vinfoP was set than we need to release open NFS */
  if (vinfoP != NULL)
    gpfs_ops.gpfsReleaseNFS(iP);

  if (retval == -ENODATA)
  {
    /* Ganesha needs the file size and offset is not used here */
    if (copy_to_user(rarg->filesize, &offset, sizeof(offset)))
    {
      retval = -EFAULT;
      code = 11;
    }
  }
  goto out_cred;
#else
  DENTRY_OPEN(filp, dentry, mnt, open_flag);
  if (IS_ERR(filp))
  {
    retval = PTR_ERR(filp);
    code = 12;
    goto out_cred;
  }
  iP = dentry->d_inode;
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    retval = -EIO;
    code = 14;
    goto out_fput;
  }
  vinfoP = (struct MMFSVInfo *)filp->private_data;

  retval = gpfs_ops.gpfsGetOpenState(privVfsP, &vinfoP, cnP, mdsAddr, NULL,
                                     0, eCredP);
  if (retval)
  {
    retval = -EIO;
    code = 16;
    goto out_fput;
  }
  retval = gpfs_f_read(filp, rarg->bufP, rarg->length, &offset);

out_fput:
  putCred(&eCred, &eCredP);
  fput(filp);
#endif
#else  // not P_NFS
  retval = -EIO;
  code = 24;
#endif
  if (retval == -ESTALE)
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);

out:

  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_DS_READ_EXIT,
         "handle_dsread: exit mountdirfd %d retval %d code %d mdsAddr 0x%X",
          rarg->mountdirfd, retval, code, mdsAddr);

  return retval;

out_cred:
  putCred(&eCred, &eCredP);

out_dentry:
  dput(dentry);
  mntput(mnt);
  goto out;
}

static int handle_dswrite(struct dswrite_arg *warg)
{
  cxiNode_t *cnP;
  ext_cred_t eCred;
  ext_cred_t *eCredP = &eCred;
  int fd, retval = 0;
  int open_flag;
  struct gpfs_file_handle __user *uhandle = warg->handle;
  struct vfsmount *mnt;
  struct dentry *dentry;
  struct gpfs_file_handle fh;
  struct inode *iP = NULL;
  struct file *filp;
  struct gpfsVfsData_t *privVfsP = NULL;
  struct MMFSVInfo *vinfoP = NULL;
  uint64_t offset = warg->offset;
  int mdsAddr = 0;
  int code = 0;
  uint32_t stability = x_UNSTABLE4;
  uint32_t verifier[2] = {0,0};
  uint32_t *verifierP = (uint32_t *)&verifier;
  unsigned int *fhP;
  cxiIovec_t tmp_iovec;
  struct cxiUio_t uio;

#ifdef P_NFS4
  retval = get_kernel_handle(uhandle, &fh);
  if (retval)
  {
    code = 2;
    goto out;
  }
  fhP = (int *)&(fh.f_handle);
  mdsAddr = fhP[6];

  dentry = handle_to_dentry(warg->mountdirfd, &fh, &mnt, false);
  if (IS_ERR(dentry))
  {
    retval = PTR_ERR(dentry);
    code = 4;
    goto out;
  }
#if 0 //??? direct IO conflicts with exclusive-share token
  open_flag = O_RDWR | O_DIRECT;
#else
  open_flag = O_RDWR;
#endif
  if (warg->stability_wanted)
  {
    open_flag |= O_DSYNC;
    stability = x_DATA_SYNC4;
  }
#ifdef PNFS_IO
  retval = getCred(&eCred, &eCredP);
  if (retval)
  {
    code = 8;
    goto out_dentry;
  }
  iP = dentry->d_inode;
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  if (privVfsP == NULL)
  {
    retval = -EIO;
    code = 8;
    goto out_cred;
  }
  retval = gpfs_ops.gpfsGetOpenState(privVfsP, &vinfoP, cnP, mdsAddr, NULL,
                                     0, eCredP);
  if (retval || vinfoP == NULL)
  {
    retval = -EIO;
    code = 10;
    goto out_cred;
  }
  tmp_iovec.iov_base = warg->bufP;    /* base memory address                  */
  tmp_iovec.iov_len = warg->length;   /* length of transfer for this area     */

  retval = pnfs_rdwr(dentry, vinfoP, open_flag, eCredP, CXI_WRITE,
                     &tmp_iovec, 1, &offset, &uio, warg->options);

  /* if vinfoP was set than we need to release open NFS */
  if (vinfoP != NULL)
    gpfs_ops.gpfsReleaseNFS(iP);

  if (retval > 0)
  {
   if (copy_to_user(warg->stability_got, &stability, sizeof(int)))
   {
     retval = -EFAULT;
     code = 12;
     goto out_cred;
   }
   gpfs_ops.gpfsGetVerifier(privVfsP, verifierP);
   if (copy_to_user(warg->verifier4, verifierP, sizeof(verifier)))
   {
     retval = -EFAULT;
     code = 14;
     goto out_cred;
   }
  }
  goto out_cred;

#else
  DENTRY_OPEN(filp, dentry, mnt, open_flag);
  if (IS_ERR(filp))
  {
    retval = PTR_ERR(filp);
    code = 6;
    goto out_dentry;
  }
  iP = dentry->d_inode;
  cnP = VP_TO_CNP(iP);
  privVfsP = VP_TO_PVP(iP);
  DBGASSERT(privVfsP != NULL);
  vinfoP = (struct MMFSVInfo *)filp->private_data;

  retval = getCred(&eCred, &eCredP);
  if (retval)
  {
    code = 8;
    goto out_fput;
  }
  retval = gpfs_ops.gpfsGetOpenState(privVfsP, &vinfoP, cnP, mdsAddr, NULL, 0, eCredP);
  putCred(&eCred, &eCredP);
  if (retval)
  {
    code = 10;
    goto out_fput;
  }

  retval = gpfs_f_write(filp, warg->bufP, warg->length, &offset);
  if (retval > 0)
  {
   if (copy_to_user(warg->stability_got, &stability, sizeof(int)))
   {
     retval = -EFAULT;
     code = 12;
     goto out_fput;
   }
   privVfsP = VP_TO_PVP(dentry->d_inode);
   gpfs_ops.gpfsGetVerifier(privVfsP, verifierP);
   if (copy_to_user(warg->verifier4, verifierP, sizeof(verifier)))
   {
     retval = -EFAULT;
     code = 14;
     goto out_fput;
   }
  }

out_fput:
  fput(filp);
#endif
#else  // not P_NFS
  retval = -EIO;
  code = 24;
#endif
  if (retval == -ESTALE)
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);

out:

  TRACE7(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_DS_WRITE_EXIT,
      "handle_dswrite: exit mountdirfd %d retval %d code %d stability %d mdsAddr 0x%X verifier %d-%d",
       warg->mountdirfd, retval, code, stability, mdsAddr, verifier[0], verifier[1]);

  return retval;

out_cred:
  putCred(&eCred, &eCredP);
out_dentry:
  dput(dentry);
  mntput(mnt);
  goto out;
}

static int handle_get_verifier(void *arg)
{
  uint32_t verifier[2];
  uint32_t *verifierP = (uint32_t *)&verifier;

  gpfs_ops.gpfsGetVerifier(NULL, verifierP);
  if (copy_to_user(arg, verifierP, sizeof(verifier)))
    return -EFAULT;

  return 0;
}

static int handle_get_nodeid(struct grace_period_arg *arg)
{
  struct gpfsVfsData_t *privVfsP = NULL;
  int retval = 0;
  int code = 0;
  struct vfsmount *mnt;

  mnt = get_vfsmount_from_fd(arg->mountdirfd);
  if (IS_ERR(mnt))
  {
    code = 4;
    retval = PTR_ERR(mnt);
    goto out;
  }
  privVfsP = (struct gpfsVfsData_t *)mnt->mnt_sb->s_fs_info;
  if (privVfsP == NULL)
  {
    mntput(mnt);
    code = 8;
    goto out;
  }
  retval = gpfs_ops.gpfsGetNodeID(privVfsP, &forceOSyncWrites);
  if (retval == -ESTALE)
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);

  mntput(mnt);

out:

  TRACE3(TRACE_VNODE, 3, TRCID_GANESHA_GTE_NODEID_EXIT,
         "handle_get_nodeid: exit mountdirfd %d retval %d code %d",
          arg->mountdirfd, retval, code);

  return retval;
}

static int handle_get_deviceinfo(struct deviceinfo_arg *darg)
{
  int retval = 0;
  struct vfsmount *mnt;
  struct gpfsVfsData_t *privVfsP = NULL;

  mnt = get_vfsmount_from_fd(darg->mountdirfd);
  if (IS_ERR(mnt))
  {
    retval = PTR_ERR(mnt);
    goto out_err;
  }
#ifdef P_NFS4
  privVfsP = (struct gpfsVfsData_t *)mnt->mnt_sb->s_fs_info;
  retval = gpfs_get_deviceinfo(mnt->mnt_sb, &darg->xdr, darg->type,
                               &darg->devid);
#else
  retval = -ENOSYS;
#endif
  mntput(mnt);

out_err:

  if (retval == -ESTALE)
    retval = cxiErrorNFS(-ESTALE, privVfsP, -EIO);

  TRACE4(TRACE_VNODE, 3, TRCID_GANESHA_HANDLE_GET_DEVICEINFO_EXIT,
      "handle_get_deviceinfo: exit mountdirfd %d retval 0x%llx p 0x%llx end %p",
       darg->mountdirfd, retval, darg->xdr.p, darg->xdr.end);

  return retval;
}

int kxGanesha(int op, void *arg)
{
  int rc = 0;
  int code = 0;
  int retval = 0;
  all_args args;

  VFS_STAT_START(op);
  ENTER(0);

  /* Only allow the root users */
  if (!cxiIsSuperUser())
  {
    code = 2;
    retval = -EPERM;
    goto out;
  }
  if (op == OPENHANDLE_TRACE_ME)
  {
    char  trace_str[MAX_STR+1];
    char  *p;
    if (copy_from_user(&args.trarg, (void *)arg, sizeof(struct trace_arg)))
      {
        retval = -EFAULT;
        code = 1;
        return retval;
      }
loop:
      p = args.trarg.str;
      rc = args.trarg.len;
      if (rc >= MAX_STR)
        rc = MAX_STR;

      if (copy_from_user(trace_str, (void *)p, rc))
      {
        retval = -EFAULT;
        code = 2;
        return retval;
      }
      if (rc > 1)
      {
        if (trace_str[rc-1] == '\n')
          trace_str[rc-1] = '\0';
        else
          trace_str[rc] = '\0';
        TRACE1(TRACE_GANESHA, 1, TRCID_LINUX_GANESHA, "%s", &trace_str);
        if (rc == MAX_STR)
        {
          args.trarg.str += MAX_STR;
          args.trarg.len -= MAX_STR;
          if (args.trarg.len > 1)
            goto loop;
        }
      }
      return 0;
  }
  TRACE8(TRACE_VNODE, 1, TRCID_LINUX_GANESHA_ENTER,
       "kxGanesha: enter op %d g_tgid %d t_tgid %d t_pid %d uid %d euid %d suid %d fsuid %d",
        op, ganesha_tgid, cxiGetProcessId(), current->pid, FROM_KUID(CRED(current,uid)),
        FROM_KUID(CRED(current, euid)), FROM_KUID(CRED(current, suid)), FROM_KUID(CRED(current, fsuid)));

  if (ganesha_tgid != cxiGetProcessId())
  {
    if (ganesha_tgid == 0 || (ganesha_tgid_old != cxiGetProcessId()))
    {
      if (op == OPENHANDLE_GET_VERSION || op == OPENHANDLE_INODE_UPDATE)
        ganesha_tgid = cxiGetProcessId();
    }
    else
    {
      if (ganesha_tgid_old != cxiGetProcessId())
      {
        code = 99;
        retval = -EUNATCH;
        goto out;
      }
    }
  }

  switch (op)
  {
    case OPENHANDLE_GET_HANDLE:
      if (copy_from_user(&args.gharg, (void *)arg, sizeof(struct get_handle_arg)))
      {
        retval = -EFAULT;
        code = 4;
        goto out;
      }
      retval = get_handle(args.gharg.mountdirfd, args.gharg.dir_fh,
                          args.gharg.out_fh, args.gharg.name, args.gharg.len);
      break;

    case OPENHANDLE_NAME_TO_HANDLE:
      if (copy_from_user(&args.harg, (void *)arg, sizeof(struct name_handle_arg)))
      {
        retval = -EFAULT;
        code = 6;
        goto out;
      }
      retval = name_to_handle_at(args.harg.dfd, args.harg.name,
                                 args.harg.handle, args.harg.flag);
      break;

    case OPENHANDLE_SET_LOCK:
      if (copy_from_user(&args.larg, (void *)arg, sizeof(struct set_get_lock_arg)))
      {
        retval = -EFAULT;
        code = 8;
        goto out;
      }
      retval = set_lock(args.larg.mountdirfd, args.larg.lock, false);
      break;

    case OPENHANDLE_GET_LOCK:
      if (copy_from_user(&args.larg, (void *)arg, sizeof(struct set_get_lock_arg)))
      {
        retval = -EFAULT;
        code = 10;
        goto out;
      }
      retval = get_lock(args.larg.mountdirfd, args.larg.lock);
      break;

    case OPENHANDLE_OPEN_BY_HANDLE:
      if (copy_from_user(&args.oarg, (void *)arg, sizeof(struct open_arg)))
      {
        retval = -EFAULT;
        code = 12;
        goto out;
      }
      retval = open_by_handle(args.oarg.mountdirfd, args.oarg.handle,
                              args.oarg.flags, 0, 0);
      break;

    case OPENHANDLE_OPEN_SHARE_BY_HANDLE:
      if (copy_from_user(&args.osarg, (void *)arg, sizeof(struct open_share_arg)))
      {
        retval = -EFAULT;
        code = 14;
        goto out;
      }
      retval = open_by_handle(args.osarg.mountdirfd, args.osarg.handle,
                              args.osarg.flags, args.osarg.share_access,
                              args.osarg.share_deny);
      break;

    case OPENHANDLE_SHARE_RESERVE:
      if (copy_from_user(&args.sarg, (void *)arg, sizeof(struct share_reserve_arg)))
      {
        retval = -EFAULT;
        code = 16;
        goto out;
      }
      retval = set_share_reserve(&args.sarg);
      break;

    case OPENHANDLE_SET_DELEGATION:
      if (copy_from_user(&args.larg, (void *)arg, sizeof(struct set_get_lock_arg)))
      {
        retval = -EFAULT;
        code = 18;
        goto out;
      }
      retval = set_lock(args.larg.mountdirfd, args.larg.lock, true);
      break;

    case OPENHANDLE_LINK_BY_FH:
      if (copy_from_user(&args.lnarg, (void *)arg, sizeof(struct link_fh_arg)))
      {
        retval = -EFAULT;
        code = 22;
        goto out;
      }
      retval = link_by_fh(args.lnarg.mountdirfd, args.lnarg.dir_fh,
                          args.lnarg.dst_fh, args.lnarg.name, args.lnarg.len);
      break;

    case OPENHANDLE_STAT_BY_NAME:
      if (copy_from_user(&args.snarg, (void *)arg, sizeof(struct stat_name_arg)))
      {
        retval = -EFAULT;
        code = 24;
        goto out;
      }
      retval = stat_by_name(args.snarg.mountdirfd, args.snarg.handle,
                            args.snarg.name, args.snarg.len, args.snarg.buf);
      break;

    case OPENHANDLE_UNLINK_BY_NAME:
      if (copy_from_user(&args.snarg, (void *)arg, sizeof(struct stat_name_arg)))
      {
        retval = -EFAULT;
        code = 26;
        goto out;
      }
      retval = unlink_by_name(args.snarg.mountdirfd, args.snarg.handle,
                            args.snarg.name, args.snarg.len, args.snarg.buf);
      break;

    case OPENHANDLE_CREATE_BY_NAME:
      if (copy_from_user(&args.crarg, (void *)arg, sizeof(struct create_name_arg)))
      {
        retval = -EFAULT;
        code = 28;
        goto out;
      }
      retval = create_by_name(args.crarg.mountdirfd, args.crarg.dir_fh,
                              args.crarg.mode, args.crarg.dev,
                              args.crarg.name, args.crarg.len,
                              args.crarg.new_fh, args.crarg.buf,
                              0, 0, NULL);
      break;

    case OPENHANDLE_CREATE_BY_NAME_ATTR:
      if (copy_from_user(&args.crarg, (void *)arg, sizeof(struct create_name_arg)))
      {
        retval = -EFAULT;
        code = 29;
        goto out;
      }
      retval = create_by_name(args.crarg.mountdirfd, args.crarg.dir_fh,
                              args.crarg.mode, args.crarg.dev,
                              args.crarg.name, args.crarg.len,
                              args.crarg.new_fh, args.crarg.buf,
                              args.crarg.attr_valid, args.crarg.attr_changed,
                              args.crarg.acl);
      break;

    case OPENHANDLE_RENAME_BY_FH:
      if (copy_from_user(&args.rnarg, (void *)arg, sizeof(struct rename_fh_arg)))
      {
        retval = -EFAULT;
        code = 30;
        goto out;
      }
      retval = rename_by_fh(args.rnarg.mountdirfd, args.rnarg.old_fh,
                            args.rnarg.old_name, args.rnarg.old_len,
                            args.rnarg.new_fh, args.rnarg.new_name,
                            args.rnarg.new_len);
      break;

    case OPENHANDLE_READLINK_BY_FH:
      if (copy_from_user(&args.rlfharg, (void *)arg,
                                                sizeof(struct readlink_fh_arg)))
      {
        retval = -EFAULT;
        code = 34;
        goto out;
      }
      retval = readlink_by_fh(args.rlfharg.mountdirfd, args.rlfharg.handle,
                              args.rlfharg.buffer, args.rlfharg.size);
      break;

    case OPENHANDLE_GET_VERSION:

        retval = (GPFS_INTERFACE_VERSION + GPFS_INTERFACE_SUB_VER);
        code = 99;

      break;

    case OPENHANDLE_INODE_UPDATE:
      if (copy_from_user(&args.barg, (void *)arg, sizeof(struct callback_arg)))
      {
        retval = -EFAULT;
        code = 38;
        goto out;
      }
      if (args.barg.interface_version != GPFS_INTERFACE_VERSION +
                                         GPFS_INTERFACE_SUB_VER)
      {
        retval = -(GPFS_INTERFACE_VERSION + GPFS_INTERFACE_SUB_VER);
        code = 39;
        goto out;
      }
      retval = get_inode_update(args.barg.mountdirfd, args.barg.handle,
                 (void *)args.barg.buf, args.barg.fl, args.barg.reason,
                 args.barg.flags, (struct nfsd4_pnfs_deviceid *)args.barg.dev_id,
                 args.barg.expire_attr);
      break;

    case OPENHANDLE_THREAD_UPDATE:
      if (copy_from_user(&args.barg, (void *)arg, sizeof(struct callback_arg)))
      {
        retval = -EFAULT;
        code = 40;
        goto out;
      }
      retval = thread_update(args.barg.mountdirfd, args.barg.reason);
      break;

    case OPENHANDLE_LAYOUT_TYPE:
      if (copy_from_user(&args.oarg, (void *)arg, sizeof(struct open_arg)))
      {
        retval = -EFAULT;
        code = 42;
        goto out;
      }
      retval = handle_layout_type(args.oarg.mountdirfd, args.oarg.handle);
      break;

    case OPENHANDLE_GET_DEVICEINFO:
      if (copy_from_user(&args.darg, (void *)arg, sizeof(struct deviceinfo_arg)))
      {
        retval = -EFAULT;
        code = 44;
        goto out;
      }
      retval = handle_get_deviceinfo(&args.darg);
      break;

    case OPENHANDLE_READ_BY_FD:
      if (copy_from_user(&args.frarg, (void *)arg, sizeof(struct read_arg)))
      {
        retval = -EFAULT;
        code = 46;
        goto out;
      }
      retval = handle_read(&args.frarg);
      break;

    case OPENHANDLE_WRITE_BY_FD:
      if (copy_from_user(&args.fwarg, (void *)arg, sizeof(struct write_arg)))
      {
        retval = -EFAULT;
        code = 47;
        goto out;
      }
      retval = handle_write(&args.fwarg);
      break;

    case OPENHANDLE_ALLOCATE_BY_FD:
      if (copy_from_user(&args.aarg, (void *)arg, sizeof(struct alloc_arg)))
      {
        retval = -EFAULT;
        code = 48;
        goto out;
      }
      retval = handle_allocate(&args.aarg);
      break;

    case OPENHANDLE_DS_READ:
      if (copy_from_user(&args.rarg, (void *)arg, sizeof(struct dsread_arg)))
      {
        retval = -EFAULT;
        code = 49;
        goto out;
      }
      retval = handle_dsread(&args.rarg);
      break;

    case OPENHANDLE_DS_WRITE:
      if (copy_from_user(&args.warg, (void *)arg, sizeof(struct dswrite_arg)))
      {
        retval = -EFAULT;
        code = 50;
        goto out;
      }
      retval = handle_dswrite(&args.warg);
      break;

    case OPENHANDLE_GET_VERIFIER:
      retval = handle_get_verifier(arg);
      break;

    case OPENHANDLE_GET_NODEID:
      if (copy_from_user(&args.gparg, (void *)arg, sizeof(struct grace_period_arg)))
      {
        retval = -EFAULT;
        code = 52;
        goto out;
      }
      retval = handle_get_nodeid(&args.gparg);
      break;

    case OPENHANDLE_LAYOUT_RETURN:
      if (copy_from_user(&args.zarg, (void *)arg, sizeof(struct layoutreturn_arg)))
      {
        retval = -EFAULT;
        code = 52;
        goto out;
      }
      retval = handle_return_layout(&args.zarg);
      break;

    case OPENHANDLE_LAYOUT_GET:
      if (copy_from_user(&args.yarg, (void *)arg, sizeof(struct layoutget_arg)))
      {
        retval = -EFAULT;
        code = 53;
        goto out;
      }
      retval = handle_get_layout(&args.yarg);
      break;

    case OPENHANDLE_LAYOUT_COMMIT:
      if (copy_from_user(&args.targ, (void *)arg, sizeof(struct layoutcommit_arg)))
      {
        retval = -EFAULT;
        code = 54;
        goto out;
      }
      retval = handle_layout_commit(&args.targ);
      break;

    case OPENHANDLE_FSYNC:
      if (copy_from_user(&args.farg, (void *)arg, sizeof(struct fsync_arg)))
      {
        retval = -EFAULT;
        code = 56;
        goto out;
      }
      retval = handle_fsync(&args.farg);
      break;

    case OPENHANDLE_STATFS_BY_FH:
      if (copy_from_user(&args.sfarg, (void *)arg, sizeof(struct statfs_arg)))
      {
        retval = -EFAULT;
        code = 56;
        goto out;
      }
      retval = handle_statfs(&args.sfarg);
      break;

    case OPENHANDLE_GET_XSTAT:
      if (copy_from_user(&args.carg, (void *)arg, sizeof(struct xstat_arg)))
      {
        retval = -EFAULT;
        code = 58;
        goto out;
      }
      retval = get_acl_by_handle(&args.carg,
                                 &(((struct xstat_arg *)arg)->attr_valid));
      break;

    case OPENHANDLE_FS_LOCATIONS:
      if (copy_from_user(&args.flarg, (void *)arg, sizeof(struct fs_loc_arg)))
      {
        retval = -EFAULT;
        code = 59;
        goto out;
      }
      retval = get_fs_locations(&args.flarg, arg);
      break;

    case OPENHANDLE_SET_XSTAT:
      if (copy_from_user(&args.carg, (void *)arg, sizeof(struct xstat_arg)))
      {
        retval = -EFAULT;
        code = 60;
        goto out;
      }
      retval = set_acl_by_handle(&args.carg);
      break;

    case OPENHANDLE_CLOSE_FILE:
      if (copy_from_user(&args.cfarg, (void *)arg, sizeof(struct close_file_arg)))
      {
        retval = -EFAULT;
        code = 62;
        goto out;
      }
      retval = close_file((struct close_file_arg *)&args.cfarg);
      break;

    case OPENHANDLE_REOPEN_BY_FD:
      if (copy_from_user(&args.osarg, (void *)arg, sizeof(struct open_share_arg)))
      {
        retval = -EFAULT;
        code = 64;
        goto out;
      }
      retval = reopen_file((struct open_share_arg *)&args.osarg);
      break;

    case OPENHANDLE_FADVISE_BY_FD:
      if (copy_from_user(&args.faarg, (void *)arg, sizeof(struct fadvise_arg)))
      {
        retval = -EFAULT;
        code = 66;
        goto out;
      }
      retval = fadvise_file((struct fadvise_arg *)&args.faarg);
      break;

    case OPENHANDLE_SEEK_BY_FD:
      if (copy_from_user(&args.fsarg, (void *)arg, sizeof(struct fseek_arg)))
      {
        retval = -EFAULT;
        code = 66;
        goto out;
      }
      retval = fseek_file((struct fseek_arg *)&args.fsarg);
      break;

    case OPENHANDLE_CHECK_ACCESS:
      if (copy_from_user(&args.xarg, (void *)arg, sizeof(struct xstat_access_arg)))
      {
        retval = -EFAULT;
        code = 68;
        goto out;
      }
      retval = access_by_handle(args.xarg.mountdirfd, args.xarg.handle,
                                args.xarg.cred, args.xarg.posix_mode,
                                args.xarg.access, args.xarg.supported);
      break;

    case OPENHANDLE_GRACE_PERIOD:
      if (copy_from_user(&args.gparg, (void *)arg, sizeof(struct grace_period_arg)))
      {
        retval = -EFAULT;
        code = 70;
        goto out;
      }
      retval = set_grace_period(args.gparg.mountdirfd, args.gparg.grace_sec);
      break;

    case OPENHANDLE_QUOTA:
      if (copy_from_user(&args.qarg, (void *)arg, sizeof(struct quotactl_arg)))
      {
        retval = -EFAULT;
        code = 72;
        goto out;
      }
      retval = kxQuotactl(args.qarg.pathname, args.qarg.cmd, args.qarg.qid,
                          args.qarg.bufferP);
      break;

    default:
      code = 99;
      retval = -EOPNOTSUPP;
      break;
  }

out:

  TRACE4(TRACE_VNODE, 1, TRCID_LINUX_GANESHA_EXIT,
        "kxGanesha: exit op %d retval %d rc %d code %d", op, retval, rc, code);

  VFS_STAT_STOP;
  EXIT(0);
  return retval;
}
#endif // GANESHA

#ifdef LIGHT_WEIGHT_EVENT
int kxlweCreateSession(lwe_sessid_t oldsid, 
                       char *sessinfop, 
		       lwe_sessid_t *newsidp)
{
  int rc = 0;

  rc = gpfs_ops.gpfslweCreateSession(oldsid, sessinfop, newsidp);
out:
  return rc;
}

int kxlweDestroySession(lwe_sessid_t sid)
{
  int rc = 0;
  rc = gpfs_ops.gpfslweDestroySession(sid);
out:
  return rc;

}

int kxlweGetAllSession(u_int nelem, 
                       lwe_sessid_t *sidbufp, 
		       u_int *nelemp)
{
  int rc = 0;
  rc = gpfs_ops.gpfslweGetAllSessions(nelem, sidbufp, nelemp);
out:
  return rc;

}

int kxlweQuerySession(lwe_sessid_t sid, 
                      size_t buflen, 
		      void* bufp, 
		      size_t *rlenp)
{
  int rc = 0;
  rc = gpfs_ops.gpfslweQuerySession(sid, buflen, bufp, rlenp);
out:
  return rc;

}

int kxlweGetEvents(lwe_sessid_t sid, 
                   unsigned int maxmsgs, 
                   unsigned int flags, 
		   size_t buflen, 
		   void* bufp, 
		   size_t *rlenp)
{
  int rc = 0;
  rc = gpfs_ops.gpfslweGetEvents(sid, maxmsgs, flags, buflen, bufp, rlenp);
out:
  return rc;

}

int kxlweRespondEvent(lwe_sessid_t sid, 
                      lwe_token_t token,
                      lwe_resp_t response, 
		      int reterror)
{
  int rc = 0;
  rc = gpfs_ops.gpfslweRespondEvent(sid, token, response, reterror);
out:
  return rc;

}

#endif /* LIGHT_WEIGHT_EVENT */

void kxAioComplete(struct cxiUioAio_t *uioaioP, size_t bytesProcessed,
                   int mbAioErr)
{
  /* A value of IS_AIO_SYNC_LIST for bytesProcessed means this is a list that
     was attached to a buffer descriptor. */
  #define IS_AIO_SYNC_LIST ((size_t)-1)
  bool fromBufferList = false;
  if (bytesProcessed == IS_AIO_SYNC_LIST)
  {
    fromBufferList = true;
    bytesProcessed = 0;
  }

  while (uioaioP)
  {
    struct cxiUioAio_t *nextP = uioaioP->bdNextP;
    TRACE3(TRACE_VNODE, 2, TRCID_LINUX_AIO_COMPLETE,
          "kxAioComplete: fromBufferList %d uioaioP 0x%lX next 0x%lX",
          fromBufferList, uioaioP, nextP);
    if (fromBufferList)
      DBGASSERT(uioaioP->bdAttached);
    else
      nextP = NULL;
    uioaioP->bdNextP = NULL;
    uioaioP->bdAttached = false;
    aioComplete(uioaioP, bytesProcessed, mbAioErr, true);
    uioaioP = nextP;
  }
}

#ifdef TS_RPC_PERF
int kxGetTscKhz()
{
  int tscSpeed;

#if defined(GPFS_ARCH_X86_64) && LINUX_KERNEL_VERSION >= 2062200
  if (tsc_khz > 10000 && tsc_khz < 100000000)
    tscSpeed = tsc_khz;
  else
    tscSpeed = 0;
#elif (defined(GPFS_ARCH_PPC64) || defined(GPFS_ARCH_PPC64_LE)) && LINUX_KERNEL_VERSION >= 2062200
  tscSpeed = (int)(tb_ticks_per_sec / 1000);   // convert to Kilohertz
#elif defined(GPFS_ARCH_POWER) || defined(GPFS_ARCH_S390X) || LINUX_KERNEL_VERSION < 2062200
  tscSpeed = 0;
#else
  #error "Can't determine tsc clock rate for this linux architecture"
#endif
  return(tscSpeed);
}
#endif

