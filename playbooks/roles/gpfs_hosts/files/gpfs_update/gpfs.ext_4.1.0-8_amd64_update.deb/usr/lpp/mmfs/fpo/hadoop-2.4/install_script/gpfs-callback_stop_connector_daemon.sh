#!/bin/bash
# IBM_PROLOG_BEGIN_TAG 
# This is an automatically generated prolog. 
#  
#  
#  
# Licensed Materials - Property of IBM 
#  
# (C) COPYRIGHT International Business Machines Corp. 2014,2015 
# All Rights Reserved 
#  
# US Government Users Restricted Rights - Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
#  
# IBM_PROLOG_END_TAG 
#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2012, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# callback definition ----------------------------------------
id="stop-connector-daemon"
event="shutdown"
nodes=ALL
parms="%myNode"

# print definition -------------------------------------------
if [ "$1" = "-d" ]; then
  echo "def:$id:$event:$nodes:$parms"
  exit
fi

/usr/lpp/mmfs/bin/mmhadoopctl connector stop
exit $?
