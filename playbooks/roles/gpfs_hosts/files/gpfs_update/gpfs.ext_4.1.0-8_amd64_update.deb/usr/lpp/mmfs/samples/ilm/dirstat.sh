#!/bin/bash
#  Description: 
#  -------------
#  dirstat.sh tool uses GPFS policy engine to traverse the file system to produce lists of all files and directories and a 
#  sorted list of directories with number of entries per each directory.  The results output file sorted on the entries 
#  count to show the directories with most entries on the top.
#  
#  The script can be started from any GPFS node that has the filesystem used for shared storage mounted. mmapplypolicy 
#  command used by this tool will use all nodes specified via configuration parameter defaultHelperNodes. If defaultHelperNodes 
#  is not speacified only the local node will be used
#  
#  Usage:
#  -------
#   Usage: $progname  [ -g sharedWorkDirectory ] [ -s workDirectory ] [ -N nodeList ] -d resultDirectory  <GPFS directory path to scan>
#  
#   where 
#          -g GlobalWorkDirectory
#               Specifies a global directory to be used for temporary storage during mmapplypolicy command processing.
#               The specified directory must exist within a shared file system. It must also be mounted and available 
#               for writing and reading from each of the nodes paticipating inthe policy scan.
#
#          -s LocalWorkDirectory
#               Specifies the directory to be used for temporary storage during mmapplypolicy command processing.
#               The default directory is /tmp.
#
#          -d resultDirectory
#               Specifies the directory to be used for result files. Two files will be created at the end. One is 
#               results.out, which contains the sorted count of files per directory. Another is fulllist.list.allfiles,
#               which contains a full file list under <GPFS directory path to scan>.
#
#          -N {all | mount |Node[,Node...] |NodeFile|NodeClass}
#               Specifies the list of nodes that will run parallel instances of policy code in the GPFS home cluster.
#               This command supports all defined node classes. The default is to run on the node where the
#               mmapplypolicycommand is running or the current value of the defaultHelperNodes parameter of
#               the mmchconfigcommand.
#
#          <GPFS directory path to scan>  
#               Specifies the GPFS directory to be scanned.
#  
#  Example: 
#     ./dirstat.sh -g /gpfs3/g_policy -s /tmp/l_policy -d /tmp/r_policy /gpfs3/mixed/group8
#
#  ------
#  Final lines of output would be 
#    ...
#    [I] A total of 0 files have been migrated, deleted or processed by an EXTERNAL EXEC/script;
#            0 'skipped' files and/or errors.
#    
#    2014-10-23@21:55:34 The following files have been generated for your review.
#    /tmp/r_policy/fulllist.list.allfiles - contains full file list
#    /tmp/r_policy/results.out - contains entries per directory
#  
#  Notes:
#  -----
#  1. The -g, -s and -N option will be passed to mmapplypolicy. So see man page of mmapplypolicy for more details.
#  2. If for some reason you need to stop the script please follow the steps described in the man page of mmapplypolicy command.
#  3. There needs to have enough space in sharedWorkDirectory, workDirectory and resultDirectory. For 40M files, ~8.xGB file space 
#     is required for workDirectory.

progname=$0

# ARGS will be passed to mmapplypolicy
ARGS=""
resultDirectory=""

while getopts d:s:g:N: OPT
do
  case $OPT in

    g) sharedWorkDirectory="$OPTARG"

       if [[ ! -d  $sharedWorkDirectory ]]
       then
           echo "$sharedWorkDirectory doesn't exit, terminate"
           exit 1
       fi
       ARGS="$ARGS -g $sharedWorkDirectory"
       ;;

    s) workDirectory="$OPTARG"

       if [[ ! -d  $workDirectory ]]
       then
           echo "$workDirectory doesn't exit, create it"
           mkdir -p $workDirectory
           mkdir -p $workDirectory  || exit 1
       fi
       ARGS="$ARGS -s $workDirectory"
       ;;
 
    d) resultDirectory="$OPTARG"

       if [[ ! -d  $resultDirectory ]]
       then
           echo "$resultDirectory doesn't exit, create it"
           mkdir -p $resultDirectory || exit 1
       fi
       ;;

    N) ARGS="$ARGS -N $OPTARG"
       ;;
 
    :) # Missing argument.
       echo "missing argument"
       ;;
    *) # Invalid option.
       echo "Invalid option"
       ;;
  esac
done

shift $(($OPTIND - 1))

if [[ "${resultDirectory}" == "" ]] ; then
   echo "Missing directory for output files" 
   echo "Usage: $progname  [ -g sharedWorkDirectory ] [ -s workDirectory ] [ -N nodeList ] -d resultDirectory  <GPFS directory path to scan>"
   exit 1
fi

FILESYSTEM_NAME=$1
if [[ "${FILESYSTEM_NAME}" == "" ]] ; then
   echo "Missing GPFS directory path to scan" 
   echo "Usage: $progname  [ -g sharedWorkDirectory ] [ -s workDirectory ] [ -N nodeList ] -d resultDirectory  <GPFS directory path to scan>"
   exit 1
fi

echo "About to scan file system tree under $FILESYSTEM_NAME. It will remove files in $resultDirectory, Hit any key to continue..."
read ans

#Ensure no temp files exist from prev run 
rm -f $resultDirectory/fulllist.list.allfiles  $resultDirectory/results.out


#CREATE  policy file first
POLICY_FILE=/tmp/filelist.pol

#prefix of the generated file list
FILE_LIST=$resultDirectory/fulllist

echo "/* Define three external lists */" >$POLICY_FILE
echo "RULE EXTERNAL LIST 'allfiles' EXEC ''" >>$POLICY_FILE
echo "" >>$POLICY_FILE
echo "/* Simply generate a list of all files, directories, plus all other" >>$POLICY_FILE
echo "   file system objects, like symlinks, named pipes, etc. Include the directory hash to help sort the objects. */" >>$POLICY_FILE
echo "RULE 'r1' LIST 'allfiles' " >>$POLICY_FILE
echo "                SHOW(DIRECTORY_HASH)" >>$POLICY_FILE
echo "                WEIGHT(DIRECTORY_HASH)" >>$POLICY_FILE

#RUN the policy against the file system supplied
#  -I defer is used to eliminuate the Policy execution time.
#  -f is used because we want only the file list generated by mmapplypolicy. The list 
#     is sorted because we have used WEIGHT(DIRECTORY_HASH) in the policy.
#  You can add more options to mmapplypolicy. See man page of mmapplypolicy
echo "Executing /usr/lpp/mmfs/bin/mmapplypolicy  $FILESYSTEM_NAME  $ARGS -P $POLICY_FILE -I defer -f $FILE_LIST"
/usr/lpp/mmfs/bin/mmapplypolicy  $FILESYSTEM_NAME  $ARGS -P $POLICY_FILE -I defer -f $FILE_LIST

if [[ $? != 0 ]] ; then
   exit 1
fi

# use awk to count the # of files under each directory
awk ' 
BEGIN {
  prev_hash=""
  prev_name=""
  cnt=0
}

{ if( $4 == prev_hash)
  {
        cnt++
  }
  else
  {
        if(cnt != 0) {
                sub(/\/[^\/]*$/, "", prev_name)
                print cnt, prev_name
        }
        cnt=1
        prev_hash=$4
        prev_name=$6
  }
}

END {
  sub(/\/[^\/]*$/, "", prev_name)
   print cnt, prev_name
} '  $FILE_LIST.* | sort -k1,1 -nr > $resultDirectory/results.out

echo -e "\n`date +%Y-%m-%d@%H:%M:%S` The following files have been generated for your review."
echo -e "$FILE_LIST.list.allfiles - contains full file list"
echo -e "$resultDirectory/results.out - contains entries per directory\n"

#remove  intermediate files
rm -f /tmp/filelist.pol
exit 0
