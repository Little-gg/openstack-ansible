#!/usr/bin/env bash
# IBM_PROLOG_BEGIN_TAG 
# This is an automatically generated prolog. 
#  
#  
#  
# Licensed Materials - Property of IBM 
#  
# (C) COPYRIGHT International Business Machines Corp. 2014 
# All Rights Reserved 
#  
# US Government Users Restricted Rights - Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
#  
# IBM_PROLOG_END_TAG 
#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2014
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# Specify callback scripts to be maintained by the script here. The scripts need
# to be present and executable under /var/mmfs/etc on each node.
callbacks="
  gpfs-callback_start_connector_daemon.sh
  gpfs-callback_stop_connector_daemon.sh
"

# global definitions
MMPATH="/usr/lpp/mmfs/bin"
CBPATH="/var/mmfs/etc"
TMPFILE="/tmp/$(basename $0 .sh)"
returncode=0

# common functions
function info {
  echo -e "$(basename $0 .sh): $1"
}

function error {
  echo -e "$(basename $0 .sh): $1" >&2
  returncode=1 
}

function check_success {
  if [ $? != 0 ]; then
    error "$1"
    exit 1
  fi
}

# root check
if [ "$(whoami)" != "root" ]; then
  error "user must be root to modify callbacks"
  exit 1
fi

# create tmp file
echo > $TMPFILE
check_success "unable to create tmp file $TMPFILE"

# select mode
if [ "$1" == "--list" ]; then
  $MMPATH/mmlscallback
  exit 0
elif [ "$1" == "--add" ]; then
  mode="add"
elif [ "$1" == "--delete" ]; then
  mode="delete"
else
  error "unsupported mode
Usage: ./$(basename $0) [ --list | --add | --delete ]
    --list   - list all registered callbacks
    --add    - add all callbacks specified in the script to the cluster
    --delete - delete all callback specified in the script from the cluster"
  exit 1
fi


# prepare definitions
ids=""
for callback in $callbacks; do
  # check if callback exist and is executable
  if [ ! -x $CBPATH/$callback ]; then
    error "$CBPATH/$callback doesn't exists or is not executable"
    continue
  fi
  
  # get definition from callback
  def=$($CBPATH/$callback -d 2>&1)
  # Example of what a definition will look like:
  # def:reassign-primary-server:nodeLeave::%myNode %upNodes %eventNode
  IFS=":"
  set $def
  flag="$1"; id="$2"; event="$3"; nodes="$4"; parms="$5"
  unset IFS
  
  # check flag
  if [ "$flag" != "def" ]; then
    error "$callback has no definition: \"$def\""
    continue
  fi
  
  # prepare parameters
  if [ -z "$nodes" ]; then
    nodes_param=()
  else
    nodes_param=("-N" "$nodes")
  fi
  if [ -z "$parms" ]; then
    parms_param=()
  else
    parms_param=("--parms" "\"$parms\"") 
  fi
    
  # add callback
  cmd=("$id" "--command" "$CBPATH/$callback" "--event" "$event" "${nodes_param[@]}" "${parms_param[@]}")
  echo "${cmd[@]}" >> $TMPFILE
  
  # delete callback
  ids="$ids,$id"
done

# execute command
if [ $mode == "add" ]; then
  # add callbacks
  cause=$($MMPATH/mmaddcallback -S $TMPFILE 2>&1 >/dev/null)
else
  # remove leading comma from id list
  ids=$(echo $ids | sed 's/^,//')
  # delete callbacks
  cause=$($MMPATH/mmdelcallback $ids 2>&1 >/dev/null)
fi
check_success "unable to $mode all callbacks\n$cause"

# delete tmp file
rm -f $TMPFILE

# echo success message
info "${mode} callbacks completed successfully"
