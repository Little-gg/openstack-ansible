#!/bin/bash
# IBM_PROLOG_BEGIN_TAG 
# This is an automatically generated prolog. 
#  
#  
#  
# Licensed Materials - Property of IBM 
#  
# (C) COPYRIGHT International Business Machines Corp. 2015 
# All Rights Reserved 
#  
# US Government Users Restricted Rights - Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
#  
# IBM_PROLOG_END_TAG 
#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2015
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

PROG=$(basename $0)

MMDIR=/usr/lpp/mmfs
FPODIR=${MMDIR}/fpo
CALLBACK_DIR=/var/mmfs/etc/

ARCH=
DISTRIBUTION=
VERSION=
CONNECTOR_VERSION=

CONNECTOR_DIR=
JAR_FILE=
JAR_DIR=
NATIVE_LIB_DIR=

OOZIE_SERVER_DIR=
OOZIE_JAR_DIR=

SLIDER_JAR_DIR=

# common functions
function info {
  echo -e "$1"
}

function error {
  echo -e "$1" >&2
  exit 1
}

function check_success {
  if [[ $? != 0 ]]
  then
    error "$1 failed."
  else
    info "$1 succeeded."
  fi
}

# Run a command and check if it succeeded for failed.
function run_cmd {
  cmd=$1
  $cmd >/dev/null 2>/dev/null
  check_success "$cmd"
}

# Usage: install_file $opt $src $dest
# Install src to dest if src exists.
function install_file {
  opt="-D$1"
  src=$2
  dest=$3

  [[ ! -f $src ]] && error "$src does not exist."
  cmd="install $opt $src $dest"
  run_cmd "$cmd"
}

# Usage: link_file $target $name
# Link name to target
function link_file {
  target=$1
  name=$2

  [[ ! -f $target ]] && error "$target does not exist."
  cmd="ln -f -s $target $name"
  run_cmd "$cmd"
}

function usage {
  info "Usage: $PROG -d [distribution] -v [version] install
       $PROG -d [distribution] -v [version] uninstall
       $PROG -h
  -d [distribution]  Specify Hadoop distribution this command is used for.
                     Supported distributions are:
                       - Hortonworks
                       - BigInsights
  -v [version]       Specify distribution version this command is used for.
                     Supported versions are:
                       - Hortownworks:
                           - 2.2
                       - BigInsights:
                           - 4.0
  -h                 Print Help (this message) and exit"
  exit 1
}

function check_arguments {
  # Must specify distribution and version
  [[ -z $DISTRIBUTION || -z $VERSION ]] && usage

  # Only support install uninstall action for now
  [[ $ACTION != "install" && $ACTION != "uninstall" ]] && usage
}

function parse_arguments {
  while getopts 'd:v:h' OPT; do
    case $OPT in
      d)
      DISTRIBUTION=$(tr "[:upper:]" "[:lower:]" <<< "$OPTARG")
      ;;
      v)
      VERSION="$OPTARG"
      ;;
      h)
      usage
    esac
  done
  shift $(($OPTIND - 1))
  ACTION=$(tr "[:upper:]" "[:lower:]" <<< $1)

  check_arguments
}

function dump_env {
  echo "DISTRIBUTION=$DISTRIBUTION"
  echo "VERSION=$VERSION"
  echo "ARCH=$ARCH"
  echo "CONNECTOR_VERSION=$CONNECTOR_VERSION"
  echo "CONNECTOR_DIR=$CONNECTOR_DIR"
  echo "JAR_FILE=$JAR_FILE"
  echo "JAR_DIR=$JAR_DIR"
  echo "NATIVE_LIB_DIR=$NATIVE_LIB_DIR"
  echo "OOZIE_SERVER_DIR=$OOZIE_SERVER_DIR"
  echo "OOZIE_JAR_DIR=$OOZIE_JAR_DIR"
  echo "SLIDER_JAR_DIR=$SLIDER_JAR_DIR"
}

function init_for_hortonworks {
  case $VERSION in
    2.2)
    CONNECTOR_VERSION=2.4
    CONNECTOR_DIR=$FPODIR/hadoop-${CONNECTOR_VERSION}

    JAR_FILE=hadoop-gpfs-${CONNECTOR_VERSION}.jar
    JAR_DIR=/usr/hdp/current/hadoop-client/lib
    NATIVE_LIB_DIR=/usr/lib64

    OOZIE_SERVER_DIR=/usr/hdp/current/oozie-server
    OOZIE_JAR_DIR=$OOZIE_SERVER_DIR/oozie-server/webapps/oozie/WEB-INF/lib/

    SLIDER_JAR_DIR=/usr/hdp/current/slider-client/lib/
    ;;
    *)
    error "Hortonworks $VERSION is not supported."
    ;;
  esac
}

function init_for_cloudera {
  error "Cloudera $VERSION is not supported yet"
}

function init_for_biginsights {
  case $VERSION in
    4.0)
    CONNECTOR_VERSION=2.4
    CONNECTOR_DIR=$FPODIR/hadoop-${CONNECTOR_VERSION}

    JAR_FILE=hadoop-gpfs-${CONNECTOR_VERSION}.jar
    JAR_DIR=/usr/iop/current/hadoop-client/lib
    NATIVE_LIB_DIR=/usr/lib64

    OOZIE_SERVER_DIR=/usr/iop/current/oozie-server
    OOZIE_JAR_DIR=$OOZIE_SERVER_DIR/oozie-server/webapps/oozie/WEB-INF/lib/


    SLIDER_JAR_DIR=/usr/iop/current/slider-client/lib/
    ;;
    *)
    error "BigInsights $VERSION is not supported."
    ;;
  esac
}

function init_arch {
  case $(arch) in
    x86_64)
    ARCH=Linux-amd64-64
    ;;
    ppc64)
    ARCH=Linux-ppc64-64
    ;;
    *)
    error "$(arch) is not supported."
    ;;
  esac 
}

function init {
  init_arch
  case $DISTRIBUTION in
    hortonworks)
    init_for_hortonworks
    ;;
    cloudera)
    init_for_cloudera
    ;;
    biginsights)
    init_for_biginsights
    ;;
    *)
    error "Distribution $DISTRIBUTION is not supported."
    ;;
  esac

  dump_env
}

function deploy_callbacks {
  echo -e "\nDeploy callbacks for connector"

  # Kill the running daemon and copy the new one
  if [[ -f $MMDIR/bin/mmhadoopctl ]]
  then
    run_cmd "$MMDIR/bin/mmhadoopctl connector stop"
  elif [[ -f $CONNECTOR_DIR/install_script/gpfs-callback_stop_connector_daemon.sh ]]
  then
    run_cmd "$CONNECTOR_DIR/install_script/gpfs-callback_stop_connector_daemon.sh"
  else
    pkill -KILL -f gpfs-connector-daemon
  fi
  install_file m755 $CONNECTOR_DIR/gpfs-connector-daemon $CALLBACK_DIR/

  # Callback scripts
  for f in gpfs-callback_start_connector_daemon.sh gpfs-callback_stop_connector_daemon.sh
  do
    install_file m755 $CONNECTOR_DIR/install_script/$f $CALLBACK_DIR/
  done

  # Register callbacks
  cb1=$($CONNECTOR_DIR/install_script/gpfs-callbacks.sh --list | \
          grep 'start-connector-daemon' 2>/dev/null)
  cb2=$($CONNECTOR_DIR/install_script/gpfs-callbacks.sh --list | \
          grep 'stop-connector-daemon' 2>/dev/null)
  if [[ $cb1 == "start-connector-daemon" && $cb2 == "stop-connector-daemon" ]]
  then
    info "Callbacks were already registered."
  elif [[ $cb1 == "start-connector-daemon" || $cb2 == "stop-connector-daemon" ]]
  then
    info "Callbacks were partially registered."
    run_cmd "$CONNECTOR_DIR/install_script/gpfs-callbacks.sh --delete"
    run_cmd "$CONNECTOR_DIR/install_script/gpfs-callbacks.sh --add"
  else
    info "Register callbacks."
    run_cmd "$CONNECTOR_DIR/install_script/gpfs-callbacks.sh --add"
  fi

  # Start the connector daemon
  if [[ -f $MMDIR/bin/mmhadoopctl ]]
  then
    run_cmd "$MMDIR/bin/mmhadoopctl connector start"
  else
    run_cmd "$CALLBACK_DIR/gpfs-callback_start_connector_daemon.sh"
  fi
}

function deploy_oozie {
  [[ ! -d $OOZIE_SERVER_DIR ]] && return
  echo -e "\nDeploy connector for Oozie"

  link_file $CONNECTOR_DIR/$JAR_FILE $OOZIE_SERVER_DIR/libtools/$JAR_FILE

  # Backup oozie.war
  run_cmd "mv -f $OOZIE_SERVER_DIR/oozie.war $OOZIE_SERVER_DIR/oozie.war.gpfs.donotremove"

  currentdir=$PWD
  tmpdir="/tmp/$PROG-$$"
  run_cmd "mkdir $tmpdir"
  cd $tmpdir
  run_cmd "unzip $OOZIE_SERVER_DIR/oozie.war.gpfs.donotremove"
  if [[ -f ./WEB-INF/lib/$JAR_FILE ]]
  then
    echo "oozie.war already includes $JAR_FILE."
    run_cmd "cp $OOZIE_SERVER_DIR/oozie.war.gpfs.donotremove $OOZIE_SERVER_DIR/oozie.war"
  else
    run_cmd "cp $CONNECTOR_DIR/$JAR_FILE ./WEB-INF/lib/"
    run_cmd "zip -r $OOZIE_SERVER_DIR/oozie.war ."
  fi
  cd $currentdir
  run_cmd "rm -rf $tmpdir"
}

function deploy_slider {
  [[ ! -d $SLIDER_JAR_DIR ]] && return
  echo -e "\nDeploy connector for Slider"

  link_file $CONNECTOR_DIR/$JAR_FILE $SLIDER_JAR_DIR/$JAR_FILE
}

function deploy_for_hortonworks {
  case $VERSION in
    2.2)
    link_file $CONNECTOR_DIR/$JAR_FILE $JAR_DIR/$JAR_FILE
    link_file $CONNECTOR_DIR/libgpfshadoop.64.so $NATIVE_LIB_DIR/libgpfshadoop.so

    deploy_oozie
    deploy_slider
    ;;
    *)
    error "Hortonworks $VERSION is not supported."
    ;;
  esac

  deploy_callbacks
}

function deploy_for_cloudera {
  error "Cloudera $VERSION is not supported yet"
}

function deploy_for_biginsights {
  case $VERSION in
    4.0)
    link_file $CONNECTOR_DIR/$JAR_FILE $JAR_DIR/$JAR_FILE
    link_file $CONNECTOR_DIR/libgpfshadoop.64.so $NATIVE_LIB_DIR/libgpfshadoop.so

    deploy_oozie
    deploy_slider
    ;;
    *)
    error "BigInsights $VERSION is not supported."
    ;;
  esac

  deploy_callbacks
}

# Copy binaries to proper places and register callbacks
function deploy_connector {
  echo -e "\nDeploy connector"
  case $DISTRIBUTION in
    hortonworks)
    deploy_for_hortonworks 
    ;;
    cloudera)
    deploy_for_cloudera
    ;;
    biginsights)
    deploy_for_biginsights
    ;;
    *)
    error "Distribution $DISTRIBUTION is not supported."
    ;;
  esac
}

function remove_connector {
  echo -e "\nRemove connector"

  # Stop the daemon
  if [[ -f $MMDIR/bin/mmhadoopctl ]]
  then
    run_cmd "$MMDIR/bin/mmhadoopctl connector stop"
  elif [[ -f $CALLBACK_DIR/gpfs-callback_stop_connector_daemon.sh ]]
  then
    run_cmd "$CALLBACK_DIR/gpfs-callback_stop_connector_daemon.sh"
  else
    pkill -KILL -f gpfs-connector-daemon
  fi

  [[ -f $JAR_DIR/$JAR_FILE ]] && \
    run_cmd "rm -f $JAR_DIR/$JAR_FILE"
  [[ -f $NATIVE_LIB_DIR/libgpfshadoop.so ]] && \
    run_cmd "rm -f $NATIVE_LIB_DIR/libgpfshadoop.so"
  # Oozie
  [[ -f $OOZIE_SERVER_DIR/libtools/$JAR_FILE ]] && \
    run_cmd "rm -f $OOZIE_SERVER_DIR/libtools/$JAR_FILE"
  [[ -f $OOZIE_SERVER_DIR/oozie.war.gpfs.donotremove ]] && \
    run_cmd "mv -f $OOZIE_SERVER_DIR/oozie.war.gpfs.donotremove $OOZIE_SERVER_DIR/oozie.war"
  # Slider
  [[ -f $SLIDER_JAR_DIR/$JAR_FILE ]] && \
    run_cmd "rm -f $SLIDER_JAR_DIR/$JAR_FILE"
  # Callbacks
  $CONNECTOR_DIR/install_script/gpfs-callbacks.sh --list | \
      grep -e "start-connector-daemon" \
           -e "stop-connector-daemon"  \
           -e "connector-daemon-gpfs" >/dev/null 2>/dev/null && \
    run_cmd "$CONNECTOR_DIR/install_script/gpfs-callbacks.sh --delete"
  [[ -f $CALLBACK_DIR/gpfs-callback_start_connector_daemon.sh ]] && \
    run_cmd "rm -f $CALLBACK_DIR/gpfs-callback_start_connector_daemon.sh"
  [[ -f $CALLBACK_DIR/gpfs-callback_stop_connector_daemon.sh ]] && \
    run_cmd "rm -f $CALLBACK_DIR/gpfs-callback_stop_connector_daemon.sh"
  [[ -f $CALLBACK_DIR/gpfs-connector-daemon ]] && \
    run_cmd "rm -f $CALLBACK_DIR/gpfs-connector-daemon"
}

parse_arguments $@
init
case $ACTION in
  install)
  deploy_connector
  ;;
  uninstall)
  remove_connector
  ;;
esac

exit 0
